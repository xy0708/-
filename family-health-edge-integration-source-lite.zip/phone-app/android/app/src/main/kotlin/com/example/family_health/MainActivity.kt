package com.example.family_health

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
