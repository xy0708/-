#!/bin/bash
set -e

# 家庭健康管理 APP 构建脚本
# 支持 x86_64 和 ARM64 (aarch64) Linux 主机

ARCH=$(uname -m)
echo "=== 主机架构: $ARCH ==="

# ARM64 特有配置
if [ "$ARCH" = "aarch64" ]; then
  echo "检测到 ARM64 架构，应用兼容性配置..."

  # Android SDK 37.0.0+ 提供 ARM64 原生 aapt2
  SDK_BUILD_TOOLS="/opt/android-sdk/build-tools/37.0.0"
  if [ -f "$SDK_BUILD_TOOLS/aapt2" ]; then
    export AAPT2_FROM_MAVEN_OVERRIDE="$SDK_BUILD_TOOLS/aapt2"
    echo "使用 ARM64 原生 aapt2: $AAPT2_FROM_MAVEN_OVERRIDE"
  fi

  # 使用系统 ARM64 原生 cmake 替代 SDK 内置的 x86_64 版本
  SYSTEM_CMAKE=$(which cmake 2>/dev/null || echo "")
  if [ -n "$SYSTEM_CMAKE" ]; then
    export ANDROID_CMAKE_HOME=$(dirname $(dirname "$SYSTEM_CMAKE"))
    echo "使用系统 cmake: $SYSTEM_CMAKE"
  fi
fi

echo ""
echo "=== 1. 清理旧构建 ==="
flutter clean

echo ""
echo "=== 2. 获取依赖 ==="
flutter pub get

echo ""
echo "=== 3. 静态分析 ==="
flutter analyze

echo ""
echo "=== 4. 构建 Debug APK ==="
if [ "$ARCH" = "aarch64" ] && [ -n "$AAPT2_FROM_MAVEN_OVERRIDE" ]; then
  flutter build apk --debug \
    --target-platform android-arm64 \
    --android-aapt2-path "$AAPT2_FROM_MAVEN_OVERRIDE" 2>&1
else
  flutter build apk --debug --target-platform android-arm64 2>&1
fi

echo ""
echo "=== 构建完成 ==="
echo "APK 位置: build/app/outputs/flutter-apk/app-arm64-v8a-debug.apk"
