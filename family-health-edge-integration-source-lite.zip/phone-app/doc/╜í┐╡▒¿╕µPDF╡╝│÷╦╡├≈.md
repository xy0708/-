# 健康报告 PDF 导出说明

> 面向后续维护者，说明报告包含什么、数据从哪来、怎么改，以及踩过的坑。

## 一、报告结构

导出物为 A4 多页 PDF（典型 4 页），页眉固定显示报告归属与类型，页脚显示页码与免责提示。

| 页 | 章节 | 内容 |
|---|---|---|
| 1 | 标题带 | 报告名、成员、数据周期、综合评级标签 |
| 1 | 一、报告基本信息 | 姓名/关系/性别/年龄/报告编号/生成时间/数据周期/数据天数/既往病史/数据来源 |
| 1 | 综合评分卡 | 大号总分 + 当日健康状态 + 当日四项体征小卡 |
| 1 | 二、评估摘要 | 评估引擎产出的结论文案 |
| 1 | 三、四维评分明细 | 维度 / 周均值 / 得分（进度条）/ 等级 / 达标率 |
| 2 | 四、健康预警 | 该成员的异常预警卡片（等级色条 + 标题 + 内容 + 时间） |
| 2 | 五、趋势分析 | 步数、脉搏、睡眠、活动度四张矢量趋势图（2×2），各带达标率与参考范围 |
| 2–3 | 六、每日数据明细 | 逐日四项数值 + 当日达标项数 |
| 3 | 七、统计汇总 | 各指标周均值/最低/最高/达标天数/达标率/参考范围/趋势方向 |
| 3–4 | 八、改善建议 | 评估引擎给出的建议，带序号 |
| 4 | 九、健康提醒计划 | 已启用的提醒（时间/类型/内容/状态） |
| 4 | 十、既往病史 | 病史名称/确诊时间/备注 |
| 4 | 十一、家庭成员概览 | 全部成员档案，当前报告对象标注「（本报告对象）」 |
| 4 | 说明 | 免责声明与生成时间 |

## 二、代码结构

| 文件 | 职责 |
|---|---|
| `lib/core/pdf/report_pdf_exporter.dart` | 唯一的编排入口：字体加载、`MultiPage` 组装、各章节构建、保存文件名 |
| `lib/core/pdf/report_pdf_styles.dart` | 配色、文本样式、可复用小组件（章节标题、卡片、进度条、信息表、数据表行） |
| `lib/core/pdf/report_pdf_charts.dart` | 趋势图（pdf 内置 Chart 家族，矢量绘制，自动推导 y 轴刻度） |
| `lib/core/pdf/report_export_flow.dart` | 从各 Provider 收集数据 → 导出 → 打开/提示；两个入口页共用 |
| `lib/core/assessment/health_stats.dart` | 纯函数统计：均值/极值/达标天数/达标率/趋势方向 |
| `lib/core/pdf/pdf_saver*.dart` | 平台分支保存（原生写文档目录 / Web 触发下载） |

`ReportPdfExporter.buildDocument()` 是 `@visibleForTesting` 的公开方法，返回 `pw.Document` 而不落盘，测试可直接渲染整份报告，不触碰 `path_provider` 平台通道。`export()` 只是在它之上加保存。

## 三、数据来源

`HealthReport` 是报告的唯一数据载体，由 `HealthProvider.generateReport()` 在生成时一次性填好：

- `dimensions`（四维评分明细）、`records`（统计区间原始记录）、`vitalSummary`（当日体征）、`periodStart/periodEnd`
- **注意**：这些字段是 W14 新增的。在此之前报告只存了总分和一段摘要，导出 PDF 时明细全部丢失。**改动 `generateReport` 时不要漏填**，否则报告会退化成「总分 + 一段文字」。

跨模块数据不在 `HealthReport` 里，由页面层从各 Provider 读取后作为参数传给导出器（导出器本身不依赖 Provider）：

- `member` / `familyMembers` ← `FamilyProvider`
- `alerts` ← `AlertProvider`（为空时 `report_export_flow` 会用 `AssessmentEngine.deriveAlerts` 从报告自身数据再派生一次，避免因未触发过预警拉取而漏报）
- `reminders` ← `ReminderProvider`（全局，不区分成员，报告中已标注「家庭通用」）
- `medicalHistory` ← `MedicalHistoryProvider`（同样为全局数据）

提醒与病史是按页面加载的，`report_export_flow` 在导出前会补一次加载，保证报告内容与本地存储一致。

## 四、达标口径

各指标的「达标线」统一取该维度评分中的**「良」阈值**，避免出现「天天达标却只得一般」的观感矛盾：

| 指标 | 达标线 | 参考常量 |
|---|---|---|
| 步数 | ≥6000 步 | `AssessmentEngine.stepsGood` |
| 睡眠 | ≥7.0 小时 | `AssessmentEngine.sleepGoodHigh` |
| 脉搏 | 60–100 次/分 | `AssessmentEngine.hrNormalLow/High` |
| 活动度 | ≥60% | `AssessmentEngine.activityGood` |

阈值常量已从 `AssessmentEngine` 的私有字段改为公开（`stepsGood`、`sleepGoodLow` 等），统计模块、图表参考范围、报告文案共用同一份口径，改阈值只需改一处。

趋势方向：后半段均值 vs 前半段均值，相对变化超过 5%（`HealthStats.trendThreshold`）才判定上升/下降。

## 五、已知限制与踩坑记录

### 1. 字体没有真正的粗体

项目只打包了 `NotoSansSC-Regular.ttf`，同时充当 `base` 和 `bold`。pdf 包**不做合成加粗**，所以 `fontWeight: bold` 渲染出来与正文同粗。报告的层级完全靠**字号、颜色、色块底纹、左侧色条**表达（见 `ReportPdfStyles` 中的注释）。

若要真正的粗体，需要新增一个约 17MB 的 `NotoSansSC-Bold.ttf`，安装包会明显变大——当时评估后放弃了。

另外：`ThemeData.withFont` 若不传 `bold`，加粗文字会回退到 Helvetica，**中文会直接抛 Latin-1 编码异常**。所以 `buildDocument` 里显式设置了 `bold/italic/boldItalic/fontFallback` 全部指向同一个 TTF，不要删。

### 2. pdf 包的两个布局陷阱（都踩过，都会导致 `PdfTooBigPageException`）

- **四边不等宽的 `Border` + `borderRadius` 组合**：pdf 3.13.0 会算错布局高度，导致 `MultiPage` 无限翻页直到超过 `maxPages` 抛异常。左侧色条（如预警卡片）改用 `Row` 里放一个固定宽度的 `Container` 绘制，卡片本身只保留 `Border.all`。
- **`CrossAxisAlignment.stretch` 用在 `Row` 上**：在无界高度约束下会撑出无限高度，同样导致无限翻页。当日体征卡片行改用 `start`。

新增区块后如果测试报页数异常，优先排查这两类写法。

### 3. 其他

- 数据类型不足 2 天时不画趋势图（`FixedAxis.toChart` 会除以 0），改为显示占位提示。
- 提醒与病史数据全局不区分成员，报告中已明确标注，不要当作成员个人数据解读。
- 报告始终为浅色文档样式，不受 APP 深色模式/助老模式影响。

## 六、本地预览

`test/pdf_report_test.dart` 会真实渲染报告（不落盘）。要看实际效果，临时写一个测试调用 `buildDocument` 并 `File(...).writeAsBytesSync(await doc.save())`，再用任意 PDF 阅读器打开即可。

参考页数与体积：7 天数据、2 条预警、3 条提醒、2 条病史、3 名成员时约 **4 页 / 65KB**。

## 七、测试覆盖

| 文件 | 覆盖内容 |
|---|---|
| `test/pdf_report_test.dart` | 完整数据能渲染成多页（页数下界与上界）、空数据不抛异常、单条记录跳过趋势图、超长摘要与大量建议、中文与符号、预警按成员过滤 |
| `test/health_stats_test.dart` | 均值/极值、达标天数与边界值、达标率、趋势三态与阈值边界、单条记录、前半段均值为零 |
| `test/model_test.dart` | `HealthReport` 新旧字段往返（含缺省字段兼容） |
| `test/health_provider_test.dart` | `generateReport` 确实填入了明细与原始记录、四维得分等于均值 |
| `test/pdf_font_test.dart` | 中文字体可绘制回归（保留） |
