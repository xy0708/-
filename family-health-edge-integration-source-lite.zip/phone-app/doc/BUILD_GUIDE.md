# 构建指南

## 环境要求

- **Flutter SDK**: 3.44.8（已在 `/opt/flutter` 安装）
- **Android SDK**: 已配置 `ANDROID_HOME=/opt/android-sdk`
- **Java**: OpenJDK 17+
- **内存**: 建议 8GB+（ARM64 构建最低 4GB + 2GB Swap）

## 快速构建

```bash
# 方式一：使用构建脚本（自动检测架构）
./build.sh

# 方式二：手动构建
flutter pub get
flutter build apk --debug
```

输出 APK：`build/app/outputs/flutter-apk/app-debug.apk`

## 架构说明

### x86_64 主机（推荐）
标准构建流程，直接运行 `flutter build apk --debug`。

### ARM64 主机（aarch64）
Android SDK 从 **build-tools 37.0.0** 起提供 ARM64 原生二进制。需注意：

| 组件 | 问题 | 解决方案 |
|---|---|---|
| **aapt2** | Android Gradle Plugin 自带的 aapt2 为 x86_64 | 使用 SDK 37.0.0 的 ARM64 版本，通过 `android.aapt2FromMavenOverride` 或 `--android-aapt2-path` 指定 |
| **cmake** | SDK 内置 cmake 为 x86_64 | 使用系统 ARM64 cmake（需预先安装），设置 `ANDROID_CMAKE_HOME=/usr` |
| **内存** | Gradle 构建消耗大 | `gradle.properties` 中调节 `org.gradle.jvmargs=-Xmx2G`，建议创建 Swap |

## CI/CD（GitHub Actions）

推送代码到 GitHub 后自动构建，配置已就绪：

```yaml
# .github/workflows/build-apk.yml
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.44.8'
      - run: flutter build apk --debug
      - uses: actions/upload-artifact@v4
        with:
          name: family-health-apk
          path: build/app/outputs/flutter-apk/*.apk
```

## Release APK 签名

```bash
# 1. 生成密钥库
keytool -genkey -v -keystore release-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias release

# 2. 在 android/app/build.gradle.kts 中配置签名
# signingConfigs { create("release") { ... } }

# 3. 构建
flutter build apk --release
```
