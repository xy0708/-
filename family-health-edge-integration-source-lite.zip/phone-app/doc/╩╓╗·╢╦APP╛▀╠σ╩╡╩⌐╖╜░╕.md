# 家庭健康管理 AI 终端 APP — 手机端具体实施方案

> 本方案依据《家庭健康管理AI终端APP设计方案.doc》制定，覆盖手机端（竖屏）APP 的架构、页面、数据流、接口对接及后续开发路线。

---

## 一、技术选型

| 层面 | 选择 | 说明 |
|---|---|---|
| 框架 | **Flutter 3.44.8** | 跨平台，一套代码同时输出 Android/iOS |
| 语言 | **Dart 3.12** | 空安全，类型安全 |
| 状态管理 | **Provider** | Flutter 官方推荐，轻量可扩展 |
| 路由 | **命名路由 + onGenerateRoute** | 简单可控，支持参数传递 |
| HTTP 通信 | **http** 包 | RESTful API 调用 |
| 图表 | **fl_chart** | 折线图、柱状图展示健康趋势 |
| 本地存储 | **shared_preferences** | Token、用户偏好持久化 |
| 图片选择 | **image_picker** | OCR 拍照 / 相册上传 |
| 权限处理 | **permission_handler** | 相机、位置等运行时权限 |
| 外部导航 | **url_launcher** | 唤起地图APP导航 / 拨打电话 |

---

## 二、项目目录结构

```
lib/
├── main.dart                          # 入口：MultiProvider 注入
├── app.dart                           # MaterialApp + 路由配置
├── core/
│   ├── constants/app_constants.dart    # 常量（API 地址、类型名）
│   ├── theme/app_theme.dart           # Material3 绿色主题
│   ├── network/
│   │   ├── api_client.dart            # HTTP 封装（GET/POST/PUT/DELETE/uploadFile）
│   │   └── api_endpoints.dart         # 所有 API 路径定义
│   └── routes/app_router.dart         # 命名路由映射表
├── models/
│   ├── user.dart                      # 用户模型
│   ├── family_member.dart             # 家庭成员模型
│   ├── health_record.dart             # 健康记录 + 总览模型
│   ├── device.dart                    # 设备模型（手环/血压计/体脂秤/AI终端）
│   └── health_report.dart             # 健康报告模型
├── providers/
│   ├── auth_provider.dart             # 登录态 + Token 管理
│   ├── health_provider.dart           # 健康数据 + 报告生成
│   ├── family_provider.dart           # 家庭成员 CRUD
│   └── device_provider.dart           # 设备扫描与连接
├── pages/
│   ├── splash/splash_page.dart        # 启动页（检查登录态）
│   ├── login/login_page.dart          # 手机绑定页
│   ├── home/home_page.dart            # 主页：4 个 Tab 底部导航
│   ├── dashboard/dashboard_page.dart  # ① 数据看板
│   ├── assessment/assessment_page.dart# ② 数据评估（生成报告 + OCR）
│   ├── map/map_page.dart              # ③ 就医导航（附近医院 + 紧急求助）
│   ├── profile/profile_page.dart      # ④ 个人信息（设备/成员/设置）
│   └── family/
│       ├── family_list_page.dart       # 家庭成员列表
│       └── family_edit_page.dart       # 添加 / 编辑成员
└── widgets/
    ├── health_card.dart               # 生命体征指标卡片
    └── member_avatar.dart             # 家庭成员头像组件
```

---

## 三、页面详细说明

### 3.1 启动页（SplashPage）
- 展示 App Logo + 名称
- 初始化 `AuthProvider`，检查本地 Token
- 有 Token → 跳转 `/home`，无 Token → 跳转 `/login`

### 3.2 手机绑定页（LoginPage）
- 输入手机号 + 姓名
- 调用 `POST /api/devices/bind` 获取 Token
- Token 写入 `shared_preferences`，保持登录态

### 3.3 主页（HomePage）
- 底部 4 个 Tab：数据看板 / 数据评估 / 地图 / 我的
- 使用 `IndexedStack` 保持页面状态不丢失

### 3.4 数据看板（DashboardPage）
- **成员选择器**：横向滚动的 ChoiceChip，切换不同成员
- **四维体征卡片**：今日步数 | 睡眠时长 | 脉搏 | 活动度
- **心率趋势折线图**：fl_chart LineChart，展示最近 7 天脉搏变化
- **活动度柱状图**：fl_chart BarChart，展示每日活动百分比
- **最新报告卡片**：快速入口查看最近 AI 评估报告并导出 PDF

**对应设计方案**：深层展示多体征生命检测指标趋势，汇总周度AI健康评估报告，支持PDF生成。

### 3.5 数据评估（AssessmentPage）
- **一键生成周度报告**：点击后调用 `GET /api/ai/report/latest`，展示评分 + 摘要 + 改善建议
- **OCR 医疗影像识别**：两个入口（拍照 / 相册），调用 `POST /api/ai/ocr/upload`
- **报告结果展示**：得分、总结文本、逐条改善建议

**对应设计方案**：提供一键生成周度评估报告功能，集成 OCR 医疗影像识别系统，支持纸质化验单照片上传识别。

### 3.6 地图（MapPage）
- **当前位置卡片**：显示定位地址
- **快速操作区**：附近医院 / 绿色通道 / 紧急求助
- **附近医疗机构列表**：医院名称、距离、等级、候诊时间、导航按钮
- **紧急求助按钮**：弹出对话框，可拨打 120 或通知紧急联系人

**对应设计方案**：集成 GPS 定位与基站定位，提供就医导航、绿色通道查询及紧急求助指引。

### 3.7 个人信息（ProfilePage）
- **用户信息卡**：头像、姓名、手机号
- **设备管理区**：蓝牙设备列表（手环/血压计/体脂秤/AI终端），开关连接，扫描新设备
- **家庭成员区**：成员列表快照，点击「管理」进入完整列表页
- **设置区**：个人病史档案 | 紧急联系人 | 助老系统参数（播报语速、蓝牙配置）
- **退出登录**

**对应设计方案**：维护个人病史档案、管理紧急联系人，并进行助老系统参数设置。

### 3.8 家庭成员管理
- **列表页**：所有成员卡片，显示关系、年龄、病史标签
- **编辑页**：添加新成员（姓名、关系、性别、年龄）

**对应设计方案**：家庭成员数据库输入页，支持语音+文字输入。

---

## 四、数据流架构

```
┌──────────────┐     Provider（状态层）     ┌──────────────┐
│   UI 页面     │◄──── notifyListeners() ────│  Provider     │
│  (Widget)     │──── 调用方法 ────────────►│  (ChangeNotifier)│
└──────────────┘                            └──────┬───────┘
                                                    │
                                           fetch / post
                                                    │
                                              ┌─────▼──────┐
                                              │  ApiClient  │
                                              │ (HTTP 封装)  │
                                              └─────┬──────┘
                                                    │
                                          HTTP / mDNS
                                                    │
                                              ┌─────▼──────┐
                                              │  AI 终端盒子 │
                                              │ (局域网/云端) │
                                              └────────────┘
```

- 页面通过 `context.watch<Provider>()` 监听状态变化
- 用户操作 → Provider方法 → ApiClient → 后端接口 → 更新状态 → UI 自动刷新
- 所有数据首次通过 Provider 的 `fetch*` 方法从 Mock 数据加载，后续替换为真实 API

---

## 五、API 对接清单

| 设计方案接口 | API 路径 | Provider 方法 | 状态 |
|---|---|---|---|
| 扫描局域网 AI 终端 | `GET /api/devices/scan` | `DeviceProvider.scanDevices()` | ✅ Mock |
| 绑定 / 配对终端 | `POST /api/devices/bind` | `AuthProvider.login()` | ✅ Mock |
| 获取设备状态 | `GET /api/devices/status` | (设备列表自带) | ✅ Mock |
| 健康总览 | `GET /api/health/summary` | `HealthProvider.fetchSummary()` | ✅ Mock |
| 上传生理指标 | `POST /api/health/upload` | — | 待对接 |
| 历史趋势数据 | `GET /api/health/trend` | `HealthProvider.fetchRecords()` | ✅ Mock |
| 最新 AI 评估报告 | `GET /api/ai/report/latest` | `HealthProvider.generateReport()` | ✅ Mock |
| OCR 解析 | `POST /api/ai/ocr/upload` | `ApiClient.uploadFile()` | 待对接 |
| 预警信息 | `GET /api/alerts/active` | — | 待对接 |

---

## 六、关键实现细节

### 6.1 状态管理使用方式

```dart
// 1. 入口注入（main.dart）
MultiProvider(
  providers: [
    ChangeNotifierProvider(create: (_) => AuthProvider()),
    ChangeNotifierProvider(create: (_) => HealthProvider()),
    ChangeNotifierProvider(create: (_) => FamilyProvider()),
    ChangeNotifierProvider(create: (_) => DeviceProvider()),
  ],
  child: FamilyHealthApp(),
)

// 2. 页面监听（读取状态 + 自动刷新）
final health = context.watch<HealthProvider>();

// 3. 页面调用方法（写操作）
context.read<HealthProvider>().fetchSummary();
```

### 6.2 API 客户端使用

```dart
final api = ApiClient();
api.setToken('bearer_token');
final data = await api.get('/api/health/summary');
await api.post('/api/devices/bind', body: {'phone': '138xxx'});
await api.uploadFile('/api/ai/ocr/upload', File('lab_report.jpg'));
```

### 6.3 蓝牙设备管理

设备列表通过 `DeviceProvider` 管理，每个设备有 `isConnected` 和 `batteryLevel` 属性。扫描局域网设备使用 mDNS 协议，设计方案中建议：

```
APP <-> AI终端：HTTP/REST API + mDNS 服务发现
```

### 6.4 安全与隐私

- 所有敏感数据接口使用 HTTPS 加密传输
- Token 存储在 `shared_preferences`，不明文存储密码
- 定位权限仅在进入地图页时申请

---

## 七、后续开发路线

| 阶段 | 任务 | 优先级 |
|---|---|---|
| **Phase 1** | 替换所有 Mock 数据为真实 API 调用 | P0 |
| **Phase 1** | 接入 mDNS 实现局域网 AI 终端发现 | P0 |
| **Phase 2** | 集成 OCR SDK（百度/腾讯云），完成化验单识别 | P1 |
| **Phase 2** | 实现 WebSocket 接收实时预警推送 | P1 |
| **Phase 2** | 实现 PDF 报告下载与打开 | P1 |
| **Phase 3** | 集成穿戴设备数据（手环 SDK + HealthKit） | P2 |
| **Phase 3** | 语音输入支持（百度语音 / 讯飞） | P2 |
| **Phase 3** | 助老模式：大字体、高对比度、极简交互 | P2 |

---

## 八、构建与部署

```bash
# 开发调试
flutter run

# 构建 Debug APK
flutter build apk --debug

# 构建 Release APK
flutter build apk --release

# 产物路径
build/app/outputs/flutter-apk/app-debug.apk
build/app/outputs/flutter-apk/app-release.apk
```

> **注意**：Release APK 需要配置签名密钥（keystore）。Debug APK 使用 Android SDK 自带的调试证书，可直接安装测试。
