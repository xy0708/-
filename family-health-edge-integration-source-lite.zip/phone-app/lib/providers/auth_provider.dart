import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/network/api_client.dart';
import '../core/network/api_endpoints.dart';
import '../core/config/app_config.dart';

class AuthProvider extends ChangeNotifier {
  bool _isLoggedIn = false;
  String? _token;
  String? _userName;
  String? _phone;

  bool get isLoggedIn => _isLoggedIn;
  String? get token => _token;
  String? get userName => _userName;
  String? get phone => _phone;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('token');
    _userName = prefs.getString('userName');
    _phone = prefs.getString('phone');
    if (!AppConfig.allowDemoData && _token?.startsWith('mock_token_') == true) {
      await prefs.remove('token');
      await prefs.remove('userName');
      await prefs.remove('phone');
      _token = null;
      _userName = null;
      _phone = null;
    }
    _isLoggedIn = _token != null;
    ApiClient().setToken(_token);
    notifyListeners();
  }

  /// 手机绑定登录。
  ///
  /// 优先调用后端绑定接口换取 Token；后端未配置或网络失败时
  /// 使用本地演示 Token（离线闭环）。
  Future<void> login(String phone, String name) async {
    String? token;
    if (AppConfig.useBackend) {
      try {
        final data = await ApiClient().post(
          ApiEndpoints.bindDevice,
          body: {'phone': phone, 'name': name},
          timeout: const Duration(seconds: 5),
        );
        final t = (data as Map<String, dynamic>)['token'];
        if (t is String && t.isNotEmpty) {
          token = t;
        } else {
          throw const FormatException(
              'Binding response does not contain a token.');
        }
      } on ApiException catch (e) {
        if (!AppConfig.allowDemoData) rethrow;
        debugPrint('[AuthProvider] 绑定接口不可用，使用本地演示 Token: $e');
      }
    } else {
      if (!AppConfig.allowDemoData) {
        throw StateError('Authentication service is not configured.');
      }
      await Future.delayed(const Duration(milliseconds: 400)); // 模拟请求耗时
    }

    token ??= _mockToken();

    _phone = phone;
    _userName = name;
    _token = token;
    _isLoggedIn = true;
    ApiClient().setToken(token);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
    await prefs.setString('userName', name);
    await prefs.setString('phone', phone);
    notifyListeners();
  }

  String _mockToken() => 'mock_token_${DateTime.now().millisecondsSinceEpoch}';

  Future<void> updateProfile(
      {required String name, required String phone}) async {
    _userName = name;
    _phone = phone;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('userName', name);
    await prefs.setString('phone', phone);
    notifyListeners();
  }

  Future<void> logout() async {
    _token = null;
    _userName = null;
    _phone = null;
    _isLoggedIn = false;
    ApiClient().setToken(null);
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await prefs.remove('userName');
    await prefs.remove('phone');
    notifyListeners();
  }
}
