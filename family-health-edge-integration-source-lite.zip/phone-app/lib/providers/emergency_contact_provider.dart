import 'package:flutter/foundation.dart';
import '../models/emergency_contact.dart';
import '../core/storage/local_store.dart';

class EmergencyContactProvider extends ChangeNotifier {
  static const String _storageKey = 'emergency_contacts';

  List<EmergencyContact> _contacts = [];
  bool _isLoading = false;

  List<EmergencyContact> get contacts => _contacts;
  bool get isLoading => _isLoading;

  Future<void> load() async {
    _isLoading = true;
    notifyListeners();

    try {
      final list = await LocalStore.getJsonList(_storageKey);
      _contacts = list.map(EmergencyContact.fromJson).toList();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> add(EmergencyContact contact) async {
    _contacts.add(contact);
    await LocalStore.setJsonList(
      _storageKey,
      _contacts.map((c) => c.toJson()).toList(),
    );
    notifyListeners();
  }

  Future<void> update(EmergencyContact contact) async {
    final index = _contacts.indexWhere((c) => c.id == contact.id);
    if (index < 0) return;
    _contacts[index] = contact;
    await LocalStore.setJsonList(
      _storageKey,
      _contacts.map((c) => c.toJson()).toList(),
    );
    notifyListeners();
  }

  Future<void> remove(String id) async {
    _contacts.removeWhere((c) => c.id == id);
    await LocalStore.setJsonList(
      _storageKey,
      _contacts.map((c) => c.toJson()).toList(),
    );
    notifyListeners();
  }
}
