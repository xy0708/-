import 'package:flutter/foundation.dart';
import '../models/health_alert.dart';
import '../core/assessment/assessment_engine.dart';
import '../core/mock/mock_health_data.dart';
import '../core/config/app_config.dart';
import '../core/network/api_client.dart';
import '../core/network/api_endpoints.dart';

/// 健康预警：优先调用后端预警接口，失败回退本地按体征阈值派生。
class AlertProvider extends ChangeNotifier {
  final Map<String, List<HealthAlert>> _memberAlerts = {};
  String? _activeMemberId;
  bool _isLoading = false;

  /// 当前选中成员的预警列表（按成员缓存，切换成员各自独立）。
  List<HealthAlert> get alerts => _activeMemberId == null
      ? const []
      : _memberAlerts[_activeMemberId] ?? const [];

  /// 需要用户关注的预警数（warning + danger），供看板铃铛角标展示。
  int get warningDangerCount =>
      alerts.where((a) => a.level != AlertLevel.info).length;

  bool get isLoading => _isLoading;

  Future<void> fetchAlerts({
    required String memberId,
    String memberName = '本人',
    int age = 40,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      _activeMemberId = memberId;
      _memberAlerts[memberId] = await _loadAlerts(memberId, memberName, age);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// 优先调用后端预警接口；后端未配置或网络失败时按本地体征数据派生。
  Future<List<HealthAlert>> _loadAlerts(
      String memberId, String memberName, int age) async {
    if (AppConfig.useBackend) {
      try {
        final data = await ApiClient().get(
          '${ApiEndpoints.alertsActive}?memberId=$memberId',
          timeout: const Duration(seconds: 4),
        );
        return (data as List<dynamic>)
            .map((e) => HealthAlert.fromJson(e as Map<String, dynamic>))
            .toList();
      } on ApiException catch (e) {
        if (!AppConfig.allowDemoData) rethrow;
        debugPrint('[AlertProvider] 预警接口不可用，回退本地数据: $e');
      }
    }
    if (!AppConfig.allowDemoData) {
      throw StateError('Health alert service is not configured.');
    }
    return AssessmentEngine.deriveAlerts(
      memberId: memberId,
      memberName: memberName,
      summary: MockHealthData.summaryFor(memberId, age: age),
      records: MockHealthData.recordsFor(memberId, age: age),
    );
  }
}
