import 'package:flutter/foundation.dart';
import '../core/watch/unavailable_watch_gateway.dart';
import '../core/watch/watch_gateway.dart';
import '../models/device.dart';

class DeviceProvider extends ChangeNotifier {
  DeviceProvider({WatchGateway? watchGateway})
    : _watchGateway = watchGateway ?? const UnavailableWatchGateway();

  final WatchGateway _watchGateway;
  List<HealthDevice> _devices = [];
  bool _isScanning = false;
  String? _lastError;

  List<HealthDevice> get devices => List.unmodifiable(_devices);
  bool get isScanning => _isScanning;
  String? get lastError => _lastError;

  Future<void> scanDevices() async {
    _isScanning = true;
    _lastError = null;
    notifyListeners();

    try {
      _devices = await _watchGateway.scan();
    } catch (error) {
      _devices = [];
      _lastError = '手表扫描失败：$error';
    } finally {
      _isScanning = false;
      notifyListeners();
    }
  }

  Future<void> setConnection(String deviceId, bool shouldConnect) async {
    final index = _devices.indexWhere((device) => device.id == deviceId);
    if (index < 0) {
      _lastError = '未找到要连接的手表';
      notifyListeners();
      return;
    }

    _lastError = null;
    try {
      final current = _devices[index];
      final updated = shouldConnect
          ? await _watchGateway.connect(current)
          : await _watchGateway.disconnect(current);
      _devices = [..._devices]..[index] = updated;
    } catch (error) {
      _lastError = shouldConnect ? '手表连接失败：$error' : '手表断开失败：$error';
    }
    notifyListeners();
  }

  @override
  void dispose() {
    _watchGateway.dispose();
    super.dispose();
  }
}
