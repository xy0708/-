import 'package:flutter/foundation.dart';
import '../models/health_record.dart';
import '../models/health_report.dart';
import '../core/assessment/assessment_engine.dart';
import '../core/mock/mock_health_data.dart';
import '../core/config/app_config.dart';
import '../core/network/api_client.dart';
import '../core/network/api_endpoints.dart';

class HealthProvider extends ChangeNotifier {
  HealthSummary? _summary;
  List<HealthRecord> _records = [];
  String? _dataKey; // 当前 _summary/_records 对应的数据键（成员ID@年龄）
  final Map<String, HealthReport> _memberReports = {};
  String? _activeMemberId;
  bool _isLoading = false;

  HealthSummary? get summary => _summary;
  List<HealthRecord> get records => _records;

  /// 当前选中成员最近一次生成的报告（按成员缓存，切换成员各自独立）。
  HealthReport? get latestReport =>
      _activeMemberId == null ? null : _memberReports[_activeMemberId];

  bool get isLoading => _isLoading;
  String? get activeMemberId => _activeMemberId;

  void setActiveMember(String? memberId) {
    if (_activeMemberId == memberId) return;
    final dataBelongsToMember =
        memberId != null && _dataKey?.startsWith('$memberId@') == true;
    _activeMemberId = memberId;
    if (!dataBelongsToMember) {
      _summary = null;
      _records = [];
      _dataKey = null;
    }
    notifyListeners();
  }

  Future<void> fetchSummary({String? memberId, int age = 40}) async {
    _isLoading = true;
    notifyListeners();

    try {
      final id = memberId ?? _activeMemberId ?? 'default';
      _summary = await _loadSummary(id, age);
      _dataKey = '$id@$age';
    } catch (_) {
      _summary = null;
      _dataKey = null;
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> fetchRecords({String? memberId, int age = 40}) async {
    _isLoading = true;
    notifyListeners();

    try {
      final id = memberId ?? _activeMemberId ?? 'default';
      _records = await _loadRecords(id, age);
      _dataKey = '$id@$age';
    } catch (_) {
      _records = [];
      _dataKey = null;
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// 优先调用后端健康总览接口；后端未配置或网络失败时回退本地 Mock。
  Future<HealthSummary> _loadSummary(String id, int age) async {
    if (AppConfig.useBackend) {
      try {
        final data = await ApiClient().get(
          '${ApiEndpoints.healthSummary}?memberId=$id',
          timeout: const Duration(seconds: 4),
        );
        return HealthSummary.fromJson(data as Map<String, dynamic>);
      } on ApiException catch (e) {
        if (!AppConfig.allowDemoData) rethrow;
        debugPrint('[HealthProvider] 健康总览接口不可用，回退本地数据: $e');
      }
    }
    if (!AppConfig.allowDemoData) {
      throw StateError('Health data service is not configured.');
    }
    await Future.delayed(const Duration(milliseconds: 400)); // 模拟网络延迟
    return MockHealthData.summaryFor(id, age: age);
  }

  /// 优先调用后端历史趋势接口；后端未配置或网络失败时回退本地 Mock。
  Future<List<HealthRecord>> _loadRecords(String id, int age) async {
    if (AppConfig.useBackend) {
      try {
        final data = await ApiClient().get(
          '${ApiEndpoints.healthTrend}?memberId=$id',
          timeout: const Duration(seconds: 4),
        );
        final list = (data as List<dynamic>)
            .map((e) => HealthRecord.fromJson(e as Map<String, dynamic>))
            .toList();
        if (list.isNotEmpty) return list;
      } on ApiException catch (e) {
        if (!AppConfig.allowDemoData) rethrow;
        debugPrint('[HealthProvider] 趋势接口不可用，回退本地数据: $e');
      }
    }
    if (!AppConfig.allowDemoData) {
      throw StateError('Health trend service is not configured.');
    }
    await Future.delayed(const Duration(milliseconds: 400)); // 模拟网络延迟
    return MockHealthData.recordsFor(id, age: age);
  }

  Future<void> generateReport({
    String memberName = '本人',
    String? memberId,
    int age = 40,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final id = memberId ?? _activeMemberId ?? 'default';
      final key = '$id@$age';
      // 若当前缓存数据不是该成员（或年龄画像不同），则重新拉取，避免误用其他成员的数据
      if (_dataKey != key) {
        await fetchSummary(memberId: id, age: age);
        await fetchRecords(memberId: id, age: age);
      }

      final result = AssessmentEngine.evaluate(
        summary: _summary!,
        records: _records,
      );

      await Future.delayed(const Duration(milliseconds: 400));
      final report = HealthReport(
        id: 'rpt_${DateTime.now().millisecondsSinceEpoch}',
        memberName: memberName,
        generatedAt: DateTime.now(),
        type: '周度评估',
        summary: result.summary,
        overallScore: result.overallScore,
        suggestions: result.suggestions,
        memberId: id,
        // 报告要完整留存评分明细与原始记录，否则导出 PDF 时只剩总分和一段文字
        dimensions: result.dimensions
            .map((d) => ReportDimension(
                  name: d.name,
                  score: d.score,
                  level: d.level,
                  suggestion: d.suggestion,
                ))
            .toList(),
        records: List.unmodifiable(_records),
        vitalSummary: _summary,
        periodStart: _records.isEmpty ? null : _records.first.date,
        periodEnd: _records.isEmpty ? null : _records.last.date,
      );
      _memberReports[id] = report;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
