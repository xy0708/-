import 'package:flutter/foundation.dart';

import '../core/config/app_config.dart';
import '../core/edge/edge_asr_client.dart';
import '../core/edge/edge_client.dart';

typedef EdgeVersionProbe = Future<Map<String, dynamic>> Function(
  Uri endpoint,
  String bearerToken,
  String memberId,
  bool allowInsecureTransportForEngineering,
);

class EdgeConnectionProvider extends ChangeNotifier {
  EdgeConnectionProvider({EdgeVersionProbe? versionProbe})
      : _versionProbe = versionProbe ?? _defaultVersionProbe;

  final EdgeVersionProbe _versionProbe;

  Uri? _endpoint;
  String? _bearerToken;
  String? _memberId;
  Map<String, dynamic>? _version;
  String? _lastError;
  bool _isVerifying = false;

  bool get isConfigured => _endpoint != null && _bearerToken != null;
  bool get isVerifying => _isVerifying;
  Uri? get endpoint => _endpoint;
  String? get memberId => _memberId;
  Map<String, dynamic>? get version => _version;
  String? get lastError => _lastError;

  Future<bool> configureAndVerify({
    required String endpoint,
    required String bearerToken,
    required String memberId,
  }) async {
    _isVerifying = true;
    _lastError = null;
    notifyListeners();
    try {
      final parsed = Uri.parse(endpoint.trim());
      final token = bearerToken.trim();
      final member = memberId.trim();
      final response = await _versionProbe(
        parsed,
        token,
        member,
        AppConfig.allowInsecureEdgeTransportForEngineering,
      );
      if (response['status'] != 'success' ||
          response['result'] is! Map<String, dynamic>) {
        throw const EdgeApiException(
          'RESPONSE_INVALID',
          '端侧版本响应无效',
          retryable: false,
        );
      }
      _endpoint = parsed;
      _bearerToken = token;
      _memberId = member;
      _version = Map<String, dynamic>.unmodifiable(
        response['result'] as Map<String, dynamic>,
      );
      return true;
    } on FormatException {
      _lastError = '端侧地址格式无效';
      _clearConnection();
      return false;
    } on EdgeApiException catch (error) {
      _lastError = '${error.code}: ${error.message}';
      _clearConnection();
      return false;
    } on ArgumentError catch (error) {
      _lastError = error.message?.toString() ?? '端侧配置无效';
      _clearConnection();
      return false;
    } catch (_) {
      _lastError = '无法验证端侧连接';
      _clearConnection();
      return false;
    } finally {
      _isVerifying = false;
      notifyListeners();
    }
  }

  EdgeClient createHttpClient(String memberId) {
    final endpoint = _endpoint;
    final bearerToken = _bearerToken;
    if (endpoint == null || bearerToken == null) {
      throw StateError('端侧尚未完成验证');
    }
    if (_memberId != memberId) {
      throw StateError('当前端侧会话不属于所选家庭成员');
    }
    return EdgeClient(
      endpoint: endpoint,
      bearerToken: bearerToken,
      memberId: memberId,
      allowInsecureTransportForEngineering:
          AppConfig.allowInsecureEdgeTransportForEngineering,
    );
  }

  EdgeAsrClient createAsrClient(String memberId) {
    final endpoint = _endpoint;
    final bearerToken = _bearerToken;
    if (endpoint == null || bearerToken == null) {
      throw StateError('端侧尚未完成验证');
    }
    if (_memberId != memberId) {
      throw StateError('当前端侧会话不属于所选家庭成员');
    }
    return EdgeAsrClient(
      endpoint: endpoint,
      bearerToken: bearerToken,
      memberId: memberId,
      allowInsecureTransportForEngineering:
          AppConfig.allowInsecureEdgeTransportForEngineering,
    );
  }

  void disconnect() {
    _lastError = null;
    _clearConnection();
    notifyListeners();
  }

  void _clearConnection() {
    _endpoint = null;
    _bearerToken = null;
    _memberId = null;
    _version = null;
  }

  static Future<Map<String, dynamic>> _defaultVersionProbe(
    Uri endpoint,
    String bearerToken,
    String memberId,
    bool allowInsecureTransportForEngineering,
  ) async {
    final client = EdgeClient(
      endpoint: endpoint,
      bearerToken: bearerToken,
      memberId: memberId,
      allowInsecureTransportForEngineering:
          allowInsecureTransportForEngineering,
    );
    try {
      return await client.getVersion();
    } finally {
      client.close();
    }
  }
}
