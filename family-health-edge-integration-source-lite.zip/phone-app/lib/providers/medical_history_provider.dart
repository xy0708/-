import 'package:flutter/foundation.dart';
import '../models/medical_history_entry.dart';
import '../core/storage/local_store.dart';

class MedicalHistoryProvider extends ChangeNotifier {
  static const String _storageKey = 'medical_history';

  List<MedicalHistoryEntry> _entries = [];
  bool _isLoading = false;

  List<MedicalHistoryEntry> get entries => _entries;
  bool get isLoading => _isLoading;

  Future<void> load() async {
    _isLoading = true;
    notifyListeners();

    try {
      final list = await LocalStore.getJsonList(_storageKey);
      _entries = list.map(MedicalHistoryEntry.fromJson).toList();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> add(MedicalHistoryEntry entry) async {
    _entries.add(entry);
    await LocalStore.setJsonList(
      _storageKey,
      _entries.map((e) => e.toJson()).toList(),
    );
    notifyListeners();
  }

  Future<void> update(MedicalHistoryEntry entry) async {
    final index = _entries.indexWhere((e) => e.id == entry.id);
    if (index < 0) return;
    _entries[index] = entry;
    await LocalStore.setJsonList(
      _storageKey,
      _entries.map((e) => e.toJson()).toList(),
    );
    notifyListeners();
  }

  Future<void> remove(String id) async {
    _entries.removeWhere((e) => e.id == id);
    await LocalStore.setJsonList(
      _storageKey,
      _entries.map((e) => e.toJson()).toList(),
    );
    notifyListeners();
  }
}
