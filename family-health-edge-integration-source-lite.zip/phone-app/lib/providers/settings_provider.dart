import 'dart:convert';

import 'package:flutter/material.dart';
import '../core/storage/local_store.dart';

/// 应用级设置（当前仅深色模式），持久化到 LocalStore。
class SettingsProvider extends ChangeNotifier {
  static const String _storageKey = 'app_settings';

  ThemeMode _themeMode = ThemeMode.system;
  bool _isLoading = false;

  ThemeMode get themeMode => _themeMode;
  bool get isLoading => _isLoading;

  Future<void> load() async {
    _isLoading = true;
    notifyListeners();

    try {
      final raw = await LocalStore.getString(_storageKey);
      if (raw == null || raw.isEmpty) return;
      final json = Map<String, dynamic>.from(
        const JsonDecoder().convert(raw) as Map,
      );
      _themeMode = _parseMode(json['themeMode']);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    await LocalStore.setString(
      _storageKey,
      jsonEncode({'themeMode': mode.name}),
    );
    notifyListeners();
  }

  static ThemeMode _parseMode(dynamic value) => ThemeMode.values.firstWhere(
        (m) => m.name == value,
        orElse: () => ThemeMode.system,
      );
}
