import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/elderly_settings.dart';
import '../core/storage/local_store.dart';

class ElderlySettingsProvider extends ChangeNotifier {
  static const String _storageKey = 'elderly_settings';

  ElderlySettings _settings = const ElderlySettings();
  bool _isLoading = false;

  ElderlySettings get settings => _settings;
  bool get isLoading => _isLoading;

  Future<void> load() async {
    _isLoading = true;
    notifyListeners();

    try {
      final raw = await LocalStore.getString(_storageKey);
      if (raw == null || raw.isEmpty) return;
      final json = Map<String, dynamic>.from(
        const JsonDecoder().convert(raw) as Map,
      );
      _settings = ElderlySettings.fromJson(json);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> update(ElderlySettings settings) async {
    _settings = settings;
    await LocalStore.setString(_storageKey, jsonEncode(settings.toJson()));
    notifyListeners();
  }
}
