import 'package:flutter/foundation.dart';
import '../models/family_member.dart';
import '../core/storage/local_store.dart';

class FamilyProvider extends ChangeNotifier {
  static const String _storageKey = 'family_members';

  List<FamilyMember> _members = [];
  bool _isLoading = false;

  List<FamilyMember> get members => _members;
  bool get isLoading => _isLoading;

  Future<void> fetchMembers() async {
    _isLoading = true;
    notifyListeners();

    try {
      final list = await LocalStore.getJsonList(_storageKey);
      if (list.isEmpty) {
        _members = _seedMembers();
        await _persist();
      } else {
        _members = list.map(FamilyMember.fromJson).toList();
      }
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  List<FamilyMember> _seedMembers() {
    return [
      FamilyMember(id: '1', name: '张三', relation: '本人', age: 35, gender: '男', hasDevice: true),
      FamilyMember(id: '2', name: '李四', relation: '配偶', age: 33, gender: '女'),
      FamilyMember(id: '3', name: '张爷爷', relation: '父亲', age: 65, gender: '男', medicalHistory: '高血压'),
      FamilyMember(id: '4', name: '张奶奶', relation: '母亲', age: 62, gender: '女', medicalHistory: '糖尿病'),
    ];
  }

  Future<void> addMember(FamilyMember member) async {
    await Future.delayed(const Duration(milliseconds: 300));
    _members.add(member);
    await _persist();
    notifyListeners();
  }

  Future<void> updateMember(FamilyMember member) async {
    final index = _members.indexWhere((m) => m.id == member.id);
    if (index < 0) return;
    _members[index] = member;
    await _persist();
    notifyListeners();
  }

  Future<void> deleteMember(String id) async {
    _members.removeWhere((m) => m.id == id);
    await _persist();
    notifyListeners();
  }

  Future<void> _persist() async {
    await LocalStore.setJsonList(
      _storageKey,
      _members.map((m) => m.toJson()).toList(),
    );
  }
}
