import 'package:flutter/foundation.dart';

import '../core/storage/local_store.dart';
import '../models/reminder.dart';
import '../services/notification_service.dart';

/// 健康提醒管理：本地持久化 + 系统通知调度同步。
class ReminderProvider extends ChangeNotifier {
  static const String _storageKey = 'reminders';

  List<Reminder> _reminders = [];
  bool _isLoading = false;

  List<Reminder> get reminders => _reminders;
  int get enabledCount => _reminders.where((r) => r.enabled).length;
  bool get isLoading => _isLoading;

  Future<void> load() async {
    _isLoading = true;
    notifyListeners();

    try {
      final list = await LocalStore.getJsonList(_storageKey);
      _reminders = list.map(Reminder.fromJson).toList();
      // 安装更新/系统重启会清空已注册的系统闹钟，启动时统一重新注册
      if (_reminders.isNotEmpty) {
        await rescheduleAll();
      }
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// 重新注册全部已启用提醒（幂等：先取消再注册，同 id 覆盖旧调度）。
  Future<void> rescheduleAll() async {
    for (final reminder in _reminders) {
      await NotificationService.instance.cancel(reminder.id);
      if (reminder.enabled) {
        await NotificationService.instance.scheduleDaily(reminder);
      }
    }
  }

  Future<void> add(Reminder reminder) async {
    _reminders.add(reminder);
    await _persist();
    if (reminder.enabled) {
      await NotificationService.instance.scheduleDaily(reminder);
    }
    notifyListeners();
  }

  Future<void> update(Reminder reminder) async {
    final index = _reminders.indexWhere((r) => r.id == reminder.id);
    if (index < 0) return;
    _reminders[index] = reminder;
    await _persist();
    await NotificationService.instance.cancel(reminder.id);
    if (reminder.enabled) {
      await NotificationService.instance.scheduleDaily(reminder);
    }
    notifyListeners();
  }

  Future<void> remove(String id) async {
    _reminders.removeWhere((r) => r.id == id);
    await _persist();
    await NotificationService.instance.cancel(id);
    notifyListeners();
  }

  Future<void> _persist() async {
    await LocalStore.setJsonList(
      _storageKey,
      _reminders.map((r) => r.toJson()).toList(),
    );
  }
}
