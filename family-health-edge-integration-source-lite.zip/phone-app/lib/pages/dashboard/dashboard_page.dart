import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../../core/routes/app_router.dart';
import '../../providers/health_provider.dart';
import '../../providers/family_provider.dart';
import '../../providers/alert_provider.dart';
import '../../providers/elderly_settings_provider.dart';
import '../../models/family_member.dart';
import '../../core/theme/app_theme.dart';
import '../../core/pdf/report_export_flow.dart';
import '../../models/health_record.dart';
import '../../models/health_report.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  String? _selectedMemberId;
  bool _exporting = false;
  String? _loadError;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final family = context.read<FamilyProvider>();
      family.fetchMembers().then((_) {
        if (!mounted) return;
        final self =
            family.members.where((m) => m.relation == '本人').firstOrNull;
        if (self != null) {
          setState(() => _selectedMemberId = self.id);
          _loadMemberData(self.id, self.age);
        }
      });
    });
  }

  Future<void> _loadMemberData(String memberId, int age) async {
    final health = context.read<HealthProvider>();
    health.setActiveMember(memberId);
    final member = context
        .read<FamilyProvider>()
        .members
        .where((m) => m.id == memberId)
        .firstOrNull;
    if (mounted) setState(() => _loadError = null);
    try {
      await Future.wait<void>([
        health.fetchSummary(memberId: memberId, age: age),
        health.fetchRecords(memberId: memberId, age: age),
        context.read<AlertProvider>().fetchAlerts(
              memberId: memberId,
              memberName: member?.name ?? '本人',
              age: age,
            ),
      ]);
    } catch (_) {
      if (mounted) {
        setState(() {
          _loadError = '健康数据服务不可用，请检查连接后重试。';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final health = context.watch<HealthProvider>();
    final family = context.watch<FamilyProvider>();
    final alertCount = context.watch<AlertProvider>().warningDangerCount;

    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('数据看板'),
        actions: [
          Badge(
            isLabelVisible: alertCount > 0,
            label: Text('$alertCount'),
            offset: const Offset(-3, 3),
            child: IconButton(
              icon: const Icon(Icons.notifications_outlined),
              onPressed: () => Navigator.pushNamed(context, AppRouter.alerts),
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          final selected = _selectedMember(family);
          if (selected != null) {
            await _loadMemberData(selected.id, selected.age);
          }
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildMemberSelector(family),
              if (_loadError != null) ...[
                const SizedBox(height: 12),
                Material(
                  color: Theme.of(context).colorScheme.errorContainer,
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline),
                        const SizedBox(width: 8),
                        Expanded(child: Text(_loadError!)),
                        TextButton(
                          onPressed: () {
                            final selected = _selectedMember(family);
                            if (selected != null) {
                              _loadMemberData(selected.id, selected.age);
                            }
                          },
                          child: const Text('重试'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              if (health.summary != null) _buildVitalCards(health.summary!),
              const SizedBox(height: 16),
              _buildSectionTitle('周度趋势'),
              const SizedBox(height: 8),
              _buildHeartRateChart(health.records),
              const SizedBox(height: 16),
              _buildSectionTitle('周度活动分布'),
              const SizedBox(height: 8),
              _buildActivityChart(health.records),
              const SizedBox(height: 16),
              _buildLatestReportCard(health),
            ],
          ),
        ),
      ),
    );
  }

  FamilyMember? _selectedMember(FamilyProvider family) {
    return family.members.where((m) => m.id == _selectedMemberId).firstOrNull;
  }

  Widget _buildMemberSelector(FamilyProvider family) {
    return SizedBox(
      height: 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: family.members
            .map<Widget>((m) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(m.name),
                    selected: m.id == _selectedMemberId,
                    onSelected: (selected) {
                      if (selected) {
                        setState(() => _selectedMemberId = m.id);
                        _loadMemberData(m.id, m.age);
                      }
                    },
                  ),
                ))
            .toList(),
      ),
    );
  }

  Widget _buildVitalCards(HealthSummary summary) {
    final cards = [
      _vitalCard(
          '步数', '${summary.todaySteps}', Icons.directions_walk, Colors.blue),
      _vitalCard('睡眠', '${summary.todaySleep.toStringAsFixed(1)}h',
          Icons.bedtime, Colors.indigo),
      _vitalCard(
          '脉搏', '${summary.currentHeartRate}', Icons.favorite, Colors.red),
      _vitalCard('活动度', '${(summary.todayActivity * 100).toInt()}%',
          Icons.show_chart, Colors.orange),
    ];
    // 助老模式：2×2 大卡片布局，数值更大更易读
    if (context.watch<ElderlySettingsProvider>().settings.elderlyMode) {
      return Column(
        children: [
          Row(children: [
            Expanded(child: cards[0]),
            const SizedBox(width: 8),
            Expanded(child: cards[1]),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: cards[2]),
            const SizedBox(width: 8),
            Expanded(child: cards[3]),
          ]),
        ],
      );
    }
    // 普通模式：一行四张等宽卡片
    return Row(
      children: [
        Expanded(child: cards[0]),
        Expanded(child: cards[1]),
        Expanded(child: cards[2]),
        Expanded(child: cards[3]),
      ],
    );
  }

  Widget _vitalCard(String label, String value, IconData icon, Color color) {
    final elderly =
        context.watch<ElderlySettingsProvider>().settings.elderlyMode;
    return Card(
      child: Padding(
        padding: EdgeInsets.symmetric(
            vertical: elderly ? 20 : 12, horizontal: elderly ? 4 : 0),
        child: Column(
          children: [
            Icon(icon, color: color, size: elderly ? 36 : 28),
            const SizedBox(height: 6),
            Text(value,
                style: TextStyle(
                    fontSize: elderly ? 24 : 18, fontWeight: FontWeight.bold)),
            Text(label,
                style: TextStyle(
                    fontSize: elderly ? 15 : 12, color: context.textSecondary)),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        TextButton(
          onPressed: () => _showDetailSheet(),
          child: const Text('查看详情'),
        ),
      ],
    );
  }

  void _showDetailSheet() {
    final health = context.read<HealthProvider>();
    final records = health.records;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        minChildSize: 0.3,
        expand: false,
        builder: (_, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: context.textSecondary.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text('周度健康数据详情',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              ...records.asMap().entries.map((e) {
                final r = e.value;
                final dayLabel =
                    '第${e.key + 1}天 (${r.date.month}/${r.date.day})';
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(dayLabel,
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 14)),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _detailItem(Icons.directions_walk, '步数',
                                '${r.steps}', Colors.blue),
                            _detailItem(
                                Icons.bedtime,
                                '睡眠',
                                '${r.sleepHours.toStringAsFixed(1)}h',
                                Colors.indigo),
                            _detailItem(Icons.favorite, '脉搏', '${r.heartRate}',
                                Colors.red),
                            _detailItem(
                                Icons.show_chart,
                                '活动度',
                                '${(r.activityLevel * 100).toInt()}%',
                                Colors.orange),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _detailItem(IconData icon, String label, String value, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        Text(label,
            style: TextStyle(fontSize: 10, color: context.textSecondary)),
      ],
    );
  }

  Widget _buildHeartRateChart(List<HealthRecord> records) {
    if (records.isEmpty) return const SizedBox();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          height: 180,
          child: LineChart(
            LineChartData(
              minY: 40,
              maxY: 120,
              gridData: const FlGridData(show: true, drawVerticalLine: false),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 40,
                  interval: 20,
                  getTitlesWidget: (v, _) => Text(
                    '${v.toInt()}',
                    maxLines: 1,
                    style:
                        TextStyle(fontSize: 10, color: context.textSecondary),
                  ),
                )),
                bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                  showTitles: true,
                  getTitlesWidget: (v, _) {
                    final idx = v.toInt();
                    if (idx < 0 || idx >= records.length) {
                      return const SizedBox();
                    }
                    return Text('${idx + 1}',
                        style: const TextStyle(fontSize: 10));
                  },
                )),
                topTitles:
                    const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles:
                    const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              ),
              borderData: FlBorderData(show: false),
              lineBarsData: [
                LineChartBarData(
                  spots: records
                      .asMap()
                      .entries
                      .map((e) => FlSpot(
                          e.key.toDouble(), e.value.heartRate.toDouble()))
                      .toList(),
                  isCurved: true,
                  color: Colors.red.shade300,
                  barWidth: 2,
                  dotData: const FlDotData(show: true),
                  belowBarData: BarAreaData(
                      show: true, color: Colors.red.withValues(alpha: 0.15)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActivityChart(List<HealthRecord> records) {
    if (records.isEmpty) return const SizedBox();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          height: 160,
          child: BarChart(
            BarChartData(
              minY: 0,
              maxY: 100,
              gridData: const FlGridData(show: false),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 40,
                  interval: 25,
                  getTitlesWidget: (v, _) => Text(
                    '${v.toInt()}',
                    maxLines: 1,
                    style:
                        TextStyle(fontSize: 10, color: context.textSecondary),
                  ),
                )),
                bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                  showTitles: true,
                  getTitlesWidget: (v, _) {
                    final idx = v.toInt();
                    if (idx < 0 || idx >= records.length) {
                      return const SizedBox();
                    }
                    return Text('${idx + 1}',
                        style: const TextStyle(fontSize: 10));
                  },
                )),
                topTitles:
                    const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles:
                    const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              ),
              borderData: FlBorderData(show: false),
              barGroups: records
                  .asMap()
                  .entries
                  .map((e) => BarChartGroupData(
                        x: e.key,
                        barRods: [
                          BarChartRodData(
                              toY: e.value.activityLevel * 100,
                              color: AppTheme.primaryGreen,
                              width: 12,
                              borderRadius: BorderRadius.circular(4))
                        ],
                      ))
                  .toList(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLatestReportCard(HealthProvider health) {
    final family = context.read<FamilyProvider>();
    final selected = _selectedMember(family);
    if (health.latestReport == null) {
      if (selected == null) return const SizedBox();
      return Card(
        child: ListTile(
          leading: const Icon(Icons.assignment,
              color: AppTheme.primaryGreen, size: 40),
          title: Text('为 ${selected.name} 生成周度报告'),
          subtitle: const Text('点击生成最新健康评估'),
          trailing: FilledButton(
            onPressed: health.isLoading
                ? null
                : () => health.generateReport(
                      memberName: selected.name,
                      memberId: selected.id,
                      age: selected.age,
                    ),
            child: const Text('生成'),
          ),
        ),
      );
    }
    final report = health.latestReport!;
    final generatedText = DateFormat('MM-dd HH:mm').format(report.generatedAt);
    return Card(
      child: ListTile(
        leading: const Icon(Icons.assignment,
            color: AppTheme.primaryGreen, size: 40),
        title: Text('${report.type} - ${report.memberName}'),
        subtitle: Text(
            '得分: ${report.overallScore.toStringAsFixed(0)}分 · $generatedText 生成'),
        trailing: TextButton.icon(
          onPressed: _exporting ? null : () => _exportPdf(report),
          icon: _exporting
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.picture_as_pdf),
          label: Text(_exporting ? '导出中' : 'PDF'),
        ),
      ),
    );
  }

  Future<void> _exportPdf(HealthReport report) {
    return runReportExport(
      context,
      report,
      setBusy: (busy) {
        if (mounted) setState(() => _exporting = busy);
      },
    );
  }
}
