import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import '../../providers/health_provider.dart';
import '../../providers/family_provider.dart';
import '../../providers/edge_connection_provider.dart';
import '../../models/family_member.dart';
import '../../core/edge/edge_client.dart';
import '../../core/edge/edge_health_result.dart';
import '../../core/watch/wearable_measurement.dart';
import '../../core/theme/app_theme.dart';
import '../../core/pdf/report_export_flow.dart';
import '../../models/health_report.dart';
import 'ocr_preview_page.dart';
import 'asr_capture_page.dart';

class AssessmentPage extends StatefulWidget {
  const AssessmentPage({super.key});

  @override
  State<AssessmentPage> createState() => _AssessmentPageState();
}

class _AssessmentPageState extends State<AssessmentPage> {
  bool _exporting = false;
  bool _evaluatingEdgeHealth = false;
  final _heartRateController = TextEditingController(text: '72');
  EdgeHealthResult? _edgeHealthResult;
  String? _edgeHealthError;

  @override
  void dispose() {
    _heartRateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final health = context.watch<HealthProvider>();
    final family = context.watch<FamilyProvider>();
    final edge = context.watch<EdgeConnectionProvider>();
    final activeMember = _activeMember(family, health);

    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('数据评估'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildGenerateReportCard(context, health, activeMember),
            const SizedBox(height: 16),
            _buildEdgeHealthCard(context, edge, activeMember),
            const SizedBox(height: 16),
            _buildAsrSection(context, edge, activeMember),
            const SizedBox(height: 16),
            _buildOcrSection(context, activeMember),
            const SizedBox(height: 16),
            if (health.latestReport != null)
              _buildReportResult(health.latestReport!),
          ],
        ),
      ),
    );
  }

  FamilyMember? _activeMember(FamilyProvider family, HealthProvider health) {
    return family.members
        .where((m) => m.id == health.activeMemberId)
        .firstOrNull;
  }

  Widget _buildGenerateReportCard(
      BuildContext context, HealthProvider health, FamilyMember? activeMember) {
    final memberName = activeMember?.name ?? '本人';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.auto_awesome,
                size: 48, color: AppTheme.primaryGreen),
            const SizedBox(height: 12),
            const Text('生成本地周度规则报告',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('为 $memberName 生成，基于已加载数据的本地规则汇总（非诊断）',
                style: TextStyle(color: context.textSecondary)),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: FilledButton.icon(
                onPressed: health.isLoading
                    ? null
                    : () => health.generateReport(
                          memberName: memberName,
                          memberId: activeMember?.id,
                          age: activeMember?.age ?? 40,
                        ),
                icon: health.isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.generating_tokens),
                label: Text(health.isLoading ? '生成中...' : '立即生成'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAsrSection(
    BuildContext context,
    EdgeConnectionProvider edge,
    FamilyMember? activeMember,
  ) {
    final ready = activeMember != null &&
        edge.isConfigured &&
        edge.memberId == activeMember.id;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.mic, size: 48, color: AppTheme.accentBlue),
            const SizedBox(height: 12),
            const Text(
              '端侧语音转文字',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              '原始音频仅流式处理，识别文字需人工确认后保存',
              style: TextStyle(color: context.textSecondary),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: ready
                    ? () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AsrCapturePage(
                              memberId: activeMember.id,
                            ),
                          ),
                        )
                    : null,
                icon: const Icon(Icons.keyboard_voice),
                label: const Text('开始语音录入'),
              ),
            ),
            if (!ready)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                  '请先为当前家庭成员验证端侧连接。',
                  style: TextStyle(color: Colors.orange),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildEdgeHealthCard(
    BuildContext context,
    EdgeConnectionProvider edge,
    FamilyMember? activeMember,
  ) {
    final memberMatches = activeMember != null &&
        edge.isConfigured &&
        edge.memberId == activeMember.id;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.monitor_heart, color: AppTheme.primaryGreen),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '端侧健康提示（非诊断）',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text('输入并确认本次脉搏值后，由家庭端侧规则接口返回健康管理提示。'),
            const SizedBox(height: 12),
            TextField(
              controller: _heartRateController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: '已确认脉搏',
                suffixText: 'bpm',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: memberMatches && !_evaluatingEdgeHealth
                    ? () => _runEdgeHealth(edge, activeMember)
                    : null,
                icon: _evaluatingEdgeHealth
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.send),
                label: Text(
                  _evaluatingEdgeHealth ? '端侧评估中...' : '确认并发送到端侧',
                ),
              ),
            ),
            if (!memberMatches) ...[
              const SizedBox(height: 8),
              const Text(
                '请先在“我的”页面为当前家庭成员完成端侧连接验证。',
                style: TextStyle(color: Colors.orange),
              ),
            ],
            if (_edgeHealthError != null) ...[
              const SizedBox(height: 12),
              Text(
                _edgeHealthError!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ],
            if (_edgeHealthResult != null) ...[
              const Divider(height: 28),
              Text(
                '提示级别：${_edgeHealthResult!.attentionLevel}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              ..._edgeHealthResult!.messages.map(
                (message) => Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text('• $message'),
                ),
              ),
              if (!_edgeHealthResult!.productReleaseAllowed)
                const Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Text(
                    '当前规则尚未获产品发布批准，本结果仅用于工程验证。',
                    style: TextStyle(color: Colors.orange),
                  ),
                ),
              const SizedBox(height: 6),
              Text(
                _edgeHealthResult!.disclaimer,
                style: TextStyle(fontSize: 12, color: context.textSecondary),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _runEdgeHealth(
    EdgeConnectionProvider edge,
    FamilyMember member,
  ) async {
    final value = double.tryParse(_heartRateController.text.trim());
    if (value == null || value < 20 || value > 250) {
      setState(() {
        _edgeHealthError = '请输入 20–250 bpm 的有效脉搏值。';
        _edgeHealthResult = null;
      });
      return;
    }

    setState(() {
      _evaluatingEdgeHealth = true;
      _edgeHealthError = null;
      _edgeHealthResult = null;
    });
    final capturedAt = DateTime.now().toUtc();
    EdgeClient? client;
    try {
      client = edge.createHttpClient(member.id);
      final response = await client.evaluateConfirmedMeasurement(
        WearableMeasurement(
          recordId: 'manual:${member.id}:${capturedAt.microsecondsSinceEpoch}',
          memberId: member.id,
          deviceId: 'phone_manual_confirmation',
          metric: WearableMetric.heartRate,
          value: value,
          unit: 'bpm',
          capturedAt: capturedAt,
          source: 'user_confirmed_manual',
          quality: MeasurementQuality.valid,
        ),
      );
      final result = EdgeHealthResult.fromResponse(response);
      if (mounted) setState(() => _edgeHealthResult = result);
    } on EdgeApiException catch (error) {
      if (mounted) {
        setState(() => _edgeHealthError = '${error.code}：${error.message}');
      }
    } on FormatException {
      if (mounted) setState(() => _edgeHealthError = '端侧健康结果格式不安全，已拒绝显示。');
    } on StateError catch (error) {
      if (mounted) setState(() => _edgeHealthError = error.message.toString());
    } catch (_) {
      if (mounted) setState(() => _edgeHealthError = '端侧健康评估失败，请检查连接。');
    } finally {
      client?.close();
      if (mounted) setState(() => _evaluatingEdgeHealth = false);
    }
  }

  Widget _buildOcrSection(BuildContext context, FamilyMember? activeMember) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.document_scanner,
                size: 48, color: AppTheme.accentBlue),
            const SizedBox(height: 12),
            const Text('OCR 医疗影像识别',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('上传纸质化验单照片，自动识别分析',
                style: TextStyle(color: context.textSecondary)),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton.icon(
                onPressed: activeMember == null
                    ? null
                    : () => _pickImage(
                          context,
                          ImageSource.camera,
                          activeMember.id,
                        ),
                icon: const Icon(Icons.camera_alt),
                label: const Text('拍照上传'),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton.icon(
                onPressed: activeMember == null
                    ? null
                    : () => _pickImage(
                          context,
                          ImageSource.gallery,
                          activeMember.id,
                        ),
                icon: const Icon(Icons.photo_library),
                label: const Text('从相册选择'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(
    BuildContext context,
    ImageSource source,
    String memberId,
  ) async {
    final picker = ImagePicker();
    final xFile = await picker.pickImage(source: source, imageQuality: 85);
    if (xFile == null || !context.mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => OcrPreviewPage(
          imagePath: xFile.path,
          memberId: memberId,
        ),
      ),
    );
  }

  Widget _buildReportResult(HealthReport report) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.assignment_turned_in,
                    color: AppTheme.primaryGreen),
                const SizedBox(width: 8),
                Text('${report.type}报告',
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryGreen.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text('${report.overallScore.toStringAsFixed(0)}分',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryGreen)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '生成时间：${DateFormat('yyyy-MM-dd HH:mm').format(report.generatedAt)}',
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const Divider(),
            Text(report.summary),
            const SizedBox(height: 12),
            const Text('改善建议', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            ...report.suggestions.map((s) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('• ',
                          style: TextStyle(color: AppTheme.primaryGreen)),
                      Expanded(child: Text(s)),
                    ],
                  ),
                )),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _exporting ? null : () => _exportPdf(report),
                icon: _exporting
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.picture_as_pdf),
                label: Text(_exporting ? '导出中...' : '导出 PDF 报告'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _exportPdf(HealthReport report) {
    return runReportExport(
      context,
      report,
      setBusy: (busy) {
        if (mounted) setState(() => _exporting = busy);
      },
    );
  }
}
