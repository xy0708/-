import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/edge/edge_client.dart';
import '../../core/edge/edge_ocr_review.dart';
import '../../providers/edge_connection_provider.dart';

class OcrPreviewPage extends StatefulWidget {
  const OcrPreviewPage({
    super.key,
    required this.imagePath,
    required this.memberId,
  });

  final String imagePath;
  final String memberId;

  @override
  State<OcrPreviewPage> createState() => _OcrPreviewPageState();
}

class _OcrPreviewPageState extends State<OcrPreviewPage> {
  bool _isAnalyzing = false;
  bool _isSaving = false;
  EdgeOcrReview? _review;
  EdgeClient? _client;
  TextEditingController? _textController;
  String? _pendingTaskId;
  String? _error;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OCR 识别')),
      body: Column(
        children: [
          _buildImagePreview(),
          const Divider(height: 1),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildImagePreview() {
    return Container(
      height: 200,
      width: double.infinity,
      color: Colors.black,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.file(File(widget.imagePath), fit: BoxFit.contain),
          if (_isAnalyzing || _isSaving)
            Container(
              color: Colors.black54,
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircularProgressIndicator(color: Colors.white),
                    const SizedBox(height: 12),
                    Text(
                      _isSaving ? '正在保存确认结果...' : '正在端侧识别...',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    final review = _review;
    if (review != null) return _buildReview(review);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.document_scanner, size: 64),
            const SizedBox(height: 16),
            Text(
              _error ?? '图片只发送到已验证的家庭端侧；识别结果需人工确认。',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _error == null
                    ? Theme.of(context).colorScheme.onSurfaceVariant
                    : Theme.of(context).colorScheme.error,
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: 220,
              height: 48,
              child: FilledButton.icon(
                onPressed: _isAnalyzing ? null : _startOcr,
                icon: const Icon(Icons.auto_awesome),
                label: Text(_error == null ? '开始端侧识别' : '重试'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReview(EdgeOcrReview review) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.fact_check_outlined),
                    SizedBox(width: 8),
                    Text(
                      '待人工确认',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  '请核对并修改识别文本。确认前不会写入成员健康记录。',
                  style: TextStyle(fontSize: 13),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _textController,
                  minLines: 6,
                  maxLines: 14,
                  decoration: const InputDecoration(
                    labelText: '识别文本',
                    alignLabelWithHint: true,
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        ExpansionTile(
          title: Text('逐行置信度（${review.lines.length} 行）'),
          subtitle: const Text('置信度不是医学准确率'),
          children: review.lines
              .map(
                (line) => ListTile(
                  dense: true,
                  title: Text(line.text),
                  trailing: Text(
                    '${(line.confidence * 100).toStringAsFixed(1)}%',
                  ),
                ),
              )
              .toList(growable: false),
        ),
        if (_error != null) ...[
          const SizedBox(height: 12),
          Text(
            _error!,
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        ],
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _isSaving ? null : _cancelTaskAndClose,
                child: const Text('取消识别'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FilledButton(
                onPressed: _isSaving ? null : _confirmAndSave,
                child: const Text('确认并保存'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> _startOcr() async {
    final connection = context.read<EdgeConnectionProvider>();
    if (!connection.isConfigured) {
      setState(() => _error = '请先在“我的”页面验证家庭端侧连接。');
      return;
    }
    if (connection.memberId != widget.memberId) {
      setState(() => _error = '当前端侧会话不属于所选家庭成员，请重新验证连接。');
      return;
    }
    setState(() {
      _isAnalyzing = true;
      _error = null;
    });
    EdgeClient? client;
    String? taskId;
    try {
      final file = File(widget.imagePath);
      final length = await file.length();
      if (length < 1 || length > EdgeClient.maxOcrImageBytes) {
        throw ArgumentError('图片必须小于 8 MiB');
      }
      final bytes = await file.readAsBytes();
      final mediaType =
          bytes.length >= 2 && bytes[0] == 0xff && bytes[1] == 0xd8
              ? 'image/jpeg'
              : 'image/png';
      client = connection.createHttpClient(widget.memberId);
      final created = await client.createOcrTask(
        imageBytes: bytes,
        mediaType: mediaType,
      );
      taskId = created['task_id'] as String?;
      if (taskId == null) {
        throw const FormatException('OCR create response is missing task_id');
      }
      final task = await client.getTask(taskId);
      final review = EdgeOcrReview.fromTaskResponse(task);
      if (!mounted) {
        await client.cancelTask(taskId);
        client.close();
        return;
      }
      _textController?.dispose();
      setState(() {
        _client = client;
        _pendingTaskId = taskId;
        _review = review;
        _textController = TextEditingController(text: review.fullText);
      });
      client = null;
      taskId = null;
    } on EdgeApiException catch (error) {
      _setError('${error.code}: ${error.message}');
    } on FormatException {
      _setError('端侧返回的 OCR 结果格式无效。');
    } on ArgumentError catch (error) {
      _setError(error.message?.toString() ?? '图片不符合 OCR 输入要求。');
    } catch (_) {
      _setError('OCR 端侧调用失败，请检查配对和网络。');
    } finally {
      if (taskId != null && client != null) {
        try {
          await client.cancelTask(taskId);
        } catch (_) {}
      }
      client?.close();
      if (mounted) setState(() => _isAnalyzing = false);
    }
  }

  Future<void> _confirmAndSave() async {
    final client = _client;
    final taskId = _pendingTaskId;
    final text = _textController?.text.trim() ?? '';
    if (client == null || taskId == null) return;
    if (text.isEmpty) {
      setState(() => _error = '确认文本不能为空。');
      return;
    }
    setState(() => _isSaving = true);
    try {
      await client.confirmTask(
        taskId: taskId,
        idempotencyKey: 'phone-ocr-$taskId',
        confirmedFields: {'full_text': text},
      );
      _pendingTaskId = null;
      client.close();
      _client = null;
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('确认后的 OCR 文本已保存')),
      );
      Navigator.pop(context, true);
    } on EdgeApiException catch (error) {
      if (mounted) setState(() => _error = '${error.code}: ${error.message}');
    } catch (_) {
      if (mounted) setState(() => _error = '保存失败，请重试。');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _cancelTaskAndClose() async {
    final client = _client;
    final taskId = _pendingTaskId;
    setState(() => _isSaving = true);
    try {
      if (client != null && taskId != null) {
        await client.cancelTask(taskId);
      }
      _pendingTaskId = null;
      client?.close();
      _client = null;
      if (mounted) Navigator.pop(context, false);
    } on EdgeApiException catch (error) {
      if (mounted) setState(() => _error = '${error.code}: ${error.message}');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _setError(String message) {
    if (mounted) setState(() => _error = message);
  }

  @override
  void dispose() {
    _textController?.dispose();
    final client = _client;
    final taskId = _pendingTaskId;
    if (client != null && taskId != null) {
      unawaited(client.cancelTask(taskId).whenComplete(client.close));
    } else {
      client?.close();
    }
    super.dispose();
  }
}
