import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/edge/edge_asr_client.dart';
import '../../core/edge/edge_asr_microphone.dart';
import '../../core/edge/edge_asr_result.dart';
import '../../core/edge/edge_client.dart';
import '../../providers/edge_connection_provider.dart';

class AsrCapturePage extends StatefulWidget {
  const AsrCapturePage({super.key, required this.memberId});

  final String memberId;

  @override
  State<AsrCapturePage> createState() => _AsrCapturePageState();
}

class _AsrCapturePageState extends State<AsrCapturePage> {
  final _textController = TextEditingController();
  EdgeConnectionProvider? _connection;
  EdgeAsrMicrophoneController? _microphone;
  String? _taskId;
  String? _partial;
  String? _error;
  bool _recording = false;
  bool _busy = false;
  bool _confirmed = false;

  @override
  void dispose() {
    unawaited(_cleanup());
    _textController.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    final connection = context.read<EdgeConnectionProvider>();
    _connection = connection;
    if (!connection.isConfigured || connection.memberId != widget.memberId) {
      setState(() => _error = '请先为当前家庭成员验证端侧连接。');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _partial = null;
      _confirmed = false;
      _textController.clear();
    });
    final microphone = EdgeAsrMicrophoneController(
      client: connection.createAsrClient(widget.memberId),
      onPartial: (text) {
        if (mounted) setState(() => _partial = text);
      },
    );
    _microphone = microphone;
    try {
      await microphone.start();
      if (mounted) setState(() => _recording = true);
    } on EdgeAsrException catch (error) {
      if (mounted) setState(() => _error = '${error.code}：${error.message}');
      await microphone.dispose();
      _microphone = null;
    } catch (_) {
      if (mounted) setState(() => _error = '无法开始录音，请检查麦克风权限和端侧连接。');
      await microphone.dispose();
      _microphone = null;
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _stop() async {
    final microphone = _microphone;
    if (microphone == null || !_recording) return;
    setState(() {
      _busy = true;
      _recording = false;
      _error = null;
    });
    try {
      final event = await microphone.stop();
      final pending = EdgeAsrPendingResult.fromEvent(event);
      _taskId = pending.taskId;
      _textController.text = pending.text;
      _partial = null;
    } on EdgeAsrException catch (error) {
      _error = '${error.code}：${error.message}';
    } on FormatException {
      _error = '端侧语音结果格式不安全，已拒绝显示。';
    } catch (_) {
      _error = '语音识别失败，请重试。';
    } finally {
      await microphone.dispose();
      _microphone = null;
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _confirm() async {
    final taskId = _taskId;
    final text = _textController.text.trim();
    if (taskId == null || text.isEmpty || _busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    EdgeClient? client;
    try {
      client = (_connection ?? context.read<EdgeConnectionProvider>())
          .createHttpClient(widget.memberId);
      await client.confirmTask(
        taskId: taskId,
        idempotencyKey: 'asr:$taskId:confirm',
        confirmedFields: {'transcript': text},
      );
      _confirmed = true;
      _taskId = null;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已保存人工确认后的文字。')),
        );
      }
    } on EdgeApiException catch (error) {
      _error = '${error.code}：${error.message}';
    } catch (_) {
      _error = '保存失败，待确认任务未被标记为完成。';
    } finally {
      client?.close();
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _cancelPending() async {
    final taskId = _taskId;
    if (taskId == null) return;
    EdgeClient? client;
    try {
      final connection = _connection;
      if (connection == null) return;
      client = connection.createHttpClient(widget.memberId);
      await client.cancelTask(taskId);
      _taskId = null;
      _textController.clear();
    } catch (_) {
      _error = '取消待确认任务失败；端侧 TTL 清理仍会生效。';
    } finally {
      client?.close();
      if (mounted) setState(() {});
    }
  }

  Future<void> _cleanup() async {
    await _microphone?.cancel();
    await _microphone?.dispose();
    _microphone = null;
    if (!_confirmed && _taskId != null) {
      await _cancelPending();
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasPending = _taskId != null;
    return Scaffold(
      appBar: AppBar(title: const Text('语音转文字')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            '录音仅以 16 kHz、单声道、PCM16 流式发送；端侧声明不保存原始音频。识别文字必须人工确认后才保存。',
          ),
          const SizedBox(height: 16),
          if (_partial != null) Text('实时识别：$_partial'),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Text(_error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _busy || hasPending
                ? null
                : _recording
                    ? _stop
                    : _start,
            icon: Icon(_recording ? Icons.stop : Icons.mic),
            label: Text(_recording ? '停止并识别' : '开始录音'),
          ),
          if (hasPending) ...[
            const SizedBox(height: 20),
            TextField(
              controller: _textController,
              minLines: 4,
              maxLines: 10,
              decoration: const InputDecoration(
                labelText: '待人工确认文字',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _busy ? null : _confirm,
              child: const Text('确认文字并保存'),
            ),
            TextButton(
              onPressed: _busy ? null : _cancelPending,
              child: const Text('取消并删除待确认任务'),
            ),
          ],
        ],
      ),
    );
  }
}
