import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../dashboard/dashboard_page.dart';
import '../assessment/assessment_page.dart';
import '../map/map_page.dart';
import '../profile/profile_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;

  final _pages = const [
    DashboardPage(),
    AssessmentPage(),
    MapPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: Container(
        // 显式绘制底部安全区条带（含手势条区域），不依赖系统导航栏颜色
        color: context.surface,
        child: SafeArea(
          top: false,
          child: BottomNavigationBar(
            currentIndex: _currentIndex,
            onTap: (i) => setState(() => _currentIndex = i),
            type: BottomNavigationBarType.fixed,
            backgroundColor: Colors.transparent,
            selectedItemColor: AppTheme.primaryGreen,
            unselectedItemColor: context.textSecondary,
            items: const [
              BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: '数据看板'),
              BottomNavigationBarItem(icon: Icon(Icons.analytics), label: '数据评估'),
              BottomNavigationBarItem(icon: Icon(Icons.map), label: '地图'),
              BottomNavigationBarItem(icon: Icon(Icons.person), label: '我的'),
            ],
          ),
        ),
      ),
    );
  }
}
