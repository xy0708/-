import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/health_alert.dart';
import '../../providers/alert_provider.dart';

class AlertsPage extends StatelessWidget {
  const AlertsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final alertProvider = context.watch<AlertProvider>();
    final alerts = alertProvider.alerts;

    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('健康预警'),
      ),
      body: alertProvider.isLoading && alerts.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : alerts.isEmpty
              ? _buildEmpty(context)
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: alerts.length,
                  itemBuilder: (_, i) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _alertCard(alerts[i]),
                  ),
                ),
    );
  }

  Widget _buildEmpty(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.verified_user_outlined, size: 64, color: AppTheme.primaryGreen),
          const SizedBox(height: 12),
          const Text('暂无预警', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text('各项指标平稳，请继续保持良好习惯', style: TextStyle(color: context.textSecondary)),
        ],
      ),
    );
  }

  Widget _alertCard(HealthAlert alert) {
    final (icon, color, levelName) = switch (alert.level) {
      AlertLevel.danger => (Icons.dangerous_outlined, AppTheme.warningRed, '危险'),
      AlertLevel.warning => (Icons.warning_amber_rounded, Colors.orange, '关注'),
      AlertLevel.info => (Icons.info_outline, AppTheme.accentBlue, '提示'),
    };

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              backgroundColor: color.withValues(alpha: 0.12),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${alert.memberName} · ${alert.title}',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          levelName,
                          style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(alert.content, style: const TextStyle(fontSize: 13, color: Colors.black87)),
                  const SizedBox(height: 6),
                  Text(
                    DateFormat('MM-dd HH:mm').format(alert.createdAt),
                    style: const TextStyle(fontSize: 11, color: Colors.grey),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
