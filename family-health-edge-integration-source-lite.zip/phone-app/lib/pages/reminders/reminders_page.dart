import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/reminder.dart';
import '../../providers/reminder_provider.dart';
import '../../services/notification_service.dart';

Color _typeColor(ReminderType type) => switch (type) {
      ReminderType.medicine => AppTheme.primaryGreen,
      ReminderType.bloodPressure => AppTheme.warningRed,
      ReminderType.bloodSugar => AppTheme.accentBlue,
      ReminderType.water => Colors.lightBlue,
      ReminderType.custom => Colors.deepPurple,
    };

IconData _typeIcon(ReminderType type) => switch (type) {
      ReminderType.medicine => Icons.medication,
      ReminderType.bloodPressure => Icons.favorite,
      ReminderType.bloodSugar => Icons.opacity,
      ReminderType.water => Icons.local_drink,
      ReminderType.custom => Icons.alarm,
    };

class RemindersPage extends StatefulWidget {
  const RemindersPage({super.key});

  @override
  State<RemindersPage> createState() => _RemindersPageState();
}

class _RemindersPageState extends State<RemindersPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ReminderProvider>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ReminderProvider>();

    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('健康提醒'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_active_outlined),
            tooltip: '通知诊断',
            onPressed: () => _runDiagnostics(context),
          ),
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showEditDialog(context),
          ),
        ],
      ),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                if (!NotificationService.instance.isReady) _buildNotReadyNotice(context),
                Expanded(
                  child: provider.reminders.isEmpty
                      ? _buildEmpty(context)
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: provider.reminders.length,
                          itemBuilder: (_, i) {
                            final reminder = provider.reminders[i];
                            return Card(
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: _typeColor(reminder.type)
                                      .withValues(alpha: 0.12),
                                  child: Icon(_typeIcon(reminder.type),
                                      color: _typeColor(reminder.type)),
                                ),
                                title: Text(
                                  reminder.title,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    decoration: reminder.enabled
                                        ? null
                                        : TextDecoration.lineThrough,
                                    color: reminder.enabled
                                        ? null
                                        : context.textSecondary,
                                  ),
                                ),
                                subtitle: Text('每天 ${reminder.timeText}'),
                                trailing: Switch(
                                  value: reminder.enabled,
                                  onChanged: (v) => provider
                                      .update(reminder.copyWith(enabled: v)),
                                ),
                                onTap: () => _showEditDialog(context,
                                    reminder: reminder),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }

  Widget _buildNotReadyNotice(BuildContext context) {
    return Card(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      color: AppTheme.warningRed.withValues(alpha: 0.08),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: AppTheme.warningRed),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                '系统通知不可用，提醒可能不会弹出。请检查系统通知权限，'
                '或使用右上角「通知诊断」排查。',
                style: TextStyle(fontSize: 13, color: context.textSecondary),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 通知诊断：逐项检查初始化/权限/系统开关/测试通知/已注册定时数。
  Future<void> _runDiagnostics(BuildContext context) async {
    final service = NotificationService.instance;
    final granted = await service.requestPermission();
    final enabled = await service.notificationsEnabled();
    final testSent = await service.showTestNotification();
    final pending = await service.pendingCount();

    if (!context.mounted) return;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('通知诊断'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _diagnosticRow('通知服务初始化', service.isReady ? '正常' : '失败（环境可能不支持）',
                ok: service.isReady),
            _diagnosticRow('通知权限', granted ? '已授予' : '未授予', ok: granted),
            _diagnosticRow('系统通知开关', enabled ? '已开启' : '已关闭', ok: enabled),
            _diagnosticRow('测试通知', testSent ? '已发送（请看通知栏）' : '发送失败', ok: testSent),
            _diagnosticRow('已注册定时提醒', '$pending 条', ok: pending > 0),
            if (service.lastError != null) ...[
              const SizedBox(height: 6),
              Text(
                '最后错误：${service.lastError}',
                style: const TextStyle(fontSize: 12, color: AppTheme.warningRed),
              ),
            ],
            const SizedBox(height: 8),
            Text(
              '说明：测试通知能收到、但定时提醒到点不弹，通常是兼容环境'
              '限制了定时闹钟；此时真实安卓手机不受影响。',
              style: TextStyle(fontSize: 12, color: context.textSecondary),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => _rescheduleAll(context),
            child: const Text('重新注册提醒'),
          ),
          TextButton(
            onPressed: () => service.openSystemNotificationSettings(),
            child: const Text('去系统设置'),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('知道了')),
        ],
      ),
    );
  }

  /// 一键重新注册全部提醒，并反馈注册后的待发数量。
  Future<void> _rescheduleAll(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final provider = context.read<ReminderProvider>();
    Navigator.pop(context);
    await provider.rescheduleAll();
    final pending = await NotificationService.instance.pendingCount();
    final error = NotificationService.instance.lastError;
    messenger.showSnackBar(SnackBar(
      content: Text(error == null
          ? '已重新注册，当前待发提醒 $pending 条'
          : '注册失败：$error'),
    ));
  }

  Widget _diagnosticRow(String label, String value, {required bool ok}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Icon(ok ? Icons.check_circle : Icons.cancel,
              size: 18, color: ok ? AppTheme.primaryGreen : AppTheme.warningRed),
          const SizedBox(width: 8),
          Expanded(child: Text('$label：$value', style: const TextStyle(fontSize: 13))),
        ],
      ),
    );
  }

  Widget _buildEmpty(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.notifications_off_outlined,
              size: 64, color: context.textSecondary),
          const SizedBox(height: 12),
          Text('暂无健康提醒', style: TextStyle(color: context.textSecondary)),
          const SizedBox(height: 4),
          Text('点击右上角 + 添加吃药、测血压等提醒',
              style: TextStyle(color: context.textSecondary, fontSize: 12)),
        ],
      ),
    );
  }

  Future<void> _showEditDialog(BuildContext context, {Reminder? reminder}) async {
    final granted = await NotificationService.instance.requestPermission();
    if (context.mounted && !granted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('未授予通知权限，提醒将无法弹出，请在系统设置中开启通知')),
      );
    }
    if (!context.mounted) return;
    await showDialog(
      context: context,
      builder: (_) => _ReminderEditDialog(reminder: reminder),
    );
  }
}

class _ReminderEditDialog extends StatefulWidget {
  final Reminder? reminder;

  const _ReminderEditDialog({this.reminder});

  @override
  State<_ReminderEditDialog> createState() => _ReminderEditDialogState();
}

class _ReminderEditDialogState extends State<_ReminderEditDialog> {
  late ReminderType _type = widget.reminder?.type ?? ReminderType.medicine;
  late TimeOfDay _time = widget.reminder != null
      ? TimeOfDay(hour: widget.reminder!.hour, minute: widget.reminder!.minute)
      : const TimeOfDay(hour: 8, minute: 0);
  late final TextEditingController _titleController;

  @override
  void initState() {
    super.initState();
    _titleController =
        TextEditingController(text: widget.reminder?.customTitle ?? '');
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.reminder == null ? '添加提醒' : '编辑提醒'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('提醒类型', style: TextStyle(fontSize: 13, color: context.textSecondary)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ReminderType.values.map((t) {
                final selected = t == _type;
                return ChoiceChip(
                  label: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(_typeIcon(t),
                        size: 16, color: selected ? Colors.white : null),
                    const SizedBox(width: 4),
                    Text(t.label),
                  ]),
                  selected: selected,
                  selectedColor: _typeColor(t),
                  checkmarkColor: Colors.white,
                  labelStyle: TextStyle(color: selected ? Colors.white : null),
                  onSelected: (_) => setState(() => _type = t),
                );
              }).toList(),
            ),
            if (_type == ReminderType.custom) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _titleController,
                autofocus: true,
                decoration: const InputDecoration(
                  labelText: '提醒内容',
                  hintText: '例如：降压药',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.schedule),
              title: const Text('提醒时间'),
              trailing: Text(
                _time.format(context),
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              onTap: () async {
                final picked =
                    await showTimePicker(context: context, initialTime: _time);
                if (picked != null) setState(() => _time = picked);
              },
            ),
          ],
        ),
      ),
      actions: [
        if (widget.reminder != null)
          TextButton(
            onPressed: () {
              context.read<ReminderProvider>().remove(widget.reminder!.id);
              Navigator.pop(context);
            },
            child: const Text('删除', style: TextStyle(color: AppTheme.warningRed)),
          ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('取消'),
        ),
        FilledButton.icon(
          onPressed: _save,
          icon: const Icon(Icons.check),
          label: const Text('保存'),
        ),
      ],
    );
  }

  Future<void> _save() async {
    final title = _titleController.text.trim();
    if (_type == ReminderType.custom && title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请填写提醒内容')),
      );
      return;
    }
    final provider = context.read<ReminderProvider>();
    final reminder = Reminder(
      id: widget.reminder?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      type: _type,
      customTitle: _type == ReminderType.custom ? title : '',
      hour: _time.hour,
      minute: _time.minute,
      enabled: widget.reminder?.enabled ?? true,
    );
    if (widget.reminder == null) {
      await provider.add(reminder);
    } else {
      await provider.update(reminder);
    }
    if (mounted) Navigator.pop(context);
  }
}
