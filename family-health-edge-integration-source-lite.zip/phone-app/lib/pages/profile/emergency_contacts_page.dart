import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../providers/emergency_contact_provider.dart';
import '../../models/emergency_contact.dart';
import '../../core/theme/app_theme.dart';

class EmergencyContactsPage extends StatefulWidget {
  const EmergencyContactsPage({super.key});

  @override
  State<EmergencyContactsPage> createState() => _EmergencyContactsPageState();
}

class _EmergencyContactsPageState extends State<EmergencyContactsPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<EmergencyContactProvider>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<EmergencyContactProvider>();

    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('紧急联系人'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showEditDialog(context),
          ),
        ],
      ),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : provider.contacts.isEmpty
              ? _buildEmpty()
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: provider.contacts.length,
                  itemBuilder: (_, i) {
                    final contact = provider.contacts[i];
                    return Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: AppTheme.warningRed.withValues(alpha: 0.1),
                          child: const Icon(Icons.emergency, color: AppTheme.warningRed),
                        ),
                        title: Text(contact.name),
                        subtitle: Text('${contact.relation} • ${contact.phone}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.phone),
                              color: AppTheme.primaryGreen,
                              onPressed: () => _launchPhone(contact.phone),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () => _confirmDelete(context, contact),
                            ),
                          ],
                        ),
                        onTap: () => _showEditDialog(context, contact: contact),
                      ),
                    );
                  },
                ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.emergency_share, size: 64, color: context.textSecondary),
          const SizedBox(height: 12),
          Text('暂无紧急联系人', style: TextStyle(color: context.textSecondary)),
          const SizedBox(height: 4),
          Text('点击右上角 + 添加', style: TextStyle(color: context.textSecondary, fontSize: 12)),
        ],
      ),
    );
  }

  Future<void> _showEditDialog(
    BuildContext context, {
    EmergencyContact? contact,
  }) async {
    final nameController = TextEditingController(text: contact?.name ?? '');
    final phoneController = TextEditingController(text: contact?.phone ?? '');
    final relationController = TextEditingController(text: contact?.relation ?? '');

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(contact == null ? '添加紧急联系人' : '编辑紧急联系人'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: '姓名', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: const InputDecoration(labelText: '手机号', border: OutlineInputBorder()),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: relationController,
                decoration: const InputDecoration(
                  labelText: '关系',
                  hintText: '例如 父亲 / 母亲 / 配偶',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          FilledButton(
            onPressed: () {
              final name = nameController.text.trim();
              final phone = phoneController.text.trim();
              if (name.isEmpty || phone.isEmpty) return;
              final provider = context.read<EmergencyContactProvider>();
              if (contact == null) {
                provider.add(EmergencyContact(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  name: name,
                  phone: phone,
                  relation: relationController.text.trim(),
                ));
              } else {
                provider.update(EmergencyContact(
                  id: contact.id,
                  name: name,
                  phone: phone,
                  relation: relationController.text.trim(),
                ));
              }
              Navigator.pop(ctx);
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, EmergencyContact contact) async {
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除联系人'),
        content: Text('确定删除「${contact.name}」吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () {
              context.read<EmergencyContactProvider>().remove(contact.id);
              Navigator.pop(ctx);
            },
            child: const Text('删除', style: TextStyle(color: AppTheme.warningRed)),
          ),
        ],
      ),
    );
  }

  Future<void> _launchPhone(String number) async {
    final uri = Uri.parse('tel:$number');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }
}
