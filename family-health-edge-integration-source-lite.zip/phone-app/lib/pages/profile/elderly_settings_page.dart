import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/elderly_settings_provider.dart';
import '../../core/theme/app_theme.dart';

class ElderlySettingsPage extends StatefulWidget {
  const ElderlySettingsPage({super.key});

  @override
  State<ElderlySettingsPage> createState() => _ElderlySettingsPageState();
}

class _ElderlySettingsPageState extends State<ElderlySettingsPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ElderlySettingsProvider>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ElderlySettingsProvider>();
    final settings = provider.settings;

    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('助老系统参数'),
      ),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                SwitchListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                  secondary: Icon(
                    Icons.accessibility_new,
                    size: 32,
                    color: settings.elderlyMode ? AppTheme.primaryGreen : context.textSecondary,
                  ),
                  title: const Text('助老模式', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  subtitle: const Text('全局大字体、高对比度显示，适合老人使用'),
                  value: settings.elderlyMode,
                  onChanged: (v) {
                    provider.update(settings.copyWith(elderlyMode: v));
                  },
                ),
                const Divider(height: 24),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const Icon(Icons.volume_up, color: AppTheme.primaryGreen),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('播报语速'),
                              Text(
                                _speedLabel(settings.speakSpeed),
                                style: TextStyle(fontSize: 12, color: context.textSecondary),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Slider(
                    value: settings.speakSpeed,
                    min: 0.5,
                    max: 2.0,
                    divisions: 3,
                    label: _speedLabel(settings.speakSpeed),
                    onChanged: (v) {
                      provider.update(settings.copyWith(speakSpeed: v));
                    },
                  ),
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  secondary: const Icon(Icons.bluetooth, color: AppTheme.accentBlue),
                  title: const Text('自动连接蓝牙设备'),
                  subtitle: const Text('打开 APP 时自动连接已绑定设备'),
                  value: settings.autoConnectBluetooth,
                  onChanged: (v) {
                    provider.update(settings.copyWith(autoConnectBluetooth: v));
                  },
                ),
                const Divider(height: 1),
                SwitchListTile(
                  secondary: const Icon(Icons.record_voice_over, color: AppTheme.accentBlue),
                  title: const Text('语音播报'),
                  subtitle: const Text('体征数据变化时语音播报提醒'),
                  value: settings.readAloud,
                  onChanged: (v) {
                    provider.update(settings.copyWith(readAloud: v));
                  },
                ),
                const Divider(height: 1),
                const ListTile(
                  leading: Icon(Icons.info_outline),
                  title: Text('关于助老模式', style: TextStyle(fontSize: 14)),
                  subtitle: Text('开启后全局大字体、高对比度显示，数据看板体征卡改为大卡片布局。'),
                ),
              ],
            ),
    );
  }

  String _speedLabel(double speed) {
    if (speed <= 0.75) return '慢速';
    if (speed <= 1.25) return '标准';
    if (speed <= 1.75) return '较快';
    return '快速';
  }
}
