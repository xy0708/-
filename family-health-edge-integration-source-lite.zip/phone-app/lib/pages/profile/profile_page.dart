import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/device_provider.dart';
import '../../providers/family_provider.dart';
import '../../providers/settings_provider.dart';
import '../../providers/reminder_provider.dart';
import '../../providers/health_provider.dart';
import '../../providers/edge_connection_provider.dart';
import '../../core/theme/app_theme.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DeviceProvider>().scanDevices();
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final devices = context.watch<DeviceProvider>();
    final family = context.watch<FamilyProvider>();
    final health = context.watch<HealthProvider>();
    final edge = context.watch<EdgeConnectionProvider>();

    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('我的'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildUserHeader(auth),
            const SizedBox(height: 16),
            _buildDeviceSection(devices),
            const SizedBox(height: 16),
            _buildEdgeSection(context, edge, family, health),
            const SizedBox(height: 16),
            _buildFamilySection(family),
            const SizedBox(height: 16),
            _buildSettingsSection(auth),
          ],
        ),
      ),
    );
  }

  Widget _buildEdgeSection(
    BuildContext context,
    EdgeConnectionProvider edge,
    FamilyProvider family,
    HealthProvider health,
  ) {
    return Card(
      child: ListTile(
        leading: Icon(
          edge.isConfigured ? Icons.lan : Icons.lan_outlined,
          color: edge.isConfigured ? AppTheme.primaryGreen : null,
        ),
        title: const Text('家庭端侧连接'),
        subtitle: Text(
          edge.isConfigured
              ? '已验证 ${edge.endpoint}'
              : edge.lastError ?? '未连接；正式产品将改为安全配对',
        ),
        trailing: edge.isVerifying
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : edge.isConfigured
                ? TextButton(
                    onPressed: edge.disconnect,
                    child: const Text('断开'),
                  )
                : const Icon(Icons.chevron_right),
        onTap: edge.isVerifying || edge.isConfigured
            ? null
            : () => _showEdgeConnectionDialog(
                  context,
                  edge,
                  health.activeMemberId ??
                      (family.members.isEmpty ? '' : family.members.first.id),
                ),
      ),
    );
  }

  Future<void> _showEdgeConnectionDialog(
    BuildContext context,
    EdgeConnectionProvider edge,
    String initialMemberId,
  ) async {
    final endpointController =
        TextEditingController(text: 'https://192.168.1.10:18100');
    final tokenController = TextEditingController();
    final memberController = TextEditingController(text: initialMemberId);
    var busy = false;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('验证家庭端侧'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  '当前为工程配对入口，令牌只保存在本次 APP 进程内。',
                  style: TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: endpointController,
                  enabled: !busy,
                  decoration: const InputDecoration(
                    labelText: 'HTTPS 地址',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: tokenController,
                  enabled: !busy,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: '运行期令牌',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: memberController,
                  enabled: !busy,
                  decoration: const InputDecoration(
                    labelText: '成员 ID',
                    border: OutlineInputBorder(),
                  ),
                ),
                if (edge.lastError != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    edge.lastError!,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                      fontSize: 12,
                    ),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: busy ? null : () => Navigator.pop(dialogContext),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      setDialogState(() => busy = true);
                      final verified = await edge.configureAndVerify(
                        endpoint: endpointController.text,
                        bearerToken: tokenController.text,
                        memberId: memberController.text,
                      );
                      if (!dialogContext.mounted) return;
                      if (verified) {
                        Navigator.pop(dialogContext);
                      } else {
                        setDialogState(() => busy = false);
                      }
                    },
              child: Text(busy ? '验证中...' : '保存并验证'),
            ),
          ],
        ),
      ),
    );
    endpointController.dispose();
    tokenController.dispose();
    memberController.dispose();
  }

  Widget _buildUserHeader(AuthProvider auth) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: AppTheme.primaryGreen.withValues(alpha: 0.2),
              child: Text(
                (auth.userName ?? '?')[0],
                style: const TextStyle(
                  fontSize: 24,
                  color: AppTheme.primaryGreen,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  auth.userName ?? '未登录',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  auth.phone ?? '',
                  style: TextStyle(color: context.textSecondary),
                ),
              ],
            ),
            const Spacer(),
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => _showEditProfileDialog(context, auth),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeviceSection(DeviceProvider devices) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text(
                  '设备管理',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                if (devices.isScanning)
                  const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                TextButton.icon(
                  onPressed:
                      devices.isScanning ? null : () => devices.scanDevices(),
                  icon: const Icon(Icons.refresh, size: 18),
                  label: const Text('扫描'),
                ),
              ],
            ),
            if (devices.lastError != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  devices.lastError!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              ),
            ...devices.devices.map(
              (d) => ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(
                  d.isConnected
                      ? Icons.bluetooth_connected
                      : Icons.bluetooth_disabled,
                  color: d.isConnected
                      ? AppTheme.primaryGreen
                      : context.textSecondary,
                ),
                title: Text(d.name),
                subtitle: Text('电量: ${d.batteryLevel}%'),
                trailing: Switch(
                  value: d.isConnected,
                  onChanged: (value) => devices.setConnection(d.id, value),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFamilySection(FamilyProvider family) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text(
                  '家庭成员',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                TextButton.icon(
                  onPressed: () => Navigator.pushNamed(context, '/family'),
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('管理'),
                ),
              ],
            ),
            ...family.members.map(
              (m) => ListTile(
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(
                  backgroundColor: AppTheme.primaryGreen.withValues(alpha: 0.2),
                  child: Text(
                    m.name[0],
                    style: const TextStyle(color: AppTheme.primaryGreen),
                  ),
                ),
                title: Text(m.name),
                subtitle: Text('${m.relation} • ${m.age}岁'),
                trailing: m.medicalHistory != null
                    ? Chip(
                        label: Text(
                          m.medicalHistory!,
                          style: const TextStyle(fontSize: 10),
                        ),
                        visualDensity: VisualDensity.compact,
                      )
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingsSection(AuthProvider auth) {
    return Card(
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.medical_services_outlined),
            title: const Text('个人病史档案'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.pushNamed(context, '/medical-history'),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.emergency_outlined),
            title: const Text('紧急联系人'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.pushNamed(context, '/emergency-contacts'),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.notifications_active_outlined),
            title: const Text('健康提醒'),
            subtitle: Text(
              '吃药、测血压等定时提醒（${context.watch<ReminderProvider>().enabledCount} 个已启用）',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.pushNamed(context, '/reminders'),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('助老系统参数'),
            subtitle: const Text('播报语速、蓝牙配置'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.pushNamed(context, '/elderly-settings'),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.dark_mode_outlined),
            title: const Text('深色模式'),
            subtitle: Text(
              _themeModeLabel(context.watch<SettingsProvider>().themeMode),
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showThemeModeDialog(context),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.logout, color: AppTheme.warningRed),
            title: const Text(
              '退出登录',
              style: TextStyle(color: AppTheme.warningRed),
            ),
            onTap: () => _showLogoutDialog(context, auth),
          ),
        ],
      ),
    );
  }

  String _themeModeLabel(ThemeMode mode) => switch (mode) {
        ThemeMode.system => '跟随系统',
        ThemeMode.light => '浅色',
        ThemeMode.dark => '深色',
      };

  void _showThemeModeDialog(BuildContext context) {
    final provider = context.read<SettingsProvider>();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('深色模式'),
        content: RadioGroup<ThemeMode>(
          groupValue: provider.themeMode,
          onChanged: (mode) {
            if (mode != null) provider.setThemeMode(mode);
            Navigator.pop(ctx);
          },
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              RadioListTile<ThemeMode>(
                value: ThemeMode.system,
                title: Text('跟随系统'),
              ),
              RadioListTile<ThemeMode>(
                value: ThemeMode.light,
                title: Text('浅色'),
              ),
              RadioListTile<ThemeMode>(
                value: ThemeMode.dark,
                title: Text('深色'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showEditProfileDialog(BuildContext context, AuthProvider auth) {
    final nameController = TextEditingController(text: auth.userName ?? '');
    final phoneController = TextEditingController(text: auth.phone ?? '');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('编辑个人信息'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: '姓名',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: const InputDecoration(
                  labelText: '手机号',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () {
              final name = nameController.text.trim();
              final phone = phoneController.text.trim();
              if (name.isEmpty || phone.isEmpty) return;
              auth.updateProfile(name: name, phone: phone);
              Navigator.pop(ctx);
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog(BuildContext context, AuthProvider auth) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('退出登录'),
        content: const Text('确定要退出登录吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              auth.logout();
              Navigator.pop(ctx);
              Navigator.of(context).pushReplacementNamed('/login');
            },
            child: const Text(
              '确定',
              style: TextStyle(color: AppTheme.warningRed),
            ),
          ),
        ],
      ),
    );
  }
}
