import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/medical_history_provider.dart';
import '../../models/medical_history_entry.dart';
import '../../core/theme/app_theme.dart';

class MedicalHistoryPage extends StatefulWidget {
  const MedicalHistoryPage({super.key});

  @override
  State<MedicalHistoryPage> createState() => _MedicalHistoryPageState();
}

class _MedicalHistoryPageState extends State<MedicalHistoryPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<MedicalHistoryProvider>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MedicalHistoryProvider>();

    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('个人病史档案'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showEditDialog(context),
          ),
        ],
      ),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : provider.entries.isEmpty
              ? _buildEmpty()
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: provider.entries.length,
                  itemBuilder: (_, i) {
                    final entry = provider.entries[i];
                    return Card(
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: Color(0x332196F3),
                          child: Icon(Icons.medication, color: AppTheme.accentBlue),
                        ),
                        title: Text(entry.name),
                        subtitle: entry.diagnosedAt != null
                            ? Text('确诊时间: ${entry.diagnosedAt}')
                            : null,
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => _confirmDelete(context, entry),
                        ),
                        onTap: () => _showEditDialog(context, entry: entry),
                      ),
                    );
                  },
                ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.folder_open, size: 64, color: context.textSecondary),
          const SizedBox(height: 12),
          Text('暂无病史档案', style: TextStyle(color: context.textSecondary)),
          const SizedBox(height: 4),
          Text('点击右上角 + 添加', style: TextStyle(color: context.textSecondary, fontSize: 12)),
        ],
      ),
    );
  }

  Future<void> _showEditDialog(
    BuildContext context, {
    MedicalHistoryEntry? entry,
  }) async {
    final nameController = TextEditingController(text: entry?.name ?? '');
    final dateController = TextEditingController(text: entry?.diagnosedAt ?? '');
    final noteController = TextEditingController(text: entry?.note ?? '');

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(entry == null ? '添加病史' : '编辑病史'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: '疾病/过敏名称', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: dateController,
                decoration: const InputDecoration(
                  labelText: '确诊时间',
                  hintText: '例如 2023-05',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: noteController,
                decoration: const InputDecoration(labelText: '备注', border: OutlineInputBorder()),
                maxLines: 2,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          FilledButton(
            onPressed: () {
              final name = nameController.text.trim();
              if (name.isEmpty) return;
              final provider = context.read<MedicalHistoryProvider>();
              if (entry == null) {
                provider.add(MedicalHistoryEntry(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  name: name,
                  diagnosedAt: dateController.text.trim().isEmpty ? null : dateController.text.trim(),
                  note: noteController.text.trim().isEmpty ? null : noteController.text.trim(),
                ));
              } else {
                provider.update(MedicalHistoryEntry(
                  id: entry.id,
                  name: name,
                  diagnosedAt: dateController.text.trim().isEmpty ? null : dateController.text.trim(),
                  note: noteController.text.trim().isEmpty ? null : noteController.text.trim(),
                ));
              }
              Navigator.pop(ctx);
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, MedicalHistoryEntry entry) async {
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除病史'),
        content: Text('确定删除「${entry.name}」吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () {
              context.read<MedicalHistoryProvider>().remove(entry.id);
              Navigator.pop(ctx);
            },
            child: const Text('删除', style: TextStyle(color: AppTheme.warningRed)),
          ),
        ],
      ),
    );
  }
}
