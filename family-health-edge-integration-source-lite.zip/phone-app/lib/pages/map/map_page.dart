import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/network/poi_client.dart';
import '../../core/routes/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../models/hospital.dart';
import '../../providers/emergency_contact_provider.dart';

/// 就医导航页：定位当前位置、附近医疗机构、绿色通道与紧急求助。
///
/// 真实定位依赖 geolocator + 运行时定位权限，失败时优雅降级为提示文案；
/// 医疗机构数据目前为本地演示数据（见 [MockMedicalData]），后续由后端下发。
class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  String _address = '暂未获取定位，点右侧刷新获取当前位置';
  bool _isLocating = false;
  Position? _lastPosition;
  List<Hospital>? _hospitals;
  bool _loadingHospitals = false;
  String? _hospitalError;

  @override
  void initState() {
    super.initState();
    // 主页使用 IndexedStack，本页 initState 在启动时即会执行；
    // 仅在已授予定位权限时静默定位，避免首次启动弹出权限申请。
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final status = await Permission.locationWhenInUse.status;
      if (status.isGranted || status.isLimited) _locate();
    });
  }

  Future<void> _locate() async {
    if (_isLocating) return;
    setState(() => _isLocating = true);

    String address;
    try {
      final status = await Permission.locationWhenInUse.request();
      if (status.isGranted || status.isLimited) {
        final position = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high,
            timeLimit: Duration(seconds: 8),
          ),
        );
        _lastPosition = position;
        address = await _reverseGeocode(position);
        _loadHospitals(position);
      } else {
        address = '未授予定位权限，无法获取当前位置';
        _toast('请授予定位权限后重试');
      }
    } catch (_) {
      address = '定位失败，请检查设备定位服务后重试';
    }

    if (!mounted) return;
    setState(() {
      _address = address;
      _isLocating = false;
    });
  }

  /// 基于定位结果检索附近医疗机构（Overpass/OSM，失败时提示重试）。
  Future<void> _loadHospitals(Position position) async {
    setState(() {
      _loadingHospitals = true;
      _hospitalError = null;
    });
    try {
      final list = await PoiClient.fetchNearbyMedical(
        latitude: position.latitude,
        longitude: position.longitude,
      );
      if (!mounted) return;
      setState(() {
        _hospitals = list;
        _loadingHospitals = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _hospitalError = 'POI 服务暂不可用';
        _loadingHospitals = false;
      });
    }
  }

  void _retryHospitals() {
    final position = _lastPosition;
    if (position != null) {
      _loadHospitals(position);
    } else {
      _locate();
    }
  }

  /// 逆地理编码解析中文地址；解析失败时降级展示经纬度。
  Future<String> _reverseGeocode(Position position) async {
    try {
      final placemarks = await Geocoding()
          .placemarkFromCoordinates(position.latitude, position.longitude)
          .timeout(const Duration(seconds: 5));
      final p = placemarks.firstOrNull;
      final parts = [
        p?.administrativeArea,
        p?.locality,
        p?.subLocality,
        p?.thoroughfare,
        p?.name,
      ].whereType<String>().where((s) => s.trim().isNotEmpty).toList();
      if (parts.isEmpty) throw Exception('未解析到地址');
      return parts.join();
    } catch (_) {
      return '纬度${position.latitude.toStringAsFixed(4)}，经度${position.longitude.toStringAsFixed(4)}';
    }
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('就医导航'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildLocationCard(),
            const SizedBox(height: 16),
            _buildQuickActions(context),
            const SizedBox(height: 16),
            _buildHospitalList(context),
            const SizedBox(height: 16),
            _buildEmergencyButton(context),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationCard() {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: AppTheme.accentBlue.withValues(alpha: 0.12),
          child: Icon(
            _isLocating ? Icons.location_searching : Icons.my_location,
            color: AppTheme.accentBlue,
          ),
        ),
        title: const Text('当前位置'),
        subtitle: Text(_address),
        trailing: IconButton(
          icon: _isLocating
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.refresh),
          onPressed: _isLocating ? null : _locate,
        ),
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    return Row(
      children: [
        Expanded(child: _actionCard(context, Icons.local_hospital, '附近医院', () => _showNearbyHospitals(context))),
        const SizedBox(width: 8),
        Expanded(child: _actionCard(context, Icons.emergency, '绿色通道', () => _showGreenChannelDialog(context))),
        const SizedBox(width: 8),
        Expanded(child: _actionCard(context, Icons.help_outline, '紧急求助', () => _showEmergencyDialog(context))),
      ],
    );
  }

  Widget _actionCard(BuildContext context, IconData icon, String label, VoidCallback onTap) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            children: [
              Icon(icon, size: 32, color: AppTheme.primaryGreen),
              const SizedBox(height: 8),
              Text(label, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHospitalList(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('附近医疗机构', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        if (_loadingHospitals)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                  const SizedBox(width: 10),
                  Text('正在检索附近医疗机构...', style: TextStyle(color: context.textSecondary)),
                ],
              ),
            ),
          )
        else if (_hospitalError != null)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Text('附近医疗机构检索失败（$_hospitalError）',
                        style: TextStyle(color: context.textSecondary)),
                  ),
                  TextButton.icon(
                    onPressed: _retryHospitals,
                    icon: const Icon(Icons.refresh, size: 18),
                    label: const Text('重试'),
                  ),
                ],
              ),
            ),
          )
        else if (_hospitals == null)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.location_searching, size: 18, color: context.textSecondary),
                  const SizedBox(width: 8),
                  Text('获取定位后自动检索附近的医疗机构', style: TextStyle(color: context.textSecondary)),
                ],
              ),
            ),
          )
        else if (_hospitals!.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Center(child: Text('附近5公里内未检索到医疗机构', style: TextStyle(color: context.textSecondary))),
            ),
          )
        else
          ..._hospitals!.map((h) => Card(
                child: ListTile(
                  leading: const Icon(Icons.local_hospital, color: AppTheme.primaryGreen),
                  title: Text(h.name),
                  subtitle: Text('${h.distanceText} • ${h.kindText}'),
                  trailing: TextButton(
                    onPressed: () => _launchNavigation(h.name, h.latitude, h.longitude),
                    child: const Text('导航'),
                  ),
                ),
              )),
      ],
    );
  }

  Widget _buildEmergencyButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: FilledButton.icon(
        onPressed: () => _showEmergencyDialog(context),
        icon: const Icon(Icons.warning),
        label: const Text('紧急求助', style: TextStyle(fontSize: 16)),
        style: FilledButton.styleFrom(backgroundColor: AppTheme.warningRed),
      ),
    );
  }

  void _showNearbyHospitals(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: context.textSecondary.withValues(alpha: 0.4),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text('附近医疗机构', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            if (_loadingHospitals)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
              )
            else if (_hospitals == null || _hospitals!.isEmpty)
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text('请先完成定位后再查看附近医疗机构', style: TextStyle(color: context.textSecondary)),
              )
            else
              ..._hospitals!.map((h) => ListTile(
                    leading: const Icon(Icons.local_hospital, color: AppTheme.primaryGreen),
                    title: Text(h.name),
                    subtitle: Text('${h.distanceText} • ${h.kindText}'),
                    trailing: TextButton(
                      onPressed: () {
                        Navigator.pop(sheetContext);
                        _launchNavigation(h.name, h.latitude, h.longitude);
                      },
                      child: const Text('导航'),
                    ),
                  )),
          ],
        ),
      ),
    );
  }

  void _showGreenChannelDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.emergency, color: AppTheme.primaryGreen),
            SizedBox(width: 8),
            Text('绿色通道'),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('绿色通道是为急危重症患者提供的快速就医服务，可缩短挂号、检查、入院等环节的等待时间。'),
              const SizedBox(height: 12),
              const Text('适用情况：', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('• 急性胸痛、胸闷、呼吸困难'),
              const Text('• 突发意识障碍、抽搐'),
              const Text('• 严重外伤、大出血'),
              const Text('• 急性中毒'),
              const Text('• 其他经医生评估需紧急处理的情况'),
              const SizedBox(height: 12),
              Text('如遇紧急情况，请立即拨打120或前往最近医院急诊科。', style: TextStyle(color: context.textSecondary)),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('我知道了')),
        ],
      ),
    );
  }

  void _showEmergencyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.warning, color: AppTheme.warningRed),
            SizedBox(width: 8),
            Text('紧急求助'),
          ],
        ),
        content: const Text('是否立即拨打急救电话或通知紧急联系人？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _showContactPicker(context);
            },
            child: const Text('通知紧急联系人'),
          ),
          FilledButton.icon(
            onPressed: () {
              Navigator.pop(ctx);
              _launchPhone('120');
            },
            icon: const Icon(Icons.phone, size: 18),
            label: const Text('拨打120'),
            style: FilledButton.styleFrom(backgroundColor: AppTheme.warningRed),
          ),
        ],
      ),
    );
  }

  /// 选择紧急联系人进行拨打或发送求助短信。
  void _showContactPicker(BuildContext context) {
    final contacts = context.read<EmergencyContactProvider>().contacts;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.contacts, color: AppTheme.primaryGreen),
            SizedBox(width: 8),
            Text('通知紧急联系人'),
          ],
        ),
        content: contacts.isEmpty
            ? const Text('尚未添加紧急联系人。添加后可在紧急情况下一键拨打或发送求助短信。')
            : SizedBox(
                width: double.maxFinite,
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: contacts.length,
                  itemBuilder: (_, i) {
                    final c = contacts[i];
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        backgroundColor: AppTheme.primaryGreen.withValues(alpha: 0.2),
                        child: Text(
                          c.name.isNotEmpty ? c.name[0] : '?',
                          style: const TextStyle(color: AppTheme.primaryGreen, fontWeight: FontWeight.bold),
                        ),
                      ),
                      title: Text(c.name),
                      subtitle: Text('${c.relation} • ${c.phone}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.phone, color: AppTheme.primaryGreen),
                            tooltip: '拨打电话',
                            onPressed: () => _launchPhone(c.phone),
                          ),
                          IconButton(
                            icon: const Icon(Icons.sms_outlined, color: AppTheme.accentBlue),
                            tooltip: '发送求助短信',
                            onPressed: () => _launchSms(c.phone),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('关闭')),
          if (contacts.isEmpty)
            FilledButton(
              onPressed: () {
                Navigator.pop(ctx);
                Navigator.pushNamed(context, AppRouter.emergencyContacts);
              },
              child: const Text('去添加'),
            ),
        ],
      ),
    );
  }

  /// 跳转高德地图导航到目的地（未安装高德时打开网页版）。
  Future<void> _launchNavigation(String name, double lat, double lon) async {
    final uri = Uri.parse(
      'https://uri.amap.com/navigation?to=${Uri.encodeComponent('${lon.toStringAsFixed(6)},${lat.toStringAsFixed(6)},$name')}'
      '&mode=car&src=familyhealth&callnative=1',
    );
    try {
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched) _toast('无法打开导航');
    } catch (_) {
      _toast('无法打开导航');
    }
  }

  Future<void> _launchPhone(String number) async {
    final uri = Uri(scheme: 'tel', path: number);
    try {
      final launched = await launchUrl(uri);
      if (!launched) _toast('无法发起拨号');
    } catch (_) {
      _toast('无法发起拨号');
    }
  }

  Future<void> _launchSms(String number) async {
    final uri = Uri(
      scheme: 'sms',
      path: number,
      queryParameters: {'body': '【紧急求助】我可能需要帮助，我当前的位置：$_address，请尽快联系我或拨打120。'},
    );
    try {
      final launched = await launchUrl(uri);
      if (!launched) _toast('无法发送短信');
    } catch (_) {
      _toast('无法发送短信');
    }
  }
}
