import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/family_provider.dart';
import '../../models/family_member.dart';

class FamilyEditPage extends StatefulWidget {
  final FamilyMember? member;

  const FamilyEditPage({super.key, this.member});

  @override
  State<FamilyEditPage> createState() => _FamilyEditPageState();
}

class _FamilyEditPageState extends State<FamilyEditPage> {
  late final TextEditingController _nameController;
  late final TextEditingController _ageController;
  late final TextEditingController _historyController;
  late String _relation;
  late String _gender;

  final _relations = ['本人', '配偶', '父亲', '母亲', '儿子', '女儿', '爷爷', '奶奶', '其他'];
  final _genders = ['男', '女'];

  bool get _isEdit => widget.member != null;

  @override
  void initState() {
    super.initState();
    final m = widget.member;
    _nameController = TextEditingController(text: m?.name ?? '');
    _ageController = TextEditingController(text: m?.age.toString() ?? '');
    _historyController = TextEditingController(text: m?.medicalHistory ?? '');
    _relation = m?.relation ?? '配偶';
    _gender = m?.gender ?? '男';
  }

  @override
  void dispose() {
    _nameController.dispose();
    _ageController.dispose();
    _historyController.dispose();
    super.dispose();
  }

  void _save() {
    final name = _nameController.text.trim();
    if (name.isEmpty) return;

    final family = context.read<FamilyProvider>();
    if (_isEdit) {
      family.updateMember(FamilyMember(
        id: widget.member!.id,
        name: name,
        relation: _relation,
        age: int.tryParse(_ageController.text.trim()) ?? 30,
        gender: _gender,
        medicalHistory: _historyController.text.trim().isEmpty ? null : _historyController.text.trim(),
        hasDevice: widget.member!.hasDevice,
      ));
    } else {
      family.addMember(FamilyMember(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: name,
        relation: _relation,
        age: int.tryParse(_ageController.text.trim()) ?? 30,
        gender: _gender,
        medicalHistory: _historyController.text.trim().isEmpty ? null : _historyController.text.trim(),
      ));
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? '编辑家庭成员' : '添加家庭成员')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: '姓名',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _relation,
              decoration: const InputDecoration(labelText: '关系', border: OutlineInputBorder()),
              items: _relations.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
              onChanged: (v) => setState(() => _relation = v!),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _gender,
              decoration: const InputDecoration(labelText: '性别', border: OutlineInputBorder()),
              items: _genders.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
              onChanged: (v) => setState(() => _gender = v!),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _ageController,
              decoration: const InputDecoration(labelText: '年龄', border: OutlineInputBorder()),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _historyController,
              decoration: const InputDecoration(
                labelText: '病史',
                hintText: '例如 高血压（可选）',
                border: OutlineInputBorder(),
              ),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: FilledButton(onPressed: _save, child: const Text('保存')),
            ),
          ],
        ),
      ),
    );
  }
}
