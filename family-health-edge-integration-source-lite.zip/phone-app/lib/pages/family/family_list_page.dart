import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/family_provider.dart';
import '../../models/family_member.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/member_avatar.dart';

class FamilyListPage extends StatelessWidget {
  const FamilyListPage({super.key});

  @override
  Widget build(BuildContext context) {
    final family = context.watch<FamilyProvider>();

    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: context.overlayStyle,
        title: const Text('家庭成员管理'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add),
            onPressed: () => Navigator.pushNamed(context, '/family/edit'),
          ),
        ],
      ),
      body: family.isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: family.members.length,
              itemBuilder: (_, i) {
                final m = family.members[i];
                return Card(
                  child: ListTile(
                    leading: MemberAvatar(name: m.name, radius: 20),
                    title: Text(m.name),
                    subtitle: Text('${m.relation} • ${m.age}岁 • ${m.gender}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (m.medicalHistory != null)
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: Chip(label: Text(m.medicalHistory!, style: const TextStyle(fontSize: 10)), visualDensity: VisualDensity.compact),
                          ),
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, size: 20),
                          onPressed: () => Navigator.pushNamed(context, '/family/edit', arguments: m),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline, size: 20, color: AppTheme.warningRed),
                          onPressed: () => _confirmDelete(context, m),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, FamilyMember member) async {
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除成员'),
        content: Text('确定删除「${member.name}」吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () {
              context.read<FamilyProvider>().deleteMember(member.id);
              Navigator.pop(ctx);
            },
            child: const Text('删除', style: TextStyle(color: AppTheme.warningRed)),
          ),
        ],
      ),
    );
  }
}
