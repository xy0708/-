import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'providers/auth_provider.dart';
import 'providers/health_provider.dart';
import 'providers/family_provider.dart';
import 'providers/device_provider.dart';
import 'providers/alert_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/reminder_provider.dart';
import 'providers/emergency_contact_provider.dart';
import 'providers/medical_history_provider.dart';
import 'providers/elderly_settings_provider.dart';
import 'providers/edge_connection_provider.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // 主题/助老设置需在 runApp 前加载，避免启动瞬间闪默认样式
  final settings = SettingsProvider();
  await settings.load();
  final elderly = ElderlySettingsProvider();
  await elderly.load();
  // 本地通知服务初始化（不支持系统通知的环境会静默降级）
  await NotificationService.instance.init();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => HealthProvider()),
        ChangeNotifierProvider(create: (_) => FamilyProvider()),
        ChangeNotifierProvider(create: (_) => DeviceProvider()),
        ChangeNotifierProvider(create: (_) => AlertProvider()),
        ChangeNotifierProvider.value(value: settings),
        ChangeNotifierProvider.value(value: elderly),
        ChangeNotifierProvider(create: (_) => ReminderProvider()),
        ChangeNotifierProvider(create: (_) => EmergencyContactProvider()),
        ChangeNotifierProvider(create: (_) => MedicalHistoryProvider()),
        ChangeNotifierProvider(create: (_) => EdgeConnectionProvider()),
      ],
      child: const FamilyHealthApp(),
    ),
  );
}
