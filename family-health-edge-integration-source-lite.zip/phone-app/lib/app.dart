import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'core/routes/app_router.dart';
import 'core/config/app_config.dart';
import 'providers/elderly_settings_provider.dart';
import 'providers/settings_provider.dart';

class FamilyHealthApp extends StatelessWidget {
  const FamilyHealthApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeMode = context.watch<SettingsProvider>().themeMode;
    final elderly =
        context.watch<ElderlySettingsProvider>().settings.elderlyMode;

    return MaterialApp(
      title: '家庭健康管理',
      theme: AppTheme.lightTheme(highContrast: elderly),
      darkTheme: AppTheme.darkTheme(highContrast: elderly),
      themeMode: themeMode,
      initialRoute: AppRouter.splash,
      onGenerateRoute: AppRouter.generateRoute,
      debugShowCheckedModeBanner: false,
      // 助老模式：全局文字放大 1.3 倍
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(
          textScaler: TextScaler.linear(elderly ? 1.3 : 1.0),
        ),
        child: AppConfig.allowDemoData
            ? Banner(
                message: '仅工程演示',
                location: BannerLocation.topEnd,
                color: Colors.deepOrange,
                child: child!,
              )
            : child!,
      ),
    );
  }
}
