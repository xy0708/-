/// 健康提醒类型。
enum ReminderType { medicine, bloodPressure, bloodSugar, water, custom }

extension ReminderTypeLabel on ReminderType {
  String get label => switch (this) {
        ReminderType.medicine => '吃药',
        ReminderType.bloodPressure => '测血压',
        ReminderType.bloodSugar => '测血糖',
        ReminderType.water => '喝水',
        ReminderType.custom => '自定义',
      };
}

class Reminder {
  final String id;
  final ReminderType type;

  /// 自定义类型的提醒文字（如"降压药"），其他类型为空。
  final String customTitle;
  final int hour;
  final int minute;
  final bool enabled;

  const Reminder({
    required this.id,
    required this.type,
    this.customTitle = '',
    required this.hour,
    required this.minute,
    this.enabled = true,
  });

  /// 通知/列表展示的标题。
  String get title => type == ReminderType.custom
      ? (customTitle.trim().isEmpty ? '自定义提醒' : customTitle.trim())
      : type.label;

  String get timeText =>
      '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

  factory Reminder.fromJson(Map<String, dynamic> json) {
    return Reminder(
      id: json['id'] ?? '',
      type: ReminderType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => ReminderType.medicine,
      ),
      customTitle: json['customTitle'] ?? '',
      hour: json['hour'] ?? 8,
      minute: json['minute'] ?? 0,
      enabled: json['enabled'] ?? true,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'customTitle': customTitle,
        'hour': hour,
        'minute': minute,
        'enabled': enabled,
      };

  Reminder copyWith({
    String? id,
    ReminderType? type,
    String? customTitle,
    int? hour,
    int? minute,
    bool? enabled,
  }) {
    return Reminder(
      id: id ?? this.id,
      type: type ?? this.type,
      customTitle: customTitle ?? this.customTitle,
      hour: hour ?? this.hour,
      minute: minute ?? this.minute,
      enabled: enabled ?? this.enabled,
    );
  }
}
