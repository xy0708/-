class ElderlySettings {
  final double speakSpeed;
  final bool autoConnectBluetooth;
  final bool readAloud;

  /// 助老模式总开关：全局大字体、高对比度显示。
  final bool elderlyMode;

  const ElderlySettings({
    this.speakSpeed = 1.0,
    this.autoConnectBluetooth = true,
    this.readAloud = true,
    this.elderlyMode = false,
  });

  factory ElderlySettings.fromJson(Map<String, dynamic> json) {
    return ElderlySettings(
      speakSpeed: (json['speakSpeed'] as num?)?.toDouble() ?? 1.0,
      autoConnectBluetooth: json['autoConnectBluetooth'] ?? true,
      readAloud: json['readAloud'] ?? true,
      elderlyMode: json['elderlyMode'] ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'speakSpeed': speakSpeed,
        'autoConnectBluetooth': autoConnectBluetooth,
        'readAloud': readAloud,
        'elderlyMode': elderlyMode,
      };

  ElderlySettings copyWith({
    double? speakSpeed,
    bool? autoConnectBluetooth,
    bool? readAloud,
    bool? elderlyMode,
  }) {
    return ElderlySettings(
      speakSpeed: speakSpeed ?? this.speakSpeed,
      autoConnectBluetooth: autoConnectBluetooth ?? this.autoConnectBluetooth,
      readAloud: readAloud ?? this.readAloud,
      elderlyMode: elderlyMode ?? this.elderlyMode,
    );
  }
}
