import 'health_record.dart';

/// 报告中单个维度的评分结果。
///
/// 与 core 层的 `DimensionScore` 字段一致，但定义在 models 层，
/// 让模型保持不依赖 core 的纯数据定位。
class ReportDimension {
  final String name;
  final double score;
  final String level;
  final String suggestion;

  ReportDimension({
    required this.name,
    required this.score,
    required this.level,
    required this.suggestion,
  });

  factory ReportDimension.fromJson(Map<String, dynamic> json) {
    return ReportDimension(
      name: json['name'] ?? '',
      score: (json['score'] ?? 0).toDouble(),
      level: json['level'] ?? '',
      suggestion: json['suggestion'] ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
    'name': name,
    'score': score,
    'level': level,
    'suggestion': suggestion,
  };
}

class HealthReport {
  final String id;
  final String memberName;
  final DateTime generatedAt;
  final String type;
  final String summary;
  final double overallScore;
  final List<String> suggestions;
  final String? pdfUrl;

  /// 报告对应的家庭成员 ID（未指定成员时为空）。
  final String? memberId;

  /// 四个维度的评分明细，老数据/后端数据缺失时为空列表。
  final List<ReportDimension> dimensions;

  /// 报告统计区间内的原始体征记录（按时间升序）。
  final List<HealthRecord> records;

  /// 生成报告当日的体征概览。
  final HealthSummary? vitalSummary;

  /// 数据统计区间的起止日期。
  final DateTime? periodStart;
  final DateTime? periodEnd;

  HealthReport({
    required this.id,
    required this.memberName,
    required this.generatedAt,
    required this.type,
    required this.summary,
    required this.overallScore,
    required this.suggestions,
    this.pdfUrl,
    this.memberId,
    this.dimensions = const [],
    this.records = const [],
    this.vitalSummary,
    this.periodStart,
    this.periodEnd,
  });

  /// 报告覆盖的数据天数（无记录时为 0）。
  int get periodDays => records.length;

  factory HealthReport.fromJson(Map<String, dynamic> json) {
    final start = json['periodStart'];
    final end = json['periodEnd'];
    final summary = json['vitalSummary'];
    return HealthReport(
      id: json['id'],
      memberName: json['memberName'],
      generatedAt: DateTime.parse(json['generatedAt']),
      type: json['type'],
      summary: json['summary'],
      overallScore: (json['overallScore'] ?? 0).toDouble(),
      suggestions: List<String>.from(json['suggestions'] ?? []),
      pdfUrl: json['pdfUrl'],
      memberId: json['memberId'],
      dimensions: (json['dimensions'] as List<dynamic>? ?? [])
          .map((e) => ReportDimension.fromJson(e as Map<String, dynamic>))
          .toList(),
      records: (json['records'] as List<dynamic>? ?? [])
          .map((e) => HealthRecord.fromJson(e as Map<String, dynamic>))
          .toList(),
      vitalSummary: summary is Map<String, dynamic>
          ? HealthSummary.fromJson(summary)
          : null,
      periodStart: start != null ? DateTime.tryParse(start) : null,
      periodEnd: end != null ? DateTime.tryParse(end) : null,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'memberName': memberName,
    'generatedAt': generatedAt.toIso8601String(),
    'type': type,
    'summary': summary,
    'overallScore': overallScore,
    'suggestions': suggestions,
    'pdfUrl': pdfUrl,
    'memberId': memberId,
    'dimensions': dimensions.map((d) => d.toJson()).toList(),
    'records': records.map((r) => r.toJson()).toList(),
    'vitalSummary': vitalSummary?.toJson(),
    'periodStart': periodStart?.toIso8601String(),
    'periodEnd': periodEnd?.toIso8601String(),
  };
}
