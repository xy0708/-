class MedicalHistoryEntry {
  final String id;
  final String name;
  final String? diagnosedAt;
  final String? note;

  const MedicalHistoryEntry({
    required this.id,
    required this.name,
    this.diagnosedAt,
    this.note,
  });

  factory MedicalHistoryEntry.fromJson(Map<String, dynamic> json) {
    return MedicalHistoryEntry(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      diagnosedAt: json['diagnosedAt'],
      note: json['note'],
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'diagnosedAt': diagnosedAt,
    'note': note,
  };
}
