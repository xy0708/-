class Hospital {
  final String name;
  final double latitude;
  final double longitude;
  final double distanceKm;

  /// 设施类型：hospital（医院）/ clinic（诊所）等。
  final String kind;

  const Hospital({
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.distanceKm,
    required this.kind,
  });

  String get distanceText =>
      distanceKm >= 1 ? '${distanceKm.toStringAsFixed(1)}km' : '${(distanceKm * 1000).round()}m';

  String get kindText => kind == 'clinic' ? '诊所' : '医院';

  factory Hospital.fromJson(Map<String, dynamic> json) {
    return Hospital(
      name: json['name'] ?? '',
      latitude: (json['latitude'] ?? 0).toDouble(),
      longitude: (json['longitude'] ?? 0).toDouble(),
      distanceKm: (json['distanceKm'] ?? 0).toDouble(),
      kind: json['kind'] ?? 'hospital',
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'latitude': latitude,
        'longitude': longitude,
        'distanceKm': distanceKm,
        'kind': kind,
      };
}
