/// 健康预警级别：info 提示 / warning 需关注 / danger 危险。
enum AlertLevel { info, warning, danger }

class HealthAlert {
  final String id;
  final String memberId;
  final String memberName;
  final AlertLevel level;
  final String title;
  final String content;
  final DateTime createdAt;

  HealthAlert({
    required this.id,
    required this.memberId,
    required this.memberName,
    required this.level,
    required this.title,
    required this.content,
    required this.createdAt,
  });

  factory HealthAlert.fromJson(Map<String, dynamic> json) {
    return HealthAlert(
      id: json['id'] ?? '',
      memberId: json['memberId'] ?? '',
      memberName: json['memberName'] ?? '',
      level: AlertLevel.values.firstWhere(
        (e) => e.name == json['level'],
        orElse: () => AlertLevel.info,
      ),
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'memberId': memberId,
        'memberName': memberName,
        'level': level.name,
        'title': title,
        'content': content,
        'createdAt': createdAt.toIso8601String(),
      };
}
