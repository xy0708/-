class User {
  final String id;
  final String name;
  final String phone;
  final int age;
  final String gender;
  final String? avatarUrl;
  final String? medicalHistory;
  final List<String> emergencyContacts;

  User({
    required this.id,
    required this.name,
    required this.phone,
    required this.age,
    required this.gender,
    this.avatarUrl,
    this.medicalHistory,
    this.emergencyContacts = const [],
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      name: json['name'],
      phone: json['phone'],
      age: json['age'],
      gender: json['gender'],
      avatarUrl: json['avatarUrl'],
      medicalHistory: json['medicalHistory'],
      emergencyContacts: List<String>.from(json['emergencyContacts'] ?? []),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'phone': phone,
    'age': age,
    'gender': gender,
    'avatarUrl': avatarUrl,
    'medicalHistory': medicalHistory,
    'emergencyContacts': emergencyContacts,
  };
}
