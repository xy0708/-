class OcrTestItem {
  final String item;
  final String result;
  final String referenceRange;
  final String unit;
  final String status; // normal, high, low

  const OcrTestItem({
    required this.item,
    required this.result,
    required this.referenceRange,
    required this.unit,
    required this.status,
  });

  factory OcrTestItem.fromJson(Map<String, dynamic> json) {
    return OcrTestItem(
      item: json['item'] ?? '',
      result: json['result'] ?? '',
      referenceRange: json['referenceRange'] ?? '',
      unit: json['unit'] ?? '',
      status: json['status'] ?? 'normal',
    );
  }

  Map<String, dynamic> toJson() => {
    'item': item,
    'result': result,
    'referenceRange': referenceRange,
    'unit': unit,
    'status': status,
  };
}

class OcrResult {
  final String id;
  final String reportName;
  final String patientName;
  final String sampleType;
  final DateTime reportDate;
  final DateTime recognizedAt;
  final List<OcrTestItem> items;
  final String? summary;

  const OcrResult({
    required this.id,
    required this.reportName,
    required this.patientName,
    required this.sampleType,
    required this.reportDate,
    required this.recognizedAt,
    required this.items,
    this.summary,
  });

  factory OcrResult.fromJson(Map<String, dynamic> json) {
    return OcrResult(
      id: json['id'] ?? '',
      reportName: json['reportName'] ?? '',
      patientName: json['patientName'] ?? '',
      sampleType: json['sampleType'] ?? '',
      reportDate: DateTime.parse(json['reportDate']),
      recognizedAt: DateTime.parse(json['recognizedAt']),
      items: (json['items'] as List<dynamic>?)
              ?.map((e) => OcrTestItem.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      summary: json['summary'],
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'reportName': reportName,
    'patientName': patientName,
    'sampleType': sampleType,
    'reportDate': reportDate.toIso8601String(),
    'recognizedAt': recognizedAt.toIso8601String(),
    'items': items.map((e) => e.toJson()).toList(),
    'summary': summary,
  };
}
