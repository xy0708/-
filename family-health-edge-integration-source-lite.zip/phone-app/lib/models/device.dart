enum DeviceType { bracelet, scale, bloodPressure, aiTerminal }

class HealthDevice {
  final String id;
  final String name;
  final DeviceType type;
  final bool isConnected;
  final int batteryLevel;

  HealthDevice({
    required this.id,
    required this.name,
    required this.type,
    this.isConnected = false,
    this.batteryLevel = 100,
  });

  HealthDevice copyWith({
    String? id,
    String? name,
    DeviceType? type,
    bool? isConnected,
    int? batteryLevel,
  }) {
    return HealthDevice(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      isConnected: isConnected ?? this.isConnected,
      batteryLevel: batteryLevel ?? this.batteryLevel,
    );
  }

  factory HealthDevice.fromJson(Map<String, dynamic> json) {
    return HealthDevice(
      id: json['id'],
      name: json['name'],
      type: DeviceType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => DeviceType.aiTerminal,
      ),
      isConnected: json['isConnected'] ?? false,
      batteryLevel: json['batteryLevel'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'type': type.name,
    'isConnected': isConnected,
    'batteryLevel': batteryLevel,
  };
}
