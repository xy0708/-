class HealthRecord {
  final int steps;
  final double sleepHours;
  final int heartRate;
  final double activityLevel;
  final DateTime date;

  HealthRecord({
    required this.steps,
    required this.sleepHours,
    required this.heartRate,
    required this.activityLevel,
    required this.date,
  });

  factory HealthRecord.fromJson(Map<String, dynamic> json) {
    return HealthRecord(
      steps: json['steps'] ?? 0,
      sleepHours: (json['sleepHours'] ?? 0).toDouble(),
      heartRate: json['heartRate'] ?? 0,
      activityLevel: (json['activityLevel'] ?? 0).toDouble(),
      date: DateTime.parse(json['date']),
    );
  }

  Map<String, dynamic> toJson() => {
    'steps': steps,
    'sleepHours': sleepHours,
    'heartRate': heartRate,
    'activityLevel': activityLevel,
    'date': date.toIso8601String(),
  };
}

class HealthSummary {
  final int todaySteps;
  final double todaySleep;
  final int currentHeartRate;
  final double todayActivity;
  final String healthStatus;

  HealthSummary({
    required this.todaySteps,
    required this.todaySleep,
    required this.currentHeartRate,
    required this.todayActivity,
    required this.healthStatus,
  });

  factory HealthSummary.fromJson(Map<String, dynamic> json) {
    return HealthSummary(
      todaySteps: json['todaySteps'] ?? 0,
      todaySleep: (json['todaySleep'] ?? 0).toDouble(),
      currentHeartRate: json['currentHeartRate'] ?? 0,
      todayActivity: (json['todayActivity'] ?? 0).toDouble(),
      healthStatus: json['healthStatus'] ?? 'unknown',
    );
  }

  Map<String, dynamic> toJson() => {
    'todaySteps': todaySteps,
    'todaySleep': todaySleep,
    'currentHeartRate': currentHeartRate,
    'todayActivity': todayActivity,
    'healthStatus': healthStatus,
  };
}
