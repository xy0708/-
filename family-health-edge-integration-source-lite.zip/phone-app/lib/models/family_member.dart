class FamilyMember {
  final String id;
  final String name;
  final String relation;
  final int age;
  final String gender;
  final String? medicalHistory;
  final bool hasDevice;

  FamilyMember({
    required this.id,
    required this.name,
    required this.relation,
    required this.age,
    required this.gender,
    this.medicalHistory,
    this.hasDevice = false,
  });

  factory FamilyMember.fromJson(Map<String, dynamic> json) {
    return FamilyMember(
      id: json['id'],
      name: json['name'],
      relation: json['relation'],
      age: json['age'],
      gender: json['gender'],
      medicalHistory: json['medicalHistory'],
      hasDevice: json['hasDevice'] ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'relation': relation,
    'age': age,
    'gender': gender,
    'medicalHistory': medicalHistory,
    'hasDevice': hasDevice,
  };
}
