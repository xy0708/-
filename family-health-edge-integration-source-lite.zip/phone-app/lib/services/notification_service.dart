import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../models/reminder.dart';

/// 本地通知服务：每天定时弹出健康提醒（吃药/测血压等）。
///
/// 完全本地实现，不依赖后端推送。在部分兼容环境（如鸿蒙卓易通）
/// 可能不支持系统通知——所有系统调用均捕获异常静默降级，
/// 不影响 App 其他功能，真实 Android 设备不受影响。
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _ready = false;
  String? _lastError;

  /// 最近一次调度/发送失败的原因（用于界面诊断）。
  String? get lastError => _lastError;

  Future<void> init() async {
    if (_ready) return;
    try {
      tz_data.initializeTimeZones();
      // 应用面向国内用户，统一使用东八区（无夏令时）
      tz.setLocalLocation(tz.getLocation('Asia/Shanghai'));
      const androidSettings =
          AndroidInitializationSettings('@mipmap/ic_launcher');
      final initialized = await _plugin.initialize(
        settings: const InitializationSettings(android: androidSettings),
      );
      _ready = initialized ?? true;
      debugPrint('[NotificationService] 初始化完成: $_ready');
      if (!_ready) _lastError = '通知服务初始化失败';
    } catch (e) {
      _lastError = e.toString();
      debugPrint('[NotificationService] 初始化失败（当前环境可能不支持系统通知）: $e');
    }
  }

  /// Android 13+ 需运行时请求通知权限，返回是否已授予。
  Future<bool> requestPermission() async {
    try {
      final android = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      final granted = await android?.requestNotificationsPermission();
      return granted ?? true;
    } catch (e) {
      debugPrint('[NotificationService] 通知权限请求失败: $e');
      return false;
    }
  }

  /// 每天 [reminder.hour]:[reminder.minute] 触发提醒，返回是否注册成功。
  Future<bool> scheduleDaily(Reminder reminder) async {
    if (!_ready) {
      _lastError = '通知服务未就绪';
      return false;
    }
    try {
      final now = tz.TZDateTime.now(tz.local);
      var scheduled = tz.TZDateTime(
        tz.local,
        now.year,
        now.month,
        now.day,
        reminder.hour,
        reminder.minute,
      );
      if (!scheduled.isAfter(now)) {
        scheduled = scheduled.add(const Duration(days: 1));
      }
      await _plugin.zonedSchedule(
        id: notificationId(reminder.id),
        title: '健康提醒',
        body: reminder.title,
        scheduledDate: scheduled,
        notificationDetails: const NotificationDetails(
          android: AndroidNotificationDetails(
            'health_reminders',
            '健康提醒',
            channelDescription: '用药、测血压等每日定时提醒',
            importance: Importance.high,
            priority: Priority.high,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        matchDateTimeComponents: DateTimeComponents.time,
      );
      _lastError = null;
      debugPrint(
          '[NotificationService] 已调度提醒: ${reminder.title} ${reminder.timeText}');
      return true;
    } catch (e) {
      _lastError = e.toString();
      debugPrint('[NotificationService] 调度提醒失败: $e');
      return false;
    }
  }

  /// 取消指定提醒的调度。
  Future<void> cancel(String reminderId) async {
    if (!_ready) return;
    try {
      await _plugin.cancel(id: notificationId(reminderId));
    } catch (e) {
      debugPrint('[NotificationService] 取消提醒失败: $e');
    }
  }

  /// 提醒 id（字符串时间戳）映射为通知 id。
  ///
  /// 系统通知 id 必须是 32 位整数，而毫秒时间戳（13 位，如 1789315649332）
  /// 远超 int32 上限会被系统拒绝，因此截取低 31 位保证为非负 int32。
  int notificationId(String reminderId) {
    final raw = int.tryParse(reminderId) ?? reminderId.hashCode;
    return raw & 0x7FFFFFFF;
  }

  // ---------- 诊断能力（排查"到点不提醒"） ----------

  /// 通知服务是否初始化就绪（部分兼容环境会初始化失败）。
  bool get isReady => _ready;

  /// 系统层面通知是否已开启（含用户手动关闭的情况）。
  Future<bool> notificationsEnabled() async {
    try {
      final android = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      return await android?.areNotificationsEnabled() ?? false;
    } catch (e) {
      debugPrint('[NotificationService] 查询通知开关失败: $e');
      return false;
    }
  }

  /// 打开系统通知设置页，便于用户手动开启权限。
  Future<void> openSystemNotificationSettings() async {
    try {
      await _plugin.openAppNotificationSettings();
    } catch (e) {
      debugPrint('[NotificationService] 打开通知设置失败: $e');
    }
  }

  /// 立即发送一条测试通知，返回是否发送成功。
  Future<bool> showTestNotification() async {
    if (!_ready) {
      await init();
    }
    if (!_ready) return false;
    try {
      await _plugin.show(
        id: 999001,
        title: '健康提醒',
        body: '这是一条测试通知，看到它就说明通知功能正常。',
        notificationDetails: const NotificationDetails(
          android: AndroidNotificationDetails(
            'health_reminders',
            '健康提醒',
            channelDescription: '用药、测血压等每日定时提醒',
            importance: Importance.high,
            priority: Priority.high,
          ),
        ),
      );
      return true;
    } catch (e) {
      _lastError = e.toString();
      debugPrint('[NotificationService] 测试通知发送失败: $e');
      return false;
    }
  }

  /// 已注册的定时提醒数量（用于确认调度是否成功）。
  Future<int> pendingCount() async {
    try {
      return (await _plugin.pendingNotificationRequests()).length;
    } catch (e) {
      debugPrint('[NotificationService] 查询待发提醒失败: $e');
      return 0;
    }
  }
}
