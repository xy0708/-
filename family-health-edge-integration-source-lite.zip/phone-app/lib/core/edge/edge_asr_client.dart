import 'dart:async';
import 'dart:convert';

import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

typedef EdgeAsrSocketConnector = Future<EdgeAsrSocket> Function(
  Uri uri,
  Map<String, dynamic> headers,
);

abstract interface class EdgeAsrSocket {
  Stream<Object?> get stream;

  void add(Object? data);

  Future<void> close();
}

class EdgeAsrException implements Exception {
  const EdgeAsrException(this.code, this.message);

  final String code;
  final String message;

  @override
  String toString() => 'EdgeAsrException($code): $message';
}

enum EdgeAsrSessionState {
  starting,
  streaming,
  finishing,
  awaitingConfirmation,
  cancelled,
  closed,
  failed,
}

class EdgeAsrEvent {
  const EdgeAsrEvent({required this.type, required this.payload});

  final String type;
  final Map<String, dynamic> payload;

  String? get text =>
      payload['text'] is String ? payload['text'] as String : null;

  String? get taskId {
    final task = payload['task'];
    return task is Map<String, dynamic> && task['task_id'] is String
        ? task['task_id'] as String
        : null;
  }
}

class EdgeAsrClient {
  EdgeAsrClient({
    required Uri endpoint,
    required String bearerToken,
    required String memberId,
    EdgeAsrSocketConnector? connector,
    bool allowInsecureTransportForEngineering = false,
  })  : _endpoint = _validatedEndpoint(
          endpoint,
          allowInsecureTransportForEngineering,
        ),
        _bearerToken = _requiredValue(bearerToken, 'bearerToken'),
        _memberId = _validatedMemberId(memberId),
        _connector = connector ?? _connectIoSocket;

  final Uri _endpoint;
  final String _bearerToken;
  final String _memberId;
  final EdgeAsrSocketConnector _connector;

  Future<EdgeAsrSession> startSession() async {
    final socket = await _connector(_streamUri(), {
      'Authorization': 'Bearer $_bearerToken',
      'X-Edge-Member-Id': _memberId,
    });
    final session = EdgeAsrSession._(socket);
    session._start();
    return session;
  }

  Uri _streamUri() {
    final normalizedBase = _endpoint.path.endsWith('/')
        ? _endpoint.path.substring(0, _endpoint.path.length - 1)
        : _endpoint.path;
    return _endpoint.replace(
      scheme: _endpoint.scheme == 'https' ? 'wss' : 'ws',
      path: '$normalizedBase/v1/asr/stream',
      query: null,
      fragment: null,
    );
  }

  static Future<EdgeAsrSocket> _connectIoSocket(
    Uri uri,
    Map<String, dynamic> headers,
  ) async {
    final channel = IOWebSocketChannel.connect(
      uri,
      headers: headers,
      connectTimeout: const Duration(seconds: 15),
      pingInterval: const Duration(seconds: 20),
    );
    await channel.ready;
    return _IoEdgeAsrSocket(channel);
  }

  static Uri _validatedEndpoint(Uri endpoint, bool allowInsecure) {
    if (!endpoint.hasAuthority) {
      throw ArgumentError.value(endpoint, 'endpoint', 'must include a host');
    }
    if (endpoint.scheme != 'https' &&
        !(allowInsecure && endpoint.scheme == 'http')) {
      throw ArgumentError.value(
        endpoint,
        'endpoint',
        'production ASR transport must use WSS',
      );
    }
    return endpoint;
  }

  static String _validatedMemberId(String value) {
    final cleaned = _requiredValue(value, 'memberId');
    if (!RegExp(r'^[A-Za-z0-9._-]{1,64}$').hasMatch(cleaned)) {
      throw ArgumentError.value(value, 'memberId', 'invalid member identifier');
    }
    return cleaned;
  }

  static String _requiredValue(String value, String name) {
    final cleaned = value.trim();
    if (cleaned.isEmpty) {
      throw ArgumentError.value(value, name, 'must not be empty');
    }
    return cleaned;
  }
}

class EdgeAsrSession {
  EdgeAsrSession._(this._socket);

  static const int maxChunkBytes = 64 * 1024;
  static const int maxTotalBytes = 16000 * 1 * 2 * 120;

  final EdgeAsrSocket _socket;
  final StreamController<EdgeAsrEvent> _events =
      StreamController<EdgeAsrEvent>.broadcast();
  StreamSubscription<Object?>? _subscription;
  EdgeAsrSessionState _state = EdgeAsrSessionState.starting;
  int _bytesSent = 0;
  bool _eventsClosed = false;
  Completer<void>? _streamingWaiter;
  Completer<EdgeAsrEvent>? _finalWaiter;
  EdgeAsrException? _terminalError;

  Stream<EdgeAsrEvent> get events => _events.stream;
  EdgeAsrSessionState get state => _state;
  int get bytesSent => _bytesSent;

  Future<void> waitUntilStreaming({
    Duration timeout = const Duration(seconds: 15),
  }) {
    if (_state == EdgeAsrSessionState.streaming) return Future.value();
    if (_state == EdgeAsrSessionState.failed) {
      return Future.error(
        _terminalError ?? const EdgeAsrException('TRANSPORT_ERROR', 'ASR启动失败'),
      );
    }
    if (_state != EdgeAsrSessionState.starting) {
      return Future.error(
          StateError('ASR session cannot start from ${_state.name}'));
    }
    return (_streamingWaiter ??= Completer<void>()).future.timeout(timeout);
  }

  Future<EdgeAsrEvent> stopAndWait({
    Duration timeout = const Duration(seconds: 30),
  }) {
    if (_state != EdgeAsrSessionState.streaming) {
      return Future.error(
        StateError('ASR session cannot stop from ${_state.name}'),
      );
    }
    final waiter = _finalWaiter ??= Completer<EdgeAsrEvent>();
    stop();
    return waiter.future.timeout(timeout);
  }

  void _start() {
    _subscription = _socket.stream.listen(
      _handleMessage,
      onError: (Object error, StackTrace stackTrace) {
        _fail('TRANSPORT_ERROR', 'ASR连接异常');
      },
      onDone: _handleDone,
      cancelOnError: false,
    );
    _socket.add(jsonEncode({
      'type': 'start',
      'sample_rate_hz': 16000,
      'channels': 1,
      'sample_format': 's16le',
    }));
  }

  void addPcm(List<int> pcmS16le) {
    if (_state != EdgeAsrSessionState.streaming) {
      throw StateError('ASR session is not accepting audio');
    }
    if (pcmS16le.isEmpty ||
        pcmS16le.length > maxChunkBytes ||
        pcmS16le.length.isOdd) {
      throw ArgumentError.value(
        pcmS16le.length,
        'pcmS16le',
        'PCM chunks must be non-empty, even-sized, and at most 64 KiB',
      );
    }
    if (_bytesSent + pcmS16le.length > maxTotalBytes) {
      throw ArgumentError.value(
        _bytesSent + pcmS16le.length,
        'pcmS16le',
        'ASR audio exceeds 120 seconds',
      );
    }
    _bytesSent += pcmS16le.length;
    _socket.add(pcmS16le);
  }

  void stop() {
    if (_state != EdgeAsrSessionState.streaming) {
      throw StateError('ASR session cannot stop from ${_state.name}');
    }
    _state = EdgeAsrSessionState.finishing;
    _socket.add(jsonEncode({'type': 'stop'}));
  }

  Future<void> cancel() async {
    if (_isTerminal) return;
    _state = EdgeAsrSessionState.cancelled;
    const error = EdgeAsrException('CANCELLED', 'ASR会话已取消');
    final streamingWaiter = _streamingWaiter;
    if (streamingWaiter != null && !streamingWaiter.isCompleted) {
      streamingWaiter.completeError(error);
    }
    final finalWaiter = _finalWaiter;
    if (finalWaiter != null && !finalWaiter.isCompleted) {
      finalWaiter.completeError(error);
    }
    _socket.add(jsonEncode({'type': 'cancel'}));
    await _socket.close();
    await _subscription?.cancel();
    await _closeEvents();
  }

  void _handleMessage(Object? message) {
    if (message is! String) {
      _fail('RESPONSE_INVALID', 'ASR端侧返回了非JSON消息');
      return;
    }
    Map<String, dynamic> payload;
    try {
      final decoded = jsonDecode(message);
      if (decoded is! Map<String, dynamic>) {
        throw const FormatException('ASR response is not an object');
      }
      payload = decoded;
    } on FormatException {
      _fail('RESPONSE_INVALID', 'ASR端侧返回格式无效');
      return;
    }
    final type = payload['type'];
    if (type is! String) {
      _fail('RESPONSE_INVALID', 'ASR端侧返回缺少消息类型');
      return;
    }
    switch (type) {
      case 'started':
        if (_state != EdgeAsrSessionState.starting) {
          _fail('RESPONSE_INVALID', 'ASR启动响应顺序无效');
          return;
        }
        _state = EdgeAsrSessionState.streaming;
        final waiter = _streamingWaiter;
        if (waiter != null && !waiter.isCompleted) {
          waiter.complete();
        }
      case 'audio_accepted':
      case 'partial':
        if (_state != EdgeAsrSessionState.streaming) {
          _fail('RESPONSE_INVALID', 'ASR流式响应顺序无效');
          return;
        }
      case 'final_pending_confirmation':
        if (_state != EdgeAsrSessionState.finishing ||
            payload['raw_audio_persisted'] != false) {
          _fail('RESPONSE_INVALID', 'ASR最终响应不符合隐私契约');
          return;
        }
        _state = EdgeAsrSessionState.awaitingConfirmation;
      case 'cancelled':
        _state = EdgeAsrSessionState.cancelled;
      case 'error':
        final error = payload['error'];
        final code = error is Map<String, dynamic> && error['code'] is String
            ? error['code'] as String
            : 'EDGE_ERROR';
        _fail(code, 'ASR端侧处理失败');
        return;
      default:
        _fail('RESPONSE_INVALID', 'ASR端侧返回未知消息类型');
        return;
    }
    if (!_eventsClosed) {
      final event = EdgeAsrEvent(type: type, payload: payload);
      _events.add(event);
      final finalWaiter = _finalWaiter;
      if (type == 'final_pending_confirmation' &&
          finalWaiter != null &&
          !finalWaiter.isCompleted) {
        finalWaiter.complete(event);
      }
    }
  }

  void _handleDone() {
    if (_state == EdgeAsrSessionState.starting ||
        _state == EdgeAsrSessionState.streaming ||
        _state == EdgeAsrSessionState.finishing) {
      _fail('TRANSPORT_CLOSED', 'ASR连接提前关闭');
      return;
    }
    if (_state == EdgeAsrSessionState.awaitingConfirmation) {
      _state = EdgeAsrSessionState.closed;
    }
    unawaited(_closeEvents());
  }

  void _fail(String code, String message) {
    if (_isTerminal) return;
    _state = EdgeAsrSessionState.failed;
    final error = EdgeAsrException(code, message);
    _terminalError = error;
    final streamingWaiter = _streamingWaiter;
    if (streamingWaiter != null && !streamingWaiter.isCompleted) {
      streamingWaiter.completeError(error);
    }
    final finalWaiter = _finalWaiter;
    if (finalWaiter != null && !finalWaiter.isCompleted) {
      finalWaiter.completeError(error);
    }
    if (!_eventsClosed) {
      _events.addError(error);
    }
    unawaited(_socket.close());
    unawaited(_closeEvents());
  }

  bool get _isTerminal =>
      _state == EdgeAsrSessionState.cancelled ||
      _state == EdgeAsrSessionState.closed ||
      _state == EdgeAsrSessionState.failed;

  Future<void> _closeEvents() async {
    if (_eventsClosed) return;
    _eventsClosed = true;
    await _events.close();
  }
}

class _IoEdgeAsrSocket implements EdgeAsrSocket {
  _IoEdgeAsrSocket(this._channel);

  final WebSocketChannel _channel;

  @override
  Stream<Object?> get stream => _channel.stream;

  @override
  void add(Object? data) => _channel.sink.add(data);

  @override
  Future<void> close() async {
    await _channel.sink.close();
  }
}
