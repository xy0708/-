class EdgeOcrLine {
  const EdgeOcrLine({required this.text, required this.confidence});

  final String text;
  final double confidence;
}

class EdgeOcrReview {
  const EdgeOcrReview({
    required this.taskId,
    required this.fullText,
    required this.lines,
  });

  final String taskId;
  final String fullText;
  final List<EdgeOcrLine> lines;

  factory EdgeOcrReview.fromTaskResponse(Map<String, dynamic> response) {
    if (response['status'] != 'success' ||
        response['requires_confirmation'] != true) {
      throw const FormatException('OCR task is not pending confirmation');
    }
    final task = response['result'];
    if (task is! Map<String, dynamic> ||
        task['kind'] != 'ocr' ||
        task['status'] != 'pending_confirmation') {
      throw const FormatException('OCR task metadata is invalid');
    }
    final taskId = task['task_id'];
    final result = task['result'];
    if (taskId is! String ||
        !RegExp(r'^[0-9a-f]{32}$').hasMatch(taskId) ||
        result is! Map<String, dynamic>) {
      throw const FormatException('OCR task result is invalid');
    }
    final fullText = result['full_text'];
    final rawLines = result['lines'];
    if (fullText is! String || rawLines is! List<dynamic>) {
      throw const FormatException('OCR text result is invalid');
    }
    final lines = rawLines.map((raw) {
      if (raw is! Map<String, dynamic> ||
          raw['text'] is! String ||
          raw['confidence'] is! num) {
        throw const FormatException('OCR line result is invalid');
      }
      final confidence = (raw['confidence'] as num).toDouble();
      if (confidence < 0 || confidence > 1) {
        throw const FormatException('OCR confidence is invalid');
      }
      return EdgeOcrLine(text: raw['text'] as String, confidence: confidence);
    }).toList(growable: false);
    if (fullText.trim().isEmpty && lines.isEmpty) {
      throw const FormatException('OCR result is empty');
    }
    return EdgeOcrReview(
      taskId: taskId,
      fullText: fullText,
      lines: List<EdgeOcrLine>.unmodifiable(lines),
    );
  }
}
