class EdgeHealthResult {
  const EdgeHealthResult({
    required this.attentionLevel,
    required this.ruleVersion,
    required this.approvalStatus,
    required this.productReleaseAllowed,
    required this.messages,
    required this.disclaimer,
  });

  final String attentionLevel;
  final String ruleVersion;
  final String approvalStatus;
  final bool productReleaseAllowed;
  final List<String> messages;
  final String disclaimer;

  factory EdgeHealthResult.fromResponse(Map<String, dynamic> response) {
    final result = response['result'];
    if (response['status'] != 'success' || result is! Map<String, dynamic>) {
      throw const FormatException('health response envelope is invalid');
    }
    if (result['scope'] != 'NON_DIAGNOSTIC_HEALTH_MANAGEMENT' ||
        result['diagnosis'] != null ||
        result['disease_probability'] != null) {
      throw const FormatException('diagnostic output is forbidden');
    }

    final attentionLevel = result['attention_level'];
    const allowedLevels = {
      'NO_RULE_TRIGGERED',
      'OBSERVE',
      'ATTENTION',
      'INPUT_REVIEW_REQUIRED',
    };
    if (attentionLevel is! String || !allowedLevels.contains(attentionLevel)) {
      throw const FormatException('health attention level is invalid');
    }
    final ruleVersion = result['rule_version'];
    final approvalStatus = result['approval_status'];
    final productReleaseAllowed = result['product_release_allowed'];
    final disclaimer = result['disclaimer'];
    final measurements = result['measurements'];
    if (ruleVersion is! String ||
        ruleVersion.isEmpty ||
        approvalStatus is! String ||
        approvalStatus.isEmpty ||
        productReleaseAllowed is! bool ||
        disclaimer is! String ||
        disclaimer.isEmpty ||
        measurements is! List<dynamic>) {
      throw const FormatException('health result fields are invalid');
    }

    final messages = <String>[];
    for (final measurement in measurements) {
      if (measurement is! Map<String, dynamic>) {
        throw const FormatException('health measurement result is invalid');
      }
      final triggers = measurement['triggers'];
      if (triggers is! List<dynamic>) {
        throw const FormatException('health triggers are invalid');
      }
      for (final trigger in triggers) {
        if (trigger is! Map<String, dynamic> || trigger['message'] is! String) {
          throw const FormatException('health trigger is invalid');
        }
        messages.add(trigger['message'] as String);
      }
    }
    if (messages.isEmpty) {
      messages.add('本次未触发提示规则，但这不代表健康或排除疾病。');
    }

    return EdgeHealthResult(
      attentionLevel: attentionLevel,
      ruleVersion: ruleVersion,
      approvalStatus: approvalStatus,
      productReleaseAllowed: productReleaseAllowed,
      messages: List.unmodifiable(messages),
      disclaimer: disclaimer,
    );
  }
}
