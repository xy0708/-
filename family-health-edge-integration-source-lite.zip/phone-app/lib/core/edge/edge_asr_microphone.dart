import 'dart:async';
import 'dart:typed_data';

import 'package:record/record.dart';

import 'edge_asr_client.dart';

abstract interface class EdgePcmSource {
  Future<Stream<Uint8List>> start();
  Future<void> stop();
  Future<void> cancel();
  Future<void> dispose();
}

class RecordEdgePcmSource implements EdgePcmSource {
  RecordEdgePcmSource({AudioRecorder? recorder})
      : _recorder = recorder ?? AudioRecorder();

  final AudioRecorder _recorder;

  @override
  Future<Stream<Uint8List>> start() async {
    if (!await _recorder.hasPermission()) {
      throw const EdgeAsrException('MIC_PERMISSION_DENIED', '未获得麦克风权限');
    }
    if (!await _recorder.isEncoderSupported(AudioEncoder.pcm16bits)) {
      throw const EdgeAsrException('PCM16_UNSUPPORTED', '设备不支持 PCM16 麦克风流');
    }
    return _recorder.startStream(
      const RecordConfig(
        encoder: AudioEncoder.pcm16bits,
        sampleRate: 16000,
        numChannels: 1,
        autoGain: false,
        echoCancel: false,
        noiseSuppress: false,
      ),
    );
  }

  @override
  Future<void> stop() async => _recorder.stop();

  @override
  Future<void> cancel() async => _recorder.cancel();

  @override
  Future<void> dispose() async => _recorder.dispose();
}

class EdgeAsrMicrophoneController {
  EdgeAsrMicrophoneController({
    required EdgeAsrClient client,
    EdgePcmSource? source,
    this.onPartial,
  })  : _client = client,
        _source = source ?? RecordEdgePcmSource();

  final EdgeAsrClient _client;
  final EdgePcmSource _source;
  final void Function(String text)? onPartial;

  EdgeAsrSession? _session;
  StreamSubscription<Uint8List>? _audioSubscription;
  StreamSubscription<EdgeAsrEvent>? _eventSubscription;
  Completer<void>? _audioDone;
  Object? _failure;
  int? _pendingByte;
  bool _recording = false;
  bool _disposed = false;

  bool get isRecording => _recording;

  Future<void> start() async {
    if (_disposed) throw StateError('ASR microphone controller is disposed');
    if (_recording) throw StateError('ASR microphone is already recording');
    final session = await _client.startSession();
    _session = session;
    try {
      await session.waitUntilStreaming();
      _eventSubscription = session.events.listen(
        (event) {
          final text = event.text;
          if (event.type == 'partial' && text != null) {
            onPartial?.call(text);
          }
        },
        onError: (Object error) => _failure ??= error,
      );
      final audio = await _source.start();
      _audioDone = Completer<void>();
      _failure = null;
      _pendingByte = null;
      _audioSubscription = audio.listen(
        _acceptChunk,
        onError: (Object error) {
          _failure ??= error;
          _completeAudio();
        },
        onDone: _completeAudio,
        cancelOnError: false,
      );
      _recording = true;
    } catch (_) {
      await session.cancel();
      _session = null;
      rethrow;
    }
  }

  Future<EdgeAsrEvent> stop() async {
    if (!_recording || _session == null) {
      throw StateError('ASR microphone is not recording');
    }
    _recording = false;
    try {
      await _source.stop();
      await _audioDone!.future.timeout(const Duration(seconds: 5));
      if (_pendingByte != null) {
        throw const EdgeAsrException('PCM_TRUNCATED', 'PCM16 音频末尾不完整');
      }
      final failure = _failure;
      if (failure != null) throw failure;
      return await _session!.stopAndWait();
    } catch (_) {
      await _session!.cancel();
      rethrow;
    } finally {
      await _clearSession();
    }
  }

  Future<void> cancel() async {
    if (_session == null) return;
    _recording = false;
    try {
      await _source.cancel();
      await _session?.cancel();
    } finally {
      await _clearSession();
    }
  }

  Future<void> dispose() async {
    if (_disposed) return;
    await cancel();
    _disposed = true;
    await _source.dispose();
  }

  void _acceptChunk(Uint8List bytes) {
    try {
      final combined = <int>[];
      final pending = _pendingByte;
      if (pending != null) combined.add(pending);
      combined.addAll(bytes);
      _pendingByte = combined.length.isOdd ? combined.removeLast() : null;
      var offset = 0;
      while (offset < combined.length) {
        final remaining = combined.length - offset;
        final length = remaining > EdgeAsrSession.maxChunkBytes
            ? EdgeAsrSession.maxChunkBytes
            : remaining;
        _session!.addPcm(combined.sublist(offset, offset + length));
        offset += length;
      }
    } catch (error) {
      _failure ??= error;
      unawaited(_source.cancel());
      _completeAudio();
    }
  }

  void _completeAudio() {
    final done = _audioDone;
    if (done != null && !done.isCompleted) done.complete();
  }

  Future<void> _clearSession() async {
    await _audioSubscription?.cancel();
    await _eventSubscription?.cancel();
    _audioSubscription = null;
    _eventSubscription = null;
    _audioDone = null;
    _session = null;
    _pendingByte = null;
    _failure = null;
  }
}
