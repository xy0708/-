import 'edge_asr_client.dart';

class EdgeAsrPendingResult {
  const EdgeAsrPendingResult({
    required this.taskId,
    required this.text,
  });

  final String taskId;
  final String text;

  factory EdgeAsrPendingResult.fromEvent(EdgeAsrEvent event) {
    if (event.type != 'final_pending_confirmation' ||
        event.payload['raw_audio_persisted'] != false) {
      throw const FormatException('ASR result is not pending confirmation');
    }
    final taskId = event.taskId;
    final result = event.payload['result'];
    if (taskId == null ||
        !RegExp(r'^[0-9a-f]{32}$').hasMatch(taskId) ||
        result is! Map<String, dynamic>) {
      throw const FormatException('ASR task result is invalid');
    }
    final text = result['text'];
    if (text is! String || text.trim().isEmpty || text.length > 16384) {
      throw const FormatException('ASR transcript is invalid');
    }
    return EdgeAsrPendingResult(taskId: taskId, text: text.trim());
  }
}
