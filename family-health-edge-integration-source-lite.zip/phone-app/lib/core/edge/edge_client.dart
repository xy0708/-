import 'dart:async';
import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

import '../watch/wearable_measurement.dart';

class EdgeApiException implements Exception {
  const EdgeApiException(this.code, this.message, {required this.retryable});

  final String code;
  final String message;
  final bool retryable;

  @override
  String toString() => 'EdgeApiException($code): $message';
}

class EdgeClient {
  static const int maxOcrImageBytes = 8 * 1024 * 1024;

  EdgeClient({
    required Uri endpoint,
    required String bearerToken,
    required String memberId,
    http.Client? httpClient,
    this.timeout = const Duration(seconds: 15),
    bool allowInsecureTransportForEngineering = false,
  })  : _endpoint = _validatedEndpoint(
          endpoint,
          allowInsecureTransportForEngineering,
        ),
        _bearerToken = _requiredValue(bearerToken, 'bearerToken'),
        _memberId = _validatedMemberId(memberId),
        _httpClient = httpClient ?? http.Client();

  final Uri _endpoint;
  final String _bearerToken;
  final String _memberId;
  final http.Client _httpClient;
  final Duration timeout;

  Future<Map<String, dynamic>> getVersion() => _get('/v1/version');

  Future<Map<String, dynamic>> evaluateConfirmedMeasurement(
    WearableMeasurement measurement,
  ) async {
    if (measurement.memberId != _memberId) {
      throw ArgumentError('measurement member does not match the edge session');
    }
    if (measurement.quality != MeasurementQuality.valid) {
      throw ArgumentError('invalid-quality measurements require user review');
    }
    if (measurement.metric != WearableMetric.heartRate) {
      throw UnsupportedError(
        '${measurement.metric.name} is not supported by health rules v1',
      );
    }

    return _post('/v1/health/evaluate', {
      'confirmed': true,
      'measurements': [
        {
          'metric': 'heart_rate',
          'value': measurement.value,
          'unit': measurement.unit,
          'measured_at': measurement.capturedAt.toUtc().toIso8601String(),
          'confirmed': true,
        },
      ],
    });
  }

  /// Creates an OCR task whose result remains pending until the user confirms
  /// the extracted fields. Raw image bytes are not persisted by the contract.
  Future<Map<String, dynamic>> createOcrTask({
    required List<int> imageBytes,
    required String mediaType,
  }) {
    _validateOcrImage(imageBytes, mediaType);
    return _post('/v1/ocr/tasks', {
      'member_id': _memberId,
      'image': {
        'media_type': mediaType,
        'data_base64': base64Encode(imageBytes),
        'sha256': sha256.convert(imageBytes).toString(),
      },
    });
  }

  Future<Map<String, dynamic>> getTask(String taskId) {
    return _get('/v1/tasks/${_validatedTaskId(taskId)}');
  }

  Future<Map<String, dynamic>> cancelTask(String taskId) {
    return _delete('/v1/tasks/${_validatedTaskId(taskId)}');
  }

  Future<Map<String, dynamic>> confirmTask({
    required String taskId,
    required String idempotencyKey,
    required Map<String, Object?> confirmedFields,
  }) {
    if (confirmedFields.isEmpty) {
      throw ArgumentError.value(
        confirmedFields,
        'confirmedFields',
        'must not be empty',
      );
    }
    return _post('/v1/records/confirm', {
      'member_id': _memberId,
      'task_id': _validatedTaskId(taskId),
      'idempotency_key': _validatedIdempotencyKey(idempotencyKey),
      'confirmed_fields': confirmedFields,
    });
  }

  Future<Map<String, dynamic>> _get(String path) async {
    final response =
        await _httpClient.get(_uri(path), headers: _headers).timeout(timeout);
    return _decode(response);
  }

  Future<Map<String, dynamic>> _post(
    String path,
    Map<String, Object?> body,
  ) async {
    final response = await _httpClient
        .post(
          _uri(path),
          headers: {..._headers, 'Content-Type': 'application/json'},
          body: jsonEncode(body),
        )
        .timeout(timeout);
    return _decode(response);
  }

  Future<Map<String, dynamic>> _delete(String path) async {
    final response = await _httpClient
        .delete(_uri(path), headers: _headers)
        .timeout(timeout);
    return _decode(response);
  }

  Map<String, String> get _headers => {
        'Accept': 'application/json',
        'Authorization': 'Bearer $_bearerToken',
        'X-Edge-Member-Id': _memberId,
      };

  Uri _uri(String path) {
    final normalizedBase = _endpoint.path.endsWith('/')
        ? _endpoint.path.substring(0, _endpoint.path.length - 1)
        : _endpoint.path;
    return _endpoint.replace(path: '$normalizedBase$path');
  }

  Map<String, dynamic> _decode(http.Response response) {
    Map<String, dynamic> body;
    try {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is! Map<String, dynamic>) {
        throw const FormatException('response is not an object');
      }
      body = decoded;
    } on FormatException {
      throw const EdgeApiException(
        'RESPONSE_INVALID',
        '端侧返回格式无效',
        retryable: false,
      );
    }

    if (response.statusCode >= 200 &&
        response.statusCode < 300 &&
        body['status'] != 'error') {
      return body;
    }
    final error = body['error'];
    if (error is Map<String, dynamic>) {
      throw EdgeApiException(
        error['code'] is String ? error['code'] as String : 'EDGE_ERROR',
        error['message'] is String ? error['message'] as String : '端侧请求失败',
        retryable: error['retryable'] == true,
      );
    }
    throw EdgeApiException(
      'HTTP_${response.statusCode}',
      '端侧请求失败',
      retryable: response.statusCode >= 500,
    );
  }

  void close() => _httpClient.close();

  static Uri _validatedEndpoint(Uri endpoint, bool allowInsecure) {
    if (!endpoint.hasAuthority) {
      throw ArgumentError.value(endpoint, 'endpoint', 'must include a host');
    }
    if (endpoint.scheme != 'https' &&
        !(allowInsecure && endpoint.scheme == 'http')) {
      throw ArgumentError.value(
        endpoint,
        'endpoint',
        'production edge transport must use HTTPS',
      );
    }
    return endpoint;
  }

  static String _validatedMemberId(String value) {
    final cleaned = _requiredValue(value, 'memberId');
    if (!RegExp(r'^[A-Za-z0-9._-]{1,64}$').hasMatch(cleaned)) {
      throw ArgumentError.value(value, 'memberId', 'invalid member identifier');
    }
    return cleaned;
  }

  static String _validatedTaskId(String value) {
    final cleaned = _requiredValue(value, 'taskId');
    if (!RegExp(r'^[0-9a-f]{32}$').hasMatch(cleaned)) {
      throw ArgumentError.value(value, 'taskId', 'invalid task identifier');
    }
    return cleaned;
  }

  static String _validatedIdempotencyKey(String value) {
    final cleaned = _requiredValue(value, 'idempotencyKey');
    if (cleaned.length > 128) {
      throw ArgumentError.value(
        value,
        'idempotencyKey',
        'must not exceed 128 characters',
      );
    }
    return cleaned;
  }

  static void _validateOcrImage(List<int> bytes, String mediaType) {
    if (mediaType != 'image/png' && mediaType != 'image/jpeg') {
      throw ArgumentError.value(
        mediaType,
        'mediaType',
        'only image/png and image/jpeg are supported',
      );
    }
    if (bytes.isEmpty || bytes.length > maxOcrImageBytes) {
      throw ArgumentError.value(
        bytes.length,
        'imageBytes',
        'image must contain 1 to $maxOcrImageBytes bytes',
      );
    }
    final validSignature =
        mediaType == 'image/png' ? _isPng(bytes) : _isJpeg(bytes);
    if (!validSignature) {
      throw ArgumentError.value(
        bytes.length,
        'imageBytes',
        'image signature does not match mediaType',
      );
    }
  }

  static bool _isPng(List<int> bytes) {
    const signature = <int>[137, 80, 78, 71, 13, 10, 26, 10];
    if (bytes.length < 24) return false;
    for (var index = 0; index < signature.length; index += 1) {
      if (bytes[index] != signature[index]) return false;
    }
    return bytes[12] == 73 &&
        bytes[13] == 72 &&
        bytes[14] == 68 &&
        bytes[15] == 82;
  }

  static bool _isJpeg(List<int> bytes) {
    return bytes.length >= 4 &&
        bytes[0] == 0xff &&
        bytes[1] == 0xd8 &&
        bytes[bytes.length - 2] == 0xff &&
        bytes.last == 0xd9;
  }

  static String _requiredValue(String value, String name) {
    final cleaned = value.trim();
    if (cleaned.isEmpty) {
      throw ArgumentError.value(value, name, 'must not be empty');
    }
    return cleaned;
  }
}
