import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../constants/app_constants.dart';
import '../config/app_config.dart';

class ApiException implements Exception {
  final String message;
  final int? statusCode;

  ApiException(this.message, {this.statusCode});

  /// 是否为网络层错误（无 HTTP 状态码：连接失败 / 超时 / 解析失败）。
  /// 为 false 时表示后端返回了业务错误（如 401/400），不应静默回退 Mock。
  bool get isNetworkError => statusCode == null;

  @override
  String toString() =>
      statusCode != null ? 'ApiException($statusCode): $message' : 'ApiException: $message';
}

/// HTTP 封装：统一超时、错误包装、日志与 Token 注入。
///
/// 单例使用；测试可通过 [ApiClient.overrideForTesting] 或 [ApiClient.forTesting] 注入 MockClient。
class ApiClient {
  static final ApiClient _instance = ApiClient._();
  static ApiClient? _override;

  factory ApiClient() => _override ?? _instance;

  @visibleForTesting
  static set overrideForTesting(ApiClient? client) => _override = client;

  @visibleForTesting
  factory ApiClient.forTesting(http.Client client) => ApiClient._(client: client);

  ApiClient._({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  String? _token;
  String _baseUrl = AppConfig.apiBaseUrl.isNotEmpty
      ? AppConfig.apiBaseUrl
      : AppConstants.baseUrl;
  Duration _timeout = const Duration(seconds: 15);

  String get baseUrl => _baseUrl;
  Duration get timeout => _timeout;

  void setToken(String? token) => _token = token;
  void setBaseUrl(String url) => _baseUrl = url;
  void setTimeout(Duration timeout) => _timeout = timeout;

  Map<String, String> get _headers => {
    if (_token != null) 'Authorization': 'Bearer $_token',
    'Accept': 'application/json',
  };

  Map<String, String> get _jsonHeaders => {
    ..._headers,
    'Content-Type': 'application/json',
  };

  Uri _uri(String path) {
    final base = _baseUrl.endsWith('/')
        ? _baseUrl.substring(0, _baseUrl.length - 1)
        : _baseUrl;
    final p = path.startsWith('/') ? path : '/$path';
    return Uri.parse('$base$p');
  }

  Future<dynamic> get(String path, {Duration? timeout}) => _guard(() async {
    final sw = Stopwatch()..start();
    final response = await _client
        .get(_uri(path), headers: _headers)
        .timeout(timeout ?? _timeout);
    _log('GET', path, response.statusCode, sw.elapsedMilliseconds);
    return _handleResponse(response);
  });

  Future<dynamic> post(String path, {Map<String, dynamic>? body, Duration? timeout}) =>
      _guard(() async {
        final sw = Stopwatch()..start();
        final response = await _client
            .post(
              _uri(path),
              headers: _jsonHeaders,
              body: body != null ? jsonEncode(body) : null,
            )
            .timeout(timeout ?? _timeout);
        _log('POST', path, response.statusCode, sw.elapsedMilliseconds);
        return _handleResponse(response);
      });

  Future<dynamic> put(String path, {Map<String, dynamic>? body, Duration? timeout}) =>
      _guard(() async {
        final sw = Stopwatch()..start();
        final response = await _client
            .put(
              _uri(path),
              headers: _jsonHeaders,
              body: body != null ? jsonEncode(body) : null,
            )
            .timeout(timeout ?? _timeout);
        _log('PUT', path, response.statusCode, sw.elapsedMilliseconds);
        return _handleResponse(response);
      });

  Future<dynamic> delete(String path, {Duration? timeout}) => _guard(() async {
    final sw = Stopwatch()..start();
    final response = await _client
        .delete(_uri(path), headers: _headers)
        .timeout(timeout ?? _timeout);
    _log('DELETE', path, response.statusCode, sw.elapsedMilliseconds);
    return _handleResponse(response);
  });

  /// 上传文件（multipart/form-data）。注意不携带 JSON Content-Type，
  /// 由 MultipartRequest 自行设置 multipart boundary。
  Future<dynamic> uploadFile(
    String path,
    File file, {
    String field = 'file',
    Duration? timeout,
  }) =>
      _guard(() async {
        final request = http.MultipartRequest('POST', _uri(path));
        request.headers.addAll(_headers);
        request.files.add(await http.MultipartFile.fromPath(field, file.path));
        final sw = Stopwatch()..start();
        final streamed = await _client.send(request).timeout(timeout ?? _timeout);
        final response = await http.Response.fromStream(streamed);
        _log('UPLOAD', path, response.statusCode, sw.elapsedMilliseconds);
        return _handleResponse(response);
      });

  /// 统一错误包装：网络异常 / 超时 / 解析失败 → ApiException。
  Future<dynamic> _guard(Future<dynamic> Function() action) async {
    try {
      return await action();
    } on ApiException {
      rethrow;
    } on TimeoutException {
      throw ApiException('请求超时，请检查网络后重试');
    } on SocketException {
      throw ApiException('无法连接服务器，请检查网络连接');
    } on http.ClientException catch (e) {
      throw ApiException('网络请求失败: ${e.message}');
    } on FormatException {
      throw ApiException('服务器返回数据格式错误');
    }
  }

  dynamic _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (response.bodyBytes.isEmpty) return null;
      // 显式按 UTF-8 解码，避免后端未声明 charset 时中文乱码
      return jsonDecode(utf8.decode(response.bodyBytes));
    }
    throw ApiException(
      _errorMessage(response),
      statusCode: response.statusCode,
    );
  }

  String _errorMessage(http.Response response) {
    try {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      if (data is Map<String, dynamic>) {
        final msg = data['message'] ?? data['msg'] ?? data['error'];
        if (msg is String && msg.isNotEmpty) return msg;
      }
    } catch (_) {}
    return '请求失败 (${response.statusCode})';
  }

  void _log(String method, String path, int statusCode, int ms) {
    debugPrint('[ApiClient] $method $path → $statusCode (${ms}ms)');
  }
}
