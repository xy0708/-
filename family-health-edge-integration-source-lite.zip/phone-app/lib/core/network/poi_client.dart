import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;

import '../../models/hospital.dart';
import '../config/app_config.dart';

/// 附近医疗机构检索客户端。
///
/// 数据源优先级：
/// 1. 高德 POI（需构建期 `--dart-define=AMAP_KEY`，国内快且准）；
/// 2. OpenStreetMap Overpass（免密钥，双镜像并行竞速，国内可能较慢）。
///
/// 全部失败时抛异常，由调用方降级为「检索失败 + 重试」，不展示固定演示数据。
/// 后续接入后端接口时，只需替换本类实现。
class PoiClient {
  const PoiClient._();

  static const List<String> _overpassEndpoints = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
  ];

  static const Duration _sourceTimeout = Duration(seconds: 18);

  /// 检索指定坐标周边的医院与诊所，按距离升序返回。
  static Future<List<Hospital>> fetchNearbyMedical({
    required double latitude,
    required double longitude,
    double radiusMeters = 5000,
    int limit = 12,
  }) async {
    final errors = <String>[];

    // 1) 高德 POI（可选数据源）
    if (AppConfig.amapKey.isNotEmpty) {
      try {
        final list = await _fetchAmap(
          latitude: latitude,
          longitude: longitude,
          radiusMeters: radiusMeters,
          limit: limit,
        );
        return list;
      } catch (e) {
        errors.add('amap: $e');
      }
    }

    // 2) Overpass 双镜像并行竞速，任一成功即返回
    try {
      return await _fetchOverpass(
        latitude: latitude,
        longitude: longitude,
        radiusMeters: radiusMeters,
        limit: limit,
      );
    } catch (e) {
      errors.add('overpass: $e');
    }

    throw Exception('全部 POI 数据源不可用（${errors.join('；')}）');
  }

  // ---------- 高德 ----------

  static Future<List<Hospital>> _fetchAmap({
    required double latitude,
    required double longitude,
    required double radiusMeters,
    required int limit,
  }) async {
    final uri = Uri.parse(
      'https://restapi.amap.com/v3/place/around'
      '?key=${AppConfig.amapKey}'
      '&location=${longitude.toStringAsFixed(6)},${latitude.toStringAsFixed(6)}'
      '&types=090000&radius=${radiusMeters.round()}&offset=${limit * 2}'
      '&sortrule=distance&output=json',
    );
    final resp = await http.get(uri).timeout(_sourceTimeout);
    if (resp.statusCode != 200) {
      throw Exception('HTTP ${resp.statusCode}');
    }
    return parseAmapResponse(
      utf8.decode(resp.bodyBytes),
      latitude: latitude,
      longitude: longitude,
      limit: limit,
    );
  }

  /// 解析高德 v3/place/around 响应，过滤无效条目并按距离排序。
  static List<Hospital> parseAmapResponse(
    String body, {
    required double latitude,
    required double longitude,
    int limit = 12,
  }) {
    final data = json.decode(body) as Map<String, dynamic>;
    if (data['status'] != '1') {
      throw Exception('amap ${(data['info'] ?? '').toString()}');
    }
    final pois = data['pois'] as List<dynamic>? ?? const [];
    final hospitals = <Hospital>[];
    for (final p in pois) {
      if (p is! Map<String, dynamic>) continue;
      final name = (p['name'] as String?)?.trim();
      final location = (p['location'] as String?)?.split(',');
      if (name == null || name.isEmpty || location == null || location.length < 2) {
        continue;
      }
      final lon = double.tryParse(location[0]);
      final lat = double.tryParse(location[1]);
      if (lat == null || lon == null) continue;

      final type = (p['type'] as String?) ?? '';
      hospitals.add(Hospital(
        name: name,
        latitude: lat,
        longitude: lon,
        distanceKm: distanceKm(latitude, longitude, lat, lon),
        kind: type.contains('诊所') ? 'clinic' : 'hospital',
      ));
    }
    hospitals.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
    return hospitals.take(limit).toList();
  }

  // ---------- Overpass ----------

  static Future<List<Hospital>> _fetchOverpass({
    required double latitude,
    required double longitude,
    required double radiusMeters,
    required int limit,
  }) async {
    final query = '[out:json][timeout:15];'
        '('
        'node["amenity"="hospital"](around:$radiusMeters,$latitude,$longitude);'
        'way["amenity"="hospital"](around:$radiusMeters,$latitude,$longitude);'
        'node["amenity"="clinic"](around:$radiusMeters,$latitude,$longitude);'
        'way["amenity"="clinic"](around:$radiusMeters,$latitude,$longitude);'
        ');'
        'out center 50;';

    // 并行请求所有镜像，等待全部返回（上限 _sourceTimeout）后择优：
    // 取第一个非空结果；均为空视为合法的「附近没有」；全失败则抛异常。
    final results = await Future.wait(
      _overpassEndpoints.map((endpoint) => _tryOverpass(endpoint, query,
          latitude: latitude, longitude: longitude, limit: limit)),
    );

    for (final list in results) {
      if (list != null && list.isNotEmpty) return list;
    }
    final firstNotNull = results.whereType<List<Hospital>>().firstOrNull;
    if (firstNotNull != null) return firstNotNull;
    throw Exception('Overpass 镜像均不可达');
  }

  static Future<List<Hospital>?> _tryOverpass(
    String endpoint,
    String query, {
    required double latitude,
    required double longitude,
    required int limit,
  }) async {
    try {
      final resp = await http
          .post(Uri.parse(endpoint), body: {'data': query})
          .timeout(_sourceTimeout);
      if (resp.statusCode != 200) return null;
      return parseOverpassResponse(
        utf8.decode(resp.bodyBytes),
        latitude: latitude,
        longitude: longitude,
        limit: limit,
      );
    } catch (_) {
      return null;
    }
  }

  /// 解析 Overpass JSON 响应：过滤未命名设施、按距离排序、截取前 limit 条。
  static List<Hospital> parseOverpassResponse(
    String body, {
    required double latitude,
    required double longitude,
    int limit = 12,
  }) {
    final data = json.decode(body) as Map<String, dynamic>;
    final elements = data['elements'] as List<dynamic>? ?? const [];
    final hospitals = <Hospital>[];

    for (final e in elements) {
      if (e is! Map<String, dynamic>) continue;
      final tags = e['tags'] as Map<String, dynamic>?;
      final name = (tags?['name:zh'] ?? tags?['name']) as String?;
      if (name == null || name.trim().isEmpty) continue;

      final center = e['center'] as Map<String, dynamic>?;
      final lat = (e['lat'] ?? center?['lat']) as num?;
      final lon = (e['lon'] ?? center?['lon']) as num?;
      if (lat == null || lon == null) continue;

      hospitals.add(Hospital(
        name: name.trim(),
        latitude: lat.toDouble(),
        longitude: lon.toDouble(),
        distanceKm: distanceKm(latitude, longitude, lat.toDouble(), lon.toDouble()),
        kind: (tags?['amenity'] as String?) ?? 'hospital',
      ));
    }

    hospitals.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
    return hospitals.take(limit).toList();
  }

  /// 球面距离（haversine），单位公里。
  static double distanceKm(double lat1, double lon1, double lat2, double lon2) {
    const r = 6371.0;
    final dLat = _rad(lat2 - lat1);
    final dLon = _rad(lon2 - lon1);
    final a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_rad(lat1)) * cos(_rad(lat2)) * sin(dLon / 2) * sin(dLon / 2);
    return 2 * r * atan2(sqrt(a), sqrt(1 - a));
  }

  static double _rad(double deg) => deg * pi / 180;
}
