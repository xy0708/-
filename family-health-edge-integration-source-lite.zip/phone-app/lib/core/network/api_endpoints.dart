class ApiEndpoints {
  static const String scanDevices = '/api/devices/scan';
  static const String bindDevice = '/api/devices/bind';
  static const String deviceStatus = '/api/devices/status';
  static const String healthSummary = '/api/health/summary';
  static const String healthUpload = '/api/health/upload';
  static const String healthTrend = '/api/health/trend';
  static const String aiReportLatest = '/api/ai/report/latest';
  static const String aiOcrUpload = '/api/ai/ocr/upload';
  static const String alertsActive = '/api/alerts/active';
}
