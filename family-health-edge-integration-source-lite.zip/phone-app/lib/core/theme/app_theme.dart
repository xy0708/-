import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppTheme {
  static const Color primaryGreen = Color(0xFF4CAF50);
  static const Color accentBlue = Color(0xFF2196F3);
  static const Color warningRed = Color(0xFFF44336);
  static const Color bgLight = Color(0xFFF5F5F5);
  static const Color cardShadow = Color(0x1A000000);
  static const Color surfaceWhite = Colors.white;

  /// 助老模式（高对比度）下的品牌绿：更深的绿底白字对比更强。
  static const Color primaryGreenHC = Color(0xFF1B5E20);

  /// 助老模式（高对比度）深色主题下的品牌绿：更亮的绿保证黑底可读。
  static const Color primaryGreenHCDark = Color(0xFF81C784);

  static ThemeData lightTheme({bool highContrast = false}) {
    final scheme = ColorScheme.fromSeed(
      seedColor: primaryGreen,
      brightness: Brightness.light,
      surface: surfaceWhite,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: highContrast
          ? scheme.copyWith(
              primary: primaryGreenHC,
              onSurface: Colors.black,
              onSurfaceVariant: Colors.black87,
            )
          : scheme,
      scaffoldBackgroundColor: highContrast ? surfaceWhite : bgLight,
      appBarTheme: const AppBarTheme(
        centerTitle: true,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
      ),
      cardTheme: CardThemeData(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        shadowColor: cardShadow,
        color: surfaceWhite,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: primaryGreen,
        backgroundColor: surfaceWhite,
        elevation: 0,
      ),
    );
  }

  /// 深色主题：同一品牌绿种子色，表面/背景由 ColorScheme 派生。
  /// 助老高对比度：纯黑底、纯白文字、更亮的品牌绿。
  static ThemeData darkTheme({bool highContrast = false}) {
    var scheme = ColorScheme.fromSeed(
      seedColor: primaryGreen,
      brightness: Brightness.dark,
    );
    if (highContrast) {
      scheme = scheme.copyWith(
        surface: Colors.black,
        onSurface: Colors.white,
        onSurfaceVariant: Colors.white70,
        primary: primaryGreenHCDark,
      );
    }
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      appBarTheme: const AppBarTheme(
        centerTitle: true,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
      ),
      cardTheme: CardThemeData(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: highContrast
              ? const BorderSide(color: Colors.white24)
              : BorderSide.none,
        ),
        shadowColor: Colors.black45,
        color: highContrast ? Colors.black : scheme.surfaceContainerHigh,
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: scheme.primary,
        backgroundColor:
            highContrast ? Colors.black : scheme.surfaceContainerHigh,
        elevation: 0,
      ),
    );
  }
}

/// 主题感知的便捷取色：页面统一从这里取表面/文字/系统栏样式，
/// 替代散落的 Colors.white / Colors.grey / bgLight 硬编码。
extension AppThemeContext on BuildContext {
  ThemeData get appTheme => Theme.of(this);

  /// 页面背景色。
  Color get pageBg => appTheme.scaffoldBackgroundColor;

  /// 卡片/面板表面色。
  Color get surface => appTheme.colorScheme.surface;

  /// 次要文字色（替代 Colors.grey；助老高对比度下自动增强）。
  Color get textSecondary => appTheme.colorScheme.onSurfaceVariant;

  bool get isDark => appTheme.brightness == Brightness.dark;

  /// 系统导航栏使用与底部导航栏一致的不透明主题色。
  /// 注：部分兼容环境（如鸿蒙卓易通）不支持透明/edge-to-edge 导航栏，
  /// 透明会透出白色窗口底，因此这里必须用不透明色。
  SystemUiOverlayStyle get overlayStyle {
    final scheme = appTheme.colorScheme;
    return SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
      systemNavigationBarColor: scheme.surface,
      systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
    );
  }
}
