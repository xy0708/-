import 'dart:typed_data';
import 'pdf_saver_stub.dart'
    if (dart.library.io) 'pdf_saver_io.dart'
    if (dart.library.js_interop) 'pdf_saver_web.dart';

abstract class PdfSaver {
  static Future<String?> saveBytes(Uint8List bytes, String fileName) {
    return savePdfBytes(bytes, fileName);
  }
}
