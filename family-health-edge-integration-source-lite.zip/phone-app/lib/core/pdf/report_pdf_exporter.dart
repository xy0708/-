import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../models/family_member.dart';
import '../../models/health_alert.dart';
import '../../models/health_record.dart';
import '../../models/health_report.dart';
import '../../models/medical_history_entry.dart';
import '../../models/reminder.dart';
import '../assessment/assessment_engine.dart';
import '../assessment/health_stats.dart';
import 'pdf_saver.dart';
import 'report_pdf_charts.dart';
import 'report_pdf_styles.dart';

/// 生成家庭健康评估报告 PDF。
///
/// 除 [HealthReport] 本身携带的评估结果与原始记录外，还可以把家庭成员档案、
/// 健康预警、提醒计划、病史记录一并带入报告。这些跨模块数据由调用方
/// （页面层从各 Provider 读取）以参数形式传入，导出器本身不依赖 Provider。
class ReportPdfExporter {
  ReportPdfExporter._();

  static const String _fontAsset = 'assets/fonts/NotoSansSC-Regular.ttf';

  static Future<String?> export({
    required HealthReport report,
    FamilyMember? member,
    List<HealthAlert> alerts = const [],
    List<Reminder> reminders = const [],
    List<MedicalHistoryEntry> medicalHistory = const [],
    List<FamilyMember> familyMembers = const [],
  }) async {
    final doc = await buildDocument(
      report: report,
      member: member,
      alerts: alerts,
      reminders: reminders,
      medicalHistory: medicalHistory,
      familyMembers: familyMembers,
    );

    final bytes = await doc.save();
    final fileName = '健康评估报告_${_safeName(report.memberName)}_${report.id}.pdf';
    return PdfSaver.saveBytes(bytes, fileName);
  }

  /// 构建文档但不落盘，供测试直接渲染整份报告（不触碰平台通道）。
  @visibleForTesting
  static Future<pw.Document> buildDocument({
    required HealthReport report,
    FamilyMember? member,
    List<HealthAlert> alerts = const [],
    List<Reminder> reminders = const [],
    List<MedicalHistoryEntry> medicalHistory = const [],
    List<FamilyMember> familyMembers = const [],
  }) async {
    final font = pw.Font.ttf(await rootBundle.load(_fontAsset));
    // bold/italic 必须显式指向同一个 TTF：pdf 包不做合成加粗，
    // 且缺省会回退到 Helvetica，中文会直接抛编码异常。
    final theme = pw.ThemeData.withFont(
      base: font,
      bold: font,
      italic: font,
      boldItalic: font,
      fontFallback: [font],
    );
    final document = pw.Document(theme: theme);

    final stats = HealthStats.compute(report.records);
    final scopedAlerts = report.memberId == null
        ? alerts
        : alerts.where((a) => a.memberId == report.memberId).toList();

    document.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(34, 30, 34, 32),
        theme: theme,
        maxPages: 30,
        header: (context) => _header(report),
        footer: (context) => _footer(context),
        build: (context) => [
          _titleBand(report),
          pw.SizedBox(height: 12),
          ..._overviewSection(report, member, stats),
          // 首页放总览，预警与趋势另起一页；
          // 趋势图整块高度较大，与预警同页才不会留下大半页空白。
          pw.NewPage(),
          ..._alertSection(scopedAlerts),
          pw.SizedBox(height: 14),
          ..._trendSection(report, stats),
          pw.SizedBox(height: 14),
          ..._detailSection(report, stats),
          pw.NewPage(),
          ..._suggestionSection(report),
          pw.SizedBox(height: 14),
          ..._reminderSection(context, reminders),
          pw.SizedBox(height: 14),
          ..._historySection(context, medicalHistory),
          pw.SizedBox(height: 14),
          ..._familySection(context, familyMembers, member),
          pw.SizedBox(height: 18),
          _disclaimer(report),
        ],
      ),
    );

    return document;
  }

  // ---------- 页眉页脚 ----------

  static pw.Widget _header(HealthReport report) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 10),
      padding: const pw.EdgeInsets.only(bottom: 4),
      decoration: const pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: ReportPdfStyles.line, width: 0.6)),
      ),
      child: pw.Row(
        children: [
          pw.Text('家庭健康管理 · 健康评估报告', style: ReportPdfStyles.caption),
          pw.Spacer(),
          pw.Text('${report.memberName} · ${report.type}', style: ReportPdfStyles.caption),
        ],
      ),
    );
  }

  static pw.Widget _footer(pw.Context context) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(top: 8),
      padding: const pw.EdgeInsets.only(top: 4),
      decoration: const pw.BoxDecoration(
        border: pw.Border(top: pw.BorderSide(color: ReportPdfStyles.line, width: 0.6)),
      ),
      child: pw.Row(
        children: [
          pw.Text('本报告仅供参考，不构成医疗建议', style: ReportPdfStyles.caption),
          pw.Spacer(),
          pw.Text(
            '第 ${context.pageNumber} / ${context.pagesCount} 页',
            style: ReportPdfStyles.caption,
          ),
        ],
      ),
    );
  }

  // ---------- 标题带 ----------

  static pw.Widget _titleBand(HealthReport report) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: pw.BoxDecoration(
        color: ReportPdfStyles.primaryGreen,
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Row(
        children: [
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('家庭健康评估报告', style: ReportPdfStyles.bandTitle),
                pw.SizedBox(height: 3),
                pw.Text(
                  '${report.type} · ${report.memberName} · 数据周期 ${_periodText(report)}',
                  style: const pw.TextStyle(fontSize: 8.5, color: PdfColors.green100),
                ),
              ],
            ),
          ),
          // 白底绿字的评级标签：半透明白底在绿底标题带上几乎看不见（已踩过）
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: pw.BoxDecoration(
              color: PdfColors.white,
              borderRadius: pw.BorderRadius.circular(12),
            ),
            child: pw.Text(
              '评级 ${ReportPdfStyles.gradeOf(report.overallScore)}',
              style: const pw.TextStyle(fontSize: 10, color: ReportPdfStyles.primaryGreenDark),
            ),
          ),
        ],
      ),
    );
  }

  // ---------- 一、基本信息 + 综合评分 + 摘要 + 四维明细 ----------

  static List<pw.Widget> _overviewSection(
    HealthReport report,
    FamilyMember? member,
    HealthStats stats,
  ) {
    return [
      ReportPdfStyles.sectionTitleWidget('一、报告基本信息'),
      ReportPdfStyles.infoGrid(_basicInfoPairs(report, member)),
      pw.SizedBox(height: 14),
      _scoreCard(report),
      pw.SizedBox(height: 14),
      ReportPdfStyles.sectionTitleWidget('二、评估摘要'),
      ReportPdfStyles.card(
        child: pw.Text(report.summary, style: ReportPdfStyles.body),
      ),
      pw.SizedBox(height: 14),
      ReportPdfStyles.sectionTitleWidget('三、四维评分明细'),
      _dimensionTable(report, stats),
    ];
  }

  static List<(String, String)> _basicInfoPairs(HealthReport report, FamilyMember? member) {
    return [
      ('姓名', member?.name ?? report.memberName),
      ('关系', member?.relation ?? '—'),
      ('性别', member?.gender ?? '—'),
      ('年龄', member != null ? '${member.age} 岁' : '—'),
      ('报告编号', report.id),
      ('生成时间', _formatDateTime(report.generatedAt)),
      ('数据周期', _periodText(report)),
      ('数据天数', report.periodDays > 0 ? '${report.periodDays} 天' : '—'),
      ('既往病史', _nonEmpty(member?.medicalHistory, '未记录')),
      ('数据来源', member != null && member.hasDevice ? '已绑定智能设备' : '手动录入 / 未绑定设备'),
    ];
  }

  /// 综合评分卡：左侧大号总分 + 评级，右侧当日四项体征。
  static pw.Widget _scoreCard(HealthReport report) {
    final vital = report.vitalSummary;

    final vitals = vital == null
        ? ReportPdfStyles.emptyNotice('暂无当日体征数据')
        : pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              ReportPdfStyles.metricCard(
                name: '步数',
                value: '${vital.todaySteps}',
                unit: '步',
                color: ReportPdfStyles.blue,
              ),
              ReportPdfStyles.metricCard(
                name: '睡眠',
                value: vital.todaySleep.toStringAsFixed(1),
                unit: 'h',
                color: const PdfColor.fromInt(0xFF3F51B5),
              ),
              ReportPdfStyles.metricCard(
                name: '脉搏',
                value: '${vital.currentHeartRate}',
                unit: '次/分',
                color: ReportPdfStyles.warningRed,
              ),
              ReportPdfStyles.metricCard(
                name: '活动度',
                value: '${(vital.todayActivity * 100).round()}',
                unit: '%',
                color: ReportPdfStyles.orange,
              ),
            ],
          );

    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: ReportPdfStyles.gradeSurface(report.overallScore),
        borderRadius: pw.BorderRadius.circular(6),
        border: pw.Border.all(color: ReportPdfStyles.gradeColor(report.overallScore), width: 0.8),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Text(report.overallScore.toStringAsFixed(0), style: ReportPdfStyles.scoreNumber),
              pw.SizedBox(width: 8),
              pw.Padding(
                padding: const pw.EdgeInsets.only(bottom: 6),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('综合健康评分', style: ReportPdfStyles.body),
                    pw.SizedBox(height: 2),
                    pw.Text(
                      // 评级已在标题带上给出，这里只补当日状态
                      '共 ${report.dimensions.length} 个维度 · 当日健康状态：${_statusText(vital?.healthStatus)}',
                      style: ReportPdfStyles.caption,
                    ),
                  ],
                ),
              ),
            ],
          ),
          pw.SizedBox(height: 10),
          pw.Text('当日体征', style: ReportPdfStyles.cardTitle),
          pw.SizedBox(height: 5),
          vitals,
        ],
      ),
    );
  }

  /// 四维评分明细：同时展示评估得分与统计口径的周均值/达标率。
  static pw.Widget _dimensionTable(HealthReport report, HealthStats stats) {
    if (report.dimensions.isEmpty) {
      return ReportPdfStyles.emptyNotice('本次报告未包含维度评分明细。');
    }

    final rows = <pw.TableRow>[
      ReportPdfStyles.headerRow(const ['维度', '周均值', '得分', '等级', '达标率']),
    ];

    for (var i = 0; i < report.dimensions.length; i++) {
      final d = report.dimensions[i];
      final stat = _statOf(stats, d.name);
      rows.add(
        ReportPdfStyles.dataRow(
          [
            ReportPdfStyles.cell(d.name),
            ReportPdfStyles.cell(
              stat == null ? '—' : '${stat.format(stat.avg)} ${stat.unit}',
              center: true,
            ),
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                ReportPdfStyles.progressBar(d.score, width: 90),
                pw.SizedBox(height: 2),
                pw.Text('${d.score.toStringAsFixed(0)} 分', style: ReportPdfStyles.caption),
              ],
            ),
            ReportPdfStyles.cell(d.level, center: true),
            ReportPdfStyles.cell(
              stat == null || stat.totalDays == 0
                  ? '—'
                  : '${stat.achievedDays}/${stat.totalDays} 天',
              center: true,
            ),
          ],
          odd: i.isOdd,
        ),
      );
    }

    return pw.Table(
      border: ReportPdfStyles.tableBorder,
      columnWidths: {
        0: const pw.FixedColumnWidth(52),
        1: const pw.FlexColumnWidth(1.1),
        2: const pw.FixedColumnWidth(100),
        3: const pw.FixedColumnWidth(38),
        4: const pw.FlexColumnWidth(0.9),
      },
      children: rows,
    );
  }

  // ---------- 四、健康预警 ----------

  static List<pw.Widget> _alertSection(List<HealthAlert> alerts) {
    return [
      ReportPdfStyles.sectionTitleWidget('四、健康预警'),
      if (alerts.isEmpty)
        ReportPdfStyles.emptyNotice('本期未发现异常指标，各项监测数据处于可接受范围。')
      else
        ...alerts.map(_alertCard),
    ];
  }

  static pw.Widget _alertCard(HealthAlert alert) {
    final color = _alertColor(alert.level);
    // 左侧色条用独立的 Row 子项绘制：pdf 包对「四边不等宽的边框 + 圆角」
    // 组合会算错布局高度，导致 MultiPage 无限翻页（PdfTooBigPageException）。
    return pw.Container(
      width: double.infinity,
      margin: const pw.EdgeInsets.only(bottom: 6),
      decoration: pw.BoxDecoration(
        color: PdfColors.white,
        borderRadius: pw.BorderRadius.circular(5),
        border: pw.Border.all(color: ReportPdfStyles.line, width: 0.6),
      ),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Container(width: 3, height: 42, color: color),
          pw.Expanded(
            child: pw.Padding(
              padding: const pw.EdgeInsets.symmetric(horizontal: 9, vertical: 8),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Row(
                    children: [
                      pw.Container(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: pw.BoxDecoration(
                          color: color,
                          borderRadius: pw.BorderRadius.circular(3),
                        ),
                        child: pw.Text(
                          _alertLevelText(alert.level),
                          style: const pw.TextStyle(fontSize: 7.5, color: PdfColors.white),
                        ),
                      ),
                      pw.SizedBox(width: 6),
                      pw.Text(alert.title, style: ReportPdfStyles.bodyStrong),
                      pw.Spacer(),
                      pw.Text(_formatDateTime(alert.createdAt), style: ReportPdfStyles.caption),
                    ],
                  ),
                  pw.SizedBox(height: 4),
                  pw.Text(alert.content, style: ReportPdfStyles.body),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------- 五、趋势图 ----------

  static List<pw.Widget> _trendSection(HealthReport report, HealthStats stats) {
    final records = report.records;
    if (records.length < 2) {
      return [
        ReportPdfStyles.sectionTitleWidget('五、趋势分析'),
        ReportPdfStyles.emptyNotice('记录不足两天，无法绘制趋势图。'),
      ];
    }

    final labels = records.map((r) => _formatShortDay(r.date)).toList();

    pw.Widget chartFor(String name, {required bool bar, required List<double> anchors}) {
      final stat = _statOf(stats, name);
      final values = _valuesOf(records, name);
      final caption = stat == null
          ? ''
          : '周均 ${stat.format(stat.avg)}${stat.unit} · 达标 ${stat.achievedDays}/${stat.totalDays} 天'
              ' · 参考 ${stat.targetText} · 趋势${stat.trend}';
      return ReportPdfCharts.trendChart(
        title: '$name趋势（近 ${records.length} 天）',
        caption: caption,
        labels: labels,
        values: values,
        color: _metricColor(name),
        anchors: anchors,
        bar: bar,
      );
    }

    return [
      ReportPdfStyles.sectionTitleWidget('五、趋势分析'),
      ReportPdfCharts.grid([
        chartFor('步数', bar: true, anchors: [AssessmentEngine.stepsGood.toDouble()]),
        chartFor('脉搏', bar: false, anchors: [
          AssessmentEngine.hrNormalLow.toDouble(),
          AssessmentEngine.hrNormalHigh.toDouble(),
        ]),
        chartFor('睡眠', bar: false, anchors: [
          AssessmentEngine.sleepGoodLow,
          AssessmentEngine.sleepExcellent,
        ]),
        chartFor('活动度', bar: true, anchors: [
          AssessmentEngine.activityGood * 100,
        ]),
      ]),
    ];
  }

  // ---------- 六、数据明细 ----------

  static List<pw.Widget> _detailSection(HealthReport report, HealthStats stats) {
    return [
      ReportPdfStyles.sectionTitleWidget('六、每日数据明细'),
      if (report.records.isEmpty)
        ReportPdfStyles.emptyNotice('本期没有采集到体征记录。')
      else
        _dailyTable(report.records),
      pw.SizedBox(height: 14),
      ReportPdfStyles.sectionTitleWidget('七、统计汇总'),
      if (stats.metrics.isEmpty)
        ReportPdfStyles.emptyNotice('数据不足，无法统计。')
      else
        _summaryTable(stats),
    ];
  }

  static pw.Widget _dailyTable(List<HealthRecord> records) {
    final rows = <pw.TableRow>[
      ReportPdfStyles.headerRow(const [
        '日期',
        '步数',
        '睡眠(h)',
        '脉搏(次/分)',
        '活动度(%)',
        '达标项',
      ]),
    ];

    for (var i = 0; i < records.length; i++) {
      final r = records[i];
      final hits = _hitCount(r);
      rows.add(
        ReportPdfStyles.dataRow(
          [
            ReportPdfStyles.cell(_formatDay(r.date)),
            ReportPdfStyles.cell('${r.steps}', center: true),
            ReportPdfStyles.cell(r.sleepHours.toStringAsFixed(1), center: true),
            ReportPdfStyles.cell('${r.heartRate}', center: true),
            ReportPdfStyles.cell('${(r.activityLevel * 100).round()}', center: true),
            pw.Align(
              alignment: pw.Alignment.center,
              child: pw.Text(
                '$hits/4',
                style: pw.TextStyle(
                  fontSize: 8.5,
                  color: hits == 4 ? ReportPdfStyles.primaryGreenDark : ReportPdfStyles.orange,
                ),
              ),
            ),
          ],
          odd: i.isOdd,
        ),
      );
    }

    return pw.Table(
      border: ReportPdfStyles.tableBorder,
      columnWidths: {
        0: const pw.FlexColumnWidth(1.3),
        1: const pw.FlexColumnWidth(1),
        2: const pw.FlexColumnWidth(1),
        3: const pw.FlexColumnWidth(1.2),
        4: const pw.FlexColumnWidth(1),
        5: const pw.FlexColumnWidth(1),
      },
      children: rows,
    );
  }

  static pw.Widget _summaryTable(HealthStats stats) {
    final rows = <pw.TableRow>[
      ReportPdfStyles.headerRow(const [
        '指标',
        '周均值',
        '最低',
        '最高',
        '达标天数',
        '达标率',
        '参考范围',
        '趋势',
      ]),
    ];

    for (var i = 0; i < stats.metrics.length; i++) {
      final m = stats.metrics[i];
      rows.add(
        ReportPdfStyles.dataRow(
          [
            ReportPdfStyles.cell(m.name),
            ReportPdfStyles.cell('${m.format(m.avg)} ${m.unit}', center: true),
            ReportPdfStyles.cell(m.format(m.min), center: true),
            ReportPdfStyles.cell(m.format(m.max), center: true),
            ReportPdfStyles.cell('${m.achievedDays}/${m.totalDays}', center: true),
            pw.Align(
              alignment: pw.Alignment.center,
              child: pw.Text(
                '${(m.achieveRate * 100).round()}%',
                style: pw.TextStyle(
                  fontSize: 8.5,
                  color: m.achieveRate >= 0.8
                      ? ReportPdfStyles.primaryGreenDark
                      : ReportPdfStyles.orange,
                ),
              ),
            ),
            ReportPdfStyles.cell(m.targetText, center: true),
            pw.Align(
              alignment: pw.Alignment.center,
              child: pw.Text(
                _trendArrow(m.trend),
                style: pw.TextStyle(fontSize: 8.5, color: _trendColor(m.trend)),
              ),
            ),
          ],
          odd: i.isOdd,
        ),
      );
    }

    return pw.Table(
      border: ReportPdfStyles.tableBorder,
      columnWidths: {
        0: const pw.FlexColumnWidth(0.9),
        1: const pw.FlexColumnWidth(1.3),
        2: const pw.FlexColumnWidth(0.8),
        3: const pw.FlexColumnWidth(0.8),
        4: const pw.FlexColumnWidth(1.1),
        5: const pw.FlexColumnWidth(0.9),
        6: const pw.FlexColumnWidth(1.7),
        7: const pw.FlexColumnWidth(0.8),
      },
      children: rows,
    );
  }

  // ---------- 八、改善建议 ----------

  static List<pw.Widget> _suggestionSection(HealthReport report) {
    final suggestions = report.suggestions.isEmpty
        ? const ['各项指标表现良好，请继续保持规律作息与运动习惯。']
        : report.suggestions;

    return [
      ReportPdfStyles.sectionTitleWidget('八、改善建议'),
      ...suggestions.asMap().entries.map(
        (e) => ReportPdfStyles.bullet(e.value, index: e.key + 1),
      ),
    ];
  }

  // ---------- 九、健康提醒计划 ----------

  static List<pw.Widget> _reminderSection(pw.Context context, List<Reminder> reminders) {
    final enabled = reminders.where((r) => r.enabled).toList();
    return [
      ReportPdfStyles.sectionTitleWidget('九、健康提醒计划'),
      if (enabled.isEmpty)
        ReportPdfStyles.emptyNotice('尚未设置健康提醒。')
      else ...[
        pw.Text(
          '以下为家庭通用提醒（不区分成员），可在 APP「健康提醒」中调整。',
          style: ReportPdfStyles.caption,
        ),
        pw.SizedBox(height: 5),
        ReportPdfStyles.dataTable(
          context: context,
          headers: const ['提醒时间', '类型', '提醒内容', '状态'],
          data: [
            for (final r in enabled) [r.timeText, r.title, _reminderContent(r), '已开启'],
          ],
          columnWidths: {
            0: const pw.FlexColumnWidth(1.1),
            1: const pw.FlexColumnWidth(0.9),
            2: const pw.FlexColumnWidth(2.4),
            3: const pw.FlexColumnWidth(0.8),
          },
          cellAlignment: pw.Alignment.centerLeft,
        ),
      ],
    ];
  }

  static String _reminderContent(Reminder r) {
    final custom = r.customTitle.trim();
    if (custom.isNotEmpty) return custom;
    switch (r.type) {
      case ReminderType.medicine:
        return '按时服药';
      case ReminderType.bloodPressure:
        return '测量血压并记录';
      case ReminderType.bloodSugar:
        return '测量血糖并记录';
      case ReminderType.water:
        return '补充水分';
      case ReminderType.custom:
        return '自定义提醒';
    }
  }

  // ---------- 十、既往病史 ----------

  static List<pw.Widget> _historySection(
    pw.Context context,
    List<MedicalHistoryEntry> history,
  ) {
    return [
      ReportPdfStyles.sectionTitleWidget('十、既往病史'),
      if (history.isEmpty)
        ReportPdfStyles.emptyNotice('未记录既往病史。')
      else
        ReportPdfStyles.dataTable(
          context: context,
          headers: const ['病史名称', '确诊时间', '备注'],
          data: [
            for (final h in history) [
              h.name,
              _nonEmpty(h.diagnosedAt, '—'),
              _nonEmpty(h.note, '—'),
            ],
          ],
          columnWidths: {
            0: const pw.FlexColumnWidth(1.4),
            1: const pw.FlexColumnWidth(1),
            2: const pw.FlexColumnWidth(2.6),
          },
        ),
    ];
  }

  // ---------- 十一、家庭成员概览 ----------

  static List<pw.Widget> _familySection(
    pw.Context context,
    List<FamilyMember> members,
    FamilyMember? current,
  ) {
    return [
      ReportPdfStyles.sectionTitleWidget('十一、家庭成员概览'),
      if (members.isEmpty)
        ReportPdfStyles.emptyNotice('未维护家庭成员信息。')
      else
        ReportPdfStyles.dataTable(
          context: context,
          headers: const ['姓名', '关系', '性别', '年龄', '既往病史'],
          data: [
            for (final m in members)
              [
                '${m.name}${m.id == current?.id ? '（本报告对象）' : ''}',
                m.relation,
                m.gender,
                '${m.age} 岁',
                _nonEmpty(m.medicalHistory, '—'),
              ],
          ],
          columnWidths: {
            0: const pw.FlexColumnWidth(2),
            1: const pw.FlexColumnWidth(1),
            2: const pw.FlexColumnWidth(0.8),
            3: const pw.FlexColumnWidth(0.9),
            4: const pw.FlexColumnWidth(2.2),
          },
        ),
    ];
  }

  static pw.Widget _disclaimer(HealthReport report) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey100,
        borderRadius: pw.BorderRadius.circular(5),
        border: pw.Border.all(color: ReportPdfStyles.line, width: 0.6),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text('说明', style: ReportPdfStyles.cardTitle),
          pw.SizedBox(height: 3),
          pw.Text(
            '本报告由「家庭健康管理」APP 依据绑定的智能设备与手工录入数据自动生成，'
            '评估结果与改善建议仅供健康管理参考，不能替代医生诊断。'
            '若出现持续异常或身体不适，请及时前往正规医疗机构就诊。',
            style: const pw.TextStyle(fontSize: 8.5, color: ReportPdfStyles.textSecondary, lineSpacing: 3),
          ),
          pw.SizedBox(height: 6),
          pw.Text('报告生成时间：${_formatDateTime(report.generatedAt)}', style: ReportPdfStyles.caption),
        ],
      ),
    );
  }

  // ---------- 工具方法 ----------

  static MetricStat? _statOf(HealthStats stats, String name) {
    for (final m in stats.metrics) {
      if (m.name == name) return m;
    }
    return null;
  }

  static List<double> _valuesOf(List<HealthRecord> records, String name) {
    switch (name) {
      case '步数':
        return records.map((r) => r.steps.toDouble()).toList();
      case '睡眠':
        return records.map((r) => r.sleepHours).toList();
      case '脉搏':
        return records.map((r) => r.heartRate.toDouble()).toList();
      case '活动度':
        return records.map((r) => r.activityLevel * 100).toList();
      default:
        return const [];
    }
  }

  static PdfColor _metricColor(String name) {
    switch (name) {
      case '步数':
        return ReportPdfStyles.blue;
      case '睡眠':
        return const PdfColor.fromInt(0xFF3F51B5);
      case '脉搏':
        return ReportPdfStyles.warningRed;
      case '活动度':
        return ReportPdfStyles.primaryGreen;
      default:
        return ReportPdfStyles.primaryGreen;
    }
  }

  /// 一天内满足达标口径的项数（与 [HealthStats] 的判定一致）。
  static int _hitCount(HealthRecord r) {
    var hits = 0;
    if (r.steps >= AssessmentEngine.stepsGood) hits++;
    if (r.sleepHours >= AssessmentEngine.sleepGoodLow &&
        r.sleepHours <= AssessmentEngine.sleepExcellent) {
      hits++;
    }
    if (r.heartRate >= AssessmentEngine.hrNormalLow &&
        r.heartRate <= AssessmentEngine.hrNormalHigh) {
      hits++;
    }
    if (r.activityLevel >= AssessmentEngine.activityGood) hits++;
    return hits;
  }

  static PdfColor _alertColor(AlertLevel level) {
    switch (level) {
      case AlertLevel.danger:
        return ReportPdfStyles.warningRed;
      case AlertLevel.warning:
        return ReportPdfStyles.orange;
      case AlertLevel.info:
        return ReportPdfStyles.blue;
    }
  }

  static String _alertLevelText(AlertLevel level) {
    switch (level) {
      case AlertLevel.danger:
        return '危险';
      case AlertLevel.warning:
        return '关注';
      case AlertLevel.info:
        return '提示';
    }
  }

  static String _trendArrow(String trend) {
    switch (trend) {
      case '上升':
        return '↑ 上升';
      case '下降':
        return '↓ 下降';
      default:
        return '— 平稳';
    }
  }

  static PdfColor _trendColor(String trend) {
    switch (trend) {
      case '上升':
        return ReportPdfStyles.primaryGreenDark;
      case '下降':
        return ReportPdfStyles.orange;
      default:
        return ReportPdfStyles.textSecondary;
    }
  }

  static String _statusText(String? status) {
    switch (status) {
      case '良好':
        return '良好';
      case '需关注':
        return '需关注';
      default:
        return '未知';
    }
  }

  static String _nonEmpty(String? value, String fallback) {
    if (value == null || value.trim().isEmpty) return fallback;
    return value;
  }

  static String _periodText(HealthReport report) {
    final start = report.periodStart;
    final end = report.periodEnd;
    if (start == null || end == null) {
      return report.periodDays > 0 ? '近 ${report.periodDays} 天' : '暂无数据';
    }
    return '${_formatDay(start)} 至 ${_formatDay(end)}';
  }

  static String _formatDateTime(DateTime dt) {
    return '${_formatDay(dt)} ${_two(dt.hour)}:${_two(dt.minute)}';
  }

  static String _formatDay(DateTime dt) {
    return '${dt.year}-${_two(dt.month)}-${_two(dt.day)}';
  }

  static String _formatShortDay(DateTime dt) => '${_two(dt.month)}/${_two(dt.day)}';

  static String _two(int value) => value.toString().padLeft(2, '0');

  static String _safeName(String name) {
    return name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
  }
}
