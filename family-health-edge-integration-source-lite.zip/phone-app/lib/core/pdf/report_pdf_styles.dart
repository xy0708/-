import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

/// 报告 PDF 的配色、文本样式与可复用小组件。
///
/// 注意：pdf 包不会对字体做合成加粗，而项目只打包了 NotoSansSC-Regular，
/// 因此 `fontWeight: bold` 渲染出来与正文同粗。层级完全靠字号、颜色、
/// 色块底纹和左侧色条表达——这也是这里所有样式都显式指定 fontSize 的原因。
class ReportPdfStyles {
  ReportPdfStyles._();

  // ---------- 配色（与 AppTheme 对齐） ----------

  static const PdfColor primaryGreen = PdfColor.fromInt(0xFF4CAF50);
  static const PdfColor primaryGreenDark = PdfColor.fromInt(0xFF2E7D32);
  static const PdfColor primaryGreenSurface = PdfColor.fromInt(0xFFF1F8E9);
  static const PdfColor primaryGreenBorder = PdfColor.fromInt(0xFFC8E6C9);

  static const PdfColor warningRed = PdfColor.fromInt(0xFFF44336);
  static const PdfColor warningRedSurface = PdfColor.fromInt(0xFFFFEBEE);
  static const PdfColor orange = PdfColor.fromInt(0xFFFB8C00);
  static const PdfColor orangeSurface = PdfColor.fromInt(0xFFFFF3E0);
  static const PdfColor blue = PdfColor.fromInt(0xFF2196F3);
  static const PdfColor blueSurface = PdfColor.fromInt(0xFFE3F2FD);

  static const PdfColor textPrimary = PdfColor.fromInt(0xFF212121);
  static const PdfColor textSecondary = PdfColor.fromInt(0xFF616161);
  static const PdfColor textFaint = PdfColor.fromInt(0xFF9E9E9E);
  static const PdfColor line = PdfColor.fromInt(0xFFE0E0E0);

  // ---------- 文本样式 ----------

  static const pw.TextStyle bandTitle = pw.TextStyle(
    fontSize: 19,
    color: PdfColors.white,
  );

  static const pw.TextStyle sectionTitle = pw.TextStyle(
    fontSize: 13,
    color: primaryGreenDark,
  );

  static const pw.TextStyle cardTitle = pw.TextStyle(
    fontSize: 10.5,
    color: primaryGreenDark,
  );

  static const pw.TextStyle body = pw.TextStyle(
    fontSize: 9.5,
    color: textPrimary,
    lineSpacing: 3,
  );

  static const pw.TextStyle bodyStrong = pw.TextStyle(
    fontSize: 10,
    color: textPrimary,
    lineSpacing: 3,
  );

  static const pw.TextStyle label = pw.TextStyle(fontSize: 9, color: textSecondary);

  static const pw.TextStyle caption = pw.TextStyle(fontSize: 8, color: textFaint);

  static const pw.TextStyle scoreNumber = pw.TextStyle(fontSize: 38, color: primaryGreenDark);

  static const pw.TextStyle metricValue = pw.TextStyle(fontSize: 15, color: textPrimary);

  // ---------- 评级 ----------

  /// 综合分评级：与评估摘要中「较健康/需关注」的措辞口径保持一致。
  static String gradeOf(double score) {
    if (score >= 85) return '优秀';
    if (score >= 75) return '良好';
    if (score >= 60) return '一般';
    return '需关注';
  }

  static PdfColor gradeColor(double score) {
    if (score >= 85) return primaryGreenDark;
    if (score >= 75) return primaryGreen;
    if (score >= 60) return orange;
    return warningRed;
  }

  static PdfColor gradeSurface(double score) {
    if (score >= 75) return primaryGreenSurface;
    if (score >= 60) return orangeSurface;
    return warningRedSurface;
  }

  // ---------- 小组件 ----------

  /// 章节标题：左侧绿色竖条 + 标题文字 + 下方细分隔线。
  static pw.Widget sectionTitleWidget(String text) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            pw.Container(width: 4, height: 14, color: primaryGreen),
            pw.SizedBox(width: 6),
            pw.Text(text, style: sectionTitle),
          ],
        ),
        pw.SizedBox(height: 4),
        pw.Container(height: 0.8, color: primaryGreenBorder),
        pw.SizedBox(height: 7),
      ],
    );
  }

  /// 卡片：浅色底纹 + 圆角边框。
  static pw.Widget card({
    required pw.Widget child,
    PdfColor color = primaryGreenSurface,
    PdfColor borderColor = primaryGreenBorder,
    pw.EdgeInsets padding = const pw.EdgeInsets.all(10),
  }) {
    return pw.Container(
      width: double.infinity,
      padding: padding,
      decoration: pw.BoxDecoration(
        color: color,
        borderRadius: pw.BorderRadius.circular(5),
        border: pw.Border.all(color: borderColor, width: 0.7),
      ),
      child: child,
    );
  }

  /// 数据缺失时的占位提示条。
  static pw.Widget emptyNotice(String text) {
    return card(
      color: PdfColors.grey100,
      borderColor: line,
      padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: pw.Text(text, style: caption),
    );
  }

  /// 得分进度条：按固定宽度切分两段色块。
  ///
  /// 用固定宽度而不是 Expanded，是为了在表格单元格里也能确定尺寸。
  static pw.Widget progressBar(double score, {double width = 96, double height = 7}) {
    final filled = (score.clamp(0, 100) / 100 * width).roundToDouble();
    final color = gradeColor(score);
    return pw.Container(
      width: width,
      height: height,
      decoration: pw.BoxDecoration(
        color: PdfColors.grey300,
        borderRadius: pw.BorderRadius.circular(height / 2),
      ),
      child: pw.Row(
        children: [
          pw.Container(
            width: filled,
            height: height,
            decoration: pw.BoxDecoration(
              color: color,
              borderRadius: pw.BorderRadius.circular(height / 2),
            ),
          ),
        ],
      ),
    );
  }

  // ---------- 手工表格（需要自定义单元格控件时使用） ----------

  static const pw.TextStyle tableHeaderText = pw.TextStyle(
    fontSize: 8.5,
    color: primaryGreenDark,
  );

  static const pw.TextStyle tableCellText = pw.TextStyle(
    fontSize: 8.5,
    color: textPrimary,
  );

  /// 表头行：[repeat] 让表格跨页时自动重复表头。
  static pw.TableRow headerRow(List<String> labels, {bool repeat = true}) {
    return pw.TableRow(
      repeat: repeat,
      decoration: const pw.BoxDecoration(color: primaryGreenSurface),
      verticalAlignment: pw.TableCellVerticalAlignment.middle,
      children: labels
          .map(
            (l) => pw.Padding(
              padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 5),
              child: pw.Align(
                alignment: pw.Alignment.center,
                child: pw.Text(l, style: tableHeaderText),
              ),
            ),
          )
          .toList(),
    );
  }

  /// 数据行：[odd] 为 true 时使用浅灰底纹，形成斑马纹。
  static pw.TableRow dataRow(List<pw.Widget> cells, {bool odd = false}) {
    return pw.TableRow(
      decoration: odd ? const pw.BoxDecoration(color: PdfColors.grey100) : null,
      verticalAlignment: pw.TableCellVerticalAlignment.middle,
      children: cells
          .map(
            (c) => pw.Padding(
              padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 4),
              child: c,
            ),
          )
          .toList(),
    );
  }

  /// 表格文本单元格，[center] 控制是否居中。
  static pw.Widget cell(String text, {bool center = false}) {
    return pw.Align(
      alignment: center ? pw.Alignment.center : pw.Alignment.centerLeft,
      child: pw.Text(text, style: tableCellText),
    );
  }

  /// 表格边框样式（与 [dataTable] 保持一致）。
  static const pw.TableBorder tableBorder = pw.TableBorder(
    left: pw.BorderSide(color: line, width: 0.5),
    right: pw.BorderSide(color: line, width: 0.5),
    top: pw.BorderSide(color: line, width: 0.5),
    bottom: pw.BorderSide(color: line, width: 0.5),
    horizontalInside: pw.BorderSide(color: line, width: 0.5),
    verticalInside: pw.BorderSide(color: line, width: 0.5),
  );

  /// 带圆点前缀的项目符号行（NotoSansSC 自带 ● 字形）。
  static pw.Widget bullet(String text, {int? index}) {
    final prefix = index != null ? '$index.  ' : '●  ';
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 4),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            prefix,
            style: const pw.TextStyle(fontSize: 9.5, color: primaryGreenDark),
          ),
          pw.Expanded(child: pw.Text(text, style: body)),
        ],
      ),
    );
  }

  /// 键值对表格：label / value 逐行交替，2 列 × N 行。
  ///
  /// [pairs] 为 (label, value) 元组列表，按每行 2 组排布。
  static pw.Widget infoGrid(List<(String, String)> pairs) {
    const labelWidth = 62.0;
    final rows = <pw.TableRow>[];
    for (var i = 0; i < pairs.length; i += 2) {
      final left = pairs[i];
      final right = i + 1 < pairs.length ? pairs[i + 1] : null;
      rows.add(
        pw.TableRow(
          children: [
            _infoLabel(left.$1, labelWidth),
            _infoValue(left.$2),
            if (right != null) ...[
              _infoLabel(right.$1, labelWidth),
              _infoValue(right.$2),
            ] else ...[
              pw.SizedBox(),
              pw.SizedBox(),
            ],
          ],
        ),
      );
    }

    return pw.Table(
      border: const pw.TableBorder(
        horizontalInside: pw.BorderSide(color: line, width: 0.5),
      ),
      columnWidths: {
        0: const pw.FixedColumnWidth(labelWidth),
        1: const pw.FlexColumnWidth(1),
        2: const pw.FixedColumnWidth(labelWidth),
        3: const pw.FlexColumnWidth(1),
      },
      children: rows,
    );
  }

  static pw.Widget _infoLabel(String text, double width) {
    return pw.Container(
      width: width,
      padding: const pw.EdgeInsets.symmetric(vertical: 5, horizontal: 4),
      child: pw.Text(text, style: label),
    );
  }

  static pw.Widget _infoValue(String text) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 5, horizontal: 4),
      child: pw.Text(text, style: bodyStrong),
    );
  }

  /// 单项体征小卡：名称 + 数值 + 单位。
  static pw.Widget metricCard({
    required String name,
    required String value,
    required String unit,
    required PdfColor color,
  }) {
    return pw.Expanded(
      child: pw.Container(
        margin: const pw.EdgeInsets.symmetric(horizontal: 3),
        padding: const pw.EdgeInsets.symmetric(vertical: 8, horizontal: 6),
        decoration: pw.BoxDecoration(
          color: PdfColors.white,
          borderRadius: pw.BorderRadius.circular(5),
          border: pw.Border.all(color: color, width: 0.8),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(name, style: pw.TextStyle(fontSize: 8.5, color: color)),
            pw.SizedBox(height: 3),
            pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pw.Text(value, style: metricValue),
                pw.SizedBox(width: 2),
                pw.Padding(
                  padding: const pw.EdgeInsets.only(bottom: 2),
                  child: pw.Text(unit, style: caption),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// 数据表格统一样式（跨页时表头自动重复）。
  static pw.Widget dataTable({
    required pw.Context context,
    required List<dynamic> headers,
    required List<List<dynamic>> data,
    Map<int, pw.TableColumnWidth>? columnWidths,
    pw.AlignmentGeometry cellAlignment = pw.Alignment.centerLeft,
    pw.AlignmentGeometry headerAlignment = pw.Alignment.center,
    double fontSize = 8.5,
  }) {
    return pw.TableHelper.fromTextArray(
      context: context,
      headers: headers,
      data: data,
      headerCount: 1,
      columnWidths: columnWidths,
      cellAlignment: cellAlignment,
      headerAlignment: headerAlignment,
      cellPadding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      headerPadding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 5),
      cellStyle: pw.TextStyle(fontSize: fontSize, color: textPrimary),
      headerStyle: pw.TextStyle(fontSize: fontSize, color: primaryGreenDark),
      headerDecoration: const pw.BoxDecoration(color: primaryGreenSurface),
      oddRowDecoration: const pw.BoxDecoration(color: PdfColors.grey100),
      border: pw.TableBorder.all(color: line, width: 0.5),
    );
  }
}
