import 'dart:math' as math;

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'report_pdf_styles.dart';

/// 报告里的趋势图。
///
/// 用 pdf 包内置的 Chart 家族绘制（矢量、可缩放），不依赖任何图片资源。
/// y 轴刻度由数据范围自动推导，并把参考阈值作为锚点纳入取值范围，
/// 参考区间以图下方的说明文字给出——刻度与阈值不一定对齐，
/// 所以不画参考线，避免视觉上误导。
class ReportPdfCharts {
  ReportPdfCharts._();

  /// 单张趋势图的固定高度。
  static const double chartHeight = 118;

  /// 一张趋势图：标题 + 图表 + 说明文字。
  ///
  /// [anchors] 是需要一并纳入 y 轴范围的参考值（如脉搏的 60/100）。
  static pw.Widget trendChart({
    required String title,
    required String caption,
    required List<String> labels,
    required List<double> values,
    required PdfColor color,
    List<double> anchors = const [],
    bool bar = false,
  }) {
    // 少于两个点无法构成趋势，也无法划分坐标轴（会除以 0）。
    if (labels.length < 2 || labels.length != values.length) {
      return _tile(
        title: title,
        child: pw.Container(
          height: chartHeight,
          alignment: pw.Alignment.center,
          child: pw.Text('数据不足，无法绘制趋势', style: ReportPdfStyles.caption),
        ),
        caption: caption,
      );
    }

    return _tile(
      title: title,
      child: pw.SizedBox(
        height: chartHeight,
        child: pw.Chart(
          grid: pw.CartesianGrid(
            xAxis: pw.FixedAxis.fromStrings(
              labels,
              textStyle: const pw.TextStyle(fontSize: 6.5, color: ReportPdfStyles.textSecondary),
              marginStart: 12,
              marginEnd: 12,
              ticks: true,
              divisions: false,
              color: ReportPdfStyles.line,
            ),
            yAxis: pw.FixedAxis<double>(
              _ticks(values: values, anchors: anchors),
              format: (num v) => _formatTick(v.toDouble()),
              textStyle: const pw.TextStyle(fontSize: 6.5, color: ReportPdfStyles.textSecondary),
              margin: 3,
              ticks: true,
              divisions: true,
              divisionsDashed: true,
              divisionsColor: ReportPdfStyles.line,
              divisionsWidth: 0.5,
              color: ReportPdfStyles.line,
            ),
          ),
          datasets: [
            if (bar)
              pw.BarDataSet(
                data: [
                  for (var i = 0; i < values.length; i++)
                    pw.PointChartValue(i.toDouble(), values[i]),
                ],
                color: color,
                width: _barWidth(labels.length),
                drawSurface: true,
                surfaceOpacity: 0.85,
              )
            else
              pw.LineDataSet(
                data: [
                  for (var i = 0; i < values.length; i++)
                    pw.PointChartValue(i.toDouble(), values[i]),
                ],
                color: color,
                lineColor: color,
                lineWidth: 1.6,
                pointColor: color,
                pointSize: 2.2,
                drawPoints: true,
                drawLine: true,
                drawSurface: true,
                surfaceColor: color,
                surfaceOpacity: 0.12,
                isCurved: false,
              ),
          ],
        ),
      ),
      caption: caption,
    );
  }

  /// 把多张图按每行两张排布，避免单张图拉满整页宽度。
  static pw.Widget grid(List<pw.Widget> charts) {
    final rows = <pw.Widget>[];
    for (var i = 0; i < charts.length; i += 2) {
      final left = charts[i];
      final right = i + 1 < charts.length ? charts[i + 1] : null;
      rows.add(
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Expanded(child: left),
            pw.SizedBox(width: 10),
            pw.Expanded(child: right ?? pw.SizedBox()),
          ],
        ),
      );
      if (i + 2 < charts.length) rows.add(pw.SizedBox(height: 10));
    }
    return pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: rows);
  }

  static pw.Widget _tile({
    required String title,
    required pw.Widget child,
    required String caption,
  }) {
    return pw.Container(
      padding: const pw.EdgeInsets.fromLTRB(8, 7, 8, 7),
      decoration: pw.BoxDecoration(
        color: PdfColors.white,
        borderRadius: pw.BorderRadius.circular(5),
        border: pw.Border.all(color: ReportPdfStyles.line, width: 0.7),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            title,
            style: const pw.TextStyle(fontSize: 9, color: ReportPdfStyles.primaryGreenDark),
          ),
          pw.SizedBox(height: 5),
          child,
          pw.SizedBox(height: 4),
          pw.Text(caption, style: ReportPdfStyles.caption),
        ],
      ),
    );
  }

  /// 柱子宽度：按点数摊分，避免 7 个点用固定宽度时两侧留白过大。
  static double _barWidth(int count) => count <= 0 ? 8 : (60 / count).clamp(4, 10);

  /// 生成 y 轴刻度：覆盖数据与锚点，向外扩 8%，再取整到易读步长。
  static List<double> _ticks({
    required List<double> values,
    required List<double> anchors,
    int divisions = 4,
  }) {
    var lo = values.first;
    var hi = values.first;
    for (final v in values) {
      lo = math.min(lo, v);
      hi = math.max(hi, v);
    }
    for (final a in anchors) {
      lo = math.min(lo, a);
      hi = math.max(hi, a);
    }

    if (hi - lo < 1e-6) hi = lo + 1;

    final pad = (hi - lo) * 0.08;
    lo -= pad;
    hi += pad;

    final step = _niceStep((hi - lo) / divisions);
    final start = (lo / step).floorToDouble() * step;

    final ticks = <double>[];
    // 上限用 hi + step/2 兜底，保证 step 取整后另一端仍被覆盖。
    for (var v = start; v <= hi + step * 0.5; v += step) {
      ticks.add(v);
    }
    if (ticks.length < 2) ticks.add(start + step);
    return ticks;
  }

  /// 把步长取整到 1/2/5 × 10^n，让刻度值是整数而不是 1374 这类怪数。
  static double _niceStep(double raw) {
    if (raw <= 0 || !raw.isFinite) return 1;

    final magnitude = math.pow(10, (math.log(raw) / math.ln10).floor()).toDouble();
    final normalized = raw / magnitude;
    final double nice;
    if (normalized <= 1) {
      nice = 1;
    } else if (normalized <= 2) {
      nice = 2;
    } else if (normalized <= 5) {
      nice = 5;
    } else {
      nice = 10;
    }
    return nice * magnitude;
  }

  static String _formatTick(double value) {
    if (value.abs() >= 1000) {
      final k = value / 1000;
      return k == k.roundToDouble()
          ? '${k.round()}k'
          : '${k.toStringAsFixed(1)}k';
    }
    if (value == value.roundToDouble()) return value.round().toString();
    return value.toStringAsFixed(1);
  }
}
