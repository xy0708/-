import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:provider/provider.dart';

import '../../models/family_member.dart';
import '../../models/health_alert.dart';
import '../../models/health_report.dart';
import '../assessment/assessment_engine.dart';
import '../../providers/alert_provider.dart';
import '../../providers/family_provider.dart';
import '../../providers/medical_history_provider.dart';
import '../../providers/reminder_provider.dart';
import 'report_pdf_exporter.dart';

/// 从各 Provider 收集报告所需的全部数据，导出 PDF 并打开/提示。
///
/// 数据看板与数据评估两个入口的行为完全一致，统一走这里，
/// 避免两处重复实现导致的导出内容或提示不一致。
Future<void> exportReportFromContext(BuildContext context, HealthReport report) async {
  final family = context.read<FamilyProvider>();
  final alerts = context.read<AlertProvider>();
  final reminders = context.read<ReminderProvider>();
  final history = context.read<MedicalHistoryProvider>();

  // 提醒与病史是按页加载的，没访问过对应页面时内存里还是空的。
  // 导出前补一次加载，让报告内容与本地存储一致。
  if (reminders.reminders.isEmpty && !reminders.isLoading) {
    await reminders.load();
  }
  if (history.entries.isEmpty && !history.isLoading) {
    await history.load();
  }

  // 报告可能不是当前选中成员生成的，优先按 memberId 精确定位档案。
  final member = _memberOf(family.members, report.memberId, report.memberName);

  final path = await ReportPdfExporter.export(
    report: report,
    member: member,
    alerts: _resolveAlerts(alerts.alerts, report),
    reminders: reminders.reminders,
    medicalHistory: history.entries,
    familyMembers: family.members,
  );

  if (!context.mounted) return;

  if (path != null) {
    await OpenFile.open(path);
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('PDF 已开始下载，请查看浏览器下载目录')),
    );
  }
}

/// 预警优先用 AlertProvider 的结果（后端优先、失败已回退本地派生）；
/// 一条都没有时按报告自身的数据再派生一次，避免因未触发过预警拉取而漏掉异常。
List<HealthAlert> _resolveAlerts(List<HealthAlert> provided, HealthReport report) {
  final relevant = report.memberId == null
      ? provided
      : provided.where((a) => a.memberId == report.memberId).toList();
  if (relevant.isNotEmpty) return relevant;

  final vital = report.vitalSummary;
  if (vital == null) return const [];

  return AssessmentEngine.deriveAlerts(
    memberId: report.memberId ?? 'default',
    memberName: report.memberName,
    summary: vital,
    records: report.records,
  );
}

/// 先按 ID 匹配，ID 缺失时退回按姓名匹配，都没有则返回 null。
FamilyMember? _memberOf(List<FamilyMember> members, String? id, String name) {
  if (id != null) {
    for (final m in members) {
      if (m.id == id) return m;
    }
  }
  for (final m in members) {
    if (m.name == name) return m;
  }
  return null;
}

/// 导出的统一入口：负责加载态、异常提示与结果反馈。
///
/// [setBusy] 在导出前后回调，供页面切换按钮的加载态。
Future<void> runReportExport(
  BuildContext context,
  HealthReport report, {
  required void Function(bool busy) setBusy,
}) async {
  setBusy(true);
  try {
    await exportReportFromContext(context, report);
  } catch (e) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('导出失败: $e')),
    );
  } finally {
    setBusy(false);
  }
}
