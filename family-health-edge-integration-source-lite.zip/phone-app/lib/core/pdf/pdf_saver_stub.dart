import 'dart:typed_data';

Future<String?> savePdfBytes(Uint8List bytes, String fileName) async {
  throw UnsupportedError('PDF 保存在此平台暂不支持');
}
