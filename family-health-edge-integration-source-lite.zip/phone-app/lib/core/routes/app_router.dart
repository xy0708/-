import 'package:flutter/material.dart';
import '../../pages/splash/splash_page.dart';
import '../../pages/login/login_page.dart';
import '../../pages/home/home_page.dart';
import '../../pages/alerts/alerts_page.dart';
import '../../pages/reminders/reminders_page.dart';
import '../../pages/family/family_list_page.dart';
import '../../pages/family/family_edit_page.dart';
import '../../pages/profile/medical_history_page.dart';
import '../../pages/profile/emergency_contacts_page.dart';
import '../../pages/profile/elderly_settings_page.dart';
import '../../models/family_member.dart';

class AppRouter {
  static const String splash = '/';
  static const String login = '/login';
  static const String home = '/home';
  static const String alerts = '/alerts';
  static const String reminders = '/reminders';
  static const String family = '/family';
  static const String familyEdit = '/family/edit';
  static const String medicalHistory = '/medical-history';
  static const String emergencyContacts = '/emergency-contacts';
  static const String elderlySettings = '/elderly-settings';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splash:
        return MaterialPageRoute(builder: (_) => const SplashPage());
      case login:
        return MaterialPageRoute(builder: (_) => const LoginPage());
      case home:
        return MaterialPageRoute(builder: (_) => const HomePage());
      case alerts:
        return MaterialPageRoute(builder: (_) => const AlertsPage());
      case reminders:
        return MaterialPageRoute(builder: (_) => const RemindersPage());
      case family:
        return MaterialPageRoute(builder: (_) => const FamilyListPage());
      case familyEdit:
        return MaterialPageRoute(
          builder: (_) => FamilyEditPage(member: settings.arguments as FamilyMember?),
        );
      case medicalHistory:
        return MaterialPageRoute(builder: (_) => const MedicalHistoryPage());
      case emergencyContacts:
        return MaterialPageRoute(builder: (_) => const EmergencyContactsPage());
      case elderlySettings:
        return MaterialPageRoute(builder: (_) => const ElderlySettingsPage());
      default:
        return MaterialPageRoute(builder: (_) => const SplashPage());
    }
  }
}
