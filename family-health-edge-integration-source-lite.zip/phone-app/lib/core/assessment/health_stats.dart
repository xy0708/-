import '../../models/health_record.dart';
import 'assessment_engine.dart';

/// 单项指标在一段记录区间内的统计结果。
class MetricStat {
  final String name;
  final String unit;

  /// 周平均值（步数/脉搏为整数取整后的 double，便于统一展示）。
  final double avg;
  final double min;
  final double max;

  /// 达标口径的文字描述，如「≥6000 步」。
  final String targetText;

  /// 达标天数 / 统计天数。
  final int achievedDays;
  final int totalDays;

  /// 后半段与前半段相比的趋势方向：上升 / 下降 / 平稳。
  final String trend;

  const MetricStat({
    required this.name,
    required this.unit,
    required this.avg,
    required this.min,
    required this.max,
    required this.targetText,
    required this.achievedDays,
    required this.totalDays,
    required this.trend,
  });

  double get achieveRate => totalDays == 0 ? 0 : achievedDays / totalDays;

  /// 按指标决定小数位：步数/脉搏取整，睡眠/活动度保留一位。
  int get decimals => name == '步数' || name == '脉搏' ? 0 : 1;

  String format(double value) => value.toStringAsFixed(decimals);
}

/// 一段时间内 4 项体征的统计汇总，供报告与详情展示使用。
///
/// 纯函数、无 Flutter 依赖：同一份 records 每次结果一致，便于测试。
class HealthStats {
  /// 趋势判定阈值：前后半段相对变化超过 5% 才认为发生了升降。
  static const double trendThreshold = 0.05;

  final List<MetricStat> metrics;

  const HealthStats({required this.metrics});

  /// 是否所有指标都处于平稳状态。
  bool get isStable => metrics.every((m) => m.trend == '平稳');

  /// 综合趋势：取各指标趋势中最常见的一种，全平稳时返回「平稳」。
  String get overallTrend {
    if (metrics.isEmpty) return '平稳';
    final rising = metrics.where((m) => m.trend == '上升').length;
    final falling = metrics.where((m) => m.trend == '下降').length;
    if (rising > falling) return '整体上升';
    if (falling > rising) return '整体下降';
    return '整体平稳';
  }

  static HealthStats compute(List<HealthRecord> records) {
    return HealthStats(
      metrics: [
        _build(
          name: '步数',
          unit: '步',
          records: records,
          valueOf: (r) => r.steps.toDouble(),
          achieved: (v) => v >= AssessmentEngine.stepsGood,
          targetText: '≥${AssessmentEngine.stepsGood} 步',
          roundAverage: true,
        ),
        _build(
          name: '睡眠',
          unit: '小时',
          records: records,
          valueOf: (r) => r.sleepHours,
          // 达标线统一取该维度的「良」阈值，避免出现「天天达标却只得一般」的观感矛盾
          achieved: (v) => v >= AssessmentEngine.sleepGoodHigh,
          targetText: '≥${AssessmentEngine.sleepGoodHigh.toStringAsFixed(1)} 小时',
        ),
        _build(
          name: '脉搏',
          unit: '次/分',
          records: records,
          valueOf: (r) => r.heartRate.toDouble(),
          achieved: (v) => v >= AssessmentEngine.hrNormalLow && v <= AssessmentEngine.hrNormalHigh,
          targetText: '${AssessmentEngine.hrNormalLow}'
              '-${AssessmentEngine.hrNormalHigh} 次/分',
          roundAverage: true,
        ),
        _build(
          name: '活动度',
          unit: '%',
          records: records,
          valueOf: (r) => r.activityLevel * 100,
          achieved: (v) => v >= AssessmentEngine.activityGood * 100,
          targetText: '≥${(AssessmentEngine.activityGood * 100).round()}%',
        ),
      ],
    );
  }

  /// 单项统计：均值/极值/达标天数/趋势方向。
  ///
  /// [roundAverage] 为 true 时对均值取整（步数、脉搏这类离散量），
  /// 但极值始终基于原始值，避免取整掩盖真实波动。
  static MetricStat _build({
    required String name,
    required String unit,
    required List<HealthRecord> records,
    required double Function(HealthRecord) valueOf,
    required bool Function(double) achieved,
    required String targetText,
    bool roundAverage = false,
  }) {
    if (records.isEmpty) {
      return MetricStat(
        name: name,
        unit: unit,
        avg: 0,
        min: 0,
        max: 0,
        targetText: targetText,
        achievedDays: 0,
        totalDays: 0,
        trend: '平稳',
      );
    }

    final values = records.map(valueOf).toList();
    final sum = values.fold<double>(0, (acc, v) => acc + v);
    final rawAvg = sum / values.length;
    final avg = roundAverage ? rawAvg.roundToDouble() : rawAvg;
    final min = values.reduce((a, b) => a < b ? a : b);
    final max = values.reduce((a, b) => a > b ? a : b);
    final achievedDays = values.where(achieved).length;

    return MetricStat(
      name: name,
      unit: unit,
      avg: avg,
      min: min,
      max: max,
      targetText: targetText,
      achievedDays: achievedDays,
      totalDays: values.length,
      trend: _trendOf(values),
    );
  }

  /// 后半段均值与前半段均值比较，相对变化超过 [trendThreshold] 才判定升降。
  ///
  /// 单条记录没有前后半段之分，直接返回「平稳」。
  static String _trendOf(List<double> values) {
    if (values.length < 2) return '平稳';

    final mid = values.length ~/ 2;
    final firstHalf = values.sublist(0, mid);
    final secondHalf = values.sublist(mid);
    if (firstHalf.isEmpty || secondHalf.isEmpty) return '平稳';

    final firstAvg = firstHalf.fold<double>(0, (a, b) => a + b) / firstHalf.length;
    final secondAvg = secondHalf.fold<double>(0, (a, b) => a + b) / secondHalf.length;

    // 前半段均值为 0 时无法计算相对变化，改用绝对变化判断。
    if (firstAvg == 0) {
      if (secondAvg == 0) return '平稳';
      return secondAvg > 0 ? '上升' : '下降';
    }

    final change = (secondAvg - firstAvg) / firstAvg.abs();
    if (change > trendThreshold) return '上升';
    if (change < -trendThreshold) return '下降';
    return '平稳';
  }
}
