import '../../models/health_alert.dart';
import '../../models/health_record.dart';

class DimensionScore {
  final String name;
  final double score;
  final String level;
  final String suggestion;

  const DimensionScore({
    required this.name,
    required this.score,
    required this.level,
    required this.suggestion,
  });
}

class AssessmentResult {
  final double overallScore;
  final String summary;
  final List<String> suggestions;
  final List<DimensionScore> dimensions;

  const AssessmentResult({
    required this.overallScore,
    required this.summary,
    required this.suggestions,
    required this.dimensions,
  });
}

class AssessmentEngine {
  const AssessmentEngine._();

  // 分档阈值：报告统计、图表参考线等复用同一份口径，改这里即全局生效。
  static const int stepsExcellent = 10000;
  static const int stepsGood = 6000;
  static const int stepsFair = 3000;

  static const double sleepExcellent = 8.5;
  static const double sleepGoodHigh = 7.0;
  static const double sleepGoodLow = 6.0;

  static const int hrNormalLow = 60;
  static const int hrNormalHigh = 100;

  static const double activityExcellent = 0.8;
  static const double activityGood = 0.6;
  static const double activityFair = 0.4;

  static AssessmentResult evaluate({
    required HealthSummary summary,
    required List<HealthRecord> records,
  }) {
    final avg = _weeklyAverage(records);
    final today = summary;

    final steps = avg != null ? avg.steps : today.todaySteps;
    final sleep = avg != null ? avg.sleepHours : today.todaySleep;
    final heartRate = avg != null ? avg.heartRate : today.currentHeartRate;
    final activity = avg != null ? avg.activityLevel : today.todayActivity;

    final dimensions = [
      _scoreSteps(steps),
      _scoreSleep(sleep),
      _scoreHeartRate(heartRate),
      _scoreActivity(activity),
    ];

    final overall = dimensions.fold<double>(0, (sum, d) => sum + d.score) / dimensions.length;
    final totalScore = double.parse(overall.toStringAsFixed(1));

    final weak = dimensions.where((d) => d.score < 80).toList();
    final strong = dimensions
        .where((d) => d.score >= 80)
        .toList();

    final String summaryText;
    if (weak.isEmpty) {
      summaryText = '本周各项指标表现优秀，请继续保持现有作息与运动习惯。';
    } else if (strong.isEmpty) {
      summaryText = '本周多项指标处于一般水平，建议重点关注并结合下方建议逐步改善。';
    } else {
      summaryText = '本周「${weak.map((d) => d.name).join('、')}」偏弱，'
          '「${strong.map((d) => d.name).join('、')}」表现良好，整体${totalScore >= 75 ? '较健康' : '需关注'}。';
    }

    final suggestions = weak.map((d) => d.suggestion).toList();
    if (heartRate < hrNormalLow || heartRate > hrNormalHigh) {
      suggestions.insert(0, '脉搏处于异常区间，建议近期前往医院做一次心电图检查。');
    }

    return AssessmentResult(
      overallScore: totalScore,
      summary: summaryText,
      suggestions: suggestions,
      dimensions: dimensions,
    );
  }

  /// 从健康数据派生健康预警（阈值与 [evaluate] 的分档规则一致）。
  ///
  /// 纯函数、确定性输出：同一份 summary/records 每次结果一致，便于测试。
  static List<HealthAlert> deriveAlerts({
    required String memberId,
    required String memberName,
    required HealthSummary summary,
    required List<HealthRecord> records,
  }) {
    final avg = _weeklyAverage(records);
    final heartRate = avg != null ? avg.heartRate : summary.currentHeartRate;
    final sleep = avg != null ? avg.sleepHours : summary.todaySleep;
    final steps = avg != null ? avg.steps : summary.todaySteps;
    final now = DateTime.now();

    final alerts = <HealthAlert>[];
    if (heartRate < hrNormalLow || heartRate > hrNormalHigh) {
      alerts.add(HealthAlert(
        id: 'alert_${memberId}_heart_rate',
        memberId: memberId,
        memberName: memberName,
        level: AlertLevel.danger,
        title: '脉搏异常',
        content: '静息脉搏 $heartRate 次/分，超出正常范围（$hrNormalLow-$hrNormalHigh），建议尽快就医检查。',
        createdAt: now,
      ));
    }
    if (sleep < sleepGoodLow) {
      alerts.add(HealthAlert(
        id: 'alert_${memberId}_sleep',
        memberId: memberId,
        memberName: memberName,
        level: AlertLevel.warning,
        title: '睡眠不足',
        content: '近7天平均睡眠 ${sleep.toStringAsFixed(1)} 小时，长期睡眠不足会加重心血管负担，建议调整作息。',
        createdAt: now,
      ));
    }
    if (steps < stepsFair) {
      alerts.add(HealthAlert(
        id: 'alert_${memberId}_steps',
        memberId: memberId,
        memberName: memberName,
        level: AlertLevel.info,
        title: '活动量偏少',
        content: '近7天平均每日步数 $steps 步，建议循序渐进增加至6000步以上。',
        createdAt: now,
      ));
    }
    return alerts;
  }

  static HealthRecord? _weeklyAverage(List<HealthRecord> records) {
    if (records.isEmpty) return null;
    return HealthRecord(
      steps: (records.fold<int>(0, (sum, r) => sum + r.steps) / records.length).round(),
      sleepHours: records.fold<double>(0, (sum, r) => sum + r.sleepHours) / records.length,
      heartRate: (records.fold<int>(0, (sum, r) => sum + r.heartRate) / records.length).round(),
      activityLevel: records.fold<double>(0, (sum, r) => sum + r.activityLevel) / records.length,
      date: records.last.date,
    );
  }

  static DimensionScore _scoreSteps(int steps) {
    if (steps >= stepsExcellent) {
      return const DimensionScore(
        name: '步数',
        score: 95,
        level: '优',
        suggestion: '每日步数保持在1万步以上，继续保持。',
      );
    }
    if (steps >= stepsGood) {
      return const DimensionScore(
        name: '步数',
        score: 80,
        level: '良',
        suggestion: '建议每日步数提升至8000-10000步，可增加户外散步时间。',
      );
    }
    if (steps >= stepsFair) {
      return const DimensionScore(
        name: '步数',
        score: 60,
        level: '一般',
        suggestion: '每日步数偏少，建议逐步增加至6000步以上，久坐时多起身活动。',
      );
    }
    return const DimensionScore(
      name: '步数',
      score: 40,
      level: '差',
      suggestion: '每日步数严重不足，建议每日至少完成3000步，循序渐进增加运动量。',
    );
  }

  static DimensionScore _scoreSleep(double hours) {
    if (hours >= sleepExcellent) {
      return const DimensionScore(
        name: '睡眠',
        score: 90,
        level: '优',
        suggestion: '睡眠时长充足，请保持规律作息。',
      );
    }
    if (hours >= sleepGoodHigh) {
      return const DimensionScore(
        name: '睡眠',
        score: 85,
        level: '良',
        suggestion: '睡眠时长良好，建议维持在7-8小时并固定入睡时间。',
      );
    }
    if (hours >= sleepGoodLow) {
      return const DimensionScore(
        name: '睡眠',
        score: 65,
        level: '一般',
        suggestion: '睡眠时长略短，建议保证每晚7小时以上，睡前减少电子屏幕使用。',
      );
    }
    return const DimensionScore(
      name: '睡眠',
      score: 45,
      level: '差',
      suggestion: '睡眠时长严重不足，长期缺觉会加重心血管负担，请及时调整作息。',
    );
  }

  static DimensionScore _scoreHeartRate(int heartRate) {
    if (heartRate >= hrNormalLow && heartRate <= hrNormalHigh) {
      return const DimensionScore(
        name: '脉搏',
        score: 85,
        level: '良',
        suggestion: '静息脉搏处于正常范围，请定期监测变化。',
      );
    }
    if (heartRate < hrNormalLow) {
      return const DimensionScore(
        name: '脉搏',
        score: 50,
        level: '差',
        suggestion: '静息脉搏偏低，如伴随头晕乏力请及时就医。',
      );
    }
    return const DimensionScore(
      name: '脉搏',
      score: 50,
      level: '差',
      suggestion: '静息脉搏偏高，可能与情绪或活动有关，如持续偏高请及时就医。',
    );
  }

  static DimensionScore _scoreActivity(double activity) {
    if (activity >= activityExcellent) {
      return const DimensionScore(
        name: '活动度',
        score: 90,
        level: '优',
        suggestion: '活动度优秀，继续保持规律运动。',
      );
    }
    if (activity >= activityGood) {
      return const DimensionScore(
        name: '活动度',
        score: 80,
        level: '良',
        suggestion: '活动度良好，可适当加入力量训练提升体质。',
      );
    }
    if (activity >= activityFair) {
      return const DimensionScore(
        name: '活动度',
        score: 60,
        level: '一般',
        suggestion: '日常活动量偏低，建议每天安排30分钟中等强度运动。',
      );
    }
    return const DimensionScore(
      name: '活动度',
      score: 40,
      level: '差',
      suggestion: '日常活动量严重不足，建议从散步、太极拳等低强度活动开始。',
    );
  }
}
