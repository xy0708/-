import '../../models/device.dart';
import 'watch_gateway.dart';

/// Deterministic substitute used only while the real watch is unavailable.
class SimulatedWatchGateway implements WatchGateway {
  SimulatedWatchGateway({
    this.operationDelay = const Duration(milliseconds: 20),
  });

  final Duration operationDelay;
  bool _connected = false;

  @override
  Future<List<HealthDevice>> scan({
    Duration timeout = const Duration(seconds: 10),
  }) async {
    await Future<void>.delayed(operationDelay);
    return [_device()];
  }

  @override
  Future<HealthDevice> connect(HealthDevice device) async {
    await Future<void>.delayed(operationDelay);
    _connected = true;
    return device.copyWith(isConnected: true);
  }

  @override
  Future<HealthDevice> disconnect(HealthDevice device) async {
    await Future<void>.delayed(operationDelay);
    _connected = false;
    return device.copyWith(isConnected: false);
  }

  HealthDevice _device() {
    return HealthDevice(
      id: 'simulated_yucheng_watch_001',
      name: '玉成手表（模拟）',
      type: DeviceType.bracelet,
      isConnected: _connected,
      batteryLevel: 85,
    );
  }

  @override
  void dispose() {}
}
