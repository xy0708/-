enum WearableMetric { heartRate, steps }

enum MeasurementQuality { valid, invalid }

class WearableMeasurement {
  const WearableMeasurement({
    required this.recordId,
    required this.memberId,
    required this.deviceId,
    required this.metric,
    required this.value,
    required this.unit,
    required this.capturedAt,
    required this.source,
    required this.quality,
  });

  final String recordId;
  final String memberId;
  final String deviceId;
  final WearableMetric metric;
  final double value;
  final String unit;
  final DateTime capturedAt;
  final String source;
  final MeasurementQuality quality;

  Map<String, Object> toJson() {
    return {
      'recordId': recordId,
      'memberId': memberId,
      'deviceId': deviceId,
      'metric': metric.name,
      'value': value,
      'unit': unit,
      'capturedAt': capturedAt.toUtc().toIso8601String(),
      'source': source,
      'quality': quality.name,
    };
  }
}

class YuchengMeasurementNormalizer {
  static const source = 'yucheng_android_sdk_4.0.11';

  WearableMeasurement? normalize({
    required String memberId,
    required String deviceId,
    required WearableMetric metric,
    required Map<String, Object?> vendorPayload,
  }) {
    final specification = _specifications[metric]!;
    final value = _asDouble(vendorPayload[specification.valueKey]);
    final capturedAt = _asUtcDateTime(vendorPayload[specification.timeKey]);
    if (value == null || capturedAt == null) {
      return null;
    }

    final quality = specification.isValid(value)
        ? MeasurementQuality.valid
        : MeasurementQuality.invalid;
    final recordId =
        '$source:$deviceId:${metric.name}:'
        '${capturedAt.millisecondsSinceEpoch}:$value';
    return WearableMeasurement(
      recordId: recordId,
      memberId: memberId,
      deviceId: deviceId,
      metric: metric,
      value: value,
      unit: specification.unit,
      capturedAt: capturedAt,
      source: source,
      quality: quality,
    );
  }

  double? _asDouble(Object? raw) {
    if (raw is num) return raw.toDouble();
    if (raw is String) return double.tryParse(raw);
    return null;
  }

  DateTime? _asUtcDateTime(Object? raw) {
    final numeric = _asDouble(raw);
    if (numeric == null || numeric <= 0) return null;
    final integer = numeric.round();
    final milliseconds = integer >= 100000000000 ? integer : integer * 1000;
    return DateTime.fromMillisecondsSinceEpoch(milliseconds, isUtc: true);
  }
}

class _MetricSpecification {
  const _MetricSpecification({
    required this.valueKey,
    required this.timeKey,
    required this.unit,
    required this.minimum,
    required this.maximum,
  });

  final String valueKey;
  final String timeKey;
  final String unit;
  final double minimum;
  final double maximum;

  bool isValid(double value) => value >= minimum && value <= maximum;
}

const _specifications = <WearableMetric, _MetricSpecification>{
  WearableMetric.heartRate: _MetricSpecification(
    valueKey: 'heartValue',
    timeKey: 'heartStartTime',
    unit: 'bpm',
    minimum: 20,
    maximum: 250,
  ),
  WearableMetric.steps: _MetricSpecification(
    valueKey: 'sportStep',
    timeKey: 'sportStartTime',
    unit: 'count',
    minimum: 0,
    maximum: 200000,
  ),
};
