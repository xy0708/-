import '../../models/device.dart';

/// Phone-side boundary for a wearable SDK.
///
/// The production implementation will wrap the pinned Yucheng Android SDK.
/// Keeping the vendor API behind this boundary prevents BLE and vendor details
/// from leaking into UI state.
abstract interface class WatchGateway {
  Future<List<HealthDevice>> scan({
    Duration timeout = const Duration(seconds: 10),
  });

  Future<HealthDevice> connect(HealthDevice device);

  Future<HealthDevice> disconnect(HealthDevice device);

  void dispose();
}
