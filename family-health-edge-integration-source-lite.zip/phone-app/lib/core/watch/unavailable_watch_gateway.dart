import '../../models/device.dart';
import 'watch_gateway.dart';

/// Fail-closed default until the pinned vendor SDK has a verified adapter.
class UnavailableWatchGateway implements WatchGateway {
  const UnavailableWatchGateway();

  @override
  Future<List<HealthDevice>> scan({
    Duration timeout = const Duration(seconds: 10),
  }) async {
    throw const WatchGatewayUnavailableException();
  }

  @override
  Future<HealthDevice> connect(HealthDevice device) async {
    throw const WatchGatewayUnavailableException();
  }

  @override
  Future<HealthDevice> disconnect(HealthDevice device) async {
    throw const WatchGatewayUnavailableException();
  }

  @override
  void dispose() {}
}

class WatchGatewayUnavailableException implements Exception {
  const WatchGatewayUnavailableException();

  @override
  String toString() => '真实手表 SDK 尚未接入';
}
