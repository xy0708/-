/// 应用级配置。
///
/// 构建期可通过 `--dart-define` 注入：
/// ```
/// flutter run --dart-define=API_BASE_URL=http://192.168.1.100:8080
/// flutter build apk --dart-define=API_BASE_URL=https://api.example.com
/// ```
class AppConfig {
  const AppConfig._();

  /// 后端 API 地址（未配置时为空字符串）。
  static const String apiBaseUrl = String.fromEnvironment('API_BASE_URL');

  /// 是否优先调用后端接口。
  ///
  /// 仅当构建期配置了 [apiBaseUrl] 时为 true。未配置后端时默认拒绝
  /// 伪造业务数据；工程演示必须另外显式开启 [allowDemoData]。
  static bool useBackend = apiBaseUrl.isNotEmpty;

  /// Mock data is an explicit engineering-only capability. Production builds
  /// must fail closed when a service is missing or unreachable instead of
  /// presenting generated values as if they came from a person or device.
  static bool allowDemoData = const bool.fromEnvironment(
    'ALLOW_DEMO_DATA',
    defaultValue: false,
  );

  /// Cleartext is forbidden by default. This flag exists only for explicit
  /// local engineering builds that connect to a loopback test service.
  static const bool allowInsecureEdgeTransportForEngineering =
      bool.fromEnvironment('EDGE_ALLOW_INSECURE_ENGINEERING');

  /// 高德开放平台 Web 服务 key（可选）。
  ///
  /// 配置后「附近医疗机构」优先走高德 POI 检索（国内快且准）：
  /// ```
  /// flutter build apk --dart-define=AMAP_KEY=你的key
  /// ```
  /// 未配置时使用 OpenStreetMap Overpass 免费源（国内可能较慢）。
  static const String amapKey = String.fromEnvironment('AMAP_KEY');
}
