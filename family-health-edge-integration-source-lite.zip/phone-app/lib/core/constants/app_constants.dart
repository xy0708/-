class AppConstants {
  static const String appName = '家庭健康管理';
  static const String baseUrl = 'http://192.168.1.100:8080';
  static const String mServiceType = '_familyhealth._tcp';
  static const int scanTimeoutSeconds = 10;

  static const List<String> vitalSignLabels = [
    '步数', '睡眠', '脉搏', '活动度',
  ];
}
