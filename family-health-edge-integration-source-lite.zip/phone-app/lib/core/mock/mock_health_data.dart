import '../../models/health_record.dart';

/// 按成员生成确定性的 Mock 健康数据。
///
/// 设计目标：
/// - 同一成员每次调用结果一致（可测试、可复现）；
/// - 不同成员数据不同（看板切换成员时数据真实变化）；
/// - 结合年龄画像模拟真实规律（老人活动量低、静息脉搏略高等）。
class MockHealthData {
  const MockHealthData._();

  static int _seedOf(String memberId) {
    return memberId.codeUnits.fold(17, (a, b) => a * 31 + b);
  }

  /// 确定性伪随机数，范围 [0, 1)。
  static double _rand(int seed, int salt) {
    final r = (seed * 9301 + salt * 49297) % 233280;
    return r / 233280;
  }

  static int _intIn(int seed, int salt, int min, int max) =>
      min + (_rand(seed, salt) * (max - min + 1)).floor();

  static double _doubleIn(int seed, int salt, double min, double max) =>
      min + _rand(seed, salt) * (max - min);

  /// 年龄段基础健康画像。
  static ({int stepsLo, int stepsHi, double sleepLo, double sleepHi, int hrLo, int hrHi, double actLo, double actHi}) _profile(int age) {
    if (age >= 60) {
      return (
        stepsLo: 3500,
        stepsHi: 7000,
        sleepLo: 6.0,
        sleepHi: 7.5,
        hrLo: 74,
        hrHi: 88,
        actLo: 0.35,
        actHi: 0.6,
      );
    }
    if (age <= 25) {
      return (
        stepsLo: 9000,
        stepsHi: 13000,
        sleepLo: 6.5,
        sleepHi: 8.0,
        hrLo: 62,
        hrHi: 78,
        actLo: 0.6,
        actHi: 0.85,
      );
    }
    return (
      stepsLo: 6000,
      stepsHi: 11000,
      sleepLo: 6.5,
      sleepHi: 8.5,
      hrLo: 66,
      hrHi: 82,
      actLo: 0.5,
      actHi: 0.75,
    );
  }

  static String _statusFor(int heartRate, double activity) {
    if (heartRate < 60 || heartRate > 100) return '需关注';
    if (activity < 0.4) return '需关注';
    return '良好';
  }

  /// 生成某成员今日体征摘要。
  static HealthSummary summaryFor(String memberId, {int age = 40}) {
    final seed = _seedOf(memberId);
    final p = _profile(age);
    final steps = _intIn(seed, 1, p.stepsLo, p.stepsHi);
    final sleep = _doubleIn(seed, 2, p.sleepLo, p.sleepHi);
    final heartRate = _intIn(seed, 3, p.hrLo, p.hrHi);
    final activity = _doubleIn(seed, 4, p.actLo, p.actHi);
    return HealthSummary(
      todaySteps: steps,
      todaySleep: sleep,
      currentHeartRate: heartRate,
      todayActivity: activity,
      healthStatus: _statusFor(heartRate, activity),
    );
  }

  /// 生成某成员最近 7 天健康记录（含轻微周内趋势与每日波动）。
  static List<HealthRecord> recordsFor(String memberId, {int age = 40}) {
    final seed = _seedOf(memberId);
    final p = _profile(age);
    final now = DateTime.now();
    return List.generate(7, (i) {
      final trend = (i - 3) * 0.03; // 周中略高，两端略低
      final steps = (_intIn(seed, 10 + i, p.stepsLo, p.stepsHi) * (1 + trend)).round();
      final sleep = (_doubleIn(seed, 20 + i, p.sleepLo, p.sleepHi) + trend * 2)
          .clamp(4.5, 10.0)
          .toDouble();
      final heartRate = _intIn(seed, 30 + i, p.hrLo, p.hrHi);
      final activity = (_doubleIn(seed, 40 + i, p.actLo, p.actHi) + trend)
          .clamp(0.1, 1.0)
          .toDouble();
      return HealthRecord(
        steps: steps,
        sleepHours: sleep,
        heartRate: heartRate,
        activityLevel: activity,
        date: now.subtract(Duration(days: 6 - i)),
      );
    });
  }
}
