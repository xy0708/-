import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class MemberAvatar extends StatelessWidget {
  final String name;
  final double radius;
  final bool isSelected;

  const MemberAvatar({
    super.key,
    required this.name,
    this.radius = 24,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundColor: isSelected
          ? AppTheme.primaryGreen
          : AppTheme.primaryGreen.withValues(alpha: 0.2),
      child: Text(
        name[0],
        style: TextStyle(
          color: isSelected ? Colors.white : AppTheme.primaryGreen,
          fontWeight: FontWeight.bold,
          fontSize: radius * 0.6,
        ),
      ),
    );
  }
}
