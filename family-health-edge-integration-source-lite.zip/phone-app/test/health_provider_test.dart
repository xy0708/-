import 'package:flutter_test/flutter_test.dart';
import 'package:family_health/core/config/app_config.dart';
import 'package:family_health/providers/health_provider.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    AppConfig.useBackend = false;
    AppConfig.allowDemoData = true;
  });

  tearDown(() {
    AppConfig.useBackend = false;
    AppConfig.allowDemoData = false;
  });

  group('HealthProvider 成员数据联动', () {
    test('fetchSummary 按成员 ID 生成不同数据', () async {
      final provider = HealthProvider();
      await provider.fetchSummary(memberId: 'member-1', age: 35);
      final s1 = provider.summary!;
      await provider.fetchSummary(memberId: 'member-2', age: 35);
      final s2 = provider.summary!;
      expect(
          s1.todaySteps == s2.todaySteps &&
              s1.todaySleep == s2.todaySleep &&
              s1.currentHeartRate == s2.currentHeartRate &&
              s1.todayActivity == s2.todayActivity,
          isFalse);
    });

    test('fetchRecords 按成员 ID 生成不同数据', () async {
      final provider = HealthProvider();
      await provider.fetchRecords(memberId: 'member-1', age: 35);
      final r1 = provider.records.map((r) => r.steps).toList();
      await provider.fetchRecords(memberId: 'member-2', age: 35);
      final r2 = provider.records.map((r) => r.steps).toList();
      expect(r1, isNot(equals(r2)));
    });

    test('generateReport 为指定成员生成报告并按活动成员取回', () async {
      final provider = HealthProvider();
      await provider.generateReport(memberName: '张三', memberId: '1', age: 35);
      expect(provider.latestReport, isNull); // 尚未设置活动成员

      provider.setActiveMember('1');
      expect(provider.latestReport!.memberName, '张三');
    });

    test('切换成员后报告各自独立缓存', () async {
      final provider = HealthProvider();
      await provider.generateReport(memberName: '张三', memberId: '1', age: 35);
      await provider.generateReport(memberName: '李四', memberId: '2', age: 33);

      provider.setActiveMember('1');
      expect(provider.latestReport!.memberName, '张三');
      provider.setActiveMember('2');
      expect(provider.latestReport!.memberName, '李四');
    });

    test('不同年龄画像的报告评分不同（老年活动度画像与青年无交集）', () async {
      final provider = HealthProvider();
      provider.setActiveMember('3');
      // 同一成员 ID，仅年龄不同：活动度画像区间不相交，评分必不同
      await provider.generateReport(memberName: '张爷爷', memberId: '3', age: 65);
      final elderScore = provider.latestReport!.overallScore;
      await provider.generateReport(memberName: '孙辈', memberId: '3', age: 20);
      final youngScore = provider.latestReport!.overallScore;
      expect(elderScore, isNot(equals(youngScore)));
    });

    test('generateReport 会把评分明细与原始记录一并存入报告', () async {
      final provider = HealthProvider();
      await provider.generateReport(memberName: '张三', memberId: '1', age: 35);
      provider.setActiveMember('1');
      final report = provider.latestReport!;

      // 导出 PDF 全靠这些字段，缺一项报告就会退化成「总分 + 一段文字」
      expect(report.memberId, '1');
      expect(report.dimensions.length, 4);
      expect(
        report.dimensions.map((d) => d.name),
        containsAll(<String>['步数', '睡眠', '脉搏', '活动度']),
      );
      expect(report.records.length, provider.records.length);
      expect(report.records.length, greaterThan(1));
      expect(report.vitalSummary, isNotNull);
      expect(report.periodStart, isNotNull);
      expect(report.periodEnd, isNotNull);
      expect(report.periodStart!.isAfter(report.periodEnd!), isFalse);
      expect(report.periodDays, report.records.length);
    });

    test('报告的四维得分等于各维度均值', () async {
      final provider = HealthProvider();
      await provider.generateReport(memberName: '张三', memberId: '1', age: 35);
      provider.setActiveMember('1');
      final report = provider.latestReport!;
      final avg = report.dimensions.fold<double>(0, (s, d) => s + d.score) /
          report.dimensions.length;
      expect(report.overallScore, closeTo(avg, 0.05));
    });

    test('generateReport 不会误用其他成员的历史缓存数据', () async {
      final provider = HealthProvider();
      // 先给成员 A 生成，再直接给成员 B 生成（不经过 fetch）
      // 青年（步数 9000-13000）与老年（3500-7000）画像区间不相交，保证断言稳健
      await provider.generateReport(memberName: '小张', memberId: 'a', age: 20);
      final aSteps = provider.summary!.todaySteps;
      await provider.generateReport(memberName: '张爷爷', memberId: 'b', age: 65);
      expect(provider.summary!.todaySteps, isNot(equals(aSteps)));
    });
  });
}
