import 'package:family_health/core/edge/edge_ocr_review.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('parses only a pending-confirmation OCR task response', () {
    final review = EdgeOcrReview.fromTaskResponse({
      'status': 'success',
      'requires_confirmation': true,
      'result': {
        'task_id': '0123456789abcdef0123456789abcdef',
        'kind': 'ocr',
        'status': 'pending_confirmation',
        'result': {
          'full_text': '血压 120/80',
          'lines': [
            {'text': '血压 120/80', 'confidence': 0.91},
          ],
        },
      },
    });

    expect(review.taskId, '0123456789abcdef0123456789abcdef');
    expect(review.fullText, '血压 120/80');
    expect(review.lines.single.confidence, 0.91);
  });

  test('rejects a response that bypasses user confirmation', () {
    expect(
      () => EdgeOcrReview.fromTaskResponse({
        'status': 'success',
        'requires_confirmation': false,
        'result': <String, Object?>{},
      }),
      throwsFormatException,
    );
  });
}
