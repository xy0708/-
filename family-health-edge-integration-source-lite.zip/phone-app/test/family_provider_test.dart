import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:family_health/providers/family_provider.dart';
import 'package:family_health/models/family_member.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  group('FamilyProvider 持久化', () {
    test('首次加载注入默认成员并持久化', () async {
      final provider = FamilyProvider();
      await provider.fetchMembers();
      expect(provider.members.length, 4);
      expect(provider.members.first.relation, '本人');
      expect(provider.members.first.name, '张三');

      // 新实例可读回同一批成员（持久化生效）
      final reloaded = FamilyProvider();
      await reloaded.fetchMembers();
      expect(reloaded.members.length, 4);
      expect(reloaded.members.map((m) => m.name).toList(),
          provider.members.map((m) => m.name).toList());
    });

    test('addMember 后持久化，新实例可见', () async {
      final provider = FamilyProvider();
      await provider.fetchMembers();
      await provider.addMember(FamilyMember(
        id: '5',
        name: '小王',
        relation: '孙子',
        age: 12,
        gender: '男',
      ));

      final reloaded = FamilyProvider();
      await reloaded.fetchMembers();
      expect(reloaded.members.any((m) => m.id == '5' && m.name == '小王'), isTrue);
    });

    test('updateMember 更新后持久化', () async {
      final provider = FamilyProvider();
      await provider.fetchMembers();
      final target = provider.members.first;
      await provider.updateMember(FamilyMember(
        id: target.id,
        name: '张三丰',
        relation: target.relation,
        age: target.age,
        gender: target.gender,
      ));

      final reloaded = FamilyProvider();
      await reloaded.fetchMembers();
      expect(reloaded.members.first.name, '张三丰');
    });

    test('deleteMember 删除后持久化', () async {
      final provider = FamilyProvider();
      await provider.fetchMembers();
      final before = provider.members.length;
      await provider.deleteMember(provider.members.first.id);

      final reloaded = FamilyProvider();
      await reloaded.fetchMembers();
      expect(reloaded.members.length, before - 1);
    });
  });
}
