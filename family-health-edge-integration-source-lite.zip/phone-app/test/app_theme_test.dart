import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:family_health/core/theme/app_theme.dart';

void main() {
  group('AppTheme 助老高对比度变体', () {
    test('深色高对比度：纯黑底、纯白文字', () {
      final hc = AppTheme.darkTheme(highContrast: true);
      expect(hc.scaffoldBackgroundColor, Colors.black);
      expect(hc.colorScheme.surface, Colors.black);
      expect(hc.colorScheme.onSurface, Colors.white);
      expect(hc.colorScheme.onSurfaceVariant, Colors.white70);
      expect(hc.colorScheme.primary, AppTheme.primaryGreenHCDark);
      // 卡片描边（黑底上靠描边区分卡片）
      final shape = hc.cardTheme.shape as RoundedRectangleBorder;
      expect(shape.side, isNot(BorderSide.none));
    });

    test('深色普通模式：非纯黑', () {
      final normal = AppTheme.darkTheme();
      expect(normal.scaffoldBackgroundColor, isNot(Colors.black));
      final shape = normal.cardTheme.shape as RoundedRectangleBorder;
      expect(shape.side, BorderSide.none);
    });

    test('浅色高对比度：纯白底、更深品牌绿', () {
      final hc = AppTheme.lightTheme(highContrast: true);
      expect(hc.scaffoldBackgroundColor, Colors.white);
      expect(hc.colorScheme.primary, AppTheme.primaryGreenHC);
      expect(hc.colorScheme.onSurfaceVariant, Colors.black87);
    });
  });
}
