import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:family_health/core/network/poi_client.dart';

void main() {
  // 北京天安门附近构造的 Overpass 样例响应
  const sample = {
    'version': 0.6,
    'elements': [
      {
        'type': 'node',
        'id': 1,
        'lat': 39.9125,
        'lon': 116.4170,
        'tags': {'amenity': 'hospital', 'name': '北京协和医院'},
      },
      {
        'type': 'way',
        'id': 2,
        'center': {'lat': 39.9200, 'lon': 116.4300},
        'tags': {'amenity': 'hospital', 'name:zh': '朝阳医院'},
      },
      {
        // 未命名设施应被过滤
        'type': 'node',
        'id': 3,
        'lat': 39.9100,
        'lon': 116.4100,
        'tags': {'amenity': 'clinic'},
      },
      {
        // 诊所，且比医院更近
        'type': 'node',
        'id': 4,
        'lat': 39.9080,
        'lon': 116.4090,
        'tags': {'amenity': 'clinic', 'name': '社区诊所'},
      },
      {
        // 缺少坐标应被跳过
        'type': 'node',
        'id': 5,
        'tags': {'amenity': 'hospital', 'name': '无坐标医院'},
      },
    ],
  };

  group('PoiClient.parseOverpassResponse', () {
    test('解析名称、类型并按距离升序排序', () {
      final list = PoiClient.parseOverpassResponse(
        json.encode(sample),
        latitude: 39.9090,
        longitude: 116.4080,
      );
      expect(list.length, 3);
      // 社区诊所最近，其次是协和，朝阳医院最远
      expect(list[0].name, '社区诊所');
      expect(list[0].kindText, '诊所');
      expect(list[1].name, '北京协和医院');
      expect(list[2].name, '朝阳医院');
      for (final h in list) {
        expect(h.distanceKm, greaterThan(0));
        expect(h.latitude, isNotNull);
        expect(h.longitude, isNotNull);
      }
    });

    test('limit 截取最近 N 条', () {
      final list = PoiClient.parseOverpassResponse(
        json.encode(sample),
        latitude: 39.9090,
        longitude: 116.4080,
        limit: 1,
      );
      expect(list.length, 1);
      expect(list.first.name, '社区诊所');
    });

    test('空 elements 返回空列表', () {
      final list = PoiClient.parseOverpassResponse(
        json.encode({'elements': []}),
        latitude: 39.9,
        longitude: 116.4,
      );
      expect(list, isEmpty);
    });

    test('distanceKm 计算符合已知地理距离', () {
      // 北京站到天安门直线约 2.6 公里
      final d = PoiClient.distanceKm(39.9028, 116.4273, 39.9087, 116.3975);
      expect(d, greaterThan(2.2));
      expect(d, lessThan(3.0));
    });
  });

  group('PoiClient.parseAmapResponse', () {
    const sample = {
      'status': '1',
      'info': 'OK',
      'pois': [
        {
          'name': '北京大学人民医院',
          'location': '116.352,39.941',
          'type': '医疗保健服务;综合医院;综合医院',
        },
        {
          'name': '社区诊所',
          'location': '116.356,39.944',
          'type': '医疗保健服务;诊所;普通诊所',
        },
        {
          // 缺少坐标应被跳过
          'name': '无效条目',
        },
      ],
    };

    test('解析名称/坐标/类型并按距离排序', () {
      final list = PoiClient.parseAmapResponse(
        json.encode(sample),
        latitude: 39.9450,
        longitude: 116.3560,
      );
      expect(list.length, 2);
      expect(list[0].name, '社区诊所');
      expect(list[0].kindText, '诊所');
      expect(list[1].name, '北京大学人民医院');
      expect(list[1].kindText, '医院');
      expect(list[0].distanceKm, lessThan(list[1].distanceKm));
    });

    test('status 非 1 时抛出异常', () {
      expect(
        () => PoiClient.parseAmapResponse(
          json.encode({'status': '0', 'info': 'INVALID_USER_KEY'}),
          latitude: 39.9,
          longitude: 116.4,
        ),
        throwsException,
      );
    });
  });
}
