import 'package:flutter_test/flutter_test.dart';
import 'package:family_health/models/user.dart';
import 'package:family_health/models/family_member.dart';
import 'package:family_health/models/health_record.dart';
import 'package:family_health/models/health_report.dart';
import 'package:family_health/models/device.dart';
import 'package:family_health/models/emergency_contact.dart';
import 'package:family_health/models/medical_history_entry.dart';
import 'package:family_health/models/elderly_settings.dart';
import 'package:family_health/models/ocr_result.dart';
import 'package:family_health/models/health_alert.dart';
import 'package:family_health/models/hospital.dart';
import 'package:family_health/models/reminder.dart';

void main() {
  group('模型序列化 round-trip', () {
    test('User', () {
      final m = User(
        id: 'u1',
        name: '张三',
        phone: '13800000000',
        age: 35,
        gender: '男',
        avatarUrl: 'http://x/a.png',
        medicalHistory: '高血压',
        emergencyContacts: const ['13811111111', '13822222222'],
      );
      final restored = User.fromJson(m.toJson());
      expect(restored.id, m.id);
      expect(restored.name, m.name);
      expect(restored.phone, m.phone);
      expect(restored.age, m.age);
      expect(restored.gender, m.gender);
      expect(restored.avatarUrl, m.avatarUrl);
      expect(restored.medicalHistory, m.medicalHistory);
      expect(restored.emergencyContacts, m.emergencyContacts);
    });

    test('FamilyMember', () {
      final m = FamilyMember(
        id: '1',
        name: '张爷爷',
        relation: '父亲',
        age: 65,
        gender: '男',
        medicalHistory: '高血压',
        hasDevice: true,
      );
      final restored = FamilyMember.fromJson(m.toJson());
      expect(restored.id, m.id);
      expect(restored.name, m.name);
      expect(restored.relation, m.relation);
      expect(restored.age, m.age);
      expect(restored.gender, m.gender);
      expect(restored.medicalHistory, m.medicalHistory);
      expect(restored.hasDevice, m.hasDevice);
    });

    test('HealthRecord', () {
      final m = HealthRecord(
        steps: 8432,
        sleepHours: 7.5,
        heartRate: 72,
        activityLevel: 0.68,
        date: DateTime(2026, 8, 20, 10, 30),
      );
      final restored = HealthRecord.fromJson(m.toJson());
      expect(restored.steps, m.steps);
      expect(restored.sleepHours, m.sleepHours);
      expect(restored.heartRate, m.heartRate);
      expect(restored.activityLevel, m.activityLevel);
      expect(restored.date, m.date);
    });

    test('HealthSummary', () {
      final m = HealthSummary(
        todaySteps: 8000,
        todaySleep: 7.5,
        currentHeartRate: 72,
        todayActivity: 0.65,
        healthStatus: '良好',
      );
      final restored = HealthSummary.fromJson(m.toJson());
      expect(restored.todaySteps, m.todaySteps);
      expect(restored.todaySleep, m.todaySleep);
      expect(restored.currentHeartRate, m.currentHeartRate);
      expect(restored.todayActivity, m.todayActivity);
      expect(restored.healthStatus, m.healthStatus);
    });

    test('HealthReport', () {
      final m = HealthReport(
        id: 'rpt_1',
        memberName: '张三',
        generatedAt: DateTime(2026, 8, 20, 12, 0),
        type: '周度评估',
        summary: '整体良好',
        overallScore: 78.5,
        suggestions: const ['建议多运动', '保持作息'],
        pdfUrl: 'http://x/report.pdf',
      );
      final restored = HealthReport.fromJson(m.toJson());
      expect(restored.id, m.id);
      expect(restored.memberName, m.memberName);
      expect(restored.generatedAt, m.generatedAt);
      expect(restored.type, m.type);
      expect(restored.summary, m.summary);
      expect(restored.overallScore, m.overallScore);
      expect(restored.suggestions, m.suggestions);
      expect(restored.pdfUrl, m.pdfUrl);
      // 新增字段缺省时保持空值，不抛异常
      expect(restored.memberId, isNull);
      expect(restored.dimensions, isEmpty);
      expect(restored.records, isEmpty);
      expect(restored.vitalSummary, isNull);
      expect(restored.periodStart, isNull);
      expect(restored.periodEnd, isNull);
    });

    test('HealthReport（含评估明细与原始记录的完整往返）', () {
      final m = HealthReport(
        id: 'rpt_2',
        memberName: '张爷爷',
        memberId: 'm1',
        generatedAt: DateTime(2026, 9, 19, 20, 30),
        type: '周度评估',
        summary: '本周「睡眠」偏弱',
        overallScore: 71.3,
        suggestions: const ['建议保证7小时睡眠'],
        dimensions: [
          ReportDimension(name: '步数', score: 80, level: '良', suggestion: '提升至8000步'),
          ReportDimension(name: '睡眠', score: 65, level: '一般', suggestion: '保证7小时'),
        ],
        records: [
          HealthRecord(
            steps: 7000,
            sleepHours: 6.4,
            heartRate: 70,
            activityLevel: 0.55,
            date: DateTime(2026, 9, 13),
          ),
        ],
        vitalSummary: HealthSummary(
          todaySteps: 9100,
          todaySleep: 7.2,
          currentHeartRate: 74,
          todayActivity: 0.63,
          healthStatus: '良好',
        ),
        periodStart: DateTime(2026, 9, 13),
        periodEnd: DateTime(2026, 9, 19),
      );

      final restored = HealthReport.fromJson(m.toJson());
      expect(restored.memberId, 'm1');
      expect(restored.dimensions.length, 2);
      expect(restored.dimensions.first.name, '步数');
      expect(restored.dimensions.first.score, 80);
      expect(restored.dimensions.first.level, '良');
      expect(restored.records.length, 1);
      expect(restored.records.first.steps, 7000);
      expect(restored.records.first.date, DateTime(2026, 9, 13));
      expect(restored.vitalSummary?.currentHeartRate, 74);
      expect(restored.vitalSummary?.healthStatus, '良好');
      expect(restored.periodStart, DateTime(2026, 9, 13));
      expect(restored.periodEnd, DateTime(2026, 9, 19));
      expect(restored.periodDays, 1);
    });

    test('HealthDevice（枚举类型映射）', () {
      final m = HealthDevice(
        id: 'd1',
        name: '手环',
        type: DeviceType.bracelet,
        isConnected: true,
        batteryLevel: 80,
      );
      final restored = HealthDevice.fromJson(m.toJson());
      expect(restored.id, m.id);
      expect(restored.name, m.name);
      expect(restored.type, DeviceType.bracelet);
      expect(restored.isConnected, m.isConnected);
      expect(restored.batteryLevel, m.batteryLevel);
    });

    test('EmergencyContact', () {
      const m = EmergencyContact(
        id: 'c1',
        name: '李四',
        phone: '13900000000',
        relation: '配偶',
      );
      final restored = EmergencyContact.fromJson(m.toJson());
      expect(restored.id, m.id);
      expect(restored.name, m.name);
      expect(restored.phone, m.phone);
      expect(restored.relation, m.relation);
    });

    test('MedicalHistoryEntry', () {
      const m = MedicalHistoryEntry(
        id: 'h1',
        name: '高血压',
        diagnosedAt: '2020-05',
        note: '每日服药',
      );
      final restored = MedicalHistoryEntry.fromJson(m.toJson());
      expect(restored.id, m.id);
      expect(restored.name, m.name);
      expect(restored.diagnosedAt, m.diagnosedAt);
      expect(restored.note, m.note);
    });

    test('ElderlySettings（含默认值）', () {
      const m = ElderlySettings(
        speakSpeed: 1.5,
        autoConnectBluetooth: false,
        readAloud: true,
        elderlyMode: true,
      );
      final restored = ElderlySettings.fromJson(m.toJson());
      expect(restored.speakSpeed, m.speakSpeed);
      expect(restored.autoConnectBluetooth, m.autoConnectBluetooth);
      expect(restored.readAloud, m.readAloud);
      expect(restored.elderlyMode, m.elderlyMode);

      // 缺失字段回退默认值
      final defaults = ElderlySettings.fromJson(const {});
      expect(defaults.speakSpeed, 1.0);
      expect(defaults.autoConnectBluetooth, true);
      expect(defaults.readAloud, true);
      expect(defaults.elderlyMode, false);
    });

    test('OcrResult（含条目列表）', () {
      final m = OcrResult(
        id: 'ocr_1',
        reportName: '血常规检验报告',
        patientName: '张三',
        sampleType: '静脉血',
        reportDate: DateTime(2026, 8, 10),
        recognizedAt: DateTime(2026, 8, 12, 9, 30),
        items: const [
          OcrTestItem(
            item: '白细胞计数 (WBC)',
            result: '6.8',
            referenceRange: '3.5-9.5',
            unit: '10^9/L',
            status: 'normal',
          ),
          OcrTestItem(
            item: '空腹血糖 (GLU)',
            result: '6.5',
            referenceRange: '3.9-6.1',
            unit: 'mmol/L',
            status: 'high',
          ),
        ],
        summary: '血糖轻度偏高',
      );
      final restored = OcrResult.fromJson(m.toJson());
      expect(restored.id, m.id);
      expect(restored.reportName, m.reportName);
      expect(restored.patientName, m.patientName);
      expect(restored.sampleType, m.sampleType);
      expect(restored.reportDate, m.reportDate);
      expect(restored.recognizedAt, m.recognizedAt);
      expect(restored.items.length, 2);
      expect(restored.items.first.item, '白细胞计数 (WBC)');
      expect(restored.items.last.status, 'high');
      expect(restored.summary, m.summary);
    });
    test('HealthAlert（枚举级别映射）', () {
      final m = HealthAlert(
        id: 'alert_m1_hr',
        memberId: 'm1',
        memberName: '张三',
        level: AlertLevel.danger,
        title: '脉搏异常',
        content: '静息脉搏 105 次/分，建议尽快就医检查。',
        createdAt: DateTime(2026, 8, 25, 9, 30),
      );
      final restored = HealthAlert.fromJson(m.toJson());
      expect(restored.id, m.id);
      expect(restored.memberId, m.memberId);
      expect(restored.memberName, m.memberName);
      expect(restored.level, AlertLevel.danger);
      expect(restored.title, m.title);
      expect(restored.content, m.content);
      expect(restored.createdAt, m.createdAt);

      // 未知级别回退 info
      final fallback = HealthAlert.fromJson(const {'level': 'unknown'});
      expect(fallback.level, AlertLevel.info);
    });

    test('Hospital', () {
      const m = Hospital(
        name: '北京协和医院',
        latitude: 39.9125,
        longitude: 116.4170,
        distanceKm: 2.345,
        kind: 'hospital',
      );
      final restored = Hospital.fromJson(m.toJson());
      expect(restored.name, m.name);
      expect(restored.latitude, m.latitude);
      expect(restored.longitude, m.longitude);
      expect(restored.distanceKm, m.distanceKm);
      expect(restored.kind, m.kind);
      expect(m.distanceText, '2.3km');
      expect(m.kindText, '医院');
      expect(
        const Hospital(latitude: 0, longitude: 0, distanceKm: 0.3, name: 'x', kind: 'clinic').distanceText,
        '300m',
      );
      expect(
        const Hospital(latitude: 0, longitude: 0, distanceKm: 0.3, name: 'x', kind: 'clinic').kindText,
        '诊所',
      );
    });
    test('Reminder（枚举类型映射 + 默认值）', () {
      const m = Reminder(
        id: '1735000000000',
        type: ReminderType.water,
        hour: 10,
        minute: 30,
      );
      final restored = Reminder.fromJson(m.toJson());
      expect(restored.id, m.id);
      expect(restored.type, ReminderType.water);
      expect(restored.hour, 10);
      expect(restored.minute, 30);
      expect(restored.enabled, true);
      expect(restored.title, '喝水');
      expect(restored.timeText, '10:30');

      // 自定义类型标题
      final custom = Reminder.fromJson(const {
        'id': 'x',
        'type': 'custom',
        'customTitle': '降压药',
        'hour': 7,
        'minute': 15,
      });
      expect(custom.title, '降压药');

      // 未知类型/缺失字段回退默认值
      final fallback = Reminder.fromJson(const {'type': 'nope'});
      expect(fallback.type, ReminderType.medicine);
      expect(fallback.hour, 8);
      expect(fallback.enabled, true);
      expect(fallback.title, '吃药');
    });
  });
}
