import 'package:family_health/core/edge/edge_health_result.dart';
import 'package:flutter_test/flutter_test.dart';

Map<String, dynamic> _response({
  Object? diagnosis,
  Object? diseaseProbability,
  List<dynamic>? triggers,
}) {
  return {
    'status': 'success',
    'result': {
      'scope': 'NON_DIAGNOSTIC_HEALTH_MANAGEMENT',
      'rule_version': '1.0.0',
      'approval_status': 'PENDING_NAMED_PRODUCT_AND_DOMAIN_REVIEW',
      'product_release_allowed': false,
      'disease_probability': diseaseProbability,
      'diagnosis': diagnosis,
      'attention_level': 'NO_RULE_TRIGGERED',
      'measurements': [
        {
          'metric': 'heart_rate',
          'triggers': triggers ?? <dynamic>[],
        },
      ],
      'disclaimer': '仅用于健康管理提示，不用于诊断。',
    },
  };
}

void main() {
  test('parses non-diagnostic health result and preserves release gate', () {
    final result = EdgeHealthResult.fromResponse(_response());

    expect(result.attentionLevel, 'NO_RULE_TRIGGERED');
    expect(result.productReleaseAllowed, isFalse);
    expect(result.messages.single, contains('不代表健康'));
  });

  test('extracts attention messages', () {
    final result = EdgeHealthResult.fromResponse(
      _response(triggers: [
        {
          'code': 'PERSONAL_TREND_CHANGE',
          'level': 'OBSERVE',
          'message': '建议核对测量条件并持续观察。',
        },
      ]),
    );

    expect(result.messages, ['建议核对测量条件并持续观察。']);
  });

  test('rejects any diagnostic output', () {
    expect(
      () => EdgeHealthResult.fromResponse(_response(diagnosis: '疾病')),
      throwsFormatException,
    );
    expect(
      () => EdgeHealthResult.fromResponse(_response(diseaseProbability: 0.8)),
      throwsFormatException,
    );
  });
}
