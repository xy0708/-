import 'package:flutter_test/flutter_test.dart';
import 'package:family_health/core/assessment/health_stats.dart';
import 'package:family_health/models/health_record.dart';

HealthRecord _record({
  int steps = 8000,
  double sleep = 7.5,
  int heartRate = 72,
  double activity = 0.7,
  int day = 1,
}) {
  return HealthRecord(
    steps: steps,
    sleepHours: sleep,
    heartRate: heartRate,
    activityLevel: activity,
    date: DateTime(2026, 9, day),
  );
}

MetricStat _metric(HealthStats stats, String name) {
  return stats.metrics.firstWhere((m) => m.name == name);
}

void main() {
  group('HealthStats 统计口径', () {
    test('空记录返回四项全零而不是抛异常', () {
      final stats = HealthStats.compute(const []);
      expect(stats.metrics.length, 4);
      for (final m in stats.metrics) {
        expect(m.avg, 0);
        expect(m.min, 0);
        expect(m.max, 0);
        expect(m.totalDays, 0);
        expect(m.achieveRate, 0);
        expect(m.trend, '平稳');
      }
      expect(stats.overallTrend, '整体平稳');
      expect(stats.isStable, isTrue);
    });

    test('均值与极值按原始值统计，步数均值取整', () {
      final stats = HealthStats.compute([
        _record(steps: 4000, day: 1),
        _record(steps: 5001, day: 2),
        _record(steps: 9000, day: 3),
      ]);
      final steps = _metric(stats, '步数');
      // (4000 + 5001 + 9000) / 3 = 6000.33…
      expect(steps.avg, 6000);
      expect(steps.min, 4000);
      expect(steps.max, 9000);
      expect(steps.totalDays, 3);
      expect(steps.unit, '步');
      expect(steps.targetText, '≥6000 步');
    });

    test('睡眠均值保留一位小数', () {
      final stats = HealthStats.compute([
        _record(sleep: 6.0, day: 1),
        _record(sleep: 7.0, day: 2),
      ]);
      final sleep = _metric(stats, '睡眠');
      expect(sleep.avg, 6.5);
      expect(sleep.decimals, 1);
      expect(sleep.format(sleep.avg), '6.5');
    });

    test('达标天数据各项阈值判定，边界值算达标', () {
      final stats = HealthStats.compute([
        // 四项全部恰好踩在达标线上（达标线 = 该维度的「良」阈值）
        _record(steps: 6000, sleep: 7.0, heartRate: 60, activity: 0.6, day: 1),
        // 步数不足、睡眠不足、脉搏偏高、活动度不足
        _record(steps: 5999, sleep: 6.9, heartRate: 101, activity: 0.59, day: 2),
      ]);
      expect(_metric(stats, '步数').achievedDays, 1);
      expect(_metric(stats, '睡眠').achievedDays, 1);
      expect(_metric(stats, '脉搏').achievedDays, 1);
      expect(_metric(stats, '活动度').achievedDays, 1);
      for (final m in stats.metrics) {
        expect(m.totalDays, 2);
      }
    });

    test('达标率按达标天数与总天数计算', () {
      final stats = HealthStats.compute([
        _record(steps: 8000, day: 1),
        _record(steps: 8000, day: 2),
        _record(steps: 2000, day: 3),
        _record(steps: 2000, day: 4),
      ]);
      final steps = _metric(stats, '步数');
      expect(steps.achievedDays, 2);
      expect(steps.achieveRate, 0.5);
    });

    test('活动度按百分比换算后与阈值比较', () {
      // 活动度阈值 0.6 → 60%
      final stats = HealthStats.compute([
        _record(activity: 0.75, day: 1),
        _record(activity: 0.45, day: 2),
      ]);
      final activity = _metric(stats, '活动度');
      expect(activity.avg, closeTo(60, 0.001));
      expect(activity.unit, '%');
      expect(activity.achievedDays, 1);
    });
  });

  group('HealthStats 趋势判定', () {
    test('后半段明显升高判为上升', () {
      final stats = HealthStats.compute([
        _record(activity: 0.40, day: 1),
        _record(activity: 0.40, day: 2),
        _record(activity: 0.40, day: 3),
        _record(activity: 0.60, day: 4),
        _record(activity: 0.60, day: 5),
        _record(activity: 0.60, day: 6),
      ]);
      expect(_metric(stats, '活动度').trend, '上升');
      expect(stats.overallTrend, '整体上升');
    });

    test('后半段明显降低判为下降', () {
      final stats = HealthStats.compute([
        _record(activity: 0.80, day: 1),
        _record(activity: 0.80, day: 2),
        _record(activity: 0.80, day: 3),
        _record(activity: 0.50, day: 4),
        _record(activity: 0.50, day: 5),
        _record(activity: 0.50, day: 6),
      ]);
      expect(_metric(stats, '活动度').trend, '下降');
      expect(stats.overallTrend, '整体下降');
    });

    test('变化幅度在阈值内判为平稳', () {
      // 相对变化 3.3%，未超过 5% 的判定阈值
      final stats = HealthStats.compute([
        _record(activity: 0.60, day: 1),
        _record(activity: 0.60, day: 2),
        _record(activity: 0.62, day: 3),
        _record(activity: 0.62, day: 4),
      ]);
      expect(_metric(stats, '活动度').trend, '平稳');
    });

    test('恰好等于阈值不算升降', () {
      final stats = HealthStats.compute([
        _record(activity: 0.50, day: 1),
        _record(activity: 0.50, day: 2),
        _record(activity: 0.525, day: 3), // +5.0%
        _record(activity: 0.525, day: 4),
      ]);
      expect(_metric(stats, '活动度').trend, '平稳');
    });

    test('单条记录没有前后半段之分，判为平稳', () {
      final stats = HealthStats.compute([_record(activity: 0.95, day: 1)]);
      expect(_metric(stats, '活动度').trend, '平稳');
      expect(_metric(stats, '活动度').totalDays, 1);
    });

    test('前半段均值为零时改用绝对变化判断', () {
      final stats = HealthStats.compute([
        _record(activity: 0, day: 1),
        _record(activity: 0, day: 2),
        _record(activity: 0.5, day: 3),
        _record(activity: 0.5, day: 4),
      ]);
      expect(_metric(stats, '活动度').trend, '上升');

      final flat = HealthStats.compute([
        _record(activity: 0, day: 1),
        _record(activity: 0, day: 2),
      ]);
      expect(_metric(flat, '活动度').trend, '平稳');
    });

    test('升降指标数量相同时整体趋势判为平稳', () {
      final stats = HealthStats.compute([
        // 活动度上升
        _record(activity: 0.20, sleep: 7.0, day: 1),
        _record(activity: 0.20, sleep: 7.0, day: 2),
        _record(activity: 0.60, sleep: 4.0, day: 3),
        _record(activity: 0.60, sleep: 4.0, day: 4),
      ]);
      expect(_metric(stats, '活动度').trend, '上升');
      expect(_metric(stats, '睡眠').trend, '下降');
      expect(stats.overallTrend, '整体平稳');
      expect(stats.isStable, isFalse);
    });
  });
}
