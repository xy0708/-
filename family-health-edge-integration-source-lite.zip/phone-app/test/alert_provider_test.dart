import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:family_health/core/config/app_config.dart';
import 'package:family_health/core/network/api_client.dart';
import 'package:family_health/core/assessment/assessment_engine.dart';
import 'package:family_health/core/mock/mock_health_data.dart';
import 'package:family_health/models/health_alert.dart';
import 'package:family_health/providers/alert_provider.dart';

http.Response _jsonResponse(String body, int status) =>
    http.Response.bytes(utf8.encode(body), status);

List<HealthAlert> _expectedDerived(String memberId,
    {int age = 40, String name = '本人'}) {
  return AssessmentEngine.deriveAlerts(
    memberId: memberId,
    memberName: name,
    summary: MockHealthData.summaryFor(memberId, age: age),
    records: MockHealthData.recordsFor(memberId, age: age),
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  tearDown(() {
    AppConfig.useBackend = false;
    AppConfig.allowDemoData = false;
    ApiClient.overrideForTesting = null;
  });

  group('后端模式（useBackend=true）', () {
    setUp(() {
      AppConfig.useBackend = true;
    });

    test('成功调用预警接口时使用后端数据', () async {
      ApiClient.overrideForTesting = ApiClient.forTesting(MockClient(
        (request) async {
          expect(request.url.path, '/api/alerts/active');
          expect(request.url.queryParameters['memberId'], 'm1');
          return _jsonResponse(
            '[{"id":"a1","memberId":"m1","memberName":"张三","level":"warning",'
            '"title":"血压偏高","content":"收缩压持续偏高","createdAt":"2026-08-25T08:00:00.000"},'
            '{"id":"a2","memberId":"m1","memberName":"张三","level":"danger",'
            '"title":"脉搏异常","content":"静息脉搏105次/分","createdAt":"2026-08-25T09:00:00.000"}]',
            200,
          );
        },
      ));
      final provider = AlertProvider();
      await provider.fetchAlerts(memberId: 'm1', memberName: '张三');

      expect(provider.alerts.length, 2);
      expect(provider.alerts.first.title, '血压偏高');
      expect(provider.alerts.first.level, AlertLevel.warning);
      expect(provider.alerts.last.level, AlertLevel.danger);
      expect(provider.warningDangerCount, 2);
    });

    test('接口返回空列表时角标计数为0', () async {
      ApiClient.overrideForTesting = ApiClient.forTesting(MockClient(
        (request) async => _jsonResponse('[]', 200),
      ));
      final provider = AlertProvider();
      await provider.fetchAlerts(memberId: 'm1');

      expect(provider.alerts, isEmpty);
      expect(provider.warningDangerCount, 0);
    });

    test('接口失败时回退本地体征派生预警', () async {
      AppConfig.allowDemoData = true;
      ApiClient.overrideForTesting = ApiClient.forTesting(MockClient(
        (request) async => throw http.ClientException('connection refused'),
      ));
      final provider = AlertProvider();
      await provider.fetchAlerts(memberId: 'm1', memberName: '张三', age: 35);

      final expected = _expectedDerived('m1', age: 35, name: '张三');
      expect(provider.alerts.map((a) => a.title), expected.map((a) => a.title));
      expect(provider.alerts.map((a) => a.level), expected.map((a) => a.level));
    });

    test('正式模式接口失败时不生成假预警', () async {
      ApiClient.overrideForTesting = ApiClient.forTesting(MockClient(
        (request) async => throw http.ClientException('connection refused'),
      ));
      final provider = AlertProvider();

      await expectLater(
        provider.fetchAlerts(memberId: 'm1', memberName: '张三', age: 35),
        throwsA(isA<ApiException>()),
      );
      expect(provider.alerts, isEmpty);
    });
  });

  group('本地 Mock 模式（useBackend=false，默认）', () {
    setUp(() {
      AppConfig.allowDemoData = true;
    });
    test('不走网络，直接派生本地预警', () async {
      // 未配置 override，若误走网络会因无法连接而抛异常，此测试确保直接走本地派生
      final provider = AlertProvider();
      await provider.fetchAlerts(memberId: 'm1', memberName: '张三');

      final expected = _expectedDerived('m1', name: '张三');
      expect(provider.alerts.map((a) => a.title), expected.map((a) => a.title));
    });

    test('不同成员各自缓存，互不影响', () async {
      final provider = AlertProvider();
      await provider.fetchAlerts(memberId: 'm1', memberName: '张三');
      final m1Titles = provider.alerts.map((a) => a.title).toList();

      await provider.fetchAlerts(memberId: 'm2', memberName: '李四');
      final m2Titles = provider.alerts.map((a) => a.title).toList();

      // 两个成员数据独立（缓存分别保存）
      expect(provider.alerts.map((a) => a.title), m2Titles);
      expect(m2Titles, _expectedDerived('m2', name: '李四').map((a) => a.title));

      // 切回 m1 重新拉取时得到与首次一致的确定性结果
      await provider.fetchAlerts(memberId: 'm1', memberName: '张三');
      expect(provider.alerts.map((a) => a.title), m1Titles);
    });
  });
}
