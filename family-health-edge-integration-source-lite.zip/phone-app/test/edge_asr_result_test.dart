import 'package:family_health/core/edge/edge_asr_client.dart';
import 'package:family_health/core/edge/edge_asr_result.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('parses only memory-safe pending transcript', () {
    final result = EdgeAsrPendingResult.fromEvent(
      const EdgeAsrEvent(
        type: 'final_pending_confirmation',
        payload: {
          'task': {'task_id': '0123456789abcdef0123456789abcdef'},
          'result': {'text': '  心率七十二  '},
          'raw_audio_persisted': false,
        },
      ),
    );

    expect(result.taskId, '0123456789abcdef0123456789abcdef');
    expect(result.text, '心率七十二');
  });

  test('rejects raw audio persistence or malformed transcript', () {
    expect(
      () => EdgeAsrPendingResult.fromEvent(
        const EdgeAsrEvent(
          type: 'final_pending_confirmation',
          payload: {
            'task': {'task_id': '0123456789abcdef0123456789abcdef'},
            'result': {'text': '内容'},
            'raw_audio_persisted': true,
          },
        ),
      ),
      throwsFormatException,
    );
    expect(
      () => EdgeAsrPendingResult.fromEvent(
        const EdgeAsrEvent(
          type: 'final_pending_confirmation',
          payload: {
            'task': {'task_id': 'bad'},
            'result': {'text': ''},
            'raw_audio_persisted': false,
          },
        ),
      ),
      throwsFormatException,
    );
  });
}
