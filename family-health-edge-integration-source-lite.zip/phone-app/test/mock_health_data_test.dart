import 'package:flutter_test/flutter_test.dart';
import 'package:family_health/core/mock/mock_health_data.dart';

void main() {
  group('summaryFor', () {
    test('同一成员多次生成结果一致（确定性）', () {
      final a = MockHealthData.summaryFor('member-1', age: 35);
      final b = MockHealthData.summaryFor('member-1', age: 35);
      expect(a.todaySteps, b.todaySteps);
      expect(a.todaySleep, b.todaySleep);
      expect(a.currentHeartRate, b.currentHeartRate);
      expect(a.todayActivity, b.todayActivity);
    });

    test('不同成员生成不同数据', () {
      final a = MockHealthData.summaryFor('member-1');
      final b = MockHealthData.summaryFor('member-2');
      expect(a.todaySteps == b.todaySteps &&
          a.todaySleep == b.todaySleep &&
          a.currentHeartRate == b.currentHeartRate &&
          a.todayActivity == b.todayActivity, isFalse);
    });

    test('老年画像：活动量低于年轻人，脉搏不低于年轻人', () {
      const id = 'member-1';
      final elder = MockHealthData.summaryFor(id, age: 65);
      final young = MockHealthData.summaryFor(id, age: 22);
      expect(elder.todaySteps, lessThan(young.todaySteps));
      expect(elder.todayActivity, lessThan(young.todayActivity));
      expect(elder.currentHeartRate, greaterThanOrEqualTo(young.currentHeartRate));
    });

    test('老年步数不超过画像上限，年轻步数不低于画像下限', () {
      final elder = MockHealthData.summaryFor('m1', age: 70);
      final young = MockHealthData.summaryFor('m2', age: 20);
      expect(elder.todaySteps, lessThanOrEqualTo(7000));
      expect(young.todaySteps, greaterThanOrEqualTo(9000));
    });

    test('数据落在合理生理范围内', () {
      for (var i = 1; i <= 10; i++) {
        final s = MockHealthData.summaryFor('member-$i', age: 40 + i);
        expect(s.todaySteps, inInclusiveRange(1000, 20000));
        expect(s.todaySleep, inInclusiveRange(4.5, 10.0));
        expect(s.currentHeartRate, inInclusiveRange(50, 110));
        expect(s.todayActivity, inInclusiveRange(0.1, 1.0));
      }
    });
  });

  group('recordsFor', () {
    test('返回 7 天记录，日期连续', () {
      final records = MockHealthData.recordsFor('member-1', age: 40);
      expect(records.length, 7);
      for (var i = 0; i < 6; i++) {
        final diff = records[i + 1].date.difference(records[i].date).inDays;
        expect(diff, 1);
      }
    });

    test('同一成员记录确定，不同成员记录不同', () {
      final a1 = MockHealthData.recordsFor('member-1');
      final a2 = MockHealthData.recordsFor('member-1');
      final b1 = MockHealthData.recordsFor('member-2');
      expect(a1.map((r) => r.steps).toList(), a2.map((r) => r.steps).toList());
      expect(a1.map((r) => r.steps).toList(), isNot(b1.map((r) => r.steps).toList()));
    });

    test('老年成员步数整体低于年轻成员', () {
      const id = 'member-1';
      final elder = MockHealthData.recordsFor(id, age: 68);
      final young = MockHealthData.recordsFor(id, age: 24);
      final elderAvg = elder.fold<int>(0, (s, r) => s + r.steps) / 7;
      final youngAvg = young.fold<int>(0, (s, r) => s + r.steps) / 7;
      expect(elderAvg, lessThan(youngAvg));
    });
  });
}
