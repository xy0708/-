import 'package:flutter_test/flutter_test.dart';
import 'package:family_health/core/assessment/assessment_engine.dart';
import 'package:family_health/models/health_alert.dart';
import 'package:family_health/models/health_record.dart';

HealthSummary _s({int st = 8000, double sl = 7.5, int hr = 72, double ac = 0.65}) {
  return HealthSummary(
    todaySteps: st,
    todaySleep: sl,
    currentHeartRate: hr,
    todayActivity: ac,
    healthStatus: 'OK',
  );
}

List<HealthRecord> _r(int d, {int Function(int)? s, double Function(int)? sl, int Function(int)? h, double Function(int)? a}) {
  final n = DateTime.now();
  return List.generate(d, (i) => HealthRecord(
    steps: s?.call(i) ?? 8000,
    sleepHours: sl?.call(i) ?? 7.5,
    heartRate: h?.call(i) ?? 72,
    activityLevel: a?.call(i) ?? 0.65,
    date: n.subtract(Duration(days: d - 1 - i)),
  ));
}

void main() {
  group('evaluate', () {
    test('all excellent high score', () {
      final r = AssessmentEngine.evaluate(summary: _s(st: 12000, sl: 9, ac: 0.85), records: _r(7, s: (_) => 12000, sl: (_) => 9, a: (_) => 0.85));
      expect(r.overallScore, greaterThan(85));
    });

    test('all poor low score', () {
      final r = AssessmentEngine.evaluate(summary: _s(st: 2000, sl: 5, ac: 0.3), records: _r(7, s: (_) => 2000, sl: (_) => 5, a: (_) => 0.3));
      expect(r.overallScore, lessThan(60));
    });

    test('low heart rate triggers medical advice', () {
      final r = AssessmentEngine.evaluate(summary: _s(hr: 55), records: _r(7, h: (_) => 55));
      expect(r.dimensions[2].level, '差');
      expect(r.suggestions.any((s) => s.contains('就医')), isTrue);
    });

    test('high heart rate triggers medical advice', () {
      final r = AssessmentEngine.evaluate(summary: _s(hr: 105), records: _r(7, h: (_) => 105));
      expect(r.dimensions[2].level, '差');
      expect(r.suggestions.any((s) => s.contains('就医')), isTrue);
    });

    test('empty records falls back to summary', () {
      final r = AssessmentEngine.evaluate(summary: _s(st: 9000), records: []);
      expect(r.overallScore, greaterThan(0));
      expect(r.dimensions.length, 4);
    });

    test('returns 4 dimensions', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7));
      expect(r.dimensions.length, 4);
    });
  });

  group('steps boundaries', () {
    test('10000 excellent', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, s: (_) => 10000));
      expect(r.dimensions[0].level, '优');
      expect(r.dimensions[0].score, 95);
    });
    test('6000 good', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, s: (_) => 6000));
      expect(r.dimensions[0].level, '良');
      expect(r.dimensions[0].score, 80);
    });
    test('3000 fair', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, s: (_) => 3000));
      expect(r.dimensions[0].level, '一般');
      expect(r.dimensions[0].score, 60);
    });
    test('2000 poor', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, s: (_) => 2000));
      expect(r.dimensions[0].level, '差');
      expect(r.dimensions[0].score, 40);
    });
  });

  group('sleep boundaries', () {
    test('8.5h excellent', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, sl: (_) => 8.5));
      expect(r.dimensions[1].level, '优');
    });
    test('7h good', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, sl: (_) => 7.0));
      expect(r.dimensions[1].level, '良');
    });
    test('6h fair', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, sl: (_) => 6.0));
      expect(r.dimensions[1].level, '一般');
    });
    test('5h poor', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, sl: (_) => 5.0));
      expect(r.dimensions[1].level, '差');
    });
  });

  group('activity boundaries', () {
    test('0.8 excellent', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, a: (_) => 0.85));
      expect(r.dimensions[3].level, '优');
    });
    test('0.6 good', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, a: (_) => 0.6));
      expect(r.dimensions[3].level, '良');
    });
    test('0.4 fair', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, a: (_) => 0.5));
      expect(r.dimensions[3].level, '一般');
    });
    test('0.3 poor', () {
      final r = AssessmentEngine.evaluate(summary: _s(), records: _r(7, a: (_) => 0.35));
      expect(r.dimensions[3].level, '差');
    });
  });

  group('deriveAlerts', () {
    List<HealthAlert> derive({
      HealthSummary? summary,
      List<HealthRecord>? records,
    }) {
      return AssessmentEngine.deriveAlerts(
        memberId: 'm1',
        memberName: '张三',
        summary: summary ?? _s(),
        records: records ?? _r(7),
      );
    }

    test('正常数据不产生预警', () {
      expect(derive(), isEmpty);
    });

    test('静息脉搏低于60产生 danger 预警', () {
      final alerts = derive(summary: _s(hr: 55), records: _r(7, h: (_) => 55));
      expect(alerts.length, 1);
      expect(alerts.first.level, AlertLevel.danger);
      expect(alerts.first.title, '脉搏异常');
      expect(alerts.first.content, contains('就医'));
    });

    test('静息脉搏高于100产生 danger 预警', () {
      final alerts = derive(summary: _s(hr: 105), records: _r(7, h: (_) => 105));
      expect(alerts.first.level, AlertLevel.danger);
    });

    test('睡眠均值低于6小时产生 warning 预警', () {
      final alerts = derive(records: _r(7, sl: (_) => 5.0));
      expect(alerts.length, 1);
      expect(alerts.first.level, AlertLevel.warning);
      expect(alerts.first.title, '睡眠不足');
    });

    test('步数均值低于3000产生 info 预警', () {
      final alerts = derive(records: _r(7, s: (_) => 2000));
      expect(alerts.length, 1);
      expect(alerts.first.level, AlertLevel.info);
      expect(alerts.first.title, '活动量偏少');
    });

    test('阈值边界不触发：脉搏60/100、睡眠6.0h、步数3000', () {
      expect(
        derive(records: _r(7, h: (_) => 60, sl: (_) => 6.0, s: (_) => 3000)),
        isEmpty,
      );
      expect(
        derive(records: _r(7, h: (_) => 100)),
        isEmpty,
      );
    });

    test('多项异常时按 danger→warning→info 排序并携带成员信息', () {
      final alerts = derive(
        summary: _s(st: 2000, sl: 5.0, hr: 105),
        records: _r(7, s: (_) => 2000, sl: (_) => 5.0, h: (_) => 105),
      );
      expect(alerts.length, 3);
      expect(alerts.map((a) => a.level).toList(), [
        AlertLevel.danger,
        AlertLevel.warning,
        AlertLevel.info,
      ]);
      for (final a in alerts) {
        expect(a.memberId, 'm1');
        expect(a.memberName, '张三');
        expect(a.id, isNotEmpty);
      }
    });

    test('records 为空时回退 summary 阈值', () {
      final alerts = derive(summary: _s(hr: 110), records: []);
      expect(alerts.length, 1);
      expect(alerts.first.title, '脉搏异常');
    });

    test('同一份数据多次派生结果一致（确定性）', () {
      final a1 = derive(records: _r(7, s: (_) => 2000, sl: (_) => 5.0));
      final a2 = derive(records: _r(7, s: (_) => 2000, sl: (_) => 5.0));
      expect(a1.map((e) => e.title), a2.map((e) => e.title));
      expect(a1.map((e) => e.level), a2.map((e) => e.level));
    });
  });
}
