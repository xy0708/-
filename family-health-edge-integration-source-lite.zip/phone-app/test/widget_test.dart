import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:family_health/app.dart';
import 'package:family_health/providers/auth_provider.dart';
import 'package:family_health/providers/health_provider.dart';
import 'package:family_health/providers/family_provider.dart';
import 'package:family_health/providers/device_provider.dart';
import 'package:family_health/providers/alert_provider.dart';
import 'package:family_health/providers/settings_provider.dart';
import 'package:family_health/providers/emergency_contact_provider.dart';
import 'package:family_health/providers/medical_history_provider.dart';
import 'package:family_health/providers/elderly_settings_provider.dart';

void main() {
  testWidgets('App displays splash screen', (WidgetTester tester) async {
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => AuthProvider()),
          ChangeNotifierProvider(create: (_) => HealthProvider()),
          ChangeNotifierProvider(create: (_) => FamilyProvider()),
          ChangeNotifierProvider(create: (_) => DeviceProvider()),
          ChangeNotifierProvider(create: (_) => AlertProvider()),
          ChangeNotifierProvider(create: (_) => SettingsProvider()),
          ChangeNotifierProvider(create: (_) => EmergencyContactProvider()),
          ChangeNotifierProvider(create: (_) => MedicalHistoryProvider()),
          ChangeNotifierProvider(create: (_) => ElderlySettingsProvider()),
        ],
        child: const FamilyHealthApp(),
      ),
    );
    expect(find.text('家庭健康管理'), findsOneWidget);
  });
}
