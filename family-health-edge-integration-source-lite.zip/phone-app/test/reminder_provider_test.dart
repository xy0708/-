import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:family_health/models/reminder.dart';
import 'package:family_health/providers/reminder_provider.dart';
import 'package:family_health/services/notification_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('通知 id 映射为合法 int32（毫秒时间戳会越界）', () {
    final service = NotificationService.instance;
    // 13 位毫秒时间戳，直接作为通知 id 会被系统拒绝
    const ts = '1789315649332';
    final id = service.notificationId(ts);
    expect(id, inInclusiveRange(0, 2147483647));
    // 同一提醒 id 映射稳定（便于取消时匹配）
    expect(service.notificationId(ts), id);
    expect(service.notificationId('1000'), inInclusiveRange(0, 2147483647));
  });

  test('首次加载为空列表', () async {
    SharedPreferences.setMockInitialValues({});
    final provider = ReminderProvider();
    await provider.load();
    expect(provider.reminders, isEmpty);
    expect(provider.enabledCount, 0);
  });

  test('添加提醒并持久化，跨实例可见', () async {
    SharedPreferences.setMockInitialValues({});
    final provider = ReminderProvider();
    await provider.load();
    await provider.add(const Reminder(
      id: '1735000000000',
      type: ReminderType.medicine,
      hour: 8,
      minute: 0,
    ));
    expect(provider.reminders.length, 1);
    expect(provider.enabledCount, 1);

    final restored = ReminderProvider();
    await restored.load();
    expect(restored.reminders.length, 1);
    expect(restored.reminders.first.title, '吃药');
    expect(restored.reminders.first.timeText, '08:00');
  });

  test('更新（改时间/停用）与删除', () async {
    SharedPreferences.setMockInitialValues({});
    final provider = ReminderProvider();
    await provider.load();
    await provider.add(const Reminder(
      id: '1000',
      type: ReminderType.medicine,
      hour: 8,
      minute: 0,
    ));

    await provider.update(const Reminder(
      id: '1000',
      type: ReminderType.medicine,
      hour: 9,
      minute: 30,
      enabled: false,
    ));
    expect(provider.reminders.first.enabled, false);
    expect(provider.reminders.first.timeText, '09:30');
    expect(provider.enabledCount, 0);

    await provider.remove('1000');
    expect(provider.reminders, isEmpty);
  });

  test('启停开关计数控', () async {
    SharedPreferences.setMockInitialValues({});
    final provider = ReminderProvider();
    await provider.load();
    await provider.add(const Reminder(id: '1', type: ReminderType.water, hour: 9, minute: 0));
    await provider.add(const Reminder(
      id: '2',
      type: ReminderType.bloodPressure,
      hour: 10,
      minute: 0,
      enabled: false,
    ));
    expect(provider.enabledCount, 1);
    await provider.update(const Reminder(id: '2', type: ReminderType.bloodPressure, hour: 10, minute: 0));
    expect(provider.enabledCount, 2);
  });
}
