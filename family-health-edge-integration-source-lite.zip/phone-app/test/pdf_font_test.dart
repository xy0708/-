import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('PDF 中文字体可正常绘制', () async {
    // 回归：CFF 轮廓的 OTF 字体（NotoSansSC-Regular.otf）在 pdf 包中
    // 无法映射字形，绘制中文时抛出
    // Invalid argument (string): Contains invalid characters
    // 现改用 TrueType（glyf）轮廓的 TTF 字体。
    final font = pw.Font.ttf(
      await rootBundle.load('assets/fonts/NotoSansSC-Regular.ttf'),
    );
    final doc = pw.Document(theme: pw.ThemeData.withFont(base: font, bold: font));
    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text('家庭健康评估报告'),
            pw.Text('生成时间：2026-08-30 13:00'),
            pw.Text('评估摘要：各项指标基本正常。空腹血糖轻度偏高，建议控制饮食、增加运动，并定期复查。'),
            pw.Text('· 每日步行 6000 步以上'),
          ],
        ),
      ),
    );
    final bytes = await doc.save();
    expect(bytes.length, greaterThan(10000));
  });
}
