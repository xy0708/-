import 'package:family_health/core/watch/wearable_measurement.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final normalizer = YuchengMeasurementNormalizer();

  test('normalizes documented Yucheng heart history keys', () {
    final measurement = normalizer.normalize(
      memberId: 'member-1',
      deviceId: 'watch-1',
      metric: WearableMetric.heartRate,
      vendorPayload: {'heartStartTime': 1770000000, 'heartValue': 72},
    );

    expect(measurement, isNotNull);
    expect(measurement!.unit, 'bpm');
    expect(measurement.value, 72);
    expect(measurement.capturedAt.isUtc, isTrue);
    expect(measurement.quality, MeasurementQuality.valid);
    expect(measurement.toJson()['memberId'], 'member-1');
  });

  test('preserves an abnormal value but marks it invalid', () {
    final measurement = normalizer.normalize(
      memberId: 'member-1',
      deviceId: 'watch-1',
      metric: WearableMetric.heartRate,
      vendorPayload: {'heartStartTime': 1770000000000, 'heartValue': 500},
    );

    expect(measurement, isNotNull);
    expect(measurement!.quality, MeasurementQuality.invalid);
  });

  test('missing vendor fields remain unavailable instead of becoming zero', () {
    final measurement = normalizer.normalize(
      memberId: 'member-1',
      deviceId: 'watch-1',
      metric: WearableMetric.steps,
      vendorPayload: {'sportStep': 1200},
    );

    expect(measurement, isNull);
  });

  test('record id is deterministic for retry deduplication', () {
    const payload = {'sportStartTime': 1770000000, 'sportStep': 1200};
    final first = normalizer.normalize(
      memberId: 'member-1',
      deviceId: 'watch-1',
      metric: WearableMetric.steps,
      vendorPayload: payload,
    );
    final second = normalizer.normalize(
      memberId: 'member-1',
      deviceId: 'watch-1',
      metric: WearableMetric.steps,
      vendorPayload: payload,
    );

    expect(first!.recordId, second!.recordId);
  });
}
