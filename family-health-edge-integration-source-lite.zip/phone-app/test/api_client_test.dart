import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:family_health/core/network/api_client.dart';

http.Response _jsonResponse(String body, int status) =>
    http.Response.bytes(utf8.encode(body), status);

void main() {
  group('ApiClient 请求与错误处理', () {
    test('GET 成功返回解码后的 JSON', () async {
      final client = MockClient(
          (request) async => _jsonResponse('{"ok":1,"name":"张三"}', 200));
      final api = ApiClient.forTesting(client);
      final data = await api.get('/api/health/summary');
      expect(data, {'ok': 1, 'name': '张三'});
    });

    test('GET 空响应体返回 null', () async {
      final client = MockClient((request) async => http.Response('', 204));
      final api = ApiClient.forTesting(client);
      expect(await api.get('/api/x'), isNull);
    });

    test('非 2xx 提取后端 message 字段', () async {
      final client = MockClient(
          (request) async => _jsonResponse('{"message":"token 无效"}', 401));
      final api = ApiClient.forTesting(client);
      expect(
        () => api.get('/api/x'),
        throwsA(isA<ApiException>()
            .having((e) => e.message, 'message', 'token 无效')
            .having((e) => e.statusCode, 'statusCode', 401)),
      );
    });

    test('非 JSON 错误响应回退通用错误信息', () async {
      final client = MockClient(
          (request) async => http.Response('<html>Server Error</html>', 500));
      final api = ApiClient.forTesting(client);
      expect(
        () => api.post('/api/x'),
        throwsA(isA<ApiException>().having(
            (e) => e.message, 'message', '请求失败 (500)')),
      );
    });

    test('网络异常包装为友好提示', () async {
      final client = MockClient(
          (request) async => throw http.ClientException('connection refused'));
      final api = ApiClient.forTesting(client);
      expect(
        () => api.get('/api/x'),
        throwsA(isA<ApiException>().having(
            (e) => e.message, 'message', contains('网络请求失败'))),
      );
    });

    test('超时包装为友好提示', () async {
      final client = MockClient((request) async {
        await Future<void>.delayed(const Duration(milliseconds: 200));
        return http.Response('{}', 200);
      });
      final api = ApiClient.forTesting(client);
      expect(
        () => api.get('/api/slow', timeout: const Duration(milliseconds: 50)),
        throwsA(isA<ApiException>().having(
            (e) => e.message, 'message', contains('超时'))),
      );
    });

    test('2xx 但响应不是合法 JSON 时报格式错误', () async {
      final client = MockClient((request) async => http.Response('not-json', 200));
      final api = ApiClient.forTesting(client);
      expect(
        () => api.get('/api/x'),
        throwsA(isA<ApiException>().having(
            (e) => e.message, 'message', contains('格式错误'))),
      );
    });

    test('setToken 后请求携带 Authorization', () async {
      late http.Request captured;
      final client = MockClient((request) async {
        captured = request;
        return http.Response('{}', 200);
      });
      final api = ApiClient.forTesting(client);
      api.setToken('abc123');
      await api.get('/api/x');
      expect(captured.headers['Authorization'], 'Bearer abc123');
    });

    test('baseUrl 规范化：尾斜杠与缺失前导斜杠', () async {
      late http.Request captured;
      final client = MockClient((request) async {
        captured = request;
        return http.Response('{}', 200);
      });
      final api = ApiClient.forTesting(client);
      api.setBaseUrl('http://example.com/');
      await api.get('api/health/summary');
      expect(captured.url.toString(), 'http://example.com/api/health/summary');
    });

    test('POST 发送 JSON body', () async {
      late http.Request captured;
      final client = MockClient((request) async {
        captured = request;
        return http.Response('{}', 200);
      });
      final api = ApiClient.forTesting(client);
      await api.post('/api/devices/bind', body: {'phone': '13800000000'});
      expect(captured.method, 'POST');
      expect(captured.headers['Content-Type'], contains('application/json'));
      expect(captured.body, contains('13800000000'));
    });
  });

  group('ApiClient uploadFile', () {
    test('以 multipart 上传文件并解析响应', () async {
      final dir = await Directory.systemTemp.createTemp('api_client_test');
      final file = File('${dir.path}/lab.txt');
      await file.writeAsString('化验单内容');

      late http.Request captured;
      final client = MockClient((request) async {
        captured = request;
        return _jsonResponse('{"id":"ocr_1","reportName":"血常规"}', 200);
      });
      final api = ApiClient.forTesting(client);

      final data = await api.uploadFile('/api/ai/ocr/upload', file);
      expect(data, {'id': 'ocr_1', 'reportName': '血常规'});
      expect(captured.url.path, '/api/ai/ocr/upload');
      expect(captured.headers['Content-Type'], contains('multipart/form-data'));
      expect(captured.headers.containsKey('Content-Type'), isTrue);
      // multipart 不应携带 JSON Content-Type
      expect(captured.headers['Content-Type'], isNot(contains('application/json')));
      final body = utf8.decode(captured.bodyBytes);
      expect(body, contains('name="file"'));
      expect(body, contains('化验单内容'));
    });
  });
}
