import 'dart:async';
import 'dart:convert';

import 'package:family_health/core/edge/edge_asr_client.dart';
import 'package:flutter_test/flutter_test.dart';

class FakeEdgeAsrSocket implements EdgeAsrSocket {
  final StreamController<Object?> controller = StreamController<Object?>();
  final List<Object?> sent = [];
  bool closed = false;

  @override
  Stream<Object?> get stream => controller.stream;

  @override
  void add(Object? data) => sent.add(data);

  @override
  Future<void> close() async {
    closed = true;
    await controller.close();
  }

  void emit(Map<String, Object?> message) =>
      controller.add(jsonEncode(message));
}

void main() {
  test('rejects insecure ASR transport by default', () {
    expect(
      () => EdgeAsrClient(
        endpoint: Uri.parse('http://192.168.1.9:18100'),
        bearerToken: 'token',
        memberId: 'member-1',
      ),
      throwsArgumentError,
    );
  });

  test('opens authenticated WSS stream with the frozen audio format', () async {
    final socket = FakeEdgeAsrSocket();
    late Uri capturedUri;
    late Map<String, dynamic> capturedHeaders;
    final client = EdgeAsrClient(
      endpoint: Uri.parse('https://edge.local/base'),
      bearerToken: 'token',
      memberId: 'member-1',
      connector: (uri, headers) async {
        capturedUri = uri;
        capturedHeaders = headers;
        return socket;
      },
    );

    final session = await client.startSession();

    expect(capturedUri.toString(), 'wss://edge.local/base/v1/asr/stream');
    expect(capturedHeaders['Authorization'], 'Bearer token');
    expect(capturedHeaders['X-Edge-Member-Id'], 'member-1');
    final start =
        jsonDecode(socket.sent.single as String) as Map<String, dynamic>;
    expect(start, {
      'type': 'start',
      'sample_rate_hz': 16000,
      'channels': 1,
      'sample_format': 's16le',
    });
    expect(session.state, EdgeAsrSessionState.starting);
    await session.cancel();
  });

  test('streams even PCM and exposes final result only as pending confirmation',
      () async {
    final socket = FakeEdgeAsrSocket();
    final client = EdgeAsrClient(
      endpoint: Uri.parse('http://127.0.0.1:18100'),
      bearerToken: 'engineering-token',
      memberId: 'member-1',
      allowInsecureTransportForEngineering: true,
      connector: (_, __) async => socket,
    );
    final session = await client.startSession();
    final events = <EdgeAsrEvent>[];
    final errors = <Object>[];
    session.events.listen(events.add, onError: errors.add);

    final started = session.waitUntilStreaming();
    socket.emit({'type': 'started', 'raw_audio_persisted': false});
    await started;
    session.addPcm([0, 0, 1, 0]);
    socket.emit({'type': 'partial', 'text': '血压'});
    await pumpEventQueue();
    final finalFuture = session.stopAndWait();
    socket.emit({
      'type': 'final_pending_confirmation',
      'task': {'task_id': '0123456789abcdef0123456789abcdef'},
      'result': {
        'text': '血压一百二十',
        'fields': {'systolic': 120},
      },
      'raw_audio_persisted': false,
    });
    final finalEvent = await finalFuture;

    expect(socket.sent[1], [0, 0, 1, 0]);
    expect(jsonDecode(socket.sent[2] as String), {'type': 'stop'});
    expect(events.map((event) => event.type), [
      'started',
      'partial',
      'final_pending_confirmation',
    ]);
    expect(events.last.taskId, '0123456789abcdef0123456789abcdef');
    expect(finalEvent.taskId, '0123456789abcdef0123456789abcdef');
    expect(session.state, EdgeAsrSessionState.awaitingConfirmation);
    expect(errors, isEmpty);
    await socket.controller.close();
  });

  test('rejects odd PCM chunks before they leave the phone', () async {
    final socket = FakeEdgeAsrSocket();
    final client = EdgeAsrClient(
      endpoint: Uri.parse('https://edge.local'),
      bearerToken: 'token',
      memberId: 'member-1',
      connector: (_, __) async => socket,
    );
    final session = await client.startSession();
    socket.emit({'type': 'started', 'raw_audio_persisted': false});
    await pumpEventQueue();

    expect(() => session.addPcm([0]), throwsArgumentError);
    await session.cancel();
  });

  test('fails closed when final response claims raw audio persistence',
      () async {
    final socket = FakeEdgeAsrSocket();
    final client = EdgeAsrClient(
      endpoint: Uri.parse('https://edge.local'),
      bearerToken: 'token',
      memberId: 'member-1',
      connector: (_, __) async => socket,
    );
    final session = await client.startSession();
    final errors = <Object>[];
    session.events.listen((_) {}, onError: errors.add);
    socket.emit({'type': 'started', 'raw_audio_persisted': false});
    await pumpEventQueue();
    session.stop();
    socket.emit({
      'type': 'final_pending_confirmation',
      'task': {'task_id': '0123456789abcdef0123456789abcdef'},
      'result': {'text': '内容'},
      'raw_audio_persisted': true,
    });
    await pumpEventQueue();

    expect(session.state, EdgeAsrSessionState.failed);
    expect(errors.single, isA<EdgeAsrException>());
    expect(socket.closed, isTrue);
  });
}
