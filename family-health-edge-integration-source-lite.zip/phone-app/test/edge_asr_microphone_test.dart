import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:family_health/core/edge/edge_asr_client.dart';
import 'package:family_health/core/edge/edge_asr_microphone.dart';
import 'package:flutter_test/flutter_test.dart';

class _FakeSocket implements EdgeAsrSocket {
  final controller = StreamController<Object?>();
  final sent = <Object?>[];

  @override
  Stream<Object?> get stream => controller.stream;

  @override
  void add(Object? data) => sent.add(data);

  @override
  Future<void> close() => controller.close();

  void emit(Map<String, Object?> value) => controller.add(jsonEncode(value));
}

class _FakeSource implements EdgePcmSource {
  final controller = StreamController<Uint8List>.broadcast();
  Object? startError;

  @override
  Future<Stream<Uint8List>> start() async {
    final error = startError;
    if (error != null) throw error;
    return controller.stream;
  }

  void add(List<int> bytes) => controller.add(Uint8List.fromList(bytes));

  @override
  Future<void> stop() => controller.close();

  @override
  Future<void> cancel() async {
    if (!controller.isClosed) await controller.close();
  }

  @override
  Future<void> dispose() async {
    if (!controller.isClosed) await controller.close();
  }
}

void main() {
  test('streams normalized PCM16 and waits for pending confirmation', () async {
    final socket = _FakeSocket();
    final source = _FakeSource();
    final partials = <String>[];
    final client = EdgeAsrClient(
      endpoint: Uri.parse('https://edge.local'),
      bearerToken: 'token',
      memberId: 'member-1',
      connector: (_, __) async => socket,
    );
    final controller = EdgeAsrMicrophoneController(
      client: client,
      source: source,
      onPartial: partials.add,
    );

    final start = controller.start();
    await pumpEventQueue();
    socket.emit({'type': 'started', 'raw_audio_persisted': false});
    await start;
    source.add([0]);
    source.add([0, 1, 0]);
    socket.emit({'type': 'partial', 'text': '心率'});
    await pumpEventQueue();

    final stop = controller.stop();
    await pumpEventQueue();
    socket.emit({
      'type': 'final_pending_confirmation',
      'task': {'task_id': '0123456789abcdef0123456789abcdef'},
      'result': {'text': '心率七十二', 'fields': <String, Object?>{}},
      'raw_audio_persisted': false,
    });
    final result = await stop;

    expect(socket.sent[1], [0, 0, 1, 0]);
    expect(partials, ['心率']);
    expect(result.taskId, '0123456789abcdef0123456789abcdef');
    expect(controller.isRecording, isFalse);
    await socket.controller.close();
    await controller.dispose();
  });

  test('audio start failure cancels the edge session', () async {
    final socket = _FakeSocket();
    final source = _FakeSource()
      ..startError = const EdgeAsrException('MIC_PERMISSION_DENIED', 'denied');
    final client = EdgeAsrClient(
      endpoint: Uri.parse('https://edge.local'),
      bearerToken: 'token',
      memberId: 'member-1',
      connector: (_, __) async => socket,
    );
    final controller = EdgeAsrMicrophoneController(
      client: client,
      source: source,
    );

    final start = controller.start();
    await pumpEventQueue();
    socket.emit({'type': 'started', 'raw_audio_persisted': false});
    await expectLater(start, throwsA(isA<EdgeAsrException>()));
    expect(socket.sent.last, isA<String>());
    expect(jsonDecode(socket.sent.last as String), {'type': 'cancel'});
    await controller.dispose();
  });
}
