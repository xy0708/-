import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:family_health/providers/settings_provider.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('默认跟随系统', () {
    SharedPreferences.setMockInitialValues({});
    final provider = SettingsProvider();
    expect(provider.themeMode, ThemeMode.system);
  });

  test('设置深色模式并持久化', () async {
    SharedPreferences.setMockInitialValues({});
    final provider = SettingsProvider();
    await provider.load();
    await provider.setThemeMode(ThemeMode.dark);
    expect(provider.themeMode, ThemeMode.dark);

    // 新实例读取同一持久化数据
    final restored = SettingsProvider();
    await restored.load();
    expect(restored.themeMode, ThemeMode.dark);
  });

  test('未知存储值回退跟随系统', () async {
    SharedPreferences.setMockInitialValues({
      'app_settings': '{"themeMode": "unknown"}',
    });
    final provider = SettingsProvider();
    await provider.load();
    expect(provider.themeMode, ThemeMode.system);
  });

  test('往返切换浅色→深色→跟随系统', () async {
    SharedPreferences.setMockInitialValues({});
    final provider = SettingsProvider();
    await provider.load();
    await provider.setThemeMode(ThemeMode.light);
    expect(provider.themeMode, ThemeMode.light);
    await provider.setThemeMode(ThemeMode.dark);
    expect(provider.themeMode, ThemeMode.dark);
    await provider.setThemeMode(ThemeMode.system);
    expect(provider.themeMode, ThemeMode.system);
  });
}
