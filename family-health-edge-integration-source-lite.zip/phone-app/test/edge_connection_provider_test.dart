import 'package:family_health/providers/edge_connection_provider.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('stores an edge session only after member-scoped version verification',
      () async {
    late Uri capturedEndpoint;
    late String capturedToken;
    late String capturedMember;
    final provider = EdgeConnectionProvider(
      versionProbe: (endpoint, token, member, allowInsecure) async {
        capturedEndpoint = endpoint;
        capturedToken = token;
        capturedMember = member;
        expect(allowInsecure, isFalse);
        return {
          'status': 'success',
          'result': {'contract_version': '1.0.0', 'product_complete': false},
        };
      },
    );

    final verified = await provider.configureAndVerify(
      endpoint: 'https://edge.local:18100',
      bearerToken: 'runtime-token',
      memberId: 'member-1',
    );

    expect(verified, isTrue);
    expect(provider.isConfigured, isTrue);
    expect(capturedEndpoint.toString(), 'https://edge.local:18100');
    expect(capturedToken, 'runtime-token');
    expect(capturedMember, 'member-1');
    expect(provider.memberId, 'member-1');
    expect(provider.version?['product_complete'], isFalse);
    expect(() => provider.createHttpClient('member-2'), throwsStateError);
    expect(() => provider.createAsrClient('member-2'), throwsStateError);
    provider.disconnect();
    expect(provider.isConfigured, isFalse);
    expect(provider.memberId, isNull);
  });

  test('failed verification clears endpoint and token instead of falling back',
      () async {
    final provider = EdgeConnectionProvider(
      versionProbe: (_, __, ___, ____) async => {
        'status': 'error',
        'result': null,
      },
    );

    final verified = await provider.configureAndVerify(
      endpoint: 'https://edge.local',
      bearerToken: 'bad-token',
      memberId: 'member-1',
    );

    expect(verified, isFalse);
    expect(provider.isConfigured, isFalse);
    expect(provider.lastError, contains('RESPONSE_INVALID'));
    expect(() => provider.createHttpClient('member-1'), throwsStateError);
    expect(() => provider.createAsrClient('member-1'), throwsStateError);
  });
}
