import 'package:family_health/core/config/app_config.dart';
import 'package:family_health/core/watch/watch_gateway.dart';
import 'package:family_health/models/device.dart';
import 'package:family_health/providers/device_provider.dart';
import 'package:flutter_test/flutter_test.dart';

class RecordingWatchGateway implements WatchGateway {
  int scans = 0;
  int connections = 0;
  int disconnections = 0;

  @override
  Future<List<HealthDevice>> scan({
    Duration timeout = const Duration(seconds: 10),
  }) async {
    scans += 1;
    return [
      HealthDevice(
        id: 'watch-1',
        name: 'Test watch',
        type: DeviceType.bracelet,
        batteryLevel: 73,
      ),
    ];
  }

  @override
  Future<HealthDevice> connect(HealthDevice device) async {
    connections += 1;
    return device.copyWith(isConnected: true);
  }

  @override
  Future<HealthDevice> disconnect(HealthDevice device) async {
    disconnections += 1;
    return device.copyWith(isConnected: false);
  }

  @override
  void dispose() {}
}

void main() {
  test('default phone app does not pretend a watch is connected', () async {
    final provider = DeviceProvider();

    await provider.scanDevices();

    expect(provider.devices, isEmpty);
    expect(provider.lastError, contains('真实手表 SDK 尚未接入'));
    provider.dispose();
  });

  test(
    'watch scan remains phone-local even when backend mode is enabled',
    () async {
      AppConfig.useBackend = true;
      final gateway = RecordingWatchGateway();
      final provider = DeviceProvider(watchGateway: gateway);

      await provider.scanDevices();

      expect(gateway.scans, 1);
      expect(provider.devices.single.id, 'watch-1');
      expect(provider.lastError, isNull);
      provider.dispose();
      AppConfig.useBackend = false;
    },
  );

  test('connection intent is delegated to the watch gateway', () async {
    final gateway = RecordingWatchGateway();
    final provider = DeviceProvider(watchGateway: gateway);
    await provider.scanDevices();

    await provider.setConnection('watch-1', true);
    expect(gateway.connections, 1);
    expect(provider.devices.single.isConnected, isTrue);

    await provider.setConnection('watch-1', false);
    expect(gateway.disconnections, 1);
    expect(provider.devices.single.isConnected, isFalse);
    provider.dispose();
  });
}
