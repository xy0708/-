import 'dart:convert';

import 'package:family_health/core/edge/edge_client.dart';
import 'package:family_health/core/watch/wearable_measurement.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

void main() {
  const taskId = '0123456789abcdef0123456789abcdef';

  test('rejects cleartext edge transport by default', () {
    expect(
      () => EdgeClient(
        endpoint: Uri.parse('http://192.168.1.10:18100'),
        bearerToken: 'token',
        memberId: 'member-1',
      ),
      throwsArgumentError,
    );
  });

  test(
    'sends member-scoped confirmed heart rate to the v1 edge contract',
    () async {
      late http.Request captured;
      final client = EdgeClient(
        endpoint: Uri.parse('http://127.0.0.1:18100'),
        bearerToken: 'engineering-token',
        memberId: 'member-1',
        allowInsecureTransportForEngineering: true,
        httpClient: MockClient((request) async {
          captured = request;
          return http.Response(
            jsonEncode({
              'status': 'success',
              'request_id': 'request-1',
              'result': {'scope': 'NON_DIAGNOSTIC_HEALTH_MANAGEMENT'},
            }),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }),
      );
      final measurement = WearableMeasurement(
        recordId: 'record-1',
        memberId: 'member-1',
        deviceId: 'watch-1',
        metric: WearableMetric.heartRate,
        value: 72,
        unit: 'bpm',
        capturedAt: DateTime.utc(2026, 10, 13, 12),
        source: YuchengMeasurementNormalizer.source,
        quality: MeasurementQuality.valid,
      );

      final response = await client.evaluateConfirmedMeasurement(measurement);

      expect(captured.url.path, '/v1/health/evaluate');
      expect(captured.headers['authorization'], 'Bearer engineering-token');
      expect(captured.headers['x-edge-member-id'], 'member-1');
      final requestBody = jsonDecode(captured.body) as Map<String, dynamic>;
      expect(requestBody['confirmed'], isTrue);
      expect(requestBody['measurements'][0]['metric'], 'heart_rate');
      expect(response['status'], 'success');
      client.close();
    },
  );

  test(
    'does not silently send unsupported watch fields to health rules v1',
    () async {
      final client = EdgeClient(
        endpoint: Uri.parse('https://edge.local'),
        bearerToken: 'token',
        memberId: 'member-1',
        httpClient: MockClient((_) async => http.Response('{}', 200)),
      );
      final measurement = WearableMeasurement(
        recordId: 'record-1',
        memberId: 'member-1',
        deviceId: 'watch-1',
        metric: WearableMetric.steps,
        value: 1000,
        unit: 'count',
        capturedAt: DateTime.utc(2026, 10, 13, 12),
        source: YuchengMeasurementNormalizer.source,
        quality: MeasurementQuality.valid,
      );

      await expectLater(
        client.evaluateConfirmedMeasurement(measurement),
        throwsUnsupportedError,
      );
      client.close();
    },
  );

  test('creates member-scoped OCR task with hash and no multipart upload',
      () async {
    late http.Request captured;
    final client = EdgeClient(
      endpoint: Uri.parse('https://edge.local'),
      bearerToken: 'token',
      memberId: 'member-1',
      httpClient: MockClient((request) async {
        captured = request;
        return http.Response(
          jsonEncode({
            'status': 'success',
            'task_id': taskId,
            'requires_confirmation': true,
            'result': {
              'task_id': taskId,
              'status': 'pending_confirmation',
            },
          }),
          202,
        );
      }),
    );
    final png = <int>[
      137,
      80,
      78,
      71,
      13,
      10,
      26,
      10,
      0,
      0,
      0,
      13,
      73,
      72,
      68,
      82,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      1,
    ];

    final response = await client.createOcrTask(
      imageBytes: png,
      mediaType: 'image/png',
    );

    expect(captured.method, 'POST');
    expect(captured.url.path, '/v1/ocr/tasks');
    expect(captured.headers['content-type'], 'application/json');
    final body = jsonDecode(captured.body) as Map<String, dynamic>;
    expect(body['member_id'], 'member-1');
    expect(body['image']['media_type'], 'image/png');
    expect(body['image']['data_base64'], base64Encode(png));
    expect(body['image']['sha256'], hasLength(64));
    expect(response['requires_confirmation'], isTrue);
    client.close();
  });

  test('rejects OCR bytes whose signature does not match the declared type',
      () async {
    final client = EdgeClient(
      endpoint: Uri.parse('https://edge.local'),
      bearerToken: 'token',
      memberId: 'member-1',
      httpClient: MockClient((_) async => http.Response('{}', 200)),
    );

    expect(
      () => client.createOcrTask(
        imageBytes: const [1, 2, 3, 4],
        mediaType: 'image/jpeg',
      ),
      throwsArgumentError,
    );
    client.close();
  });

  test('queries, confirms, and cancels a task using the frozen v1 paths',
      () async {
    final requests = <http.Request>[];
    final client = EdgeClient(
      endpoint: Uri.parse('https://edge.local/base'),
      bearerToken: 'token',
      memberId: 'member-1',
      httpClient: MockClient((request) async {
        requests.add(request);
        return http.Response(
          jsonEncode({'status': 'success', 'result': <String, Object?>{}}),
          200,
        );
      }),
    );

    await client.getTask(taskId);
    await client.confirmTask(
      taskId: taskId,
      idempotencyKey: 'phone-confirm-1',
      confirmedFields: {'heart_rate': 72},
    );
    await client.cancelTask(taskId);

    expect(requests[0].method, 'GET');
    expect(requests[0].url.path, '/base/v1/tasks/$taskId');
    expect(requests[1].method, 'POST');
    expect(requests[1].url.path, '/base/v1/records/confirm');
    final confirmBody = jsonDecode(requests[1].body) as Map<String, dynamic>;
    expect(confirmBody['member_id'], 'member-1');
    expect(confirmBody['idempotency_key'], 'phone-confirm-1');
    expect(requests[2].method, 'DELETE');
    expect(requests[2].url.path, '/base/v1/tasks/$taskId');
    client.close();
  });
}
