import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:family_health/core/config/app_config.dart';
import 'package:family_health/core/network/api_client.dart';
import 'package:family_health/providers/health_provider.dart';
import 'package:family_health/providers/auth_provider.dart';

http.Response _jsonResponse(String body, int status) =>
    http.Response.bytes(utf8.encode(body), status);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  tearDown(() {
    AppConfig.useBackend = false;
    AppConfig.allowDemoData = false;
    ApiClient.overrideForTesting = null;
  });

  group('后端模式（useBackend=true）下的数据加载', () {
    setUp(() {
      AppConfig.useBackend = true;
    });

    test('HealthProvider 成功调用健康总览接口', () async {
      ApiClient.overrideForTesting = ApiClient.forTesting(
        MockClient((request) async {
          expect(request.url.path, '/api/health/summary');
          expect(request.url.queryParameters['memberId'], 'm1');
          return _jsonResponse(
            '{"todaySteps":8888,"todaySleep":7.2,"currentHeartRate":70,'
            '"todayActivity":0.66,"healthStatus":"良好"}',
            200,
          );
        }),
      );
      final provider = HealthProvider();
      await provider.fetchSummary(memberId: 'm1', age: 35);
      expect(provider.summary!.todaySteps, 8888);
      expect(provider.summary!.healthStatus, '良好');
    });

    test('HealthProvider 成功调用历史趋势接口', () async {
      ApiClient.overrideForTesting = ApiClient.forTesting(
        MockClient((request) async {
          expect(request.url.path, '/api/health/trend');
          return _jsonResponse(
            '[{"steps":7000,"sleepHours":7.0,"heartRate":72,'
            '"activityLevel":0.6,"date":"2026-08-20T10:00:00.000"},'
            '{"steps":8000,"sleepHours":7.5,"heartRate":70,'
            '"activityLevel":0.65,"date":"2026-08-21T10:00:00.000"}]',
            200,
          );
        }),
      );
      final provider = HealthProvider();
      await provider.fetchRecords(memberId: 'm1', age: 35);
      expect(provider.records.length, 2);
      expect(provider.records.first.steps, 7000);
    });

    test('HealthProvider 仅在显式演示开关开启时回退本地 Mock', () async {
      AppConfig.allowDemoData = true;
      ApiClient.overrideForTesting = ApiClient.forTesting(
        MockClient(
          (request) async => throw http.ClientException('connection refused'),
        ),
      );
      final provider = HealthProvider();
      await provider.fetchSummary(memberId: 'm1', age: 35);
      expect(provider.summary, isNotNull);
      expect(provider.summary!.todaySteps, greaterThan(0));
    });

    test('HealthProvider 正式模式网络失败时不伪造数据', () async {
      ApiClient.overrideForTesting = ApiClient.forTesting(
        MockClient(
          (request) async => throw http.ClientException('connection refused'),
        ),
      );
      final provider = HealthProvider();

      await expectLater(
        provider.fetchSummary(memberId: 'm1', age: 35),
        throwsA(isA<ApiException>()),
      );
      expect(provider.summary, isNull);
    });

    test('AuthProvider 绑定接口成功时使用后端 Token', () async {
      SharedPreferences.setMockInitialValues({});
      ApiClient.overrideForTesting = ApiClient.forTesting(
        MockClient((request) async {
          expect(request.url.path, '/api/devices/bind');
          return _jsonResponse('{"token":"server_token_123"}', 200);
        }),
      );
      final provider = AuthProvider();
      await provider.login('13800000000', '张三');
      expect(provider.isLoggedIn, isTrue);
      expect(provider.token, 'server_token_123');
    });

    test('AuthProvider 仅在显式演示开关开启时回退演示 Token', () async {
      AppConfig.allowDemoData = true;
      SharedPreferences.setMockInitialValues({});
      ApiClient.overrideForTesting = ApiClient.forTesting(
        MockClient((request) async => throw http.ClientException('refused')),
      );
      final provider = AuthProvider();
      await provider.login('13800000000', '张三');
      expect(provider.isLoggedIn, isTrue);
      expect(provider.token, startsWith('mock_token_'));
    });

    test('AuthProvider 正式模式绑定失败时不登录且不生成假 Token', () async {
      SharedPreferences.setMockInitialValues({});
      ApiClient.overrideForTesting = ApiClient.forTesting(
        MockClient((request) async => throw http.ClientException('refused')),
      );
      final provider = AuthProvider();

      await expectLater(
        provider.login('13800000000', '张三'),
        throwsA(isA<ApiException>()),
      );
      expect(provider.isLoggedIn, isFalse);
      expect(provider.token, isNull);
    });

    test('AuthProvider 正式模式清除历史演示 Token', () async {
      SharedPreferences.setMockInitialValues({
        'token': 'mock_token_old',
        'userName': '演示用户',
        'phone': '13800000000',
      });
      final provider = AuthProvider();

      await provider.init();

      expect(provider.isLoggedIn, isFalse);
      expect(provider.token, isNull);
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.containsKey('token'), isFalse);
    });
  });

  group('本地 Mock 模式（useBackend=false，默认）', () {
    setUp(() {
      AppConfig.allowDemoData = true;
    });
    test('HealthProvider 不走网络，直接生成 Mock 数据', () async {
      // 未配置 override，若误走网络会因无法连接而失败，此测试确保直接走 Mock
      final provider = HealthProvider();
      await provider.fetchSummary(memberId: 'm1', age: 35);
      expect(provider.summary, isNotNull);
      expect(provider.summary!.todaySteps, greaterThan(0));
    });
  });
}
