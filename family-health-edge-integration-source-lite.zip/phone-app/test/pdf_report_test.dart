import 'package:flutter_test/flutter_test.dart';
import 'package:family_health/core/pdf/report_pdf_exporter.dart';
import 'package:family_health/models/family_member.dart';
import 'package:family_health/models/health_alert.dart';
import 'package:family_health/models/health_record.dart';
import 'package:family_health/models/health_report.dart';
import 'package:family_health/models/medical_history_entry.dart';
import 'package:family_health/models/reminder.dart';

FamilyMember _member({
  String id = 'm1',
  String name = '张爷爷',
  String relation = '父亲',
  int age = 65,
  String gender = '男',
  String? medicalHistory = '高血压',
}) {
  return FamilyMember(
    id: id,
    name: name,
    relation: relation,
    age: age,
    gender: gender,
    medicalHistory: medicalHistory,
    hasDevice: true,
  );
}

List<HealthRecord> _records({int days = 7, int stepBase = 7000}) {
  return List.generate(days, (i) {
    return HealthRecord(
      steps: stepBase + i * 350,
      sleepHours: 6.0 + i * 0.2,
      heartRate: 68 + i,
      activityLevel: 0.45 + i * 0.03,
      date: DateTime(2026, 9, 13 + i),
    );
  });
}

HealthReport _report({
  List<HealthRecord>? records,
  List<ReportDimension>? dimensions,
  List<String>? suggestions,
  HealthSummary? vital,
  String? memberId = 'm1',
  String summary = '本周「睡眠」偏弱，「脉搏」表现良好，整体较健康。',
}) {
  final recs = records ?? _records();
  return HealthReport(
    id: 'rpt_1757668800000',
    memberName: '张爷爷',
    memberId: memberId,
    generatedAt: DateTime(2026, 9, 19, 20, 30),
    type: '周度评估',
    summary: summary,
    overallScore: 71.3,
    suggestions: suggestions ??
        const [
          '睡眠时长略短，建议保证每晚7小时以上，睡前减少电子屏幕使用。',
          '日常活动量偏低，建议每天安排30分钟中等强度运动。',
        ],
    dimensions: dimensions ??
        [
          ReportDimension(name: '步数', score: 80, level: '良', suggestion: '建议提升至8000步。'),
          ReportDimension(name: '睡眠', score: 65, level: '一般', suggestion: '建议保证7小时。'),
          ReportDimension(name: '脉搏', score: 85, level: '良', suggestion: '保持定期监测。'),
          ReportDimension(name: '活动度', score: 55, level: '差', suggestion: '从散步开始。'),
        ],
    records: recs,
    vitalSummary: vital ??
        HealthSummary(
          todaySteps: 9100,
          todaySleep: 7.2,
          currentHeartRate: 74,
          todayActivity: 0.63,
          healthStatus: '良好',
        ),
    periodStart: recs.isEmpty ? null : recs.first.date,
    periodEnd: recs.isEmpty ? null : recs.last.date,
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('ReportPdfExporter 报告渲染', () {
    test('带完整数据的报告能渲染成多页 PDF', () async {
      final doc = await ReportPdfExporter.buildDocument(
        report: _report(),
        member: _member(),
        alerts: [
          HealthAlert(
            id: 'a1',
            memberId: 'm1',
            memberName: '张爷爷',
            level: AlertLevel.warning,
            title: '睡眠不足',
            content: '近7天平均睡眠 6.3 小时，建议调整作息。',
            createdAt: DateTime(2026, 9, 19, 8),
          ),
        ],
        reminders: [
          const Reminder(id: 'r1', type: ReminderType.medicine, customTitle: '降压药', hour: 8, minute: 0),
          const Reminder(id: 'r2', type: ReminderType.bloodPressure, hour: 20, minute: 30),
        ],
        medicalHistory: const [
          MedicalHistoryEntry(id: 'h1', name: '高血压', diagnosedAt: '2020-05', note: '长期服药控制'),
        ],
        familyMembers: [
          _member(),
          _member(id: 'm2', name: '张奶奶', relation: '母亲', age: 62, gender: '女', medicalHistory: '糖尿病'),
        ],
      );

      // 报告主动分页两次，至少应产出 3 页；
      // 同时给页数设上限，防止布局高度算错时无限翻页（曾经踩过：
      // pdf 包对「四边不等宽边框 + 圆角」会算错高度，直到 maxPages 抛异常）。
      final pages = doc.document.pdfPageList.pages.length;
      expect(pages, greaterThanOrEqualTo(3));
      expect(pages, lessThanOrEqualTo(6));

      final bytes = await doc.save();
      expect(bytes.length, greaterThan(20000));
    });

    test('没有任何数据时仍能渲染，不抛异常', () async {
      final doc = await ReportPdfExporter.buildDocument(
        report: HealthReport(
          id: 'rpt_empty',
          memberName: '本人',
          generatedAt: DateTime(2026, 9, 19, 9),
          type: '周度评估',
          summary: '暂无足够数据完成评估。',
          overallScore: 0,
          suggestions: const [],
        ),
      );

      final bytes = await doc.save();
      expect(bytes.length, greaterThan(10000));
    });

    test('仅有单条记录时跳过趋势图而不是除以零', () async {
      final doc = await ReportPdfExporter.buildDocument(
        report: _report(records: _records(days: 1)),
        member: _member(),
      );

      final bytes = await doc.save();
      expect(bytes.length, greaterThan(10000));
    });

    test('超长摘要与大量建议不会溢出失败', () async {
      final longText = '健康建议内容' * 120;
      final doc = await ReportPdfExporter.buildDocument(
        report: _report(
          summary: longText,
          suggestions: List.generate(25, (i) => '第${i + 1}条建议：$longText'),
        ),
        member: _member(),
      );

      final bytes = await doc.save();
      expect(bytes.length, greaterThan(20000));
    });

    test('中文字符与报告符号可正常绘制', () async {
      final doc = await ReportPdfExporter.buildDocument(
        report: _report(
          memberId: null,
          summary: '● 血压偏高 ▲ 需复查 ✓ 已记录 ℃ 体温正常 ≥ 60 次/分',
        ),
        member: _member(medicalHistory: null),
      );

      final bytes = await doc.save();
      expect(bytes.length, greaterThan(10000));
    });

    test('预警按成员过滤，不混入其他成员的预警', () async {
      final doc = await ReportPdfExporter.buildDocument(
        report: _report(),
        member: _member(),
        alerts: [
          HealthAlert(
            id: 'other',
            memberId: 'm9',
            memberName: '其他人',
            level: AlertLevel.danger,
            title: '他人预警标题',
            content: '这条不应该出现在张爷爷的报告里。',
            createdAt: DateTime(2026, 9, 19, 8),
          ),
        ],
      );

      final bytes = await doc.save();
      expect(bytes.length, greaterThan(10000));
    });
  });
}
