$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$partRoot = Join-Path $repoRoot 'handoff-assets\asr'
$target = Join-Path $repoRoot 'edge-runtime\android_app\assets\asr\x_asr_streaming\encoder.int8.onnx'
$expectedBytes = 155276576
$expectedSha256 = '017e3cf23097302dbc57ebd72cf4a209cf55c367920669e2d9ce9c0381a96ddd'
$expectedParts = @(
    @{ Name = 'encoder.int8.onnx.part-001'; Bytes = 47185920; Sha256 = 'c216d07494bf1d0d1d8a533cab44aaaeebee5e13b1ad5bfab863be3a232ddc60' }
    @{ Name = 'encoder.int8.onnx.part-002'; Bytes = 47185920; Sha256 = '8e83ba65d2530cddb2f21ccba094f8e96f9ed56c3d7955a45b352c774fc6ccdd' }
    @{ Name = 'encoder.int8.onnx.part-003'; Bytes = 47185920; Sha256 = 'bdbac558ae2bf8e36e81120e5473ce3d41b17981e9b94a8dbc5d2ac8d648ae57' }
    @{ Name = 'encoder.int8.onnx.part-004'; Bytes = 13718816; Sha256 = '266b52d1f161019bbc8c84d7246d6014440cf69ca316bef094c9e14517d97172' }
)

$targetDirectory = Split-Path -Parent $target
New-Item -ItemType Directory -Path $targetDirectory -Force | Out-Null
$temporary = "$target.partial"

$output = [System.IO.File]::Create($temporary)
try {
    foreach ($part in $expectedParts) {
        $path = Join-Path $partRoot $part.Name
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "Missing ASR model part: $($part.Name)"
        }
        $item = Get-Item -LiteralPath $path
        if ($item.Length -ne $part.Bytes) {
            throw "ASR model part size mismatch: $($part.Name)"
        }
        $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
        if ($hash -ne $part.Sha256) {
            throw "ASR model part hash mismatch: $($part.Name)"
        }
        $input = [System.IO.File]::OpenRead($path)
        try {
            $input.CopyTo($output)
        }
        finally {
            $input.Dispose()
        }
    }
}
finally {
    $output.Dispose()
}

$restored = Get-Item -LiteralPath $temporary
if ($restored.Length -ne $expectedBytes) {
    throw 'Restored ASR encoder size mismatch'
}
$restoredHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $temporary).Hash.ToLowerInvariant()
if ($restoredHash -ne $expectedSha256) {
    throw 'Restored ASR encoder hash mismatch'
}

Move-Item -LiteralPath $temporary -Destination $target -Force
Write-Output "ASR encoder restored and verified: $target"
