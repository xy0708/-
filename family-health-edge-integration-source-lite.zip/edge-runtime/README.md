# 家庭健康管理 Android 端侧上线工程

活动目标是 RK3566 Android / `arm64-v8a`。当前已完成 Android 产品壳、手表 SDK
工程接入、最小 BLE 权限、非诊断健康规则及离线 ASR 工程运行时打包；状态仍是
`PASS_ENGINEERING_PRODUCT_BLOCKED`，不是正式可销售版本。

## 当前边界

- 健康 V1 只输出非诊断规则、输入质量和个人趋势提示。
- OCR、ASR 和手表健康值未经用户确认不得写入正式健康档案。
- CHARLS 永久排除；NHANES、合成和研究数据不是中国上线性能证据。
- Linux systemd、ALSA、Unix Socket、ELF/PyInstaller 和 ARM64 容器报告只保留为
  历史基线，不代表 Android 通过。
- 手表插件内嵌二进制商业再分发权利尚未确认，当前 APK 仅为工程调试包。
- ASR 的 X-ASR 权重、`sherpa_onnx 1.13.7` arm64 原生库和许可证已打入 APK 并
  通过哈希审计；16 kHz PCM 麦克风采集、停止/取消和待确认文本链路已接入并通过
  本地测试，但尚无 Android/RK3566 实际推理指标。
- OCR 在 Android 产品树中仍是失败关闭的空后端，不能用旧 Linux 或电脑结果代替。

## 工程入口

```powershell
cd C:\Users\45277\Desktop\模型\端侧上线
.\.venv-edge\Scripts\python.exe scripts\run_android_migration_loop.py
```

也可双击 `start_android_migration_loop.bat`；该入口只执行审计 Loop，不会把调试
APK 或缺少真机证据的结果提升为正式 release。

需要重建 Flutter 工程证据时，以实际 Windows 用户权限执行：

```powershell
.\.venv-edge\Scripts\python.exe scripts\run_flutter_android_checks.py
```

开发板通过 USB 或网络 ADB 接入后执行：

```powershell
.\.venv-edge\Scripts\python.exe scripts\collect_android_preflight.py
```

## 关键文件

- `ANDROID_EDGE_PRODUCTION_LOOP.md`：活动 A00-A12 Loop。
- `configs/device_profile.json`：Android 目标与真机状态。
- `configs/product_delivery_contract.json`：Android 产品交付合同。
- `configs/wearable_sdk_source.json`：手表 SDK 来源、哈希与许可边界。
- `configs/android_runtime_registry.json`：三模型 Android 运行时的失败关闭登记。
- `android_app/`：Flutter/Android 产品壳与手表适配层。
- `reports/android_flutter_validation.json`：分析、测试、APK 与内容审计。
- `reports/android_migration_loop_latest.json`：最新可恢复 Loop 报告。
- `EDGE_PRODUCTION_LOOP.md`：只读 Linux 历史 Loop。

## 当前阻断

ADB 尚无设备；真实 Android 版本/API/指纹、手表连接、ASR 真机麦克风效果、OCR
Runtime、RKNPU/RKNN、性能/温度/长稳、release 签名、OTA 和许可均未完成。任何人不得把
调试 APK、电脑构建或聊天截图标记为真机/正式产品验收通过。
