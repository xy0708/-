# RK3576 Android 14 真机验收输入

当前状态：`BLOCKED_EXTERNAL`（ADB 无设备）

接入板子后，先执行只读采集并保存原始输出：

```powershell
adb devices -l
adb shell getprop ro.product.board
adb shell getprop ro.product.cpu.abi
adb shell getprop ro.build.version.release
adb shell getprop ro.build.version.sdk
adb shell getprop ro.build.version.security_patch
adb shell getprop ro.build.fingerprint
adb shell cat /proc/meminfo
adb shell df -h
```

还需由板卡厂商提供并核验：板卡 SKU、Android 镜像/补丁来源、系统签名策略、
RKNPU 驱动、Android RKNN Runtime、音频/相机 HAL、蓝牙芯片/固件、开机启动、
kiosk、应用升级和系统 OTA 机制。

真机 Gate 不能只验证“能连手表”。还必须覆盖：

- 冷启动、授权拒绝/撤回、扫描、连接、断连、重连和多设备冲突；
- 手表字段单位、时间、重复数据、缺失值、异常值和确认后写入；
- 健康/OCR/ASR 的真实 Android arm64 推理、内存、P50/P95、温度和长稳；
- 断电、应用进程被杀、存储不足、数据库损坏、模型损坏和升级回滚；
- 离线运行、日志脱敏、网络流量、备份关闭、成员隔离和删除撤回。

所有门槛必须在验收前冻结；报告绑定设备指纹、APK、模型、配置和输入 SHA-256。
