# Privacy-safe field diagnostics

Collect only:

- anonymized device ID, image/kernel/runtime versions, free disk/memory, temperature, service state, restart count;
- manifest/model/config SHA-256 values and component-ready/error codes;
- allow-listed operational event codes and timestamps;
- SQLite integrity result and encrypted database/backup sizes and hashes.

Do not collect raw reports, OCR full text, PCM/audio, transcripts, member IDs, tokens, health values, database contents, or private signing keys. Any exceptional collection requires an approved incident scope, minimum fields, encrypted transfer, named recipient, retention deadline, and deletion confirmation.
