# RK3566 bring-up and evidence collection

Status: tooling ready; no real device evidence exists yet.

## Required external inputs

- RK3566 ARM64 4 GB device and candidate Linux image;
- RKNPU driver, RKNN Runtime, capture/playback audio devices;
- maintenance SSH key and a separately verified `known_hosts` file;
- device alias, image owner, power-recovery method, and approved maintenance window.

## Secure remote preflight

1. Copy `configs/device_connection.example.json` outside the repository and fill the real host, maintenance user, identity path, known_hosts path, known_hosts SHA-256, and device alias. Do not store a private key in this project.
2. Independently verify the SSH host-key fingerprint before pinning `known_hosts`.
3. Run:

```powershell
.\.venv-edge\Scripts\python.exe scripts\collect_rk3566_preflight.py --connection C:\secure\rk3566-connection.json
```

The collector uses BatchMode, IdentitiesOnly, strict host-key checking, a pinned known_hosts file, one connection attempt, and timeouts. It streams the current preflight script through SSH and records script hash, known_hosts hash, stdout/stderr hashes and SSH exit code without recording the private-key path or credentials.

The on-device script only sets `hardware_measured=true` when it detects RK3566 + aarch64 and no virtualization hint. Passing additionally requires an NPU character device, hashed RKNN Runtime, capture/playback audio, systemd, flock, OpenSSL and synchronized time.

## Importing evidence

Only after `reports/rk3566_remote_preflight.json` reports `PASS_REAL_DEVICE_PREFLIGHT`:

```powershell
.\.venv-edge\Scripts\python.exe scripts\import_device_preflight.py --report reports\rk3566_remote_preflight.json
```

The importer pins the report hash, current script hash, known_hosts hash and measured runtime fields into `device_profile.json`. Editing device booleans manually cannot satisfy E10 because `run_device_acceptance.py` re-verifies the pinned report and hashes.

## Deployment order

1. Freeze image/kernel/driver/runtime versions and formal acceptance thresholds.
2. Build Sherpa ARM64 from a clean, exact Git commit with a hashed toolchain and disconnected dependencies.
3. Install ASR and validate file/ALSA streaming on the target microphone.
4. Convert and install the licensed OCR ONNX/RKNN artifacts using rights-cleared calibration data.
5. Provision encryption and release-verification keys through the approved device process.
6. Install a signed release, run fault/power-loss/privacy acceptance, then independent OCR/ASR acceptance.

Windows, WSL, QEMU, edited JSON, or synthetic inputs never count as real-device evidence.
