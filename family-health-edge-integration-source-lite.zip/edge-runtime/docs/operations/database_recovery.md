# SQLite recovery procedure

Status: engineering procedure; product use requires the approved encrypted codec and RK3566 recovery acceptance.

## Backup creation

1. Pre-create a dedicated backup root owned by the device service account; do not place it below a user-controlled upload directory.
2. Call `RecordStore.create_backup(destination, allowed_root=backup_root)` with a new, unique destination name. Existing destinations, path escapes, symlinks, and Windows junctions are refused.
3. The store writes a private temporary database, runs `PRAGMA integrity_check`, flushes it, and publishes it without overwriting an existing backup. A failed copy or verification does not publish a destination file.
4. Retain the resulting SHA-256, device identity, application version, database schema version, and backup time in the approved operations record. The backup remains sensitive even when the database codec is encrypted.

## Recovery

1. Stop `family-health-edge.service` and verify it is inactive.
2. Hash the selected encrypted backup and retain the hash in the incident record.
3. Run `scripts/recover_database.py` with explicit database, backup, hash, allowed root, and `--service-stopped-confirmed`.
4. The tool refuses symlinks/junctions in the database or backup path, path escapes, non-files, hash mismatch, corrupt backups, or live WAL/SHM sidecars. Redirect checks occur before canonicalization so links cannot be hidden by `resolve()`.
5. The previous database is retained as a randomly named `pre_restore` backup. Do not delete it until application-level record checks pass.
6. Restart the service, verify `/v1/health`, member isolation, record counts, and an idempotent confirmation retry.

This procedure must not be used to claim power-loss recovery until it passes on the real RK3566 filesystem and storage medium.
