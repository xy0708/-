# Signed offline release, upgrade, and rollback

Status: engineering implementation; real RK3566 acceptance and signing-key approval remain required.

- The device trusts a public key provisioned outside the release bundle.
- `manifest.json` enumerates every file other than itself and its detached signature.
- Candidate input JSON is exact-schema and frozen before packaging. The builder rejects duplicate or escaping destinations, backslashes, source or parent symlinks, mismatched source hashes, and files whose size/hash changes during copying. Release IDs must have alphanumeric endpoints; `.`/`..`, nested paths, hidden/option-like names, redirected collection roots, and symlink targets are rejected by build, promotion, install, rollback, and activation boundaries.
- `verify_release_bundle.py` rejects missing directories, symlinks, path traversal, extra files, size/hash mismatch, invalid rollback metadata, or invalid OpenSSL signature.
- `install_release.sh` serializes operations with `flock`, verifies before and after copying, keeps immutable version directories, atomically switches the `current` symlink, and restores the prior link if restart or strict product-health validation fails.
- `rollback_release.sh` re-verifies both current and target bundles, permits only the predecessor named by the current signed `rollback.json`, requires explicit database rollback compatibility, and restores the original link if strict product-health validation fails.
- Install and rollback write and fsync a pending-activation marker in the separate root-only `/var/lib/family-health-edge-update` boundary before changing `current`; the application service has no write access to it. `family-health-edge-recovery.service` validates owner/mode before restoring the verified prior release whenever activation was interrupted. The marker is cleared only after health success or a completed restoration.
- If power is lost after an immutable version directory lands but before activation is recorded, reinstall may resume only after both copies pass verification and their signed manifest and detached signature are byte-identical; any same-ID conflict fails closed.
- `check_release_health.py` waits only within a bounded startup deadline and rejects HTTP-200-but-degraded responses on every attempt. Activation requires product-complete state, product-secure storage, ready health rules with the non-diagnostic boundary intact, and ready OCR/ASR components on the loopback-only service.
- Database rollback is allowed only when `rollback.json` explicitly records `database_rollback_compatible=true`; this value requires migration review before signing.
- Installation rejects oversized or unsupported manifest/rollback metadata, unknown schema fields, non-object JSON, and non-exact manifest entry shapes before signature acceptance; runtime rollback applies the same exact rollback schema.

Private signing keys must never be present on the device or in this repository. The scripts do not prove RK3566 power-loss safety until the approved E10 scenarios pass on real storage.
