# 独立验收证据格式

正式验收只接收已获商业使用授权、来自独立验收集且非合成的材料。CHARLS 永久禁用；NHANES 和合成数据只能用于工程验证，不能进入正式验收或发布门禁。

## 前置审批

1. 数据负责人分别批准 OCR、ASR 验收数据权利，并提供实名、带时区的批准时间、证据文件和 SHA-256。
2. 隐私负责人批准去标识化和处理方案，同样提供实名审批证据。
3. 审批原件放入受控且不提交 Git 的 `evidence/approvals/`，再将相对路径、哈希和审批信息写入 `configs/product_gate_evidence.json`；不要填写占位符或虚构信息。审批时间不得晚于当前时间。
4. 将审批证据哈希写入输入清单的 `approval_bindings`。清单绑定值必须与审批登记完全一致。
5. 验收阈值须先实名批准并冻结；测试后改阈值会导致证据失效。

## 保管边界

- 原始体检报告、录音、标注和逐样本输出只能位于受控、加密、限权的验收介质，不提交 Git，不放入发布包。
- 每个输入文件必须登记 SHA-256。采集人员、许可依据、同意或授权记录、独立划分记录由数据负责人单独审计。
- 样本 ID 必须去标识化，输入与输出不得包含姓名、证件号、电话、地址、医院流水号等直接标识符。
- `EDGE_ACCEPTANCE_TOKEN` 只通过进程环境注入，不写入清单、命令历史、日志或报告。
- 客户端只访问 `127.0.0.1`。OCR/ASR 结果保持待确认状态，取得验收字段后立即取消任务，不写入正式健康记录。
- 程序会在首次模型调用前校验整批清单、格式、哈希和路径；任一错误都会拒绝整批执行。

## OCR 清单

从 `configs/ocr_acceptance_manifest.template.json` 复制后填写。顶层必须有：

- `rights_cleared: true`
- `synthetic: false`
- `independent_split: true`
- `direct_identifiers_removed: true`
- 非空 `cases`

每个正常样本必须提供 `sample_id`、相对路径、SHA-256、媒体类型、`should_reject: false` 和人工复核字段。拒绝样本必须提供 `should_reject: true`。正式 OCR 清单必须同时包含正常样本和拒绝样本。

```powershell
$env:EDGE_ACCEPTANCE_TOKEN = '<临时成员令牌>'
$env:EDGE_ACCEPTANCE_MEMBER_ID = 'acceptance-member'
python scripts/run_ocr_acceptance_client.py --manifest <OCR清单> --input-root <受控输入根目录> --output evidence/acceptance/ocr.jsonl
```

## ASR 清单

从 `configs/asr_acceptance_manifest.template.json` 复制后填写。音频必须为目标麦克风采集的真实人声、16 kHz、单声道、16-bit PCM WAV，单条不超过 120 秒；每个样本提供人工复核文本和非空 `expected_slots`。

```powershell
python scripts/run_asr_acceptance_client.py --manifest <ASR清单> --input-root <受控输入根目录> --output evidence/acceptance/asr.jsonl
```

输出文件必须是 `evidence/acceptance/` 下尚不存在的新文件；程序不会覆盖旧证据。

## 设备性能与汇总

- `performance.jsonl`：每行含 `latency_ms`、`peak_memory_mib`、`temperature_c`、`measured_on_real_rk3566: true`。
- `soak.json`：含 `duration_hours`、`unrecovered_crashes`、`memory_growth_mib`、`measured_on_real_rk3566: true`。
- `scenarios.json`：断电恢复、模型损坏、存储满、麦克风或摄像头不可用等合同场景均须为 `PASS`。
- 把五份证据的真实哈希、冻结合同哈希、真机预检哈希和审批绑定写入 `configs/acceptance_evidence.json`，再运行：

```powershell
python scripts/compute_acceptance_metrics.py --evidence configs/acceptance_evidence.json
```

禁止手工填写或改写计算指标。示例文件的所有 `false` 和 `REPLACE` 都是故意的失败安全占位，不能作为正式证据。
