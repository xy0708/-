# Security and privacy incident response

Status: engineering playbook; owners, contacts, notification deadlines, and legal obligations require named approval.

1. Classify: service outage, suspected unauthorized member access, device loss, model/package tamper, health-data disclosure, or unsafe health wording.
2. Contain: isolate network access, stop the affected component or full service, preserve the last verified release, and do not export raw reports/audio into tickets or chat.
3. Preserve evidence: copy privacy-safe event codes, release/model hashes, service status, device clock state, and encrypted database/backup hashes under an incident ID.
4. Eradicate/recover: verify signed release, rotate/revoke local credentials, restore only hash-verified databases, and perform member-isolation and confirmation-chain checks.
5. Notify/escalate: contact the named product, privacy, security, legal, and operations owners; legal determines affected-person and regulator notification duties and timing.
6. Close: record root cause, affected versions/devices, corrective tests, residual risk, and approval before returning to service.

Never diagnose a user from incident data, and never weaken audit/privacy controls to make recovery faster.
