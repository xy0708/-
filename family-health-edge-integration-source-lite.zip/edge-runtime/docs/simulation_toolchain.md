# 模拟验证工具链登记

日期：2026-09-06。仅研发主机，不进入产品运行包；正式产品 SBOM 不据此自动通过。

| 工具 | 本轮版本/来源 | 许可与范围 |
|---|---|---|
| WSL | Microsoft.WSL 2.7.13；微软官方 GitHub 发布，winget 校验 | MIT，具体分发组件保留原通知 |
| Docker Desktop | Docker.DockerDesktop 4.89.0；desktop.docker.com，winget 校验 | Docker Subscription Service Agreement；适用订阅由使用单位确认 |
| Docker CLI | 本机返回 29.7.2 | 随 Desktop 安装，未作为产品依赖 |
| Python ARM64 基础镜像 | python:3.12.10-slim-bookworm | 尚待实际拉取；每次先记录 digest，再固定摘要构建；Python/ Debian 组件许可与漏洞需按实际镜像审计 |
| QEMU | Docker Desktop 集成能力 | 待引擎就绪和 ARM64 程序执行验证，不声称已测到版本 |
| 本轮 Python 脚本 | 项目 `.venv-edge` | 只使用标准库，没有新增 pip 依赖 |

本机安装已修改系统软件和虚拟机平台功能，存在待重启状态；没有自动重启、安装Linux发行版或修改现有模型权重。

官方说明：[WSL](https://learn.microsoft.com/en-us/windows/wsl/install)、[Docker Desktop](https://docs.docker.com/desktop/setup/install/windows-install/)、[多平台/QEMU](https://docs.docker.com/build/building/multi-platform/)。
