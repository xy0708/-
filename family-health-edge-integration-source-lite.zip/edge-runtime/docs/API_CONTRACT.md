# 端侧统一接口契约 v1

状态：工程冻结候选；等待前端、后端、产品和安全负责人具名确认。

## 调用关系

```text
前端 -> 端侧设备服务 -> 健康规则/OCR/ASR -> 待确认结果 -> 用户确认 -> SQLite
```

前端不得直接依赖三个模型内部接口。设备服务只绑定 `127.0.0.1` 或 Unix Domain Socket。除 `/v1/health` 外，请求必须携带运行期生成的本地 Bearer token。

## HTTP 接口

| 方法 | 路径 | 用途 |
|---|---|---|
| GET | `/v1/health` | 进程与子模块状态，不返回健康数据 |
| GET | `/v1/version` | 二进制、规则、模型和契约版本 |
| POST | `/v1/health/evaluate` | 对已确认测量值生成非诊断健康提示 |
| POST | `/v1/ocr/tasks` | 创建本地 OCR 任务，返回待确认字段 |
| GET | `/v1/tasks/{task_id}` | 查询 OCR/ASR 任务状态 |
| DELETE | `/v1/tasks/{task_id}` | 取消并清理未确认任务 |
| POST | `/v1/records/confirm` | 用户确认后写入成员档案，要求幂等键 |
| GET | `/v1/members/{member_id}/records` | 查询该成员已确认记录 |
| DELETE | `/v1/members/{member_id}/records/{record_id}` | 删除成员记录 |

ASR 使用 `/v1/asr/stream` WebSocket：`start` -> PCM chunks -> `partial` -> `final_pending_confirmation` -> HTTP 确认。原始 PCM 默认不落盘。

## 通用响应

```json
{
  "status": "success",
  "request_id": "uuid",
  "task_id": null,
  "requires_confirmation": false,
  "contract_version": "1.0.0",
  "component_version": "0.2.0",
  "result": {},
  "warnings": [],
  "error": null
}
```

错误响应：

```json
{
  "status": "error",
  "request_id": "uuid",
  "requires_confirmation": false,
  "result": null,
  "warnings": [],
  "error": {
    "code": "INPUT_INVALID",
    "message": "输入不符合接口约束",
    "retryable": false
  }
}
```

## 确认规则

- OCR 和 ASR 的最终结构化结果固定为 `requires_confirmation=true`。
- `/v1/records/confirm` 必须包含 `member_id`、`task_id`、`idempotency_key` 和用户确认后的字段。
- 服务端必须验证任务属于当前本地会话、未过期、未取消且尚未确认。
- 相同 `idempotency_key` 重试不得产生重复记录。
- `idempotency_key` 的唯一性按成员隔离；不同成员使用相同客户端键不得互相阻断。schema 2 数据库在启动时原子迁移为 schema 3 并保留记录。
- 健康规则只读取已确认记录或由用户直接提交并明确标为已确认的输入。

## 版本策略

- 破坏兼容性的字段变化创建 `/v2`。
- `/v1/version` 返回接口、规则、模型、数据库 schema 和 release ID。
- 未知字段可忽略；缺少必填字段必须返回固定错误码。
- 模型加载失败不得改变响应结构，只改变组件状态和错误码。

## Privacy lifecycle additions

- Runtime bearer tokens are scoped to explicit member IDs; a token cannot read or mutate another member.
- `POST /v1/members/{member_id}/records/{record_id}/correct` applies a confirmed correction with `expected_version` conflict protection.
- `POST /v1/members/{member_id}/withdraw-consent` requires `confirmed=true` and deletes that member's local records and pending tasks.
- The records listing endpoint is the local export surface; it returns at most 100 records per page with `has_more` and an opaque `next_cursor`, and rejects duplicate, unknown, malformed, or over-limit query fields. Ordinary operational logs never contain the exported payload or cursor.
- Task cancellation and confirmed-record deletion are idempotent HTTP 200 operations; `result.deleted` is true only when that call changed state, so retrying after a lost response is safe.

## OCR and ASR transport limits

- OCR accepts a JSON `image` object containing `media_type`, strict `data_base64`, and optional lowercase SHA-256. Only PNG/JPEG up to 8 MiB are accepted; declared type, magic bytes, dimensions/markers, and hash are checked before the adapter runs.
- ASR uses RFC 6455 at `/v1/asr/stream`, authenticates the Bearer token plus `X-Edge-Member-Id`, requires masked client frames, and accepts only 16 kHz mono s16le audio for at most 120 seconds.
- The WebSocket endpoint requires an HTTP/1.1 `Connection: Upgrade` handshake and negotiates no extensions: reserved bits, fragmentation, unknown opcodes, noncanonical length encodings, unmasked client frames, oversized data frames, control frames above 125 bytes, and malformed close status/reason payloads are rejected before application handling. Frame reads tolerate valid transport short reads without accepting truncation.
- Raw images/audio and pending OCR/ASR results are memory-only. Pending results are detached JSON snapshots; one bounded background sweeper removes unobserved results at `expires_at`, while task lookup persists the expired state and returns `TASK_EXPIRED`. A service restart also intentionally expires pending tasks; only user-confirmed fields enter records.
- If delivery of an ASR final result is abandoned by the transport, the stream session immediately cancels its pending task; the bounded TTL sweeper remains the cleanup fallback if storage cancellation fails.

## Component compatibility and failure behavior

- `GET`/`DELETE /v1/tasks/{task_id}` must carry `X-Edge-Member-Id`; the temporary JSON-body fallback is deprecated and exists only for engineering compatibility.
- Every OCR/ASR adapter must report contract version, component version and required capabilities. A missing or incompatible handshake is rejected before inference.
- `/v1/health` returns HTTP 200 with `status=degraded` when one component is unavailable; it exposes only sanitized reason codes, never native exception text or health content.
- A local operational-log write failure never converts an already executed operation into a lost HTTP response. The logger emits only `EVENT_LOG_UNAVAILABLE`, and subsequent `/v1/health` responses stay degraded until a safe log write succeeds; product audit durability and tamper-resistance still require named approval and real-filesystem acceptance.
- Confirmed record payloads are bounded JSON objects (128 KiB, finite numbers, bounded depth/node count). Pending component results are capped at 256 KiB.
- Native OCR/ASR production runtimes must run in isolated processes with bounded timeouts, concurrency, restart backoff and circuit breaking. The shell-free JSON-lines supervisor enforces bounded messages, secret-environment filtering and fixed public failure codes. The existing ASR V2 engineering worker is loaded only when its release-relative runtime config, backend registry and explicit selection agree on backend identity, model hash, runtime and component contract; this path has passed simulated ARM64 loopback WebSocket integration. Blocked or unknown backends never fall back silently. No licensed OCR product worker is registered, ASR is not product-approved, and this evidence does not prove RK3566 hardware acceptance.
