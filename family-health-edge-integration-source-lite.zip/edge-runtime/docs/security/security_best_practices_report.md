# Security best-practices review

Status: `PASS_ENGINEERING_WITH_PRODUCT_BLOCKERS`  
Scope: Python standard-library loopback service, SQLite storage, OCR/ASR boundaries, and offline release tooling. No matching Python stdlib `http.server` reference existed in the installed security skill, so the review used its general secure-default guidance and repository evidence.

## Executive summary

No open critical defect was found in the current engineering paths. Product mode intentionally refuses to start because approved encryption/key management is absent. High-severity external controls—device identity, trusted key provisioning, native runtime supply chain, and real RK3566 hardening—remain unresolved, so this is not a product-security approval.

## High severity — open/product blocking

### SEC-001 — Encryption at rest and device-key lifecycle are not implemented

Impact: loss or theft of a device could expose sensitive health records if plaintext engineering storage were shipped.

Evidence: `storage/database.py:70` rejects a non-product codec; `device_service/server.py:265` blocks product mode. Required fix: approve an encrypted SQLite/field codec and device-bound key injection, rotation, backup recovery, revocation, and zeroization design, then validate on RK3566.

### SEC-002 — Final member identity and token rotation source is unconfirmed

Impact: a copied long-lived local token could authorize access to all members in that token's grant.

Evidence: member-scoped grants are enforced in `device_service/application.py:48`; secrets are loaded only from named environment variables at `device_service/application.py:81`. Required fix: owner must select App login/device binding, define issuance/expiry/rotation/revocation, and confirm no shared production wildcard token.

### SEC-003 — Trusted release-key provisioning and real update/rollback validation are absent

Impact: without a device-provisioned trusted public key and real power-loss testing, a malicious or interrupted update could execute untrusted code or leave the terminal unavailable.

Evidence: structural/hash/signature verification is implemented at `release_tools/bundle.py:74`; install and rollback now reject HTTP-200-but-degraded service health unless product completion, secure storage, non-diagnostic health rules, OCR and ASR are all ready. Installation remains blocked by unapproved signing configuration and E10. Required fix: provision the trusted public key outside bundles, protect its replacement path, externally sign manifests, and pass install/interruption/rollback tests on RK3566.

### SEC-004 — Native OCR/ASR runtime and model supply chain are not frozen

Impact: an unreviewed ARM64/RKNN library or parser could introduce code execution, model tampering, or unsafe resource behavior.

Evidence: OCR input limits begin at `ocr_runtime/input_validation.py:14`; ASR memory-only streaming begins at `asr_runtime/session.py:39`. The current ASR V2 engineering worker and hash-bound runtime bootstrap passed simulated ARM64 loopback integration, but neither ASR nor OCR is approved as a product adapter and OCR has no registered real worker. Required fix: freeze all native binaries/models with license, provenance, hashes, formal SBOM, current vulnerability scan, and target-device sandbox tests.

## Medium severity — open/product blocking

### SEC-005 — Operational-log tamper resistance is not validated

Allow-listed privacy-safe events are implemented at `operations/event_log.py:29`, but the service account can still modify its local log. Decide whether signed/forward-secure audit records are required and test retention, disk-full behavior, clock changes, and deletion on the real filesystem.

### SEC-006 — Only global concurrency limiting exists

The server is bounded at `device_service/server.py:38`, but per-token request quotas and ASR session quotas are not frozen. Define product workload limits, add member/token quotas if needed, and validate that health/status operations remain available under OCR/ASR load.

### SEC-007 — Final deployment exposure and debug-port policy are unconfirmed

The server refuses product operation today and binds loopback, but production image firewall, SSH, serial, ADB/debug services, service user permissions, and physical recovery policy need RK3566 evidence.

## Resolved engineering findings

- R-001: shared-token cross-member access replaced by explicit member grants (`device_service/application.py:48`).
- R-002: unconfirmed OCR/ASR output removed from SQLite and kept in volatile memory (`storage/database.py:79`, restart invalidation at `storage/database.py:189`).
- R-003: HTTP concurrency/body/time limits and bounded health inputs added (`device_service/server.py:38`, `health_rules/engine.py:212`).
- R-004: verified, path-confined, atomic database restore with previous-copy preservation added (`storage/recovery.py:31`).
- R-005: manifest coverage, path traversal, symlink, size/hash, rollback metadata, and detached-signature checks added (`release_tools/bundle.py:74`).
- R-006: privacy-safe operation codes support CREATE/READ/UPDATE/DELETE audit without member IDs or health content (`device_service/server.py:234`).

## Threat-model checkpoint

The final threat model remains `BLOCKED_EXTERNAL_CONTEXT_CONFIRMATION` until the owner confirms port exposure, member identity source, and whether cloud sync/remote operations are disabled. See `assumption_validation.md`.
