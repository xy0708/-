# Production debug-port policy checkpoint

Status: `BLOCKED_EXTERNAL_RK3566_IMAGE_REQUIRED`

- SSH is disabled by default or restricted to a device-specific key, maintenance mode, local service network, and expiry window.
- Password login, default passwords, root remote login, test accounts, and engineering wildcard tokens are forbidden.
- Serial/UART/ADB/JTAG exposure and bootloader access require a documented physical-service policy.
- Debug enable/disable events must be auditable without logging credentials or health data.
- Firewall evidence must prove port 18100 is loopback-only.
- Recovery access must not bypass signed release verification or encrypted-data controls.

These statements are acceptance requirements, not claims about the current device image.
