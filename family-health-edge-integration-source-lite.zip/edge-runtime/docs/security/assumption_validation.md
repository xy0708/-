# Security assumption validation checkpoint

Status: `BLOCKED_EXTERNAL_CONTEXT_CONFIRMATION`

The final repository threat model is intentionally not issued until the owner confirms:

1. V1 is strictly local and TCP port 18100 will never be exposed to LAN or internet.
2. Member permissions come from App login/device binding, or instead from a shared device token.
3. Cloud sync and remote operations are disabled for V1.

Current engineering defaults are loopback-only, cloud sync disabled, and member-scoped bearer grants. These are implementation assumptions, not owner approval.
