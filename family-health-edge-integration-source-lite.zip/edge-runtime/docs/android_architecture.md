# Android 端侧架构

状态：`ENGINEERING_MIGRATION / PRODUCT_BLOCKED`  
目标：RK3576 Android 14，`arm64-v8a`

## 活动边界

产品运行入口是安装在开发板上的 Android 应用或经厂商批准的系统应用，不再是
Linux systemd 服务。Flutter 负责产品界面和领域编排；Android/Kotlin 负责运行时
权限、进程生命周期、Keystore 和原生模型桥；C/C++/JNI 只承载必须的模型运行库。

```text
UI
 ↓
Application services
 ├─ WatchGateway ── vendor Flutter/Android SDK
 ├─ HealthGateway ─ rules + optional ONNX shadow
 ├─ OcrGateway ─── Camera/Image + ONNX/RKNN
 └─ AsrGateway ─── AudioRecord + ONNX/RKNN
 ↓
Pending confirmation store
 ↓ user confirms
Encrypted member repository
```

供应商 SDK、ONNX Runtime、RKNN Runtime 等细节不得泄漏到健康业务层。每个网关
返回稳定的本地领域对象、固定错误码、来源、单位、采集时间、模型/规则版本和确认
状态。UI 不直接持有 AAR 的对象，也不把 SDK `toString()` 写入日志。

## Linux 资产处置

- 保留：模型权重、字典、输入输出 schema、规则、测试向量、哈希和历史失败报告。
- 重做：进程启动、IPC、音频采集、相机输入、存储、密钥、升级、日志与真机测试。
- 归档：systemd、Linux Shell 安装器、ALSA、AArch64 PyInstaller 生命周期工具。
- 禁止：把 Linux/QEMU 的通过报告继承为 Android Gate。

## Android 生命周期

- 默认普通 APK；不得假设 root、平台签名、隐藏 API 或静默安装能力。
- 只有确需持续蓝牙/录音任务时才启用前台服务，并显示用户可见通知。
- 开机启动、kiosk、系统应用和签名 OTA 由板卡厂商镜像能力决定，未批准前阻断。
- Activity 重建、进程被杀、蓝牙关闭、权限撤回和存储不足必须可恢复且不重复入库。

## 安全与隐私

- `android:allowBackup=false`，默认禁止明文网络；当前手表阶段不申请互联网权限。
- Android 12+ 仅申请 BLE 扫描/连接；Android 11 及以下的扫描定位权限限定
  `maxSdkVersion=30`。
- 健康数据先进入有界内存待确认区；确认后才写成员隔离的加密仓库。
- 密钥由 Android Keystore 保护；APK、配置、模型和原生库必须绑定版本与哈希。
- release 禁止 debug key、开发路径、测试数据、缓存、日志和未登记二进制。

## 三模型迁移顺序

1. 非诊断健康规则迁入纯 Dart/Kotlin 并用旧冻结测试向量做行为对齐。
2. ASR 已接入 `sherpa_onnx 1.13.7` Android arm64 JNI、冻结 X-ASR 权重、私有目录
   哈希校验供应链和 16 kHz PCM 麦克风采集；下一步在 Android/RK3576 真机执行。
3. OCR 选择可商业分发的 Android ONNX/RKNN 路线，接入相机/文件输入。
4. 在同一 Android 应用内完成超时、取消、并发、资源回收和模块故障隔离。
5. 最后才在 RK3576 Android 14 真机做性能、温度、长稳、断电、升级与回滚验收。

## 当前事实

- Flutter 3.41.7、Dart 3.11.5、Java 21、Android SDK 35/36、Build Tools 与 NDK
  已在开发机识别。
- ADB 当前没有连接设备；Android 版本、API、指纹和 RKNPU/RKNN 均未核验。
- 手表插件源码已下载并哈希固定，但上游引用仍是可变 master，内嵌二进制许可未清。
- arm64 调试 APK 已包含离线 ASR 权重、Sherpa/ONNX 原生库和许可证，并通过包内
  SHA-256 校验；麦克风采集与待确认文本链路已接入并通过本地测试，但没有 Android
  实际推理或 RK3576 资源测量，不能标记为可用产品 ASR。
- OCR Android 后端尚不存在，继续失败关闭。
- 因此当前只能进入 Android 工程迁移，不能声明真机或产品上线完成。
