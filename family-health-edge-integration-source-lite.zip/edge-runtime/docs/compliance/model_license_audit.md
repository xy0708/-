# 模型与运行时许可审计

状态：工程盘点完成，产品法务结论未全部完成。

| 资产 | 当前工程材料 | 产品状态 |
|---|---|---|
| PP-OCRv5 代码仓库 | Apache-2.0 | 代码许可已识别 |
| PP-OCRv5 检测/识别权重 | 本地 manifest 标记待确认 | BLOCKED_EXTERNAL |
| X-ASR 模型 | Apache-2.0 工程审计 | 待最终分发包复核与具名结论 |
| Sherpa-ONNX | Apache-2.0 工程审计 | 待 ARM64 版本和分发包复核 |
| MeloTTS 资产 | MIT 工程审计 | 待最终分发包复核 |
| Rockchip RKNN Model Zoo 示例代码 | Apache-2.0，commit 与完整许可已冻结 | 工程候选；不自动覆盖衍生权重 |
| RKNN Toolkit2 / Lite2 | Rockchip RKNN SDK 自定义许可已冻结 | BLOCKED_EXTERNAL：限制条款须具名法务复核 |
| Rockchip PP-OCRv4 ONNX | Model Zoo、PaddleOCR release/2.7 来源及哈希已冻结 | BLOCKED_EXTERNAL：衍生权重与设备分发权待确认 |
| Rockchip Zipformer ONNX | Model Zoo 与上游模型卡 Apache-2.0 声明及哈希已冻结 | BLOCKED_EXTERNAL：训练数据/衍生分发链待确认 |
| Rockchip Whisper ONNX | Model Zoo 与 Whisper MIT 上游来源及哈希已冻结 | BLOCKED_EXTERNAL：衍生权重与依赖分发待确认 |

正式分发必须携带 `THIRD_PARTY_NOTICES`、许可证文本、版权声明、版本、来源 URL 和文件 SHA-256。任一模型、运行库或版本变化均重新触发审计。

R01 工程证据位于 `vendor/rockchip/model_zoo.lock.json` 和 `vendor/rockchip/THIRD_PARTY_NOTICES.md`。该证据只证明来源冻结和完整性，不是法务批准。
