# 数据集补充检索记录：第三轮（2026-09-23）

## 是否已经找尽

没有，也不能声称“全网找尽”。数据仓库、论文附件、医院受控库和供应商目录会持续新增或变更。当前达到的是阶段性检索饱和：已覆盖主要公开仓库、常见中文数据集目录、官方项目页和商业采购路线，并对新增高相关候选完成许可初筛。

## 本轮新增高相关候选

- Rich Healthcare 中国成人体检随访数据：211,833 人，32 个站点、11 个城市，包含糖尿病发生随访；Dryad 官方 API 元数据为 CC0-1.0。适合糖尿病工程基线，但原始伦理/授权是否覆盖商业端侧模型仍未确认。
- 杭州 SUA/CVD 风险因素队列：6,119 名 40 岁以上人群，多次体检，含血压、血糖、血脂、肾功能及高血压/高血糖/血脂异常标签；Dryad 元数据为 CC0-1.0。可做有限工程验证，不能替代全国目标人群独立测试。
- 四川高危卒中队列与北京社区心血管事件队列：分别补充 Stroke 和 Heart 的公开候选；均需字段、泄漏、伦理和产品目的审查。
- SUPPORT 中国心血管风险合成人口：覆盖中国大陆七大区域，Zenodo 元数据为 CC-BY-4.0。只可用于分布模拟和压力测试，不得生成真实临床准确率。
- ClinOCR-Bench：384 份 MIT 许可的合成临床扫描文档，包含表格、旋转、手写和劣化。可测 OCR 故障处理，但不是中文体检报告。
- MultiMed 中文医疗语音：Hugging Face 标为 MIT，论文却说明音频来自 YouTube、依据非商业 Fair Use，且中文内容主要来自新加坡和台湾。许可与上游权利冲突，暂停使用。

## 纠正

WenetSpeech 不再列为可用工程候选。OpenSLR 展示 CC-BY-4.0，但官方项目页明确写仅限非商业目的，并说明项目方不拥有原始音频版权。对商业产品应视为禁用，除非取得完整书面授权。

## 当前真正缺口

- 健康模型：缺少覆盖目标人群、四项任务标签统一、具备商业端侧衍生权重授权的正式训练数据和独立外部测试集。
- OCR：缺少商业授权的真实中文体检报告开发集，以及机构/模板/设备独立的密封验收集。
- ASR：缺少商业授权的中国大陆家庭健康指令、目标设备麦克风录音和说话人独立验收集。

## 一手来源

- Rich Healthcare / Dryad: https://datadryad.org/dataset/doi:10.5061/dryad.ft8750v
- SUA/CVD risk factors / Dryad: https://datadryad.org/dataset/doi:10.5061/dryad.z08kprrk1
- Sichuan high-risk stroke / Dryad: https://datadryad.org/dataset/doi:10.5061/dryad.bg79cnpfx
- Beijing hs-cTnT cardiovascular outcomes / Dryad: https://datadryad.org/dataset/doi:10.5061/dryad.bq0rm
- SUPPORT synthetic population / Zenodo: https://zenodo.org/records/18731087
- ClinOCR-Bench: https://github.com/ClinOCR-Bench/ClinOCR-Bench
- MultiMed dataset: https://huggingface.co/datasets/leduckhai/MultiMed
- MultiMed paper: https://arxiv.org/abs/2409.14074
- WenetSpeech official project page: https://wenet-e2e.github.io/WenetSpeech/
