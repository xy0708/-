# 数据集补充检索记录（2026-09-23）

## 结论

本轮没有发现一份可直接下载后同时满足“三模型正式产品训练或验收”的公开数据集。新增三份可用于 ASR 工程增强的普通话候选，并登记五条可购买、定制采集或通过可信数据空间合作的产品数据路线。任何候选在具名审批前均不得标记为产品数据。

## 新增公开 ASR 候选

| 候选 | 公开许可声明 | 可做什么 | 不能证明什么 |
|---|---|---|---|
| WenetSpeech / SLR121 | CC-BY-4.0 | 通用普通话预训练或鲁棒性实验 | 医疗语音、目标麦克风或产品验收 |
| AISHELL-4 / SLR111 | CC-BY-SA-4.0 | 多人、混响、重叠语音工程实验 | 医疗场景和目标设备准确率 |
| AliMeeting / SLR119 | CC-BY-SA-4.0 | 近场/远场会议语音工程实验 | 家庭健康指令和目标麦克风验收 |

上述许可允许的范围仍需由具名法务确认归因、相同方式共享、下载条款和上游权利链；因此当前仅登记，不下载、不训练、不形成产品胜者。

## 产品数据获取路线

- ASR：向有版权数据和定制采集能力的供应商采购“目标麦克风 + 普通话医疗/家庭健康指令 + 说话人独立验收集”。
- OCR：定制采集真实中国体检报告，要求患者与机构双重授权、不可逆脱敏、模板/机构/拍摄设备独立切分和字段双人复核。
- 健康模型：优先走医检可信数据空间或城市健康数据授权运营合作，在数据沙箱中完成训练与独立验证，并在合同中取得衍生模型部署权。

机器可读采购候选位于 `configs/commercial_data_acquisition_candidates.json`；公开候选位于 `configs/public_dataset_candidates.json`。

## 来源

- OpenSLR WenetSpeech: https://www.openslr.org/121/
- OpenSLR AISHELL-4: https://www.openslr.org/111/
- OpenSLR AliMeeting: https://www.openslr.org/119/
- DataTang OCR customization: https://www.datatang.com/ocr
- DataTang medical data services: https://www.datatang.com/health
- National Data Administration, KingMed trusted medical data space: https://www.nda.gov.cn/sjj/ywpd/sjzy/1121/20251121112240886245782_pc.html
- National Data Administration, Guangzhou health trusted data space: https://www.nda.gov.cn/sjj/ywpd/sjzy/0511/20260511210307345694514_pc.html
