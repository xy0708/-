# 数据集补充检索记录：第二轮（2026-09-23）

## 结论

本轮仍未找到可直接用于三个模型正式产品验收的单一公开数据集。没有下载、申请或训练任何新增数据；CHARLS 继续永久排除。

新增可立即进入许可审批的工程候选：

- ASR：Google FLEURS 的 `cmn_hans_cn` 配置，官方数据卡标为 CC-BY-4.0，可补充普通话干净语音基准，但不是医疗语音、家庭健康指令或目标麦克风数据。
- OCR：DocLayNet 的官方许可为 CDLA-Permissive-1.0，可做文档版面鲁棒性测试，但不是中文体检报告，也不能验证字段识别能力。

新增健康数据线索：

- CardioEHR 来自武汉协和医院心血管队列，采用受控访问。其协议允许研究、教育和部分内部研发，但不授权直接商业盈利或把衍生成果作为独立商业产品，因此只能在书面扩权后再判断能否用于上线模型。
- IQVIA China Regional EHR 是明确面向商业分析和 AI/ML 的采购线索，覆盖医院、基层卫生机构、诊断和检验数据。采购合同仍必须明确端侧衍生模型分发权、目标人群覆盖、标签定义和独立验证。

## 明确排除

- ASR：KeSpeech、Primewords、ST-CMDS 的官方条款含非商用或禁止衍生限制。
- OCR：XFUND、M6Doc 的官方数据许可含非商用限制。
- 健康：CLASS 官方协议限非商业研究。

## 暂停使用，等待权利澄清

- ASR：THCHS-30 页面同时出现 Apache-2.0 元数据和学术用途措辞；ChiMeS 未找到可核验的数据许可与同意范围。
- OCR：WildReceipt 未获得明确商业数据授权；CDLA 上游缺少清晰主许可；TableBank 的仓库许可与研究用途说明冲突；DCPL 仍需核验期刊和杂志页面的上游内容权利。

## 下一步执行门槛

1. 对 FLEURS 和 DocLayNet 完成具名法务审批后，只能建立工程基准，结果标记 `ENGINEERING_ONLY`。
2. 同时向 IQVIA、可信医疗数据空间、OCR 定制采集团队和 ASR 供应商索取合同样本、字段字典、规模、价格与样例清单。
3. 产品训练前必须取得商业训练、量化、端侧部署和衍生权重分发权，并建立人员、机构或说话人独立的密封测试集。
4. 公开通用数据、合成数据和供应商展示指标均不得替代真实目标设备与目标人群验收。

## 一手来源

- Google FLEURS: https://huggingface.co/datasets/google/fleurs
- KeSpeech dataset license: https://github.com/tzyll/KeSpeech/blob/main/dataset_license.md
- Primewords / OpenSLR 47: https://www.openslr.org/47/
- ST-CMDS / OpenSLR 38: https://www.openslr.org/38/
- THCHS-30 / OpenSLR 18: https://www.openslr.org/18/
- ChiMeS repository: https://github.com/Interactive-Context-Lab/Medical-Speech-Recognition
- XFUND: https://github.com/doc-analysis/XFUND
- M6Doc: https://github.com/HCIILAB/M6Doc
- WildReceipt commercial-license issue: https://github.com/open-mmlab/mmocr/issues/777
- CDLA: https://github.com/buptlihang/CDLA
- DocLayNet license: https://github.com/DS4SD/DocLayNet/blob/main/LICENSE
- TableBank: https://github.com/doc-analysis/TableBank
- DCPL: https://data.mendeley.com/datasets/tjp3y8h46z/2
- CardioEHR data-use agreement: https://github.com/YanzeLIPub/CardioEHR/blob/main/DATA_USE_AGREEMENT.md
- CardioEHR paper: https://doi.org/10.1038/s41597-026-06855-7
- CLASS data-use agreement: https://jkzgyjy.ruc.edu.cn/sjzy/CLASSsjsq/7ce2105377724a99817b7710da6b4c8c.htm
- IQVIA China Regional EHR: https://www.iqvia.com/library/fact-sheets/china-regional-electronic-health-records-rehr-dataset
- Chinese health examination data standards: https://www.nhc.gov.cn/mohwsbwstjxxzx/s10780/201901/1546c2b88b5f46ef8c690ce5e06f2db3.shtml
