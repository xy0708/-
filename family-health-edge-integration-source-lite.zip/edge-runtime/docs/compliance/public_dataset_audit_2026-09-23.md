# 公开数据集许可与适用性审计（2026-09-23）

## 当前结论

已登记 37 项健康、OCR、ASR 候选。公开不等于可直接用于商业产品；目前没有任何候选被批准为正式产品数据，`selected_product_dataset=null`。

本地已有并完成哈希复核的两份中国健康工程数据是当前最值得先用的公开数据：

- Rich Healthcare 糖尿病随访队列：211,833 名中国成人、32 个站点、11 个城市。原始 XLSX 的 MD5 为 `b468cc3704b11ba1bd21532451fe2856`，已用于 DM 工程 shadow 候选。
- 杭州 SUA/CVD 风险因素队列：6,119 名 40 岁以上成人、多次体检。原始 CSV 的 SHA-256 为 `0824bca667160625fba7677c7cf3281545c241bbf68d277d95099ca5d7eddc63`，已用于 HT 工程 shadow 候选。

两者只能证明工程训练、切分、校准和部署链能够运行。CC0 仓库元数据不能替代原始参与者授权范围、产品目的伦理审查、具名法务批准和独立目标人群验收，因此健康 V1 仍只输出非诊断规则与趋势提示，DM/HT 概率保持 shadow；Heart/Stroke 仍缺可用正式数据。

## 推荐训练顺序

1. 健康：不重复训练已完成的 Rich DM 和杭州 HT；先保留现有冻结结果并补独立外部验证与产品目的授权。不得把两个数据集合并后随机拆分冒充外部验证。
2. ASR：Common Voice 27.0 zh-CN 可作为下一份通用普通话工程 pilot，但必须先由负责人账号接受条款并完成具名许可复核。它不是医疗语音或目标麦克风验收集；正式验收仍需自采/采购说话人独立的目标设备录音。
3. OCR：未找到许可与领域同时满足的公开中文体检报告数据。现阶段只用自有合成报告验证管线；正式训练和验收必须等权利清晰、去标识的真实报告开发集与独立机构/模板/设备测试集。

## 不应先训练的候选

- 四川高危卒中队列只覆盖已属卒中高危的人群，并围绕 19 个 SNP；不能代表普通家庭筛查人群。Dryad 页面和 CC0 元数据可读取，但文件流被站点 AWS WAF/API 令牌策略返回 403，当前未下载、未训练。
- 北京社区心血管事件队列围绕高敏肌钙蛋白 T，样本约 1,499 人；该专门生物标志物不在当前常规家庭输入合同中。文件流同样返回 403，当前未下载、未训练。
- SUPPORT 中国心血管合成人口只能用于分布模拟与压力测试，不能训练或验证真实临床性能。
- WenetSpeech 官方项目页限制非商业用途并否认拥有上游音频版权；商业产品禁用。
- MultiMed 中文医疗语音的仓库许可与论文中的非商业 Fair Use 依据冲突；商业产品禁用。
- CHARLS 永久排除，不申请、不下载、不训练，也不使用其衍生数据绕过限制。

## 产品数据缺口

- 健康：具备商业端侧训练、衍生权重、部署和持续迭代权利的中国目标人群个体数据，以及机构/地区/时间独立的封存测试集。
- OCR：商业授权的真实中文体检报告开发集和独立验收集。
- ASR：商业授权的中国大陆家庭健康指令、目标设备麦克风录音和说话人独立验收集。

机器可读登记位于 `configs/public_dataset_candidates.json`。`scripts/verify_public_dataset_candidates.py` 会核对候选数量、CHARLS 永久排除、非商业条款、已落盘文件路径和摘要；当前工程审计通过，但产品数据状态保持阻断。

## 一手来源

- Rich Healthcare / Dryad: https://datadryad.org/dataset/doi:10.5061/dryad.ft8750v
- SUA/CVD risk factors / Dryad: https://datadryad.org/dataset/doi:10.5061/dryad.z08kprrk1
- Sichuan high-risk stroke / Dryad: https://datadryad.org/dataset/doi:10.5061/dryad.bg79cnpfx
- Beijing hs-cTnT CVD / Dryad: https://datadryad.org/dataset/doi:10.5061/dryad.bq0rm
- Mozilla Common Voice 27.0 zh-CN: https://mozilladatacollective.com/datasets/cmu5lcunh00qimh078sdd5so8
- WenetSpeech: https://wenet-e2e.github.io/WenetSpeech/
- ClinOCR-Bench: https://github.com/ClinOCR-Bench/ClinOCR-Bench
