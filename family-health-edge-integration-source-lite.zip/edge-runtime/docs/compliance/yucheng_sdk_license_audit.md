# 宇晟手表 Flutter SDK 许可与接入审计

审计日期：2026-10-10  
结论：`ENGINEERING_SOURCE_AVAILABLE / PRODUCT_DISTRIBUTION_BLOCKED`

## 来源

- 仓库：`https://gitee.com/yucheng_3/yc_product_plugin`
- 本地快照：`vendor/yucheng/yc_product_plugin-master.zip`
- 快照 SHA-256：`f794c9f7dae1825737450a8ec48904a5c44d619dde9123898668dc9e7c1efe06`
- 当前只有上游短提交标识 `10200da`；完整不可变 commit 未取得。
- Windows 解压时拒绝了部分 iOS framework 链接条目；Android/Dart 源码可读，
  但不得把本次目录称为完整跨平台上游副本。

## 已核事实

- 仓库顶层 `LICENSE` 是 MIT。
- 插件 `code/LICENSE` 内容仍是 `TODO: Add your license here.`。
- `android/libs` 包含 7 个 AAR、2 个 JAR 以及原生 SO。
- 对这些 AAR/JAR 的压缩包目录检查未发现 LICENSE、NOTICE 或 COPYING 条目。
- 供应商示例 release 使用 debug signing；插件声明 `armeabi`、`armeabi-v7a`、
  `arm64-v8a`，而本产品只允许 `arm64-v8a`。
- 示例 Manifest 申请后台定位、联系人、电话状态、全盘文件访问、写系统设置、
  相机、录音和互联网等广泛权限；这些权限不得复制到产品 Manifest。

## 尚不能推出的结论

MIT 顶层许可不能自动证明每个预编译 AAR/JAR/SO、内部算法、第三方 SDK、固件
升级能力和健康指标算法均允许商业再分发。没有供应商书面确认和法务具名审核前：

- 可以做本地工程接入和兼容性测试；
- 不得把这些二进制装入正式销售 APK/系统镜像；
- 不得以插件字段名称宣传血压、血糖或 ECG 的医疗准确性；
- 不得把一次连表成功当作稳定性、兼容性或量产验收。

## 产品前置材料

1. 固定版本号、完整 commit、发布说明、SDK 文档和支持的手表/固件矩阵。
2. 供应商对全部 AAR/JAR/SO 的所有权、第三方清单、商业使用和再分发授权。
3. 漏洞响应、升级支持期、数据收集/联网行为和日志行为说明。
4. 健康字段含义、单位、时间戳、无效值、校准前提和算法免责声明。
5. Android 版本/API/蓝牙权限兼容矩阵，以及 RK3576 板端实测结果。

## 当前处置

- `configs/wearable_sdk_source.json` 的 `product_use_allowed` 固定为 `false`。
- 产品 App 通过本地 `WatchGateway` 适配，不允许业务代码直接依赖供应商对象。
- 禁用 SDK 调试日志；移除已发现的健康数据 `print`；只保留 BLE 最小权限。
- 许可关闭前，所有 APK 只能标为工程构建，不得标为正式 release。
