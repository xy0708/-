# 健康 ML 端侧候选

正式 V1 仍由非诊断规则和个人趋势驱动。中国公开 CC0 数据训练的 DM/HT ONNX 仅作为
`ENGINEERING_SHADOW_ONLY` 候选接入端侧工程，不进入正式 release，不在产品接口暴露疾病概率。

- 后端：ONNX Runtime CPU；不依赖 NPU，不伪造 RKNN。
- 目标：RK3566/RK3568 ARM64 Linux；当前只有 Windows AMD64 开发机性能证据。
- 完整性：`configs/health_ml_candidate.json` 冻结运行时、manifest、模型和基准报告 SHA-256。
- 验证：`python scripts/verify_health_ml_candidate.py`。
- 产品解锁：具名许可/法务批准、目标人群独立验证、ARM64 运行时冻结、真机性能与长稳验收。

统一 Demo 可以调用同一候选做展示，但不是部署主体，也不是产品验收证据。
