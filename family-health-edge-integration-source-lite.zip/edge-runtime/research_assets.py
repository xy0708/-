from __future__ import annotations

from pathlib import Path, PurePosixPath


PROJECT_ROOT = Path(__file__).resolve().parent
ARCHIVE_DIRECTORY_NAME = "官方模型对比实验"
OFFICIAL_MODEL_PREFIX = PurePosixPath("artifacts/official_models")


class ResearchAssetPathError(ValueError):
    """Raised when a locked research artifact path escapes its allowed root."""


def official_research_root(project_root: Path = PROJECT_ROOT) -> Path:
    return project_root.resolve().parent / ARCHIVE_DIRECTORY_NAME


def is_official_model_reference(relative: str) -> bool:
    try:
        parts = PurePosixPath(relative).parts
    except (TypeError, ValueError):
        return False
    return parts[:2] == OFFICIAL_MODEL_PREFIX.parts


def resolve_locked_artifact(project_root: Path, relative: str) -> Path:
    """Resolve project evidence or an archived official model without path escapes."""
    if not isinstance(relative, str) or not relative or "\\" in relative:
        raise ResearchAssetPathError("artifact path must be a non-empty POSIX path")
    logical = PurePosixPath(relative)
    if logical.is_absolute() or ".." in logical.parts or "." in logical.parts:
        raise ResearchAssetPathError(f"unsafe artifact path: {relative}")

    project = project_root.resolve(strict=True)
    base = official_research_root(project) if is_official_model_reference(relative) else project
    try:
        resolved_base = base.resolve(strict=True)
        target = resolved_base.joinpath(*logical.parts).resolve(strict=True)
        target.relative_to(resolved_base)
    except (OSError, ValueError) as exc:
        raise ResearchAssetPathError(f"unresolvable artifact path: {relative}") from exc
    if target.is_symlink() or not target.is_file():
        raise ResearchAssetPathError(f"artifact is not a regular file: {relative}")
    return target


def archived_model_root(project_root: Path = PROJECT_ROOT) -> Path:
    return official_research_root(project_root) / Path(*OFFICIAL_MODEL_PREFIX.parts)
