from __future__ import annotations

import json
import os
import re
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path


SAFE_VALUE = re.compile(r"^[A-Za-z0-9_.:-]{0,128}$")
OPERATIONS = {
    "UNKNOWN",
    "HEALTH_STATUS",
    "VERSION_READ",
    "HEALTH_EVALUATE",
    "OCR_TASK_CREATE",
    "TASK_READ",
    "TASK_CANCEL",
    "RECORD_CONFIRM",
    "RECORD_LIST",
    "RECORD_DELETE",
    "RECORD_CORRECT",
    "CONSENT_WITHDRAW",
    "ASR_STREAM",
}


class PrivacySafeEventLog:
    """Allow-listed operational events; never accepts paths, bodies, or user data."""

    def __init__(
        self,
        path: Path,
        *,
        max_bytes: int = 1024 * 1024,
        retention_days: int = 30,
    ) -> None:
        if max_bytes < 4096:
            raise ValueError("max_bytes must be at least 4096")
        if retention_days < 1 or retention_days > 365:
            raise ValueError("retention_days must be between 1 and 365")
        self.path = path
        self.max_bytes = max_bytes
        self.retention_days = retention_days
        self._lock = threading.Lock()
        path.parent.mkdir(parents=True, exist_ok=True)

    def request_completed(
        self,
        *,
        status: int,
        request_id: str,
        error_code: str | None,
        operation: str = "UNKNOWN",
    ) -> None:
        if operation not in OPERATIONS:
            raise ValueError("unknown operation code")
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": "request_completed",
            "status": int(status),
            "request_id": self._safe(request_id, "request_id"),
            "error_code": self._safe(error_code or "NONE", "error_code"),
            "operation": operation,
        }
        encoded = json.dumps(event, ensure_ascii=True, separators=(",", ":")) + "\n"
        with self._lock:
            self._enforce_retention()
            self._rotate_if_needed(len(encoded.encode("utf-8")))
            with self.path.open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(encoded)
            if os.name != "nt":
                self.path.chmod(0o600)

    @staticmethod
    def _safe(value: str, field: str) -> str:
        if not SAFE_VALUE.fullmatch(value):
            raise ValueError(f"unsafe {field}")
        return value

    def _rotate_if_needed(self, incoming_bytes: int) -> None:
        if not self.path.exists() or self.path.stat().st_size + incoming_bytes <= self.max_bytes:
            return
        rotated = self.path.with_suffix(self.path.suffix + ".1")
        os.replace(self.path, rotated)

    def _enforce_retention(self) -> None:
        rotated = self.path.with_suffix(self.path.suffix + ".1")
        if not rotated.exists():
            return
        cutoff = datetime.now(timezone.utc) - timedelta(days=self.retention_days)
        modified = datetime.fromtimestamp(rotated.stat().st_mtime, timezone.utc)
        if modified < cutoff:
            rotated.unlink()
