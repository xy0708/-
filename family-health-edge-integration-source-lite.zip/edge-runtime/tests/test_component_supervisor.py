from __future__ import annotations

import os
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

from integration_adapter import (
    CircuitBreaker,
    CircuitBreakerPolicy,
    ComponentOperationError,
    JsonLineProcessAdapter,
    ProcessLimits,
)


MODEL_SHA256 = "a" * 64
WORKER_SOURCE = r'''
import base64
import json
import os
import sys
import time

mode = sys.argv[1]

def send(result):
    sys.stdout.write(json.dumps({"ok": True, "result": result}, ensure_ascii=False) + "\n")
    sys.stdout.flush()

def receive():
    line = sys.stdin.readline()
    return json.loads(line) if line else None

request = receive()
if mode == "timeout":
    time.sleep(2)
elif mode == "invalid":
    sys.stdout.write("not-json\n")
    sys.stdout.flush()
elif request["op"] == "health":
    send({
        "ready": True,
        "contract_version": "1.0.0",
        "component_version": "1.2.3",
        "capabilities": ["confirmation_required", "local_only", "ocr_task"],
        "model_sha256": "a" * 64,
        "worker_pid": os.getpid(),
    })
elif request["op"] == "create_task":
    send({"fields": [], "worker_pid": os.getpid(), "input_sha256": request["payload"]["sha256"]})
elif request["op"] == "open_stream":
    if mode == "stream_contract":
        send({"started": True})
        sys.exit(0)
    send({
        "started": True,
        "ready": True,
        "contract_version": "1.0.0",
        "component_version": "1.2.3",
        "capabilities": [
            "asr_stream",
            "confirmation_required",
            "local_only",
            "raw_audio_memory_only",
        ],
        "model_sha256": "a" * 64,
        "worker_pid": os.getpid(),
    })
    while True:
        request = receive()
        if request is None:
            break
        if request["op"] == "feed_pcm":
            base64.b64decode(request["pcm_s16le_base64"], validate=True)
            send({"text": "血压"})
        elif request["op"] == "finish":
            send({"text": "血压一百二十", "fields": {"systolic": 120}, "worker_pid": os.getpid()})
            break
        elif request["op"] == "close":
            send({"closed": True})
            break
'''


class FakeClock:
    def __init__(self) -> None:
        self.value = 100.0

    def __call__(self) -> float:
        return self.value


class ComponentSupervisorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.worker = Path(self.temporary.name) / "worker.py"
        self.worker.write_text(textwrap.dedent(WORKER_SOURCE), encoding="utf-8")

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def adapter(
        self,
        mode: str = "ok",
        *,
        name: str = "ocr",
        capabilities: tuple[str, ...] = (
            "confirmation_required",
            "local_only",
            "ocr_task",
        ),
        timeout: float = 1.0,
        threshold: int = 3,
    ) -> JsonLineProcessAdapter:
        return JsonLineProcessAdapter(
            name,
            [sys.executable, str(self.worker), mode],
            required_capabilities=capabilities,
            limits=ProcessLimits(
                operation_timeout_seconds=timeout,
                max_inflight_requests=1,
            ),
            breaker_policy=CircuitBreakerPolicy(
                failure_threshold=threshold,
                recovery_timeout_seconds=60,
            ),
            expected_model_sha256=MODEL_SHA256,
        )

    def test_circuit_breaker_allows_one_recovery_probe(self) -> None:
        clock = FakeClock()
        breaker = CircuitBreaker(
            CircuitBreakerPolicy(failure_threshold=2, recovery_timeout_seconds=10),
            clock=clock,
        )
        breaker.record_failure()
        self.assertEqual(breaker.snapshot()["state"], "closed")
        breaker.record_failure()
        self.assertEqual(breaker.snapshot()["state"], "open")
        with self.assertRaises(ComponentOperationError) as blocked:
            breaker.before_call()
        self.assertEqual(blocked.exception.code, "COMPONENT_CIRCUIT_OPEN")
        clock.value += 11
        breaker.before_call()
        self.assertEqual(breaker.snapshot()["state"], "half_open")
        with self.assertRaises(ComponentOperationError):
            breaker.before_call()
        breaker.record_success()
        self.assertEqual(breaker.snapshot(), {"state": "closed", "consecutive_failures": 0})

    def test_one_shot_operation_runs_in_a_different_process(self) -> None:
        adapter = self.adapter()
        health = adapter.health()
        self.assertTrue(health["ready"])
        self.assertEqual(health["model_sha256"], MODEL_SHA256)
        result = adapter.create_task("member-a", {"sha256": "b" * 64})
        self.assertNotEqual(result["worker_pid"], os.getpid())
        self.assertEqual(result["input_sha256"], "b" * 64)
        self.assertEqual(adapter.circuit_snapshot()["state"], "closed")

    def test_timeout_opens_circuit_and_returns_only_fixed_reason(self) -> None:
        adapter = self.adapter("timeout", timeout=0.05, threshold=1)
        first = adapter.health()
        self.assertFalse(first["ready"])
        self.assertEqual(first["reason"], "COMPONENT_TIMEOUT")
        second = adapter.health()
        self.assertEqual(second["reason"], "COMPONENT_CIRCUIT_OPEN")
        self.assertEqual(adapter.circuit_snapshot()["state"], "open")

    def test_invalid_worker_output_fails_closed(self) -> None:
        adapter = self.adapter("invalid")
        health = adapter.health()
        self.assertFalse(health["ready"])
        self.assertEqual(health["reason"], "COMPONENT_NOT_READY")
        self.assertNotIn("not-json", str(health))

    def test_stream_holds_capacity_and_discards_process_after_finish(self) -> None:
        adapter = self.adapter(
            name="asr",
            capabilities=(
                "asr_stream",
                "confirmation_required",
                "local_only",
                "raw_audio_memory_only",
            ),
        )
        recognizer = adapter.open_stream(
            "member-a",
            {"sample_rate_hz": 16000, "channels": 1, "sample_format": "s16le"},
        )
        busy = adapter.health()
        self.assertFalse(busy["ready"])
        self.assertEqual(busy["reason"], "COMPONENT_BUSY")
        self.assertEqual(recognizer.feed_pcm(b"\x00\x00" * 20), "血压")
        result = recognizer.finish()
        self.assertEqual(result["fields"]["systolic"], 120)
        self.assertNotEqual(result["worker_pid"], os.getpid())
        self.assertEqual(adapter.circuit_snapshot()["state"], "closed")

    def test_stream_start_requires_contract_and_model_bound_handshake(self) -> None:
        adapter = self.adapter(
            "stream_contract",
            name="asr",
            capabilities=(
                "asr_stream",
                "confirmation_required",
                "local_only",
                "raw_audio_memory_only",
            ),
        )
        with self.assertRaises(ComponentOperationError) as failed:
            adapter.open_stream(
                "member-a",
                {"sample_rate_hz": 16000, "channels": 1, "sample_format": "s16le"},
            )
        self.assertEqual(failed.exception.code, "COMPONENT_CONTRACT_INCOMPATIBLE")

    def test_configuration_rejects_shell_string_and_unbounded_limits(self) -> None:
        with self.assertRaises(ValueError):
            JsonLineProcessAdapter(
                "ocr",
                "unsafe --shell command",  # type: ignore[arg-type]
                required_capabilities=("ocr_task",),
                limits=ProcessLimits(operation_timeout_seconds=1),
            )
        with self.assertRaises(ValueError):
            ProcessLimits(operation_timeout_seconds=0)
        with self.assertRaises(ValueError):
            JsonLineProcessAdapter(
                "ocr",
                [sys.executable, str(self.worker), "ok"],
                required_capabilities=("ocr_task",),
                limits=ProcessLimits(operation_timeout_seconds=1),
                environment={"EDGE_MEMBER_TOKEN_DEMO": "must-not-reach-worker"},
            )


if __name__ == "__main__":
    unittest.main()
