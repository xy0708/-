from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from runtime_backends import BackendRegistryError, load_registry, select_backend
from scripts.verify_runtime_backend_registry import verify_registry


ROOT = Path(__file__).resolve().parents[1]


class RuntimeBackendRegistryTests(unittest.TestCase):
    def setUp(self):
        self.registry = load_registry(ROOT / "model_registry" / "backend_registry.json")

    def test_registry_exposes_only_the_verified_cpu_asr_backend(self):
        result = verify_registry()
        self.assertEqual(result["status"], "PASS_ENGINEERING_PARTIAL", result["errors"])
        self.assertEqual(result["registered_backends"], 5)
        self.assertEqual(result["engineering_ready_backends"], ["asr_sherpa_cpu_xasr"])
        self.assertEqual(result["implemented_blocked_backends"], [])
        self.assertEqual(result["product_ready_backends"], [])
        self.assertFalse(result["silent_fallback_allowed"])
        self.assertTrue(result["device_service_integration_verified"])
        self.assertTrue(result["asr_rknn_worker_deferred_after_research_regression"])
        zipformer = self.registry.backends["asr_rknn_zipformer"]
        self.assertIn("engineering_worker_deferred", zipformer.unavailable_reasons)
        self.assertIn(
            "research_set_quality_regression_observed",
            zipformer.unavailable_reasons,
        )

    def test_blocked_or_unknown_backend_never_silently_falls_back(self):
        for backend_id, component in (
            ("ocr_rknn_ppocrv4", "ocr"),
            ("asr_rknn_zipformer", "asr"),
            ("missing_backend", "asr"),
        ):
            with self.subTest(backend_id=backend_id):
                with self.assertRaises(BackendRegistryError):
                    select_backend(
                        self.registry,
                        component=component,
                        backend_id=backend_id,
                        product_mode=False,
                    )

    def test_engineering_cpu_backend_is_still_blocked_in_product_mode(self):
        with self.assertRaisesRegex(BackendRegistryError, "BACKEND_NOT_PRODUCT_ACCEPTED"):
            select_backend(
                self.registry,
                component="asr",
                backend_id="asr_sherpa_cpu_xasr",
                product_mode=True,
            )

    def test_product_registry_requires_ready_ocr_and_asr(self):
        payload = json.loads(
            (ROOT / "model_registry" / "backend_registry.json").read_text(encoding="utf-8")
        )
        payload["status"] = "PRODUCT_REGISTRY_APPROVED"
        payload["product_complete"] = True
        asr = payload["backends"][0]
        asr.update(
            status="PRODUCT_READY",
            product_accepted=True,
            hardware_validated=True,
            license_approved=True,
        )
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "registry.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(
                BackendRegistryError, "PRODUCT_REGISTRY_COMPONENTS_INCOMPLETE"
            ):
                load_registry(path)

    def test_engineering_registry_cannot_smuggle_product_backend(self):
        payload = json.loads(
            (ROOT / "model_registry" / "backend_registry.json").read_text(encoding="utf-8")
        )
        asr = payload["backends"][0]
        asr.update(
            status="PRODUCT_READY",
            product_accepted=True,
            hardware_validated=True,
            license_approved=True,
        )
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "registry.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(
                BackendRegistryError, "ENGINEERING_REGISTRY_CONTAINS_PRODUCT_BACKEND"
            ):
                load_registry(path)

    def test_nested_registry_values_fail_closed_without_type_error(self):
        for field, expected_error in (
            ("capabilities", "BACKEND_CAPABILITIES_INVALID"),
            ("unavailable_reasons", "BACKEND_REASONS_INVALID"),
        ):
            with self.subTest(field=field):
                payload = json.loads(
                    (ROOT / "model_registry" / "backend_registry.json").read_text(
                        encoding="utf-8"
                    )
                )
                payload["backends"][0][field] = [{"nested": "invalid"}]
                with tempfile.TemporaryDirectory() as temporary:
                    path = Path(temporary) / "registry.json"
                    path.write_text(json.dumps(payload), encoding="utf-8")
                    with self.assertRaisesRegex(BackendRegistryError, expected_error):
                        load_registry(path)
