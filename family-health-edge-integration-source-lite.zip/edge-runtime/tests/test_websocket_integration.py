from __future__ import annotations

import base64
import json
import socket
import tempfile
import threading
import unittest
from pathlib import Path

from device_service import DeviceApplication, TokenAuthorizer
from device_service.server import BoundedThreadingHTTPServer, DeviceRequestHandler
from storage import PlaintextEngineeringCodec, RecordStore
from tests.test_websocket_protocol import masked_frame


TOKEN = "websocket-member-token-1234567890abcdef"


class FakeRecognizer:
    def feed_pcm(self, pcm_s16le):
        return "血压"

    def finish(self):
        return {"text": "血压一百二十", "fields": {"systolic": 120}}

    def close(self):
        return None


class FakeAsrAdapter:
    name = "asr"

    def health(self):
        raise AssertionError("stream startup must not perform a redundant health preflight")

    def open_stream(self, member_id, config):
        return FakeRecognizer()


def read_server_frame(stream) -> tuple[int, bytes]:
    first = stream.read(1)[0]
    second = stream.read(1)[0]
    length = second & 0x7F
    if length == 126:
        length = int.from_bytes(stream.read(2), "big")
    elif length == 127:
        length = int.from_bytes(stream.read(8), "big")
    return first & 0x0F, stream.read(length)


class WebSocketIntegrationTests(unittest.TestCase):
    def test_handshake_requires_http11_connection_upgrade(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = RecordStore(
                Path(temporary) / "records.db",
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
            )
            app = DeviceApplication(
                store,
                TokenAuthorizer({TOKEN: {"member-a"}}),
                asr_adapter=FakeAsrAdapter(),
            )
            server = BoundedThreadingHTTPServer(("127.0.0.1", 0), DeviceRequestHandler)
            server.application = app  # type: ignore[attr-defined]
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            sock = socket.create_connection(server.server_address, timeout=5)
            stream = sock.makefile("rwb", buffering=0)
            try:
                key = base64.b64encode(b"0123456789abcdef").decode("ascii")
                request = (
                    "GET /v1/asr/stream HTTP/1.1\r\n"
                    f"Host: 127.0.0.1:{server.server_address[1]}\r\n"
                    "Upgrade: websocket\r\n"
                    "Connection: keep-alive\r\n"
                    "Sec-WebSocket-Version: 13\r\n"
                    f"Sec-WebSocket-Key: {key}\r\n"
                    f"Authorization: Bearer {TOKEN}\r\n"
                    "X-Edge-Member-Id: member-a\r\n"
                    "Origin: null\r\n\r\n"
                )
                stream.write(request.encode("ascii"))
                self.assertIn("400", stream.readline().decode("ascii"))
            finally:
                stream.close()
                sock.close()
                server.shutdown()
                server.server_close()
                thread.join(timeout=5)
                store.close()

    def test_real_loopback_websocket_reaches_pending_confirmation_without_storage(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = RecordStore(
                Path(temporary) / "records.db",
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
            )
            app = DeviceApplication(
                store,
                TokenAuthorizer({TOKEN: {"member-a"}}),
                asr_adapter=FakeAsrAdapter(),
            )
            server = BoundedThreadingHTTPServer(("127.0.0.1", 0), DeviceRequestHandler)
            server.application = app  # type: ignore[attr-defined]
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            sock = socket.create_connection(server.server_address, timeout=5)
            stream = sock.makefile("rwb", buffering=0)
            try:
                key = base64.b64encode(b"0123456789abcdef").decode("ascii")
                request = (
                    "GET /v1/asr/stream HTTP/1.1\r\n"
                    f"Host: 127.0.0.1:{server.server_address[1]}\r\n"
                    "Upgrade: websocket\r\n"
                    "Connection: Upgrade\r\n"
                    "Sec-WebSocket-Version: 13\r\n"
                    f"Sec-WebSocket-Key: {key}\r\n"
                    f"Authorization: Bearer {TOKEN}\r\n"
                    "X-Edge-Member-Id: member-a\r\n"
                    "Origin: null\r\n\r\n"
                )
                stream.write(request.encode("ascii"))
                status = stream.readline().decode("ascii")
                self.assertTrue(status.startswith("HTTP/1.1 101"), status)
                while stream.readline() not in {b"\r\n", b""}:
                    pass

                start = json.dumps(
                    {
                        "type": "start",
                        "sample_rate_hz": 16000,
                        "channels": 1,
                        "sample_format": "s16le",
                    }
                ).encode("utf-8")
                stream.write(masked_frame(0x1, start))
                _, started = read_server_frame(stream)
                self.assertEqual(json.loads(started)["type"], "started")

                stream.write(masked_frame(0x2, b"\x00\x00" * 100))
                _, partial = read_server_frame(stream)
                self.assertEqual(json.loads(partial)["type"], "partial")

                stream.write(masked_frame(0x1, b'{"type":"stop"}'))
                _, final = read_server_frame(stream)
                final_payload = json.loads(final)
                self.assertEqual(final_payload["type"], "final_pending_confirmation")
                self.assertFalse(final_payload["raw_audio_persisted"])
                self.assertEqual(store.list_records("member-a"), [])
                pending = store.get_task(final_payload["task"]["task_id"], "member-a")
                self.assertEqual(pending["result"]["fields"]["systolic"], 120)
            finally:
                stream.close()
                sock.close()
                server.shutdown()
                server.server_close()
                thread.join(timeout=5)
                store.close()


if __name__ == "__main__":
    unittest.main()
