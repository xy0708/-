from __future__ import annotations

import tempfile
import threading
import time
import unittest
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

from storage import (
    PlaintextEngineeringCodec,
    RecordStore,
    StoragePolicyError,
    TaskStateError,
)


class StorageTests(unittest.TestCase):
    def make_store(self, temporary: str) -> RecordStore:
        return RecordStore(
            Path(temporary) / "records.db",
            PlaintextEngineeringCodec(),
            allow_unencrypted_engineering=True,
        )

    def test_plaintext_storage_is_refused_without_explicit_engineering_mode(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(StoragePolicyError):
                RecordStore(Path(temporary) / "records.db", PlaintextEngineeringCodec())

    def test_confirmation_is_idempotent_and_member_isolated(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = self.make_store(temporary)
            try:
                task = store.create_task("member-a", "ocr", {"field": "pending"})
                record, replayed = store.confirm_task(
                    task["task_id"], "member-a", "idem-1", {"field": "confirmed"}
                )
                self.assertFalse(replayed)
                replay, replayed = store.confirm_task(
                    task["task_id"], "member-a", "idem-1", {"field": "confirmed"}
                )
                self.assertTrue(replayed)
                self.assertEqual(replay["record_id"], record["record_id"])
                self.assertEqual(len(store.list_records("member-a")), 1)
                self.assertEqual(store.list_records("member-b"), [])
                with self.assertRaises(TaskStateError) as raised:
                    store.get_task(task["task_id"], "member-b")
                self.assertEqual(raised.exception.code, "TASK_NOT_FOUND")
            finally:
                store.close()

    def test_idempotency_keys_are_scoped_per_member(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = self.make_store(temporary)
            try:
                first = store.create_task("member-a", "ocr", {})
                second = store.create_task("member-b", "ocr", {})
                store.confirm_task(first["task_id"], "member-a", "shared-key", {})
                record, replayed = store.confirm_task(
                    second["task_id"], "member-b", "shared-key", {}
                )
                self.assertFalse(replayed)
                self.assertEqual(record["member_id"], "member-b")
                conflicting = store.create_task("member-b", "ocr", {})
                with self.assertRaises(TaskStateError) as raised:
                    store.confirm_task(
                        conflicting["task_id"], "member-b", "shared-key", {}
                    )
                self.assertEqual(raised.exception.code, "STORAGE_CONFLICT")
            finally:
                store.close()

    def test_schema_two_records_are_migrated_without_data_loss(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "records.db"
            connection = sqlite3.connect(path)
            connection.executescript(
                """
                CREATE TABLE tasks (
                    task_id TEXT PRIMARY KEY,
                    member_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    status TEXT NOT NULL,
                    result_blob BLOB NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    confirmed_record_id TEXT
                );
                CREATE TABLE records (
                    record_id TEXT PRIMARY KEY,
                    member_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    payload_blob BLOB NOT NULL,
                    source_task_id TEXT NOT NULL UNIQUE,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL,
                    updated_at TEXT,
                    version INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE schema_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL);
                INSERT INTO schema_meta VALUES ('schema_version','2');
                """
            )
            connection.execute(
                "INSERT INTO records VALUES (?,?,?,?,?,?,?,?,?)",
                (
                    "a" * 32,
                    "member-a",
                    "ocr",
                    PlaintextEngineeringCodec().encode({"weight": 70}),
                    "b" * 32,
                    "legacy-key",
                    "2026-09-13T00:00:00+00:00",
                    None,
                    1,
                ),
            )
            connection.commit()
            connection.close()
            store = self.make_store(temporary)
            try:
                self.assertEqual(store.schema_version(), "3")
                self.assertEqual(store.list_records("member-a")[0]["payload"], {"weight": 70})
                second = store.create_task("member-b", "ocr", {})
                store.confirm_task(second["task_id"], "member-b", "legacy-key", {})
            finally:
                store.close()

    def test_cancelled_or_expired_task_cannot_be_confirmed(self) -> None:
        now = datetime(2026, 8, 25, tzinfo=timezone.utc)
        with tempfile.TemporaryDirectory() as temporary:
            store = self.make_store(temporary)
            try:
                cancelled = store.create_task("member", "asr", {}, now=now)
                store.cancel_task(cancelled["task_id"], "member")
                with self.assertRaises(TaskStateError):
                    store.confirm_task(
                        cancelled["task_id"], "member", "cancelled-idem", {}, now=now
                    )
                expired = store.create_task("member", "ocr", {}, ttl_seconds=1, now=now)
                with self.assertRaises(TaskStateError) as raised:
                    store.confirm_task(
                        expired["task_id"],
                        "member",
                        "expired-idem",
                        {},
                        now=now + timedelta(seconds=2),
                    )
                self.assertEqual(raised.exception.code, "TASK_EXPIRED")
                self.assertEqual(
                    store.get_task(expired["task_id"], "member")["status"],
                    "expired",
                )
            finally:
                store.close()

    def test_get_task_enforces_ttl_and_clears_sensitive_result(self) -> None:
        expired_at = datetime.now(timezone.utc) - timedelta(seconds=2)
        with tempfile.TemporaryDirectory() as temporary:
            store = self.make_store(temporary)
            try:
                task = store.create_task(
                    "member-a", "ocr", {"text": "sensitive"}, ttl_seconds=1, now=expired_at
                )
                with self.assertRaises(TaskStateError) as raised:
                    store.get_task(task["task_id"], "member-a")
                self.assertEqual(raised.exception.code, "TASK_EXPIRED")
                self.assertNotIn(task["task_id"], store._pending_results)
                status = store._connection.execute(
                    "SELECT status FROM tasks WHERE task_id=?", (task["task_id"],)
                ).fetchone()[0]
                self.assertEqual(status, "expired")
            finally:
                store.close()

    def test_background_sweeper_clears_unobserved_expired_result(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = RecordStore(
                Path(temporary) / "records.db",
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
                pending_sweep_interval_seconds=0.02,
            )
            sweeper = store._pending_sweeper
            try:
                task = store.create_task(
                    "member-a", "asr", {"text": "sensitive"}, ttl_seconds=1
                )
                deadline = time.monotonic() + 4
                while task["task_id"] in store._pending_results and time.monotonic() < deadline:
                    time.sleep(0.02)
                self.assertNotIn(task["task_id"], store._pending_results)
                with self.assertRaises(TaskStateError) as raised:
                    store.get_task(task["task_id"], "member-a")
                self.assertEqual(raised.exception.code, "TASK_EXPIRED")
            finally:
                store.close()
            self.assertFalse(sweeper.is_alive())

    def test_pending_sweep_interval_is_bounded(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            for index, interval in enumerate((0, float("nan"), True, 61)):
                with self.subTest(interval=interval):
                    with self.assertRaisesRegex(StoragePolicyError, "sweep interval"):
                        RecordStore(
                            Path(temporary) / f"invalid-{index}.db",
                            PlaintextEngineeringCodec(),
                            allow_unencrypted_engineering=True,
                            pending_sweep_interval_seconds=interval,
                        )

    def test_correction_uses_optimistic_version_and_withdrawal_deletes_member_data(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = self.make_store(temporary)
            try:
                task = store.create_task("member-a", "ocr", {"field": "pending"})
                record, _ = store.confirm_task(
                    task["task_id"], "member-a", "idem-correct", {"field": "old"}
                )
                corrected = store.correct_record(
                    "member-a", record["record_id"], {"field": "new"}, expected_version=1
                )
                self.assertEqual(corrected["payload"], {"field": "new"})
                self.assertEqual(corrected["version"], 2)
                with self.assertRaises(TaskStateError) as conflict:
                    store.correct_record(
                        "member-a", record["record_id"], {"field": "stale"}, expected_version=1
                    )
                self.assertEqual(conflict.exception.code, "STORAGE_CONFLICT")
                deleted = store.withdraw_member("member-a")
                self.assertEqual(deleted, {"deleted_records": 1, "deleted_tasks": 1})
                self.assertEqual(store.list_records("member-a"), [])
                self.assertNotIn(task["task_id"], store._pending_results)
            finally:
                store.close()

    def test_integrity_check_and_online_backup(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = self.make_store(temporary)
            backup = Path(temporary) / "backup" / "records.db"
            try:
                self.assertTrue(store.integrity_check())
                store.create_backup(backup, allowed_root=Path(temporary))
                self.assertTrue(backup.is_file())
                self.assertGreater(backup.stat().st_size, 0)
            finally:
                store.close()

    def test_backup_is_confined_immutable_and_failure_atomic(self) -> None:
        class FailingConnection:
            def backup(self, _target: object) -> None:
                raise sqlite3.OperationalError("injected backup failure")

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            destination = root / "backups" / "records.db"
            fake_store = RecordStore.__new__(RecordStore)
            fake_store._lock = threading.RLock()
            fake_store._connection = FailingConnection()
            with self.assertRaisesRegex(sqlite3.OperationalError, "injected"):
                fake_store.create_backup(destination, allowed_root=root)
            self.assertFalse(destination.exists())
            self.assertEqual(list((root / "backups").iterdir()), [])

            store = self.make_store(temporary)
            try:
                store.create_backup(destination, allowed_root=root)
                original = destination.read_bytes()
                with self.assertRaisesRegex(StoragePolicyError, "already exists"):
                    store.create_backup(destination, allowed_root=root)
                self.assertEqual(destination.read_bytes(), original)
                with tempfile.TemporaryDirectory() as outside:
                    with self.assertRaisesRegex(StoragePolicyError, "allowed_root"):
                        store.create_backup(Path(outside) / "escaped.db", allowed_root=root)
            finally:
                store.close()

    def test_backup_refuses_redirected_destination_path(self) -> None:
        with tempfile.TemporaryDirectory() as temporary, tempfile.TemporaryDirectory() as outside:
            root = Path(temporary)
            link = root / "redirected"
            try:
                link.symlink_to(Path(outside), target_is_directory=True)
            except OSError:
                self.skipTest("symlink creation is unavailable on this host")
            store = self.make_store(temporary)
            try:
                with self.assertRaisesRegex(StoragePolicyError, "redirected"):
                    store.create_backup(link / "records.db", allowed_root=root)
            finally:
                store.close()

    def test_unconfirmed_result_is_memory_only_and_restart_invalidates_task(self) -> None:
        canary = "PRIVATE_OCR_TEXT_987654"
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "records.db"
            store = self.make_store(temporary)
            task = store.create_task("member-a", "ocr", {"text": canary})
            self.assertEqual(store.get_task(task["task_id"], "member-a")["result"]["text"], canary)
            store.close()

            raw_connection = sqlite3.connect(database)
            try:
                blob = raw_connection.execute(
                    "SELECT result_blob FROM tasks WHERE task_id=?", (task["task_id"],)
                ).fetchone()[0]
            finally:
                raw_connection.close()
            self.assertNotIn(canary.encode("utf-8"), bytes(blob))

            reopened = self.make_store(temporary)
            try:
                with self.assertRaises(TaskStateError) as lost:
                    reopened.confirm_task(
                        task["task_id"], "member-a", "restart-idem", {"forged": True}
                    )
                self.assertEqual(lost.exception.code, "TASK_EXPIRED")
                self.assertEqual(reopened.list_records("member-a"), [])
            finally:
                reopened.close()

    def test_pending_result_is_an_owned_snapshot_not_a_mutable_alias(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = self.make_store(temporary)
            original = {"measurements": [{"name": "weight", "value": 70}]}
            try:
                task = store.create_task("member-a", "ocr", original)
                original["measurements"][0]["value"] = 999
                first = store.get_task(task["task_id"], "member-a")
                self.assertEqual(first["result"]["measurements"][0]["value"], 70)
                first["result"]["measurements"][0]["value"] = -1
                second = store.get_task(task["task_id"], "member-a")
                self.assertEqual(second["result"]["measurements"][0]["value"], 70)
            finally:
                store.close()

    def test_untrusted_payloads_are_bounded_before_memory_or_storage(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = self.make_store(temporary)
            try:
                with self.assertRaises(TaskStateError) as non_finite:
                    store.create_task("member-a", "ocr", {"value": float("nan")})
                self.assertEqual(non_finite.exception.code, "INPUT_INVALID")

                task = store.create_task("member-a", "ocr", {"field": "pending"})
                with self.assertRaises(TaskStateError) as oversized:
                    store.confirm_task(
                        task["task_id"],
                        "member-a",
                        "oversized-idem",
                        {"text": "x" * (128 * 1024)},
                    )
                self.assertEqual(oversized.exception.code, "INPUT_INVALID")
                self.assertEqual(
                    store.get_task(task["task_id"], "member-a")["status"],
                    "pending_confirmation",
                )
            finally:
                store.close()

    def test_failed_task_insert_does_not_leave_sensitive_pending_memory(self) -> None:
        class FailingCodec(PlaintextEngineeringCodec):
            def encode(self, payload: dict) -> bytes:
                raise StoragePolicyError("injected encode failure")

        with tempfile.TemporaryDirectory() as temporary:
            store = RecordStore(
                Path(temporary) / "records.db",
                FailingCodec(),
                allow_unencrypted_engineering=True,
            )
            try:
                with self.assertRaisesRegex(StoragePolicyError, "injected"):
                    store.create_task("member-a", "ocr", {"text": "sensitive"})
                self.assertEqual(store._pending_results, {})
            finally:
                store.close()

    def test_commit_failure_keeps_pending_result_available_for_retry(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = self.make_store(temporary)
            try:
                task = store.create_task("member-a", "ocr", {"field": "pending"})

                def deny_commit(action, argument, _database, _trigger, _source):
                    if action == sqlite3.SQLITE_TRANSACTION and argument == "COMMIT":
                        return sqlite3.SQLITE_DENY
                    return sqlite3.SQLITE_OK

                store._connection.set_authorizer(deny_commit)
                with self.assertRaises(sqlite3.DatabaseError):
                    store.confirm_task(
                        task["task_id"],
                        "member-a",
                        "retry-after-commit-failure",
                        {"field": "confirmed"},
                    )
                store._connection.set_authorizer(None)
                pending = store.get_task(task["task_id"], "member-a")
                self.assertEqual(pending["status"], "pending_confirmation")
                self.assertEqual(pending["result"], {"field": "pending"})
                self.assertEqual(store.list_records("member-a"), [])
                record, replayed = store.confirm_task(
                    task["task_id"],
                    "member-a",
                    "retry-after-commit-failure",
                    {"field": "confirmed"},
                )
                self.assertFalse(replayed)
                self.assertEqual(record["payload"], {"field": "confirmed"})
            finally:
                store._connection.set_authorizer(None)
                store.close()


if __name__ == "__main__":
    unittest.main()
