from __future__ import annotations

import unittest

from acceptance import compute_metrics


class AcceptanceMetricsTests(unittest.TestCase):
    def test_metrics_are_computed_from_rows_not_supplied_scores(self) -> None:
        metrics = compute_metrics(
            [
                {"split": "independent_acceptance", "real_report": True, "required": True, "truth": "120", "prediction": "120", "should_reject": False},
                {"split": "independent_acceptance", "real_report": True, "required": False, "truth": "正常", "prediction": "异常", "should_reject": False},
                {"split": "independent_acceptance", "real_report": True, "should_reject": True, "rejected": True},
            ],
            [
                {"split": "independent_acceptance", "real_human": True, "target_microphone": True, "reference": "血压一百二十", "prediction": "血压一百二十", "expected_slots": {"systolic": 120}, "predicted_slots": {"systolic": 120}}
            ],
            [
                {"measured_on_real_rk3566": True, "latency_ms": 100, "peak_memory_mib": 200, "temperature_c": 50},
                {"measured_on_real_rk3566": True, "latency_ms": 200, "peak_memory_mib": 220, "temperature_c": 55},
            ],
            {"measured_on_real_rk3566": True, "duration_hours": 24, "unrecovered_crashes": 0, "memory_growth_mib": 3},
            {"offline_operation": "PASS"},
        )
        self.assertEqual(metrics["ocr_field_exact_match"], 0.5)
        self.assertEqual(metrics["ocr_required_field_recall"], 1.0)
        self.assertEqual(metrics["ocr_unsupported_input_rejection"], 1.0)
        self.assertEqual(metrics["asr_cer"], 0.0)
        self.assertEqual(metrics["asr_health_slot_exact_match"], 1.0)
        self.assertEqual(metrics["p50_latency_ms"], 150.0)
        self.assertEqual(metrics["p95_latency_ms"], 195.0)

    def test_synthetic_or_non_target_rows_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            compute_metrics(
                [{"split": "demo", "real_report": False, "should_reject": False}],
                [{"split": "demo"}],
                [{"measured_on_real_rk3566": False}],
                {},
                {},
            )

    def test_impossible_performance_and_soak_values_are_rejected(self) -> None:
        valid_ocr = [
            {"split": "independent_acceptance", "real_report": True, "required": True, "truth": "120", "prediction": "120", "should_reject": False},
            {"split": "independent_acceptance", "real_report": True, "should_reject": True, "rejected": True},
        ]
        valid_asr = [
            {"split": "independent_acceptance", "real_human": True, "target_microphone": True, "reference": "血压一百二十", "prediction": "血压一百二十", "expected_slots": {"systolic": 120}, "predicted_slots": {"systolic": 120}}
        ]
        with self.assertRaisesRegex(ValueError, "physical bounds"):
            compute_metrics(
                valid_ocr,
                valid_asr,
                [{"measured_on_real_rk3566": True, "latency_ms": -1, "peak_memory_mib": 200, "temperature_c": 50}],
                {"measured_on_real_rk3566": True, "duration_hours": 24, "unrecovered_crashes": 0, "memory_growth_mib": 3},
                {"offline_operation": "PASS"},
            )
        with self.assertRaisesRegex(ValueError, "soak evidence is outside"):
            compute_metrics(
                valid_ocr,
                valid_asr,
                [{"measured_on_real_rk3566": True, "latency_ms": 10, "peak_memory_mib": 200, "temperature_c": 50}],
                {"measured_on_real_rk3566": True, "duration_hours": 24, "unrecovered_crashes": -1, "memory_growth_mib": 3},
                {"offline_operation": "PASS"},
            )


if __name__ == "__main__":
    unittest.main()
