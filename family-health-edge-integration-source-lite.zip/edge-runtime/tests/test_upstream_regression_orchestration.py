from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from scripts.verify_upstream_regressions import console_json, pytest_targets, shard_timeout


class UpstreamRegressionOrchestrationTests(unittest.TestCase):
    def test_health_targets_are_all_discovered_in_stable_order(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            tests = root / "tests"
            tests.mkdir()
            (tests / "test_z.py").write_text("", encoding="utf-8")
            (tests / "test_a.py").write_text("", encoding="utf-8")
            (tests / "helper.py").write_text("", encoding="utf-8")
            self.assertEqual(
                pytest_targets(root, True),
                [Path("tests/test_a.py"), Path("tests/test_z.py")],
            )

    def test_unsharded_project_runs_the_complete_suite(self):
        self.assertEqual(pytest_targets(Path("unused"), False), [None])

    def test_only_profiled_product_acceptance_gets_extended_timeout(self):
        self.assertEqual(shard_timeout(Path("tests/test_product_acceptance.py")), 360)
        self.assertEqual(shard_timeout(Path("tests/test_modeling.py")), 240)
        self.assertEqual(shard_timeout(None), 240)

    def test_console_json_is_safe_for_legacy_windows_code_pages(self):
        rendered = console_json({"unicode": "\u0123", "chinese": "健康"})
        rendered.encode("ascii")
        self.assertIn("\\u0123", rendered)
        self.assertIn("\\u5065\\u5eb7", rendered)
