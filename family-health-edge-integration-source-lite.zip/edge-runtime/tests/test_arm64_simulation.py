from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from scripts.run_arm64_simulation_loop import (
    ROOT, TEST_FILES, decode_output, image_inspect_arguments, local_endpoint,
    pinned_repository_digest, public_reason, stage_context, validate_guest,
    validate_recovery_smoke, verified_runtime_tool,
)
from simulation.guest_probe import architecture_valid
from scripts.verify_simulation_evidence import evaluate


class Arm64SimulationTests(unittest.TestCase):
    def test_host_architecture_cannot_be_accepted_as_arm64(self):
        self.assertTrue(architecture_valid('Linux', 'aarch64', 64))
        self.assertFalse(architecture_valid('Windows', 'ARM64', 64))
        self.assertFalse(architecture_valid('Linux', 'x86_64', 64))
        self.assertFalse(architecture_valid('Linux', 'aarch64', 32))

    def test_remote_docker_is_refused(self):
        for endpoint in ('ssh://server', 'tcp://192.0.2.1:2375', 'https://example.com',
                         'npipe:////remote-server/pipe/docker_engine'):
            self.assertFalse(local_endpoint(endpoint))
        self.assertTrue(local_endpoint('unix:///var/run/docker.sock'))
        self.assertTrue(local_endpoint('npipe:////./pipe/dockerDesktopLinuxEngine'))

    def test_context_contains_only_code_and_explicit_fixture_tests(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            hashes = stage_context(ROOT, root)
            self.assertIn('health_rules/engine.py', hashes)
            self.assertIn('runtime_backends/registry.py', hashes)
            files = [p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()]
            self.assertTrue(all(
                name == 'Dockerfile'
                or name.endswith(('.py', '.json', '.sh', 'family-health-edge-tool'))
                for name in files
            ))
            self.assertFalse(any('.venv' in name or '/data/' in name or '/models/' in name for name in files))
            self.assertIn('app/scripts/recover_pending_activation.sh', files)
            self.assertIn('app/scripts/promote_release.py', files)
            self.assertIn('app/scripts/verify_release.py', files)
            self.assertIn('app/tests/linux_activation_recovery_smoke.sh', files)
            self.assertIn('app/tests/test_database_recovery.py', files)
            self.assertIn('app/tools/family-health-edge-tool', files)
            self.assertEqual(json.loads((root / 'app/source_manifest.json').read_text()),
                             {k: v for k, v in hashes.items() if k != 'simulation/Dockerfile'})

    def test_missing_or_inflated_evidence_is_rejected(self):
        valid = dict(system='Linux', machine='aarch64', bits=64,
                     status='PASS_ARM64_SOFTWARE', simulated=True, hardware_measured=False,
                     product_complete=False, three_model_inference_verified=False,
                     source_integrity_verified=True, tests_run=46, failures=0, errors=0,
                     skipped=0, test_files=list(TEST_FILES))
        self.assertTrue(validate_guest(valid))
        for key, value in [('machine', 'x86_64'), ('hardware_measured', True),
                           ('product_complete', True), ('tests_run', 0), ('errors', 1),
                           ('source_integrity_verified', False), ('test_files', [])]:
            with self.subTest(key=key):
                self.assertFalse(validate_guest({**valid, key: value}))

    def test_activation_recovery_smoke_cannot_claim_hardware(self):
        valid = {
            'status': 'PASS_ENGINEERING',
            'architecture': 'aarch64',
            'network': 'none',
            'hardware_measured': False,
            'signature_verifier_stubbed': True,
            'interrupted_destination_resume': True,
            'runtime_tool_real_arm64_artifact': True,
            'runtime_tool_hash_verified': True,
            'runtime_tool_activation_real': True,
        }
        self.assertTrue(validate_recovery_smoke(valid))
        self.assertFalse(validate_recovery_smoke({**valid, 'hardware_measured': True}))

    def test_runtime_tool_is_hash_bound_to_independent_verification(self):
        artifact, record = verified_runtime_tool(ROOT)

        self.assertTrue(artifact.is_file())
        self.assertEqual(64, len(record['sha256']))

    def test_windows_wsl_utf16_output_is_readable(self):
        content = '需要管理员权限\r\n'
        self.assertEqual(decode_output(content.encode('utf-16-le')), content)

    def test_multi_platform_image_inspection_selects_arm64_manifest(self):
        self.assertEqual(
            image_inspect_arguments('python:example'),
            ['image', 'inspect', '--platform', 'linux/arm64', 'python:example'],
        )

    def test_public_error_codes_keep_digits_but_hide_arbitrary_text(self):
        self.assertEqual(public_reason(ValueError('BASE_IMAGE_NOT_ARM64_LINUX')),
                         'BASE_IMAGE_NOT_ARM64_LINUX')
        self.assertEqual(public_reason(ValueError('unexpected path C:/private')),
                         'INVALID_ENVIRONMENT_OR_EVIDENCE')

    def test_candidate_reference_uses_repository_digest(self):
        digest = 'family-health-arm64-simulation@sha256:' + 'a' * 64
        self.assertEqual(pinned_repository_digest([digest]), digest)
        self.assertIsNone(pinned_repository_digest(['tag:mutable', 'sha256:' + 'b' * 64]))

    def test_missing_evidence_cannot_pass_verification(self):
        errors = evaluate({})
        self.assertIn('SOURCE_HASHES_MISSING', errors)
        self.assertIn('SIMULATION_PROVENANCE_MISSING', errors)
        self.assertIn('STAGED_CONTEXT_HOST_TESTS_NOT_PASS', errors)

    def test_latest_s1_evidence_is_independently_verifiable(self):
        latest = json.loads(
            (ROOT / 'reports/arm64_simulation_latest.json').read_text(encoding='utf-8')
        )

        self.assertEqual([], evaluate(latest))


if __name__ == '__main__':
    unittest.main()
