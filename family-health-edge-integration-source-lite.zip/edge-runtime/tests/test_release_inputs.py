from __future__ import annotations

import hashlib
import io
import json
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path, PurePosixPath
from unittest.mock import patch

from release_tools import (
    BundleVerification,
    ReleaseInputError,
    ReleaseInputFile,
    approved_public_key,
    controlled_release_path,
    copy_verified_release_input,
    validate_product_release_contents,
    validate_product_runtime_bundle,
    validate_release_inputs,
)
from scripts import build_release, promote_release


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class ReleaseInputTests(unittest.TestCase):
    def payload(self, content: bytes) -> dict:
        return {
            "schema_version": "1.0.0",
            "frozen": True,
            "release_id": "v2.0.0",
            "previous_release_id": "v1.0.0",
            "database_rollback_compatible": True,
            "files": [
                {
                    "source": "source.bin",
                    "destination": "bin/family-health-edge",
                    "sha256": digest(content),
                }
            ],
        }

    def test_validated_copy_is_rehashed_after_copy(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            content = b"trusted-release-input"
            (root / "source.bin").write_bytes(content)
            item = validate_release_inputs(self.payload(content), root)[0]
            staging = root / "staging"
            staging.mkdir()
            target = copy_verified_release_input(item, staging)
            self.assertEqual(target.read_bytes(), content)

    def test_product_release_requires_runtime_models_and_audit_content(self) -> None:
        incomplete = (
            ReleaseInputFile(Path("source"), PurePosixPath("bin/family-health-edge"), "0" * 64, 1),
        )
        with self.assertRaisesRegex(
            ReleaseInputError, "PRODUCT_REQUIRED_FILE_MISSING"
        ):
            validate_product_release_contents(incomplete)

        from release_tools.bundle import REQUIRED_PRODUCT_FILES, REQUIRED_PRODUCT_PREFIXES

        destinations = set(REQUIRED_PRODUCT_FILES)
        destinations.update(f"{prefix}artifact" for prefix in REQUIRED_PRODUCT_PREFIXES)
        complete = tuple(
            ReleaseInputFile(Path("source"), PurePosixPath(path), "0" * 64, 1)
            for path in destinations
        )
        validate_product_release_contents(complete)

        forbidden = complete + (
            ReleaseInputFile(
                Path("source"),
                PurePosixPath("lib/__pycache__/runtime.pyc"),
                "0" * 64,
                1,
            ),
        )
        with self.assertRaisesRegex(ReleaseInputError, "PRODUCT_FORBIDDEN_CONTENT"):
            validate_product_release_contents(forbidden)

    def test_product_runtime_bundle_cannot_be_an_empty_signed_shell(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "configs").mkdir()
            with self.assertRaisesRegex(
                ReleaseInputError, "PRODUCT_RUNTIME_BUNDLE_INVALID"
            ):
                validate_product_runtime_bundle(root)

    def test_copy_time_tampering_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            content = b"trusted-release-input"
            (root / "source.bin").write_bytes(content)
            item = validate_release_inputs(self.payload(content), root)[0]
            staging = root / "staging"
            staging.mkdir()

            def tamper(_source: Path, target: Path) -> None:
                Path(target).write_bytes(b"changed-during-copy")

            with patch("release_tools.inputs.shutil.copy2", side_effect=tamper):
                with self.assertRaisesRegex(
                    ReleaseInputError, "COPIED_RELEASE_INPUT_HASH_MISMATCH"
                ):
                    copy_verified_release_input(item, staging)

    def test_path_escape_duplicate_and_unknown_fields_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            content = b"trusted-release-input"
            (root / "source.bin").write_bytes(content)
            payload = self.payload(content)
            payload["files"][0]["destination"] = "../escape"
            with self.assertRaisesRegex(ReleaseInputError, "DESTINATION_UNSAFE"):
                validate_release_inputs(payload, root)
            payload = self.payload(content)
            payload["files"] *= 2
            with self.assertRaisesRegex(ReleaseInputError, "DESTINATION_UNSAFE_OR_DUPLICATE"):
                validate_release_inputs(payload, root)
            payload = self.payload(content)
            payload["unexpected"] = True
            with self.assertRaisesRegex(ReleaseInputError, "SCHEMA_INVALID"):
                validate_release_inputs(payload, root)

    def test_symlink_source_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            target = root / "target.bin"
            target.write_bytes(b"trusted-release-input")
            source = root / "source.bin"
            try:
                source.symlink_to(target)
            except OSError:
                self.skipTest("symlink creation is unavailable on this host")
            with self.assertRaisesRegex(ReleaseInputError, "SOURCE_MISSING_OR_UNSAFE"):
                validate_release_inputs(self.payload(target.read_bytes()), root)

    def test_release_output_is_a_validated_direct_child(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            expected = root / "release_candidates" / "v2.0.0"
            self.assertEqual(
                controlled_release_path(root, "release_candidates", "v2.0.0"),
                expected,
            )
            for invalid in (
                "../outside",
                "nested/release",
                "",
                ".",
                "..",
                "-option",
                "hidden_",
                "x" * 81,
            ):
                with self.subTest(invalid=invalid):
                    with self.assertRaisesRegex(ReleaseInputError, "RELEASE_ID_INVALID"):
                        controlled_release_path(root, "release_candidates", invalid)
            with self.assertRaisesRegex(ReleaseInputError, "COLLECTION_INVALID"):
                controlled_release_path(root, "uncontrolled", "v2.0.0")

    def test_release_collection_and_target_symlinks_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            outside = root / "outside"
            outside.mkdir()
            collection = root / "release_candidates"
            try:
                collection.symlink_to(outside, target_is_directory=True)
            except OSError:
                self.skipTest("symlink creation is unavailable on this host")
            with self.assertRaisesRegex(ReleaseInputError, "COLLECTION_REDIRECT"):
                controlled_release_path(root, "release_candidates", "v2.0.0")

            collection.unlink()
            collection.mkdir()
            target = collection / "v2.0.0"
            target.symlink_to(outside, target_is_directory=True)
            with self.assertRaisesRegex(ReleaseInputError, "TARGET_REDIRECT"):
                controlled_release_path(root, "release_candidates", "v2.0.0")

    def test_source_directory_redirect_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            content = b"trusted-release-input"
            (root / "source.bin").write_bytes(content)
            with patch(
                "release_tools.inputs.has_redirected_component", return_value=True
            ):
                with self.assertRaisesRegex(
                    ReleaseInputError, "SOURCE_MISSING_OR_UNSAFE"
                ):
                    validate_release_inputs(self.payload(content), root)

    def test_promotion_cli_rejects_unsafe_id_before_gate_or_filesystem_access(self) -> None:
        output = io.StringIO()
        with patch.object(
            sys,
            "argv",
            ["promote_release.py", "--release-id", "..", "--public-key", "missing.pem"],
        ), redirect_stdout(output):
            self.assertEqual(promote_release.main(), 2)
        self.assertIn("RELEASE_ID_INVALID", output.getvalue())

    def test_approved_public_key_rejects_caller_key_substitution(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            configs = root / "configs"
            keys = root / "keys"
            configs.mkdir()
            keys.mkdir()
            approved = keys / "release-public.pem"
            approved.write_bytes(b"approved-public-key")
            unapproved = root / "unapproved.pem"
            unapproved.write_bytes(b"unapproved-public-key")
            (configs / "signing_policy.json").write_text(
                json.dumps(
                    {
                        "schema_version": "1.0.0",
                        "approval_status": "APPROVED",
                        "algorithm": "RSA_SHA256_OPENSSL_DGST",
                        "trusted_public_key_file": "keys/release-public.pem",
                        "trusted_public_key_sha256": digest(approved.read_bytes()),
                        "private_key_on_device_forbidden": True,
                    }
                ),
                encoding="utf-8",
            )

            self.assertEqual(approved_public_key(root, approved), approved.resolve())
            with self.assertRaisesRegex(
                ReleaseInputError, "PROMOTION_PUBLIC_KEY_NOT_APPROVED"
            ):
                approved_public_key(root, unapproved)

    def test_promotion_cli_cannot_substitute_an_unapproved_signing_key(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            configs = root / "configs"
            configs.mkdir()
            approved = root / "approved.pem"
            approved.write_bytes(b"approved-public-key")
            unapproved = root / "unapproved.pem"
            unapproved.write_bytes(b"unapproved-public-key")
            (configs / "signing_policy.json").write_text(
                json.dumps(
                    {
                        "schema_version": "1.0.0",
                        "approval_status": "APPROVED",
                        "algorithm": "RSA_SHA256_OPENSSL_DGST",
                        "trusted_public_key_file": "approved.pem",
                        "trusted_public_key_sha256": digest(approved.read_bytes()),
                        "private_key_on_device_forbidden": True,
                    }
                ),
                encoding="utf-8",
            )
            candidate = root / "release_candidates" / "v2.0.0"
            destination = root / "release" / "v2.0.0"
            output = io.StringIO()
            with (
                patch.object(
                    sys,
                    "argv",
                    [
                        "promote_release.py",
                        "--release-id",
                        "v2.0.0",
                        "--public-key",
                        str(unapproved),
                    ],
                ),
                patch.object(promote_release, "ROOT", root),
                patch.object(
                    promote_release,
                    "controlled_release_path",
                    side_effect=[candidate, destination],
                ),
                redirect_stdout(output),
            ):
                self.assertEqual(promote_release.main(), 2)

            self.assertIn("PROMOTION_PUBLIC_KEY_NOT_APPROVED", output.getvalue())

    def test_candidate_copy_failure_is_reported_and_staging_is_removed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            report = root / "reports" / "release_build.json"
            (root / "configs").mkdir()
            (root / "configs" / "release_inputs.json").write_text(
                json.dumps(
                    {
                        "release_id": "v2.0.0",
                        "previous_release_id": "v1.0.0",
                        "database_rollback_compatible": True,
                    }
                ),
                encoding="utf-8",
            )
            destination = root / "release_candidates" / "v2.0.0"
            formal = {
                "release_allowed": False,
                "formal_release_verified": False,
                "blockers": [],
            }
            with (
                patch.object(build_release, "ROOT", root),
                patch.object(build_release, "REPORT", report),
                patch("scripts.verify_release.evaluate", return_value=formal),
                patch.object(build_release, "validate_release_inputs", return_value=(object(),)),
                patch.object(build_release, "validate_product_release_contents"),
                patch.object(build_release, "controlled_release_path", return_value=destination),
                patch.object(
                    build_release,
                    "copy_verified_release_input",
                    side_effect=ReleaseInputError("COPIED_RELEASE_INPUT_HASH_MISMATCH"),
                ),
                redirect_stdout(io.StringIO()),
            ):
                self.assertEqual(build_release.main(), 2)

            result = json.loads(report.read_text(encoding="utf-8"))
            self.assertEqual(result["status"], "BLOCKED_FAIL_CLOSED")
            self.assertEqual(
                result["blockers"],
                [
                    "PRODUCT_RELEASE_BUILD_INVALID:"
                    "COPIED_RELEASE_INPUT_HASH_MISMATCH"
                ],
            )
            candidates = root / "release_candidates"
            self.assertEqual(list(candidates.iterdir()), [])

    def test_promotion_rejects_signed_bundle_with_invalid_product_runtime(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            candidate = root / "release_candidates" / "v2.0.0"
            destination = root / "release" / "v2.0.0"
            candidate.mkdir(parents=True)
            output = io.StringIO()
            with (
                patch.object(
                    sys,
                    "argv",
                    [
                        "promote_release.py",
                        "--release-id",
                        "v2.0.0",
                        "--public-key",
                        str(root / "public.pem"),
                    ],
                ),
                patch.object(
                    promote_release,
                    "controlled_release_path",
                    side_effect=[candidate, destination],
                ),
                patch.object(
                    promote_release,
                    "evaluate",
                    return_value={"blockers": []},
                ),
                patch.object(
                    promote_release,
                    "approved_public_key",
                    return_value=root / "public.pem",
                ),
                patch.object(
                    promote_release,
                    "verify_product_release_bundle",
                    return_value=BundleVerification(
                        False,
                        "v2.0.0",
                        (
                            "PRODUCT_RUNTIME_BUNDLE_INVALID:"
                            "PRODUCT_RUNTIME_BUNDLE_INVALID",
                        ),
                        4,
                        True,
                    ),
                ),
                redirect_stdout(output),
            ):
                self.assertEqual(promote_release.main(), 2)

            self.assertTrue(candidate.is_dir())
            self.assertFalse(destination.exists())
            self.assertIn("PRODUCT_RUNTIME_BUNDLE_INVALID", output.getvalue())
