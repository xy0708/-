from __future__ import annotations

import copy
import math
import unittest
from datetime import datetime, timezone

from health_rules import RuleInputError, evaluate_payload, load_rule_config
from health_rules.engine import DISCLAIMER, MAX_HISTORY_PER_MEASUREMENT, MAX_MEASUREMENTS


NOW = datetime(2026, 8, 25, tzinfo=timezone.utc)


def measurement(**overrides):
    value = {
        "metric": "fasting_glucose",
        "value": 6.1,
        "unit": "mmol/L",
        "measured_at": "2026-08-24T08:00:00+08:00",
        "confirmed": True,
        "reference_low": 3.9,
        "reference_high": 6.0,
        "reference_source": "fixture_reference_only",
    }
    value.update(overrides)
    return value


class HealthRulesTests(unittest.TestCase):
    def setUp(self) -> None:
        self.config = load_rule_config()

    def evaluate(self, item):
        return evaluate_payload(
            {"confirmed": True, "measurements": [item]}, self.config, now=NOW
        )

    def test_product_chinese_disclaimer_is_valid_utf8_text(self) -> None:
        self.assertIn("家庭健康管理提示", DISCLAIMER)
        self.assertIn("不构成医疗诊断", DISCLAIMER)
        self.assertNotIn("\ufffd", DISCLAIMER)

    def test_above_provided_reference_is_attention_not_diagnosis(self) -> None:
        result = self.evaluate(measurement())
        self.assertEqual(result["attention_level"], "ATTENTION")
        self.assertIsNone(result["disease_probability"])
        self.assertIsNone(result["diagnosis"])
        self.assertFalse(result["product_release_allowed"])
        codes = {item["code"] for item in result["measurements"][0]["triggers"]}
        self.assertIn("ABOVE_PROVIDED_REFERENCE", codes)

    def test_missing_reference_never_claims_normal(self) -> None:
        result = self.evaluate(
            measurement(reference_low=None, reference_high=None, value=5.0)
        )
        item = result["measurements"][0]
        self.assertEqual(result["attention_level"], "NO_RULE_TRIGGERED")
        self.assertIn("REFERENCE_RANGE_MISSING", item["warnings"])
        self.assertTrue(item["no_rule_triggered_is_not_proof_of_health"])

    def test_mg_dl_is_converted_with_reference_range(self) -> None:
        result = self.evaluate(
            measurement(value=108, unit="mg/dL", reference_low=70, reference_high=100)
        )
        item = result["measurements"][0]
        self.assertAlmostEqual(item["value"], 5.994, places=3)
        self.assertEqual(item["unit"], "mmol/L")
        self.assertAlmostEqual(item["reference_high"], 5.55, places=3)

    def test_unconfirmed_input_is_rejected(self) -> None:
        with self.assertRaises(RuleInputError) as raised:
            self.evaluate(measurement(confirmed=False))
        self.assertEqual(raised.exception.code, "TASK_NOT_CONFIRMED")

    def test_invalid_reference_interval_is_rejected(self) -> None:
        with self.assertRaises(RuleInputError) as raised:
            self.evaluate(measurement(reference_low=7.0, reference_high=6.0))
        self.assertEqual(raised.exception.code, "INPUT_INVALID")

    def test_nan_and_unknown_unit_are_rejected(self) -> None:
        for item, code in (
            (measurement(value=math.nan), "INPUT_INVALID"),
            (measurement(unit="unknown"), "INPUT_UNIT_UNSUPPORTED"),
        ):
            with self.subTest(item=item):
                with self.assertRaises(RuleInputError) as raised:
                    self.evaluate(item)
                self.assertEqual(raised.exception.code, code)

    def test_future_timestamp_is_rejected(self) -> None:
        with self.assertRaises(RuleInputError) as raised:
            self.evaluate(measurement(measured_at="2026-08-26T00:00:00+00:00"))
        self.assertEqual(raised.exception.code, "INPUT_INVALID")

    def test_trend_capability_requires_explicit_threshold(self) -> None:
        configured = copy.deepcopy(self.config)
        configured["metrics"]["weight"]["trend"]["relative_change_threshold"] = 0.1
        item = {
            "metric": "weight",
            "value": 80,
            "unit": "kg",
            "measured_at": "2026-08-24T08:00:00+08:00",
            "confirmed": True,
            "history": [
                {"value": 70, "unit": "kg", "confirmed": True},
                {"value": 70, "unit": "kg", "confirmed": True},
                {"value": 70, "unit": "kg", "confirmed": True},
            ],
        }
        result = evaluate_payload(
            {"confirmed": True, "measurements": [item]}, configured, now=NOW
        )
        codes = {trigger["code"] for trigger in result["measurements"][0]["triggers"]}
        self.assertIn("PERSONAL_TREND_CHANGE", codes)

    def test_measurement_and_history_resource_limits(self) -> None:
        item = measurement(reference_low=None, reference_high=None)
        with self.assertRaises(RuleInputError) as too_many:
            evaluate_payload(
                {"confirmed": True, "measurements": [item] * (MAX_MEASUREMENTS + 1)},
                self.config,
                now=NOW,
            )
        self.assertEqual(too_many.exception.code, "INPUT_OUT_OF_RANGE")
        with self.assertRaises(RuleInputError) as too_much_history:
            self.evaluate(
                measurement(
                    history=[{"value": 6.0, "unit": "mmol/L", "confirmed": True}]
                    * (MAX_HISTORY_PER_MEASUREMENT + 1)
                )
            )
        self.assertEqual(too_much_history.exception.code, "INPUT_OUT_OF_RANGE")


if __name__ == "__main__":
    unittest.main()
