from __future__ import annotations

import base64
import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from ocr_runtime.rknn_worker import (
    ModelIntegrityError,
    Recognition,
    WorkerAssets,
    WorkerProtocolError,
    assert_rk3566_host,
    execute_task,
    load_and_verify_manifest,
    read_request,
)
from scripts.verify_ocr_rknn_worker import verify_worker


PNG = b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + (2).to_bytes(4, "big") + (3).to_bytes(4, "big")


class FakeEngine:
    def recognize(self, image_bytes: bytes) -> list[Recognition]:
        if image_bytes != PNG:
            raise AssertionError("unexpected image")
        return [
            Recognition(
                "血压 138/86",
                0.91,
                [[1.0, 2.0], [20.0, 2.0], [20.0, 9.0], [1.0, 9.0]],
            )
        ]

    def close(self) -> None:
        return None


def write_file(root: Path, relative: str, content: bytes) -> dict[str, object]:
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    return {
        "path": relative,
        "bytes": len(content),
        "sha256": hashlib.sha256(content).hexdigest(),
    }


def create_manifest(root: Path) -> Path:
    det = write_file(root, "models/det.rknn", b"detector")
    rec = write_file(root, "models/rec.rknn", b"recognizer")
    dictionary = write_file(root, "post/model/keys.txt", b"a\nb\n")
    init = write_file(root, "post/python/utils/__init__.py", b"")
    db = write_file(root, "post/python/utils/db_postprocess.py", b"db")
    operators = write_file(root, "post/python/utils/operators.py", b"operators")
    rec_post = write_file(root, "post/python/utils/rec_postprocess.py", b"rec")
    bundle = hashlib.sha256(b"detector" + b"recognizer").hexdigest()
    payload = {
        "schema_version": "1.0.0",
        "status": "ENGINEERING_WORKER_IMPLEMENTED_PRODUCT_BLOCKED",
        "target": "rk3566",
        "runtime_name": "rknn_toolkit_lite2",
        "runtime_version": "2.3.2",
        "source_commit": "a" * 40,
        "model_bundle_sha256": bundle,
        "product_accepted": False,
        "hardware_validated": False,
        "license_approved": False,
        "postprocess_root": "post/python",
        "pipeline": {
            "det_input_height": 480,
            "det_input_width": 480,
            "rec_input_height": 48,
            "rec_input_width": 320,
            "det_threshold": 0.3,
            "box_threshold": 0.6,
            "max_candidates": 1000,
            "unclip_ratio": 1.5,
            "use_dilation": False,
            "score_mode": "fast",
            "drop_score": 0.5,
        },
        "files": {
            "detector": det,
            "recognizer": rec,
            "dictionary": dictionary,
            "postprocess_init": init,
            "db_postprocess": db,
            "operators": operators,
            "rec_postprocess": rec_post,
        },
    }
    manifest = root / "worker.json"
    manifest.write_text(json.dumps(payload), encoding="utf-8")
    return manifest


class OcrRknnWorkerTests(unittest.TestCase):
    def test_actual_engineering_worker_is_integrity_locked_and_product_blocked(self) -> None:
        result = verify_worker()
        self.assertEqual(
            result["status"],
            "PASS_ENGINEERING_WORKER_ARCHIVED_PRODUCT_BLOCKED",
            result["errors"],
        )
        self.assertTrue(result["engineering_worker_implemented"])
        self.assertTrue(result["assets_archived_outside_product_tree"])
        self.assertFalse(result["backend_selectable"])
        self.assertFalse(result["real_rk3566_verified"])
        self.assertFalse(result["product_ready"])

    def test_manifest_checks_model_bundle_and_every_support_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            manifest = create_manifest(root)
            assets = load_and_verify_manifest(root, manifest)
            self.assertEqual(
                assets.manifest["model_bundle_sha256"],
                hashlib.sha256(b"detector" + b"recognizer").hexdigest(),
            )
            (root / "post/python/utils/operators.py").write_bytes(b"tampered")
            with self.assertRaises(ModelIntegrityError):
                load_and_verify_manifest(root, manifest)

    def test_task_request_is_json_safe_bounded_and_confirmation_required(self) -> None:
        digest = hashlib.sha256(PNG).hexdigest()
        manifest = {"model_bundle_sha256": "f" * 64}
        assets = WorkerAssets(manifest=manifest, files={})
        request = {
            "op": "create_task",
            "member_id": "member-1",
            "payload": {
                "media_type": "image/png",
                "image_base64": base64.b64encode(PNG).decode("ascii"),
                "sha256": digest,
            },
        }
        result = execute_task(request, assets, FakeEngine())
        self.assertEqual(result["full_text"], "血压 138/86")
        self.assertEqual(result["input_sha256"], digest)
        self.assertTrue(result["requires_confirmation"])
        self.assertNotIn("image", result)
        json.dumps(result, ensure_ascii=False, allow_nan=False)

    def test_request_framing_and_hash_mismatch_fail_closed(self) -> None:
        self.assertEqual(read_request(io.BytesIO(b'{"op":"health"}\n'))["op"], "health")
        with self.assertRaises(WorkerProtocolError):
            read_request(io.BytesIO(b'{"op":"health"}'))
        request = {
            "op": "create_task",
            "member_id": "member-1",
            "payload": {
                "media_type": "image/png",
                "image_base64": base64.b64encode(PNG).decode("ascii"),
                "sha256": "0" * 64,
            },
        }
        with self.assertRaises(ModelIntegrityError):
            execute_task(
                request,
                WorkerAssets({"model_bundle_sha256": "f" * 64}, {}),
                FakeEngine(),
            )

    def test_target_guard_rejects_non_rk3566_hosts(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            compatible = Path(temporary) / "compatible"
            compatible.write_bytes(b"rockchip,rk3566\x00")
            assert_rk3566_host("aarch64", compatible, "Linux")
            compatible.write_bytes(b"rockchip,rk3588\x00")
            with self.assertRaises(RuntimeError):
                assert_rk3566_host("aarch64", compatible, "Linux")
            with self.assertRaises(RuntimeError):
                assert_rk3566_host("x86_64", compatible, "Linux")


if __name__ == "__main__":
    unittest.main()
