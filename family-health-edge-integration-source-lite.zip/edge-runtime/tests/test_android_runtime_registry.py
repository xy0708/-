from __future__ import annotations

import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class AndroidRuntimeRegistryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.registry = json.loads(
            (ROOT / "configs" / "android_runtime_registry.json").read_text(
                encoding="utf-8"
            )
        )

    def test_only_implemented_android_runtimes_are_marked_packaged(self) -> None:
        runtimes = self.registry["runtimes"]
        self.assertTrue(runtimes["health"]["packaged_in_debug_apk"])
        self.assertFalse(runtimes["ocr"]["packaged_in_debug_apk"])
        self.assertTrue(runtimes["asr"]["packaged_in_debug_apk"])
        self.assertEqual(
            runtimes["asr"]["status"],
            "ENGINEERING_PACKAGED_NOT_EXECUTED_ANDROID",
        )

    def test_incomplete_runtime_set_blocks_release(self) -> None:
        self.assertFalse(self.registry["all_three_android_runtimes_ready"])
        self.assertFalse(self.registry["formal_release_allowed"])
        for runtime in self.registry["runtimes"].values():
            self.assertFalse(runtime["product_enabled"])


if __name__ == "__main__":
    unittest.main()
