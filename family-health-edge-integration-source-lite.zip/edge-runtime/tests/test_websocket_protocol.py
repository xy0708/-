from __future__ import annotations

import base64
import io
import unittest

from device_service.websocket import (
    WebSocketProtocolError,
    read_client_frame,
    websocket_accept,
    write_server_frame,
    encode_client_frame,
    read_server_frame,
)


def masked_frame(opcode: int, payload: bytes, mask: bytes = b"abcd") -> bytes:
    if len(payload) >= 126:
        header = bytes([0x80 | opcode, 0x80 | 126]) + len(payload).to_bytes(2, "big")
    else:
        header = bytes([0x80 | opcode, 0x80 | len(payload)])
    encoded = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
    return header + mask + encoded


class ShortReadStream(io.BytesIO):
    def read(self, size: int = -1) -> bytes:
        if size > 1:
            size = 1
        return super().read(size)


class WebSocketProtocolTests(unittest.TestCase):
    def test_rfc_accept_and_masked_client_frame(self) -> None:
        key = base64.b64encode(b"0123456789abcdef").decode("ascii")
        self.assertTrue(websocket_accept(key))
        opcode, payload = read_client_frame(
            io.BytesIO(masked_frame(0x1, b'{"type":"start"}')),
            max_payload_bytes=1024,
        )
        self.assertEqual(opcode, 0x1)
        self.assertEqual(payload, b'{"type":"start"}')

    def test_unmasked_or_oversized_client_frame_is_rejected(self) -> None:
        with self.assertRaises(WebSocketProtocolError):
            read_client_frame(io.BytesIO(b"\x81\x01x"), max_payload_bytes=10)
        with self.assertRaises(WebSocketProtocolError):
            read_client_frame(
                io.BytesIO(masked_frame(0x2, b"x" * 20)), max_payload_bytes=10
            )

    def test_server_frames_are_unmasked(self) -> None:
        stream = io.BytesIO()
        write_server_frame(stream, 0x1, b"ok")
        self.assertEqual(stream.getvalue(), b"\x81\x02ok")
        opcode, payload = read_server_frame(io.BytesIO(stream.getvalue()), max_payload_bytes=10)
        self.assertEqual((opcode, payload), (0x1, b"ok"))

    def test_client_encoder_always_masks(self) -> None:
        encoded = encode_client_frame(0x2, b"pcm")
        self.assertTrue(encoded[1] & 0x80)
        opcode, payload = read_client_frame(io.BytesIO(encoded), max_payload_bytes=10)
        self.assertEqual((opcode, payload), (0x2, b"pcm"))

    def test_short_stream_reads_are_reassembled(self) -> None:
        encoded = masked_frame(0x2, b"pcm")
        opcode, payload = read_client_frame(ShortReadStream(encoded), max_payload_bytes=10)
        self.assertEqual((opcode, payload), (0x2, b"pcm"))

    def test_reserved_bits_and_noncanonical_lengths_are_rejected(self) -> None:
        reserved = bytearray(masked_frame(0x1, b"x"))
        reserved[0] |= 0x40
        with self.assertRaisesRegex(WebSocketProtocolError, "reserved"):
            read_client_frame(io.BytesIO(reserved), max_payload_bytes=1024)

        mask = b"abcd"
        noncanonical = b"\x81\xfe\x00\x01" + mask + bytes([ord("x") ^ mask[0]])
        with self.assertRaisesRegex(WebSocketProtocolError, "noncanonical"):
            read_client_frame(io.BytesIO(noncanonical), max_payload_bytes=1024)

    def test_control_frames_and_opcodes_are_strictly_bounded(self) -> None:
        with self.assertRaisesRegex(WebSocketProtocolError, "control"):
            read_client_frame(
                io.BytesIO(masked_frame(0x9, b"x" * 126)), max_payload_bytes=1024
            )
        with self.assertRaisesRegex(WebSocketProtocolError, "opcode"):
            read_client_frame(io.BytesIO(masked_frame(0x3, b"x")), max_payload_bytes=1024)
        with self.assertRaisesRegex(WebSocketProtocolError, "control"):
            write_server_frame(io.BytesIO(), 0x9, b"x" * 126)
        with self.assertRaisesRegex(WebSocketProtocolError, "opcode"):
            encode_client_frame(0x3, b"x")

    def test_close_frames_require_valid_status_and_utf8_reason(self) -> None:
        for payload in (
            b"x",
            (999).to_bytes(2, "big"),
            (1005).to_bytes(2, "big"),
            (2000).to_bytes(2, "big"),
            (1000).to_bytes(2, "big") + b"\xff",
        ):
            with self.subTest(payload=payload):
                with self.assertRaisesRegex(WebSocketProtocolError, "close"):
                    read_client_frame(
                        io.BytesIO(masked_frame(0x8, payload)), max_payload_bytes=1024
                    )
        valid = (1000).to_bytes(2, "big") + "完成".encode("utf-8")
        self.assertEqual(
            read_client_frame(io.BytesIO(masked_frame(0x8, valid)), max_payload_bytes=1024),
            (0x8, valid),
        )


if __name__ == "__main__":
    unittest.main()
