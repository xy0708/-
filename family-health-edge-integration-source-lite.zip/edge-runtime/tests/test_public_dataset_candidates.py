from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path

from scripts.verify_public_dataset_candidates import download_evidence, validate_policy


ROOT = Path(__file__).resolve().parents[1]


def load_policy() -> dict:
    return json.loads(
        (ROOT / "configs" / "public_dataset_candidates.json").read_text(
            encoding="utf-8"
        )
    )


def candidate(payload: dict, candidate_id: str) -> dict:
    return next(item for item in payload["candidates"] if item["id"] == candidate_id)


class PublicDatasetCandidateTests(unittest.TestCase):
    def test_current_policy_is_fail_closed_and_valid(self):
        self.assertEqual(validate_policy(load_policy()), [])

    def test_charls_cannot_be_reenabled(self):
        payload = copy.deepcopy(load_policy())
        candidate(payload, "charls")["engineering_use_allowed"] = True
        self.assertIn("CHARLS_ENGINEERING_USE_MUST_BE_FALSE", validate_policy(payload))

    def test_noncommercial_dataset_cannot_escape_exclusion(self):
        payload = copy.deepcopy(load_policy())
        candidate(payload, "rjua_meddqa")["status"] = "ENGINEERING_ALLOWED"
        self.assertIn(
            "NONCOMMERCIAL_DATASET_NOT_EXCLUDED:rjua_meddqa",
            validate_policy(payload),
        )

    def test_common_voice_cannot_be_called_target_acceptance_data(self):
        payload = copy.deepcopy(load_policy())
        candidate(payload, "mozilla_common_voice_27_zh_cn")[
            "product_acceptance_evidence_allowed"
        ] = True
        failures = validate_policy(payload)
        self.assertIn(
            "UNSUPPORTED_PRODUCT_ACCEPTANCE_USE:mozilla_common_voice_27_zh_cn",
            failures,
        )
        self.assertIn(
            "COMMON_VOICE_CONTRACT_INVALID:product_acceptance_evidence_allowed",
            failures,
        )

    def test_general_mandarin_candidate_cannot_be_called_product_data(self):
        payload = copy.deepcopy(load_policy())
        candidate(payload, "google_fleurs_cmn_hans_cn")[
            "product_acceptance_evidence_allowed"
        ] = True
        self.assertIn(
            "UNSUPPORTED_PRODUCT_ACCEPTANCE_USE:google_fleurs_cmn_hans_cn",
            validate_policy(payload),
        )

    def test_controlled_health_research_data_cannot_be_called_commercial(self):
        payload = copy.deepcopy(load_policy())
        candidate(payload, "cardioehr")["commercial_product_use_approved"] = True
        self.assertIn(
            "UNSUPPORTED_COMMERCIAL_APPROVAL:cardioehr",
            validate_policy(payload),
        )

    def test_wenetspeech_is_blocked_by_noncommercial_upstream_terms(self):
        payload = load_policy()
        wenetspeech = candidate(payload, "wenetspeech")
        self.assertFalse(wenetspeech["engineering_use_allowed"])
        self.assertTrue(wenetspeech["status"].startswith("EXCLUDED_COMMERCIAL"))

    def test_cc0_human_health_data_is_not_automatically_product_approved(self):
        payload = load_policy()
        for candidate_id in (
            "rich_healthcare_diabetes_dryad",
            "sua_cvd_risk_factors_dryad",
            "sichuan_high_risk_stroke_dryad",
            "beijing_hstnt_cvd_dryad",
        ):
            health_candidate = candidate(payload, candidate_id)
            self.assertFalse(health_candidate["commercial_product_use_approved"])
            self.assertFalse(health_candidate["product_acceptance_evidence_allowed"])

    def test_downloaded_health_datasets_are_hash_verified(self):
        payload = load_policy()
        downloaded = {
            item["id"] for item in payload["candidates"] if item["downloaded"]
        }
        self.assertEqual(
            downloaded,
            {"rich_healthcare_diabetes_dryad", "sua_cvd_risk_factors_dryad"},
        )
        self.assertEqual(payload["downloaded_dataset_count"], len(downloaded))
        evidence = [
            download_evidence(item)
            for item in payload["candidates"]
            if item["downloaded"]
        ]
        self.assertTrue(all(item and item["integrity_verified"] for item in evidence))
        self.assertTrue(all(item and item["size_bytes"] > 0 for item in evidence))

    def test_downloaded_dataset_digest_mismatch_fails_closed(self):
        payload = copy.deepcopy(load_policy())
        candidate(payload, "rich_healthcare_diabetes_dryad")["artifact_digest"] = "0" * 32
        self.assertIn(
            "DOWNLOADED_ARTIFACT_DIGEST_MISMATCH:rich_healthcare_diabetes_dryad",
            validate_policy(payload),
        )

    def test_unregistered_download_claim_fails_closed(self):
        payload = copy.deepcopy(load_policy())
        candidate(payload, "google_fleurs_cmn_hans_cn")["downloaded"] = True
        self.assertIn(
            "DOWNLOADED_ARTIFACT_PATH_MISSING:google_fleurs_cmn_hans_cn",
            validate_policy(payload),
        )


if __name__ == "__main__":
    unittest.main()
