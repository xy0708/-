from __future__ import annotations

import unittest

from scripts.run_arm64_integration_simulation import validate_guest
from scripts.verify_arm64_integration_evidence import evaluate


class Arm64IntegrationSimulationTests(unittest.TestCase):
    def test_guest_requires_real_asr_and_preserves_product_boundaries(self):
        requirements = {"sherpa-onnx": "1.13.7", "sherpa-onnx-core": "1.13.7", "numpy": "2.5.1"}
        valid = {
            "status": "PASS_ASR_DEVICE_SERVICE_INTEGRATION",
            "stage": "S3_ASR_DEVICE_SERVICE_PARTIAL",
            "system": "Linux",
            "machine": "aarch64",
            "bits": 64,
            "simulated": True,
            "hardware_measured": False,
            "product_complete": False,
            "three_model_inference_verified": False,
            "loopback_server_cleaned": True,
            "requirements": requirements,
            "health": {"status": "PASS_REAL_NON_DIAGNOSTIC_RULE_ENGINE", "loopback_http_verified": True, "diagnosis_exposed": False, "disease_probability_exposed": False},
            "asr": {"status": "PASS_REAL_ISOLATED_WORKER_INTEGRATION", "matches_s2_reference": True, "runtime_config_bootstrap_verified": True, "backend_registry_selection_verified": True, "loopback_websocket_verified": True, "raw_audio_persisted": False, "confirmed_record_count": 0, "pending_task_cancelled": True, "product_accepted": False},
            "ocr": {"status": "BLOCKED_EXTERNAL", "real_worker_invoked": False, "test_double_used": False},
        }
        self.assertTrue(validate_guest(valid, requirements))
        self.assertFalse(validate_guest({**valid, "hardware_measured": True}, requirements))
        inflated = {**valid, "ocr": {**valid["ocr"], "test_double_used": True}}
        self.assertFalse(validate_guest(inflated, requirements))

    def test_missing_evidence_cannot_pass(self):
        errors = evaluate({})
        self.assertIn("INTEGRATION_SIMULATION_NOT_PASS", errors)
        self.assertIn("ASR_INTEGRATION_EVIDENCE_INVALID", errors)
        self.assertIn("INTEGRATION_REQUIRED_SOURCE_HASHES_MISSING", errors)


if __name__ == "__main__":
    unittest.main()
