from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path

from scripts.verify_health_ml_candidate import validate_training_lineage


ROOT = Path(__file__).resolve().parents[1]


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def current_inputs() -> tuple[dict, dict, dict, dict, dict]:
    config = read_json(ROOT / "configs" / "health_ml_candidate.json")
    manifest = read_json((ROOT / config["manifest"]).resolve())
    training_report = read_json((ROOT / config["training_report"]).resolve())
    data_manifest = read_json((ROOT / config["data_manifest"]).resolve())
    public_registry = read_json(ROOT / "configs" / "public_dataset_candidates.json")
    return config, manifest, training_report, data_manifest, public_registry


class HealthMlCandidateLineageTests(unittest.TestCase):
    def test_current_training_lineage_is_complete_and_separate(self) -> None:
        self.assertEqual(validate_training_lineage(*current_inputs()), [])

    def test_two_tasks_cannot_reuse_one_source_candidate(self) -> None:
        inputs = list(current_inputs())
        config = copy.deepcopy(inputs[0])
        config["training_lineage"]["ht"]["candidate_id"] = config[
            "training_lineage"
        ]["dm"]["candidate_id"]
        inputs[0] = config
        failures = validate_training_lineage(*inputs)
        self.assertIn("training_lineage_contract_invalid", failures)
        self.assertIn("training_tasks_reuse_same_source_candidate", failures)

    def test_training_report_digest_drift_fails_closed(self) -> None:
        inputs = list(current_inputs())
        training_report = copy.deepcopy(inputs[2])
        training_report["raw_inputs"]["rich_diabetes"]["digest"] = "0" * 32
        inputs[2] = training_report
        self.assertIn(
            "dm:training_report_digest_mismatch",
            validate_training_lineage(*inputs),
        )

    def test_split_fingerprint_reuse_fails_closed(self) -> None:
        inputs = list(current_inputs())
        training_report = copy.deepcopy(inputs[2])
        training_report["tasks"]["ht"]["splits"]["test"][
            "person_id_sha256"
        ] = training_report["tasks"]["ht"]["splits"]["train"][
            "person_id_sha256"
        ]
        inputs[2] = training_report
        self.assertIn("ht:split_fingerprint_reused", validate_training_lineage(*inputs))

    def test_engineering_report_cannot_be_promoted_by_flag_edit(self) -> None:
        inputs = list(current_inputs())
        training_report = copy.deepcopy(inputs[2])
        training_report["product_model"] = True
        inputs[2] = training_report
        self.assertIn(
            "training_report_boundary_invalid:product_model",
            validate_training_lineage(*inputs),
        )


if __name__ == "__main__":
    unittest.main()
