from __future__ import annotations

import copy
import json
import unittest

from scripts.verify_rknn_conversion_reproducibility import (
    ROOT,
    SOURCE_REPORT,
    verify_payload,
    verify_report,
)


class RknnConversionReproducibilityVerificationTests(unittest.TestCase):
    def test_current_replay_is_audited_without_product_overclaim(self) -> None:
        result = verify_report()
        self.assertEqual(
            result["status"],
            "PASS_ENGINEERING_REPLAY_AUDIT_PRODUCT_BLOCKED",
            result["errors"],
        )
        self.assertEqual(result["conversion_success_count"], 5)
        self.assertEqual(result["byte_reproduced_count"], 2)
        self.assertEqual(result["hash_drift_count"], 3)
        self.assertEqual(result["byte_reproducibility_state"], "PARTIAL")
        self.assertFalse(result["hardware_measured"])
        self.assertFalse(result["product_selected"])
        self.assertFalse(result["formal_release_allowed"])

    def test_networked_replay_command_is_rejected(self) -> None:
        payload = json.loads(SOURCE_REPORT.read_text(encoding="utf-8"))
        tampered = copy.deepcopy(payload)
        tampered["records"][0]["command"][4] = "bridge"
        self.assertIn(
            "COMMAND_NOT_ISOLATED:ppocrv4_det",
            verify_payload(ROOT, tampered),
        )


if __name__ == "__main__":
    unittest.main()
