from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from acceptance.approvals import REQUIRED_EXTERNAL_GATES
from acceptance.contract import REQUIRED_PRODUCT_SCENARIOS
from scripts.verify_privacy import (
    SECURITY_APPROVAL_GATES,
    product_privacy_blockers,
)


class PrivacyProductGateTests(unittest.TestCase):
    def test_product_gate_requires_approved_security_evidence_and_real_device(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            approval_root = root / "evidence" / "approvals"
            approval_root.mkdir(parents=True)
            pending = {
                name: {
                    "approved": False,
                    "evidence_file": None,
                    "evidence_sha256": None,
                    "approved_by": None,
                    "approved_at": None,
                }
                for name in REQUIRED_EXTERNAL_GATES
            }
            for gate_name in SECURITY_APPROVAL_GATES:
                evidence = approval_root / f"{gate_name}.txt"
                evidence.write_text(gate_name, encoding="utf-8")
                pending[gate_name] = {
                    "approved": True,
                    "evidence_file": evidence.relative_to(root).as_posix(),
                    "evidence_sha256": hashlib.sha256(evidence.read_bytes()).hexdigest(),
                    "approved_by": "Security Review Board",
                    "approved_at": datetime.now(timezone.utc).isoformat(),
                }
            configs = root / "configs"
            reports = root / "reports"
            configs.mkdir()
            reports.mkdir()
            (configs / "product_gate_evidence.json").write_text(
                json.dumps({"schema_version": "1.0.0", "gates": pending}),
                encoding="utf-8",
            )
            (configs / "acceptance_contract.json").write_text(
                json.dumps(
                    {"required_scenarios": sorted(REQUIRED_PRODUCT_SCENARIOS)}
                ),
                encoding="utf-8",
            )
            (reports / "device_acceptance.json").write_text(
                json.dumps(
                    {
                        "status": "PASS_PRODUCT_GATE",
                        "hardware_measured": True,
                        "acceptance_executed": True,
                        "synthetic_evidence_used": False,
                        "blockers": [],
                    }
                ),
                encoding="utf-8",
            )
            self.assertEqual(product_privacy_blockers(root), [])

            acceptance = json.loads(
                (reports / "device_acceptance.json").read_text(encoding="utf-8")
            )
            acceptance["hardware_measured"] = False
            (reports / "device_acceptance.json").write_text(
                json.dumps(acceptance), encoding="utf-8"
            )
            self.assertIn(
                "PRIVACY_REAL_DEVICE_ACCEPTANCE_NOT_PASS",
                product_privacy_blockers(root),
            )


if __name__ == "__main__":
    unittest.main()
