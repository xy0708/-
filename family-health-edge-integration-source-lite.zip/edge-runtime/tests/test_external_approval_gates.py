from __future__ import annotations

import copy
import hashlib
import tempfile
import unittest
from pathlib import Path

from acceptance.approvals import (
    REQUIRED_EXTERNAL_GATES,
    acceptance_manifest_approval_errors,
    approval_gate_errors,
    gate_registry_errors,
)


def pending_registry() -> dict[str, object]:
    return {
        "schema_version": "1.0.0",
        "gates": {
            name: {
                "approved": False,
                "evidence_file": None,
                "evidence_sha256": None,
                "approved_by": None,
                "approved_at": None,
            }
            for name in REQUIRED_EXTERNAL_GATES
        },
    }


class ExternalApprovalGateTests(unittest.TestCase):
    def test_registry_rejects_missing_and_unknown_gates(self) -> None:
        registry = pending_registry()
        gates = registry["gates"]
        assert isinstance(gates, dict)
        gates.pop("privacy_legal_review")
        gates["invented_gate"] = {}
        errors = gate_registry_errors(registry)
        self.assertIn("REQUIRED_GATE_MISSING:privacy_legal_review", errors)
        self.assertIn("UNEXPECTED_GATE:invented_gate", errors)

    def test_named_approval_requires_identity_time_file_and_hash(self) -> None:
        registry = pending_registry()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            evidence = root / "evidence" / "approvals" / "approval.txt"
            evidence.parent.mkdir(parents=True)
            evidence.write_text("approved scope", encoding="utf-8")
            gates = registry["gates"]
            assert isinstance(gates, dict)
            gates["privacy_legal_review"] = {
                "approved": True,
                "evidence_file": evidence.relative_to(root).as_posix(),
                "evidence_sha256": hashlib.sha256(evidence.read_bytes()).hexdigest(),
                "approved_by": "Security Owner",
                "approved_at": "2026-09-21T12:00:00+08:00",
            }
            self.assertEqual(
                approval_gate_errors(root, registry, "privacy_legal_review"), []
            )
            changed = copy.deepcopy(registry)
            changed["gates"]["privacy_legal_review"]["approved_by"] = "TBD"
            self.assertIn(
                "APPROVER_INVALID",
                approval_gate_errors(root, changed, "privacy_legal_review"),
            )
            changed = copy.deepcopy(registry)
            changed["gates"]["privacy_legal_review"]["approved_at"] = "2999-01-01T00:00:00Z"
            self.assertIn(
                "APPROVED_AT_INVALID",
                approval_gate_errors(root, changed, "privacy_legal_review"),
            )
            changed = copy.deepcopy(registry)
            outside = root / "uncontrolled.txt"
            outside.write_text("approved scope", encoding="utf-8")
            changed["gates"]["privacy_legal_review"]["evidence_file"] = outside.name
            self.assertIn(
                "EVIDENCE_PATH_UNSAFE",
                approval_gate_errors(root, changed, "privacy_legal_review"),
            )

    def test_acceptance_manifest_is_bound_to_named_data_and_privacy_evidence(self) -> None:
        registry = pending_registry()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            approval_root = root / "evidence" / "approvals"
            approval_root.mkdir(parents=True)
            bindings = {}
            gates = registry["gates"]
            assert isinstance(gates, dict)
            for name in (
                "privacy_legal_review",
                "ocr_acceptance_data_rights_approval",
            ):
                evidence = approval_root / f"{name}.txt"
                evidence.write_text(name, encoding="utf-8")
                digest = hashlib.sha256(evidence.read_bytes()).hexdigest()
                gates[name] = {
                    "approved": True,
                    "evidence_file": evidence.relative_to(root).as_posix(),
                    "evidence_sha256": digest,
                    "approved_by": "Named Owner",
                    "approved_at": "2026-09-21T12:00:00+08:00",
                }
                bindings[name] = digest
            manifest = {"approval_bindings": bindings}
            self.assertEqual(
                acceptance_manifest_approval_errors(
                    root, manifest, registry, {"ocr"}
                ),
                [],
            )
            manifest["approval_bindings"]["privacy_legal_review"] = "0" * 64
            self.assertIn(
                "APPROVAL_BINDING_HASH_MISMATCH:privacy_legal_review",
                acceptance_manifest_approval_errors(
                    root, manifest, registry, {"ocr"}
                ),
            )


if __name__ == "__main__":
    unittest.main()
