from __future__ import annotations

import hashlib
import tempfile
import unittest
import wave
from pathlib import Path
from unittest.mock import patch

from acceptance.manifests import (
    controlled_output_path,
    validate_acceptance_cases,
    write_jsonl_atomically,
)
from acceptance.paths import has_redirected_component


PNG = (
    b"\x89PNG\r\n\x1a\n"
    + b"\x00\x00\x00\rIHDR"
    + (1).to_bytes(4, "big")
    + (1).to_bytes(4, "big")
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class AcceptanceManifestTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def base_manifest(self, component: str, cases: list[dict]) -> dict:
        return {
            "schema_version": "1.0.0",
            "component": component,
            "rights_cleared": True,
            "synthetic": False,
            "independent_split": True,
            "direct_identifiers_removed": True,
            "cases": cases,
        }

    def test_ocr_manifest_is_fully_validated_before_requests(self) -> None:
        accepted = self.root / "accepted.png"
        rejected = self.root / "rejected.png"
        accepted.write_bytes(PNG)
        rejected.write_bytes(b"not-an-image")
        manifest = self.base_manifest(
            "ocr",
            [
                {
                    "sample_id": "ocr-001",
                    "path": accepted.name,
                    "sha256": digest(accepted),
                    "media_type": "image/png",
                    "should_reject": False,
                    "ground_truth": [
                        {"field": "systolic", "truth": "120", "required": True}
                    ],
                },
                {
                    "sample_id": "ocr-reject-001",
                    "path": rejected.name,
                    "sha256": digest(rejected),
                    "media_type": "image/png",
                    "should_reject": True,
                },
            ],
        )
        self.assertEqual(len(validate_acceptance_cases(manifest, "ocr", self.root)), 2)
        manifest["cases"][1]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "sha256 mismatch"):
            validate_acceptance_cases(manifest, "ocr", self.root)

    def test_asr_manifest_requires_target_runtime_audio_contract(self) -> None:
        audio_path = self.root / "utterance.wav"
        with wave.open(str(audio_path), "wb") as audio:
            audio.setnchannels(1)
            audio.setsampwidth(2)
            audio.setframerate(16_000)
            audio.writeframes(b"\x00\x00" * 1_600)
        manifest = self.base_manifest(
            "asr",
            [
                {
                    "sample_id": "asr-001",
                    "path": audio_path.name,
                    "sha256": digest(audio_path),
                    "reference": "血压一百二十",
                    "expected_slots": {"systolic": 120},
                }
            ],
        )
        self.assertEqual(len(validate_acceptance_cases(manifest, "asr", self.root)), 1)
        manifest["direct_identifiers_removed"] = False
        with self.assertRaisesRegex(ValueError, "not eligible"):
            validate_acceptance_cases(manifest, "asr", self.root)

    def test_output_must_be_new_and_inside_controlled_evidence_root(self) -> None:
        project = self.root / "project"
        (project / "evidence" / "acceptance").mkdir(parents=True)
        output = controlled_output_path(project, Path("evidence/acceptance/ocr.jsonl"))
        self.assertEqual(output, project / "evidence" / "acceptance" / "ocr.jsonl")
        with self.assertRaisesRegex(ValueError, "inside evidence/acceptance"):
            controlled_output_path(project, Path("outside.jsonl"))

    def test_atomic_writer_never_overwrites_existing_evidence(self) -> None:
        output = self.root / "evidence.jsonl"
        output.write_text("original\n", encoding="utf-8")
        with self.assertRaises(FileExistsError):
            write_jsonl_atomically(output, [{"new": True}])
        self.assertEqual(output.read_text(encoding="utf-8"), "original\n")
        self.assertEqual(list(self.root.glob(".pending-*.jsonl")), [])

    def test_atomic_writer_does_not_publish_partial_evidence(self) -> None:
        output = self.root / "evidence.jsonl"

        def failing_rows():
            yield {"complete": True}
            raise RuntimeError("model request failed")

        with self.assertRaisesRegex(RuntimeError, "model request failed"):
            write_jsonl_atomically(output, failing_rows())
        self.assertFalse(output.exists())
        self.assertEqual(list(self.root.glob(".pending-*.jsonl")), [])

    def test_windows_junction_components_are_treated_as_redirects(self) -> None:
        nested = self.root / "evidence" / "acceptance"
        nested.mkdir(parents=True)
        with patch(
            "acceptance.paths.os.path.isjunction",
            side_effect=lambda value: Path(value).absolute() == nested.absolute(),
            create=True,
        ):
            self.assertTrue(has_redirected_component(nested / "result.jsonl", self.root))


if __name__ == "__main__":
    unittest.main()
