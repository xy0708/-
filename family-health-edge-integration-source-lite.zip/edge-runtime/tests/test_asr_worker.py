from __future__ import annotations

import io
import json
import unittest
from datetime import date

from asr_runtime import extract_confirmable_fields
from asr_runtime.worker import (
    REQUIRED_MODEL_FILES,
    WorkerProtocolError,
    model_bundle_sha256,
    read_request,
)


class AsrWorkerTests(unittest.TestCase):
    def test_invalid_spoken_date_falls_back_without_crashing(self):
        fields = extract_confirmable_fields(
            "13月40号心率80",
            today=date(2026, 9, 11),
        )
        self.assertEqual(fields["measured_on"], "2026-09-11")
        self.assertTrue(fields["requires_confirmation"])

    def test_extraction_matches_confirmable_family_health_fields(self) -> None:
        result = extract_confirmable_fields(
            "妈妈昨天血压一百二十比八十，血糖五点六，心率七十二",
            today=date(2026, 9, 11),
        )
        self.assertEqual(result["owner"], "妈妈")
        self.assertEqual(result["measured_on"], "2026-09-10")
        self.assertTrue(result["requires_confirmation"])
        self.assertEqual(
            [item["metric"] for item in result["measurements"]],
            ["blood_pressure", "blood_glucose", "heart_rate"],
        )
        self.assertEqual(result["measurements"][0]["value_secondary"], 80.0)

    def test_out_of_common_input_range_requires_manual_review(self) -> None:
        result = extract_confirmable_fields("血压300比20")
        measurement = result["measurements"][0]
        self.assertEqual(measurement["confidence"], 0.4)
        self.assertIsNotNone(measurement["warning"])

    def test_bundle_hash_is_deterministic_and_requires_every_model_file(self) -> None:
        files = {
            name: {"sha256": format(index + 1, "064x")}
            for index, name in enumerate(REQUIRED_MODEL_FILES)
        }
        first = model_bundle_sha256(files)
        second = model_bundle_sha256(dict(reversed(list(files.items()))))
        self.assertEqual(first, second)
        self.assertEqual(len(first), 64)
        del files[REQUIRED_MODEL_FILES[0]]
        with self.assertRaises(ValueError):
            model_bundle_sha256(files)

    def test_worker_request_requires_bounded_utf8_json_line(self) -> None:
        request = read_request(io.BytesIO(json.dumps({"op": "health"}).encode() + b"\n"))
        self.assertEqual(request, {"op": "health"})
        for raw in (b"not-json\n", b'{"op":"health"}', b"\n"):
            with self.subTest(raw=raw), self.assertRaises(WorkerProtocolError):
                read_request(io.BytesIO(raw))


if __name__ == "__main__":
    unittest.main()
