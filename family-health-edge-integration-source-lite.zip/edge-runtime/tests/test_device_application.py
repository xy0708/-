from __future__ import annotations

import tempfile
import unittest
import base64
import json
from datetime import datetime, timezone
from pathlib import Path

from device_service import DeviceApplication, TokenAuthorizer
from storage import PlaintextEngineeringCodec, RecordStore


TOKEN = "a" * 40
AUTH = {"authorization": f"Bearer {TOKEN}"}
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + (1).to_bytes(4, "big") + (1).to_bytes(4, "big")
OCR_IMAGE = {"image": {"media_type": "image/png", "data_base64": base64.b64encode(PNG).decode("ascii")}}


class EngineeringOcrAdapter:
    name = "ocr"

    def health(self):
        return {
            "ready": True,
            "contract_version": "1.0.0",
            "component_version": "0.1.0",
            "capabilities": ["ocr_task", "confirmation_required", "local_only"],
        }

    def create_task(self, member_id, payload):
        return {"fields": [], "input_sha256": payload["sha256"], "synthetic": True}


class ReadyAsrAdapter:
    name = "asr"

    def health(self):
        return {
            "ready": True,
            "contract_version": "1.0.0",
            "component_version": "1.0.0",
            "capabilities": [
                "asr_stream",
                "confirmation_required",
                "local_only",
                "raw_audio_memory_only",
            ],
            "model_sha256": "a" * 64,
        }


class TestOnlySecureCodec:
    """Test double for product-state derivation; not a product cipher."""

    name = "test_only_secure_codec"
    secure_for_product = True

    def encode(self, payload):
        return json.dumps(payload, sort_keys=True).encode("utf-8")

    def decode(self, payload):
        return json.loads(payload.decode("utf-8"))


class DeviceApplicationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.store = RecordStore(
            Path(self.temporary.name) / "edge.db",
            PlaintextEngineeringCodec(),
            allow_unencrypted_engineering=True,
        )
        self.app = DeviceApplication(
            self.store,
            TokenAuthorizer({TOKEN: {"member-a"}}),
            ocr_adapter=EngineeringOcrAdapter(),
        )

    def tearDown(self) -> None:
        self.store.close()
        self.temporary.cleanup()

    def test_health_is_public_but_contains_no_token_or_health_values(self) -> None:
        status, payload = self.app.dispatch("GET", "/v1/health")
        self.assertEqual(status, 200)
        self.assertNotIn(TOKEN, str(payload))
        self.assertFalse(payload["result"]["product_complete"])
        self.assertFalse(payload["result"]["storage"]["product_secure"])

    def test_product_complete_requires_secure_storage_runtime_and_release_binding(self) -> None:
        product_store = RecordStore(
            Path(self.temporary.name) / "product.db",
            TestOnlySecureCodec(),
        )
        try:
            app = DeviceApplication(
                product_store,
                TokenAuthorizer({TOKEN: {"member-a"}}),
                ocr_adapter=EngineeringOcrAdapter(),
                asr_adapter=ReadyAsrAdapter(),
                release_id="release-1",
                runtime_product_accepted=True,
            )
            _, health = app.dispatch("GET", "/v1/health")
            self.assertEqual(health["result"]["status"], "ok")
            self.assertTrue(health["result"]["product_complete"])

            missing_runtime_approval = DeviceApplication(
                product_store,
                TokenAuthorizer({TOKEN: {"member-a"}}),
                ocr_adapter=EngineeringOcrAdapter(),
                asr_adapter=ReadyAsrAdapter(),
                release_id="release-1",
            )
            _, blocked = missing_runtime_approval.dispatch("GET", "/v1/health")
            self.assertEqual(blocked["result"]["status"], "degraded")
            self.assertFalse(blocked["result"]["product_complete"])
        finally:
            product_store.close()

    def test_task_lookup_uses_member_header_without_get_body(self) -> None:
        _, created = self.app.dispatch(
            "POST",
            "/v1/ocr/tasks",
            AUTH,
            {"member_id": "member-a", **OCR_IMAGE},
        )
        status, task = self.app.dispatch(
            "GET",
            f"/v1/tasks/{created['task_id']}",
            {**AUTH, "X-Edge-Member-Id": "member-a"},
        )
        self.assertEqual(status, 200)
        self.assertEqual(task["task_id"], created["task_id"])

    def test_private_endpoint_requires_token(self) -> None:
        status, payload = self.app.dispatch("GET", "/v1/version")
        self.assertEqual(status, 401)
        self.assertEqual(payload["error"]["code"], "AUTH_REQUIRED")

    def test_version_exposes_schema_and_component_readiness_without_product_claim(self) -> None:
        status, payload = self.app.dispatch("GET", "/v1/version", AUTH)
        self.assertEqual(status, 200)
        self.assertEqual(payload["result"]["database_schema_version"], "3")
        self.assertIn("ocr", payload["result"]["components"])
        self.assertFalse(payload["result"]["product_complete"])

    def test_token_cannot_cross_member_boundary(self) -> None:
        status, payload = self.app.dispatch(
            "POST",
            "/v1/ocr/tasks",
            AUTH,
            {"member_id": "member-b", **OCR_IMAGE},
        )
        self.assertEqual(status, 403)
        self.assertEqual(payload["error"]["code"], "AUTH_INVALID")

        status, payload = self.app.dispatch(
            "GET", "/v1/members/member-b/records", AUTH
        )
        self.assertEqual(status, 403)
        self.assertEqual(payload["error"]["code"], "AUTH_INVALID")

    def test_ocr_requires_confirmation_before_idempotent_storage(self) -> None:
        status, created = self.app.dispatch(
            "POST",
            "/v1/ocr/tasks",
            AUTH,
            {"member_id": "member-a", **OCR_IMAGE},
        )
        self.assertEqual(status, 202)
        self.assertTrue(created["requires_confirmation"])
        self.assertEqual(self.store.list_records("member-a"), [])
        task_id = created["task_id"]
        confirm = {
            "member_id": "member-a",
            "task_id": task_id,
            "idempotency_key": "confirm-1",
            "confirmed_fields": {"weight": 72},
        }
        status, first = self.app.dispatch("POST", "/v1/records/confirm", AUTH, confirm)
        self.assertEqual(status, 200)
        self.assertFalse(first["result"]["idempotent_replay"])
        status, replay = self.app.dispatch("POST", "/v1/records/confirm", AUTH, confirm)
        self.assertEqual(status, 200)
        self.assertTrue(replay["result"]["idempotent_replay"])
        self.assertEqual(len(self.store.list_records("member-a")), 1)

    def test_health_evaluation_never_returns_diagnosis_probability(self) -> None:
        body = {
            "confirmed": True,
            "measurements": [
                {
                    "metric": "weight",
                    "value": 72,
                    "unit": "kg",
                    "measured_at": datetime.now(timezone.utc).isoformat(),
                    "confirmed": True,
                }
            ],
        }
        status, payload = self.app.dispatch(
            "POST", "/v1/health/evaluate", {**AUTH, "X-Edge-Member-Id": "member-a"}, body
        )
        self.assertEqual(status, 200)
        self.assertIsNone(payload["result"]["diagnosis"])
        self.assertIsNone(payload["result"]["disease_probability"])

    def test_health_evaluation_rejects_missing_or_unauthorized_member(self) -> None:
        body = {
            "confirmed": True,
            "measurements": [{
                "metric": "heart_rate", "value": 72, "unit": "bpm",
                "measured_at": datetime.now(timezone.utc).isoformat(),
                "confirmed": True,
            }],
        }
        missing_status, missing = self.app.dispatch(
            "POST", "/v1/health/evaluate", AUTH, body
        )
        self.assertEqual(missing_status, 422)
        self.assertEqual(missing["error"]["code"], "INPUT_INVALID")

        foreign_status, foreign = self.app.dispatch(
            "POST", "/v1/health/evaluate",
            {**AUTH, "X-Edge-Member-Id": "member-b"}, body,
        )
        self.assertEqual(foreign_status, 403)
        self.assertEqual(foreign["error"]["code"], "AUTH_INVALID")

        accepted_status, accepted = self.app.dispatch(
            "POST", "/v1/health/evaluate",
            {**AUTH, "X-Edge-Member-Id": "member-a"}, body,
        )
        self.assertEqual(accepted_status, 200)
        self.assertEqual(accepted["result"]["scope"], "NON_DIAGNOSTIC_HEALTH_MANAGEMENT")

    def test_member_can_correct_export_delete_and_withdraw_own_record(self) -> None:
        _, created = self.app.dispatch(
            "POST", "/v1/ocr/tasks", AUTH, {"member_id": "member-a", **OCR_IMAGE}
        )
        _, confirmed = self.app.dispatch(
            "POST",
            "/v1/records/confirm",
            AUTH,
            {
                "member_id": "member-a",
                "task_id": created["task_id"],
                "idempotency_key": "privacy-flow",
                "confirmed_fields": {"weight": 70},
            },
        )
        record = confirmed["result"]["record"]
        status, corrected = self.app.dispatch(
            "POST",
            f"/v1/members/member-a/records/{record['record_id']}/correct",
            AUTH,
            {"expected_version": 1, "confirmed_fields": {"weight": 71}},
        )
        self.assertEqual(status, 200)
        self.assertEqual(corrected["result"]["record"]["version"], 2)
        status, exported = self.app.dispatch(
            "GET", "/v1/members/member-a/records", AUTH
        )
        self.assertEqual(status, 200)
        self.assertEqual(exported["result"]["records"][0]["payload"], {"weight": 71})
        status, withdrawn = self.app.dispatch(
            "POST", "/v1/members/member-a/withdraw-consent", AUTH, {"confirmed": True}
        )
        self.assertEqual(status, 200)
        self.assertEqual(withdrawn["result"]["deleted_records"], 1)

    def test_record_export_is_bounded_and_cursor_paginated(self) -> None:
        for index in range(3):
            task = self.store.create_task("member-a", "ocr", {"index": index})
            self.store.confirm_task(
                task["task_id"],
                "member-a",
                f"pagination-{index}",
                {"index": index},
            )
        status, first = self.app.dispatch(
            "GET", "/v1/members/member-a/records?limit=2", AUTH
        )
        self.assertEqual(status, 200)
        self.assertEqual(len(first["result"]["records"]), 2)
        self.assertTrue(first["result"]["has_more"])
        cursor = first["result"]["next_cursor"]
        self.assertIsInstance(cursor, str)
        status, second = self.app.dispatch(
            "GET", f"/v1/members/member-a/records?limit=2&cursor={cursor}", AUTH
        )
        self.assertEqual(status, 200)
        self.assertEqual(len(second["result"]["records"]), 1)
        self.assertFalse(second["result"]["has_more"])
        self.assertIsNone(second["result"]["next_cursor"])

    def test_record_export_rejects_unbounded_or_malformed_queries(self) -> None:
        for path in (
            "/v1/members/member-a/records?limit=101",
            "/v1/members/member-a/records?limit=1&limit=2",
            "/v1/members/member-a/records?cursor=not_a_cursor",
            "/v1/members/member-a/records?unknown=1",
        ):
            with self.subTest(path=path):
                status, response = self.app.dispatch("GET", path, AUTH)
                self.assertEqual(status, 422)
                self.assertEqual(response["error"]["code"], "INPUT_INVALID")

    def test_task_and_record_deletes_are_idempotent(self) -> None:
        task = self.store.create_task("member-a", "ocr", {"field": "pending"})
        task_path = f"/v1/tasks/{task['task_id']}"
        member_headers = {**AUTH, "X-Edge-Member-Id": "member-a"}
        for expected in (True, False):
            status, response = self.app.dispatch("DELETE", task_path, member_headers)
            self.assertEqual(status, 200)
            self.assertIs(response["result"]["deleted"], expected)

        confirmed_task = self.store.create_task("member-a", "ocr", {"field": "pending"})
        record, _ = self.store.confirm_task(
            confirmed_task["task_id"], "member-a", "delete-idempotency", {"field": "kept"}
        )
        record_path = f"/v1/members/member-a/records/{record['record_id']}"
        for expected in (True, False):
            status, response = self.app.dispatch("DELETE", record_path, AUTH)
            self.assertEqual(status, 200)
            self.assertIs(response["result"]["deleted"], expected)


if __name__ == "__main__":
    unittest.main()
