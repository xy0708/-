from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from install_android_debug import adb_result_ok, sha256, validated_apk_evidence  # noqa: E402


class AndroidInstallTests(unittest.TestCase):
    def test_batch_installer_uses_powershell_without_python(self) -> None:
        batch = (ROOT / "install_android_debug.bat").read_text(encoding="utf-8")
        script = (ROOT / "scripts" / "install_android_debug.ps1").read_text(encoding="utf-8")

        self.assertIn("install_android_debug.ps1", batch)
        self.assertNotIn("python", batch.casefold())
        self.assertIn("soc_is_not_verified_as_rk3576", script)
        self.assertIn("primary_abi_is_not_arm64_v8a", script)
        self.assertIn("android_release_is_not_14", script)
        self.assertIn("android_api_is_not_34", script)
        self.assertIn("Get-FileHash", script)

    def test_accepts_hash_bound_arm64_debug_apk(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            apk = root / "app-debug.apk"
            report = root / "validation.json"
            apk.write_bytes(b"validated-arm64-apk")
            report.write_text(
                json.dumps(
                    {
                        "status": "PASS_ENGINEERING_DEBUG_APK",
                        "apk": {"sha256": sha256(apk)},
                        "apk_inspection": {
                            "abis": ["arm64-v8a"],
                            "asr_assets_valid": True,
                        },
                    }
                ),
                encoding="utf-8",
            )

            errors, evidence = validated_apk_evidence(apk, report)

            self.assertEqual(errors, [])
            self.assertEqual(evidence["sha256"], sha256(apk))

    def test_rejects_apk_changed_after_validation(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            apk = root / "app-debug.apk"
            report = root / "validation.json"
            apk.write_bytes(b"old")
            report.write_text(
                json.dumps(
                    {
                        "status": "PASS_ENGINEERING_DEBUG_APK",
                        "apk": {"sha256": sha256(apk)},
                        "apk_inspection": {
                            "abis": ["arm64-v8a"],
                            "asr_assets_valid": True,
                        },
                    }
                ),
                encoding="utf-8",
            )
            apk.write_bytes(b"changed")

            errors, _ = validated_apk_evidence(apk, report)

            self.assertIn("debug_apk_hash_not_bound_to_validation", errors)

    def test_adb_result_rejects_error_text_with_zero_exit_code(self) -> None:
        result = subprocess.CompletedProcess(
            args=["adb"],
            returncode=0,
            stdout="Error: Activity class does not exist.",
            stderr="",
        )

        self.assertFalse(adb_result_ok(result))


if __name__ == "__main__":
    unittest.main()
