from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path

from scripts.verify_acceptance_intake_readiness import ROOT, evaluate


class AcceptanceIntakeReadinessTests(unittest.TestCase):
    def test_current_intake_is_engineering_ready_but_externally_blocked(self) -> None:
        result = evaluate()
        self.assertEqual(result["status"], "PASS_ENGINEERING")
        self.assertFalse(result["formal_acceptance_ready"])
        self.assertFalse(result["product_release_allowed"])
        self.assertEqual(result["structural_errors"], [])
        self.assertIn(
            "ocr_acceptance_data_rights_approval:NOT_APPROVED",
            result["external_blockers"],
        )

    def test_missing_required_gate_is_an_engineering_failure(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for relative in (
                ".gitignore",
                "configs/product_gate_evidence.json",
                "configs/ocr_acceptance_manifest.template.json",
                "configs/asr_acceptance_manifest.template.json",
                "configs/acceptance_evidence.example.json",
                "docs/operations/acceptance_evidence_format.md",
            ):
                source = ROOT / relative
                destination = root / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
            registry_path = root / "configs" / "product_gate_evidence.json"
            registry = json.loads(registry_path.read_text(encoding="utf-8"))
            del registry["gates"]["privacy_legal_review"]
            registry_path.write_text(json.dumps(registry), encoding="utf-8")
            result = evaluate(root)
        self.assertEqual(result["status"], "FAIL_ENGINEERING")
        self.assertIn("REQUIRED_GATE_MISSING:privacy_legal_review", result["structural_errors"])


if __name__ == "__main__":
    unittest.main()
