from __future__ import annotations

import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from release_tools.bundle import (
    REQUIRED_DIRECTORIES,
    REQUIRED_PRODUCT_FILES,
    REQUIRED_PRODUCT_PREFIXES,
    verify_release_bundle,
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class ReleaseBundleTests(unittest.TestCase):
    def make_bundle(self, root: Path) -> tuple[Path, Path]:
        bundle = root / "v1.0.0"
        for directory in REQUIRED_DIRECTORIES:
            (bundle / directory).mkdir(parents=True, exist_ok=True)
        product_files: list[Path] = []
        for relative in sorted(REQUIRED_PRODUCT_FILES):
            path = bundle / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(("verified-" + relative).encode("utf-8"))
            product_files.append(path)
        for prefix in sorted(REQUIRED_PRODUCT_PREFIXES):
            path = bundle / prefix / "required.artifact"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(("verified-" + prefix).encode("utf-8"))
            product_files.append(path)
        rollback = bundle / "rollback.json"
        rollback.write_text(
            json.dumps(
                {
                    "schema_version": "1.0.0",
                    "previous_release_id": "v0.9.0",
                    "database_rollback_compatible": True,
                }
            ),
            encoding="utf-8",
        )
        files = []
        for path in (*product_files, rollback):
            files.append(
                {
                    "path": path.relative_to(bundle).as_posix(),
                    "size": path.stat().st_size,
                    "sha256": digest(path),
                }
            )
        (bundle / "manifest.json").write_text(
            json.dumps(
                {
                    "schema_version": "1.0.0",
                    "release_id": bundle.name,
                    "created_at": "2026-09-12T00:00:00+00:00",
                    "files": files,
                }
            ),
            encoding="utf-8",
        )
        (bundle / "signatures" / "manifest.sig").write_bytes(b"external-signature")
        public_key = root / "trusted-public.pem"
        public_key.write_text("trusted outside bundle", encoding="utf-8")
        return bundle, public_key

    def test_complete_hash_covered_signed_bundle_passes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            bundle, key = self.make_bundle(Path(temporary))
            result = verify_release_bundle(
                bundle, key, signature_verifier=lambda manifest, signature, public: True
            )
            self.assertTrue(result.passed, result.failures)
            self.assertTrue(result.signature_verified)
            self.assertEqual(
                result.files_verified,
                len(REQUIRED_PRODUCT_FILES) + len(REQUIRED_PRODUCT_PREFIXES) + 1,
            )

    def test_tamper_extra_file_and_bad_signature_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            bundle, key = self.make_bundle(Path(temporary))
            (bundle / "bin" / "family-health-edge").write_bytes(b"tampered")
            (bundle / "reports" / "extra.txt").write_text("extra", encoding="utf-8")
            result = verify_release_bundle(
                bundle, key, signature_verifier=lambda manifest, signature, public: False
            )
            self.assertFalse(result.passed)
            self.assertTrue(any("FILE_SIZE_MISMATCH" in item for item in result.failures))
            self.assertTrue(any("UNMANIFESTED_FILE" in item for item in result.failures))

    def test_manifest_path_traversal_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            bundle, key = self.make_bundle(Path(temporary))
            manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
            manifest["files"].append(
                {"path": "../escape", "size": 0, "sha256": "0" * 64}
            )
            (bundle / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            result = verify_release_bundle(
                bundle, key, signature_verifier=lambda manifest, signature, public: True
            )
            self.assertFalse(result.passed)
            self.assertTrue(any("MANIFEST_PATH_UNSAFE" in item for item in result.failures))

    def test_unknown_rollback_field_is_rejected_at_install_verification(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            bundle, key = self.make_bundle(Path(temporary))
            rollback = json.loads((bundle / "rollback.json").read_text(encoding="utf-8"))
            rollback["allow_arbitrary_target"] = True
            (bundle / "rollback.json").write_text(json.dumps(rollback), encoding="utf-8")
            manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
            entry = next(item for item in manifest["files"] if item["path"] == "rollback.json")
            entry["size"] = (bundle / "rollback.json").stat().st_size
            entry["sha256"] = digest(bundle / "rollback.json")
            (bundle / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            result = verify_release_bundle(
                bundle, key, signature_verifier=lambda manifest, signature, public: True
            )
            self.assertFalse(result.passed)
            self.assertIn("ROLLBACK_METADATA_SCHEMA_INVALID", result.failures)

    def test_non_object_manifest_fails_closed_without_crashing(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            bundle, key = self.make_bundle(Path(temporary))
            (bundle / "manifest.json").write_text("[]", encoding="utf-8")
            result = verify_release_bundle(
                bundle, key, signature_verifier=lambda manifest, signature, public: True
            )
            self.assertFalse(result.passed)
            self.assertIn("MANIFEST_SCHEMA_INVALID", result.failures)

    def test_release_cannot_name_itself_as_rollback_predecessor(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            bundle, key = self.make_bundle(Path(temporary))
            rollback_path = bundle / "rollback.json"
            rollback = json.loads(rollback_path.read_text(encoding="utf-8"))
            rollback["previous_release_id"] = bundle.name
            rollback_path.write_text(json.dumps(rollback), encoding="utf-8")
            manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
            entry = next(item for item in manifest["files"] if item["path"] == "rollback.json")
            entry["size"] = rollback_path.stat().st_size
            entry["sha256"] = digest(rollback_path)
            (bundle / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            result = verify_release_bundle(
                bundle, key, signature_verifier=lambda manifest, signature, public: True
            )
            self.assertFalse(result.passed)
            self.assertIn("PREVIOUS_RELEASE_ID_INVALID", result.failures)

    def test_directory_redirect_is_rejected_without_traversal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            bundle, key = self.make_bundle(Path(temporary))
            real_is_redirected = __import__(
                "acceptance.paths", fromlist=["is_redirected"]
            ).is_redirected

            def redirected(path: Path) -> bool:
                return path == bundle / "lib" or real_is_redirected(path)

            with patch("release_tools.bundle.is_redirected", side_effect=redirected):
                result = verify_release_bundle(
                    bundle,
                    key,
                    signature_verifier=lambda manifest, signature, public: True,
                )
            self.assertFalse(result.passed)
            self.assertIn("REQUIRED_DIRECTORY_MISSING_OR_REDIRECT:lib", result.failures)
            self.assertIn("BUNDLE_REDIRECT_FORBIDDEN:lib", result.failures)

    @unittest.skipUnless(hasattr(os, "mkfifo"), "FIFO creation requires POSIX")
    def test_special_file_in_signed_bundle_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            bundle, key = self.make_bundle(Path(temporary))
            fifo = bundle / "reports" / "unexpected.pipe"
            os.mkfifo(fifo)
            result = verify_release_bundle(
                bundle,
                key,
                signature_verifier=lambda manifest, signature, public: True,
            )
            self.assertFalse(result.passed)
            self.assertIn(
                "BUNDLE_ENTRY_NOT_REGULAR:reports/unexpected.pipe",
                result.failures,
            )


if __name__ == "__main__":
    unittest.main()
