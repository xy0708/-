from __future__ import annotations

import unittest

from scripts.verify_release import evaluate


class ReleaseGateTests(unittest.TestCase):
    def test_release_fails_closed_while_external_evidence_is_missing(self) -> None:
        result = evaluate()
        self.assertFalse(result["release_allowed"])
        self.assertEqual(result["status"], "BLOCKED_EXTERNAL")
        self.assertIn("REAL_DEVICE_INDEPENDENT_ACCEPTANCE_NOT_PASS", result["blockers"])
        self.assertIn("PRIVACY_PRODUCT_GATE_NOT_PASS", result["blockers"])
        self.assertIn(
            "EXTERNAL_GATE_NOT_APPROVED:ocr_acceptance_data_rights_approval",
            result["blockers"],
        )
        self.assertIn(
            "EXTERNAL_GATE_NOT_APPROVED:asr_acceptance_data_rights_approval",
            result["blockers"],
        )


if __name__ == "__main__":
    unittest.main()
