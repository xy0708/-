from __future__ import annotations

import unittest
from types import SimpleNamespace

from benchmarks.comparison.ocr_synthetic_batch import (
    CANDIDATES,
    REPORT_SCOPE,
    REPORT_STATUS,
    aggregate_sample_scores,
    score_extracted_indicators,
    validate_report,
)
from benchmarks.comparison.ocr_tiling import (
    axis_starts,
    deduplicate,
)


class OcrSyntheticBatchComparisonTests(unittest.TestCase):
    def test_tiling_covers_edges_and_deduplicates_overlaps(self) -> None:
        self.assertEqual(axis_starts(480, 720, 120), [0])
        self.assertEqual(axis_starts(1800, 720, 120), [0, 600, 1080])
        overlapping = [
            {
                "text": "low",
                "confidence": 0.5,
                "source_box": [0, 0, 100, 0, 100, 20, 0, 20],
            },
            {
                "text": "high",
                "confidence": 0.9,
                "source_box": [2, 0, 102, 0, 102, 20, 2, 20],
            },
        ]

        result = deduplicate(overlapping)

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["text"], "high")

    def test_failed_and_empty_samples_remain_in_denominator(self) -> None:
        expected = [
            {"standard_name": "glucose", "raw_value": "6.8", "raw_unit": "mmol/L"},
            {"standard_name": "albumin", "raw_value": "46.1", "raw_unit": "g/L"},
        ]
        extracted = [
            SimpleNamespace(
                standard_name="glucose", raw_value="6.8", normalized_unit="mmol/L"
            )
        ]
        first = score_extracted_indicators(extracted, expected)
        second = score_extracted_indicators([], expected)
        aggregate = aggregate_sample_scores(
            [
                {
                    "status": "PASS_ENGINEERING_INFERENCE",
                    "raw_line_count": 1,
                    "metrics": first,
                },
                {
                    "status": "FAIL_ENGINEERING_INFERENCE",
                    "raw_line_count": 0,
                    "metrics": second,
                },
            ]
        )

        self.assertEqual(aggregate["expected_fields"], 4)
        self.assertEqual(aggregate["exact_complete_fields"], 1)
        self.assertEqual(aggregate["field_exact_match_rate"], 0.25)
        self.assertEqual(aggregate["failure_rate"], 0.5)
        self.assertEqual(aggregate["empty_result_rate"], 0.5)

    def test_report_cannot_claim_product_winner(self) -> None:
        aggregate = {
            "required_field_recall": 0.5,
            "exact_value_rate": 0.5,
            "exact_unit_rate": 0.5,
            "field_exact_match_rate": 0.5,
            "failure_rate": 0.0,
            "empty_result_rate": 0.0,
        }
        report = {
            "schema_version": "1.0.0",
            "status": REPORT_STATUS,
            "scope": REPORT_SCOPE,
            "product_acceptance_evidence": False,
            "formal_data_used": False,
            "authorized_health_report_data_used": False,
            "hardware_measured": False,
            "product_selection_allowed": False,
            "accuracy_claim_allowed": False,
            "host_timing_comparable_for_ranking": False,
            "source_hashes": {"source": "a" * 64},
            "candidates": {
                name: {"samples": [{}, {}], "aggregate": aggregate}
                for name in CANDIDATES
            },
            "conclusion": {"result": "NO_PRODUCT_WINNER", "winner": None},
        }

        self.assertEqual(
            validate_report(report, {"source": "a" * 64}),
            [],
        )
        report["conclusion"]["winner"] = "ocr_rknn_ppocrv4"
        self.assertIn(
            "PRODUCT_WINNER_OVERSTATED",
            validate_report(report, {"source": "a" * 64}),
        )


if __name__ == "__main__":
    unittest.main()
