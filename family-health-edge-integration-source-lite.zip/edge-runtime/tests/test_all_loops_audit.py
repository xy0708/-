from __future__ import annotations

import copy
import unittest

from scripts.audit_all_loops import audit_exit_code, evaluate, load_reports


class AllLoopsAuditTests(unittest.TestCase):
    def test_current_workspace_reaches_external_boundary(self):
        result = evaluate(load_reports())
        self.assertEqual(result["status"], "BLOCKED_EXTERNAL")
        self.assertTrue(
            result["all_engineering_work_reachable_without_external_inputs_complete"]
        )
        self.assertFalse(result["all_product_loops_complete"])
        self.assertEqual(result["unfinished_without_external_inputs"], [])
        self.assertTrue(result["unfinished_requiring_external_inputs"])

    def test_missing_arm64_evidence_fails_engineering(self):
        reports = copy.deepcopy(load_reports())
        reports["s1"] = {}
        result = evaluate(reports)
        self.assertEqual(result["status"], "FAIL_ENGINEERING")
        self.assertIn("arm64_simulation", result["engineering_failures"])

    def test_exit_codes_distinguish_product_external_and_failure(self):
        self.assertEqual(audit_exit_code({"status": "PASS_PRODUCT_GATE"}), 0)
        self.assertEqual(audit_exit_code({"status": "BLOCKED_EXTERNAL"}), 2)
        self.assertEqual(audit_exit_code({"status": "FAIL_ENGINEERING"}), 1)


if __name__ == "__main__":
    unittest.main()
