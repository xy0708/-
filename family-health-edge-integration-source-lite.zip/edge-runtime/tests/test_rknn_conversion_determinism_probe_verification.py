from __future__ import annotations

import copy
import json
import unittest

from scripts.verify_rknn_conversion_determinism_probe import (
    ROOT,
    SOURCE_REPORT,
    verify_payload,
    verify_report,
)


class RknnConversionDeterminismProbeVerificationTests(unittest.TestCase):
    def test_current_probe_is_audited_without_product_overclaim(self) -> None:
        result = verify_report()
        self.assertEqual(
            result["status"],
            "PASS_ENGINEERING_DETERMINISM_PROBE_PRODUCT_BLOCKED",
            result["errors"],
        )
        self.assertEqual(result["double_conversion_success_count"], 5)
        self.assertEqual(result["pairwise_byte_reproducible_count"], 2)
        self.assertEqual(result["pairwise_hash_drift_count"], 3)
        self.assertFalse(result["hardware_measured"])
        self.assertFalse(result["product_selected"])

    def test_environment_tampering_is_rejected(self) -> None:
        payload = json.loads(SOURCE_REPORT.read_text(encoding="utf-8"))
        tampered = copy.deepcopy(payload)
        tampered["fixed_environment"][0] = "PYTHONHASHSEED=random"
        self.assertIn("FIXED_ENVIRONMENT_INVALID", verify_payload(ROOT, tampered))


if __name__ == "__main__":
    unittest.main()
