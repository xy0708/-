from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from update_agent import (
    ActivationMarkerError,
    clear_activation_marker,
    prepare_activation_marker,
    read_activation_marker,
)


class ActivationMarkerTests(unittest.TestCase):
    def test_prepare_read_and_clear_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            marker = Path(temporary) / "pending-activation.json"
            prepared = prepare_activation_marker(marker, "v2.0.0", "v1.0.0")
            self.assertEqual(read_activation_marker(marker), prepared)
            clear_activation_marker(marker, "v2.0.0")
            self.assertFalse(marker.exists())

    def test_existing_or_mismatched_marker_cannot_be_overwritten_or_cleared(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            marker = Path(temporary) / "pending-activation.json"
            prepare_activation_marker(marker, "v2.0.0", "v1.0.0")
            with self.assertRaisesRegex(ActivationMarkerError, "already_exists"):
                prepare_activation_marker(marker, "v3.0.0", "v2.0.0")
            with self.assertRaisesRegex(ActivationMarkerError, "candidate_mismatch"):
                clear_activation_marker(marker, "v3.0.0")
            self.assertTrue(marker.exists())

    def test_unknown_fields_and_same_version_transition_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            marker = Path(temporary) / "pending-activation.json"
            marker.write_text(
                json.dumps(
                    {
                        "schema_version": "1.0.0",
                        "candidate_release_id": "v2.0.0",
                        "previous_release_id": "v1.0.0",
                        "ignore_recovery": True,
                    }
                ),
                encoding="utf-8",
            )
            marker.chmod(0o600)
            with self.assertRaisesRegex(ActivationMarkerError, "schema_invalid"):
                read_activation_marker(marker)
            marker.unlink()
            with self.assertRaisesRegex(ActivationMarkerError, "transition_invalid"):
                prepare_activation_marker(marker, "v2.0.0", "v2.0.0")

    def test_invalid_release_id_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            marker = Path(temporary) / "pending-activation.json"
            with self.assertRaisesRegex(ActivationMarkerError, "candidate_release_id_invalid"):
                prepare_activation_marker(marker, "../escape", None)


if __name__ == "__main__":
    unittest.main()
