from __future__ import annotations

import unittest
import tempfile
import threading
from pathlib import Path
from unittest.mock import patch

from device_service import DeviceApplication, TokenAuthorizer
from device_service.server import BoundedThreadingHTTPServer, DeviceRequestHandler
from storage import PlaintextEngineeringCodec, RecordStore
from update_agent import (
    HealthGateResult,
    check_product_health,
    fetch_product_health,
    wait_for_product_health,
)


def product_health() -> dict:
    return {
        "status": "success",
        "result": {
            "status": "ok",
            "network_scope": "loopback_only",
            "product_complete": True,
            "storage": {"ready": True, "product_secure": True},
            "health_rules": {"ready": True, "non_diagnostic": True},
            "ocr": {"ready": True},
            "asr": {"ready": True},
        },
    }


class UpdateHealthGateTests(unittest.TestCase):
    def test_complete_product_health_passes(self) -> None:
        result = check_product_health(product_health())
        self.assertTrue(result.passed, result.failures)

    def test_http_success_with_degraded_or_engineering_state_fails_closed(self) -> None:
        payload = product_health()
        payload["result"]["status"] = "degraded"
        payload["result"]["product_complete"] = False
        payload["result"]["storage"]["product_secure"] = False
        payload["result"]["ocr"]["ready"] = False
        result = check_product_health(payload)
        self.assertFalse(result.passed)
        self.assertEqual(
            set(result.failures),
            {
                "OCR_NOT_READY",
                "PRODUCT_COMPLETE_FALSE",
                "SERVICE_DEGRADED",
                "STORAGE_NOT_PRODUCT_SECURE",
            },
        )

    def test_non_loopback_health_url_is_rejected_without_network_access(self) -> None:
        result = fetch_product_health("https://example.com/v1/health")
        self.assertFalse(result.passed)
        self.assertEqual(result.failures, ("HEALTH_URL_NOT_LOOPBACK",))

    def test_startup_wait_retries_without_weakening_product_gate(self) -> None:
        unavailable = HealthGateResult(False, ("HEALTH_REQUEST_FAILED",))
        ready = HealthGateResult(True, ())
        with patch(
            "update_agent.health_gate.fetch_product_health",
            side_effect=[unavailable, ready],
        ) as fetch, patch("update_agent.health_gate.sleep"):
            result = wait_for_product_health(
                "http://127.0.0.1:18100/v1/health",
                startup_timeout_seconds=1,
            )
        self.assertTrue(result.passed)
        self.assertEqual(fetch.call_count, 2)

    def test_invalid_startup_wait_configuration_fails_closed(self) -> None:
        result = wait_for_product_health(
            "http://127.0.0.1:18100/v1/health",
            startup_timeout_seconds=True,
        )
        self.assertFalse(result.passed)
        self.assertEqual(result.failures, ("HEALTH_WAIT_CONFIGURATION_INVALID",))

    def test_real_engineering_service_http_200_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = RecordStore(
                Path(temporary) / "edge.db",
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
            )
            app = DeviceApplication(
                store,
                TokenAuthorizer.engineering_wildcard("x" * 40),
            )
            server = BoundedThreadingHTTPServer(("127.0.0.1", 0), DeviceRequestHandler)
            server.application = app  # type: ignore[attr-defined]
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                result = fetch_product_health(
                    f"http://127.0.0.1:{server.server_port}/v1/health"
                )
                self.assertFalse(result.passed)
                self.assertIn("PRODUCT_COMPLETE_FALSE", result.failures)
                self.assertIn("STORAGE_NOT_PRODUCT_SECURE", result.failures)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=5)
                store.close()


if __name__ == "__main__":
    unittest.main()
