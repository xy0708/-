from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from update_agent import check_rollback_transition


class UpdateRollbackGateTests(unittest.TestCase):
    def make_current(
        self,
        root: Path,
        *,
        previous: str = "v1.0.0",
        database_compatible: bool = True,
    ) -> Path:
        current = root / "v1.1.0"
        current.mkdir()
        (current / "rollback.json").write_text(
            json.dumps(
                {
                    "schema_version": "1.0.0",
                    "previous_release_id": previous,
                    "database_rollback_compatible": database_compatible,
                }
            ),
            encoding="utf-8",
        )
        return current

    def test_signed_predecessor_compatible_transition_passes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            result = check_rollback_transition(
                self.make_current(Path(temporary)), "v1.0.0"
            )
            self.assertTrue(result.passed, result.failures)

    def test_arbitrary_target_and_database_incompatibility_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            current = self.make_current(Path(temporary), database_compatible=False)
            result = check_rollback_transition(current, "v0.1.0")
            self.assertFalse(result.passed)
            self.assertEqual(
                set(result.failures),
                {"DATABASE_ROLLBACK_NOT_APPROVED", "TARGET_NOT_SIGNED_PREDECESSOR"},
            )

    def test_unknown_metadata_fields_and_unsafe_target_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            current = self.make_current(Path(temporary))
            metadata = current / "rollback.json"
            payload = json.loads(metadata.read_text(encoding="utf-8"))
            payload["unreviewed_override"] = True
            metadata.write_text(json.dumps(payload), encoding="utf-8")
            self.assertFalse(check_rollback_transition(current, "v1.0.0").passed)
            self.assertEqual(
                check_rollback_transition(current, "../v1.0.0").failures,
                ("TARGET_RELEASE_ID_INVALID",),
            )


if __name__ == "__main__":
    unittest.main()
