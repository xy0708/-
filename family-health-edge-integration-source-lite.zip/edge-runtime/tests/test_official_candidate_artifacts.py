from __future__ import annotations

import unittest

from scripts.verify_official_candidate_artifacts import verify_manifest


class OfficialCandidateArtifactTests(unittest.TestCase):
    def test_converted_candidates_remain_engineering_only(self) -> None:
        result = verify_manifest()
        self.assertEqual(result["status"], "PASS_ENGINEERING_PARTIAL", result["errors"])
        self.assertEqual(result["phase"], "C04_C05_IN_PROGRESS")
        self.assertEqual(result["verified_candidates"], 2)
        self.assertEqual(result["verified_artifacts"], 10)
        self.assertTrue(result["ocr_end_to_end_decoded"])
        self.assertTrue(result["asr_single_sample_functional_simulation"])
        self.assertFalse(result["authorized_selection_validation_complete"])
        self.assertFalse(result["real_rk3566_verified"])
        self.assertFalse(result["product_selected"])
        self.assertFalse(result["formal_release_allowed"])


if __name__ == "__main__":
    unittest.main()
