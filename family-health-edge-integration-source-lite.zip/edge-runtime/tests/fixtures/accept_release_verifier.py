from __future__ import annotations

# Linux activation-recovery smoke only. Cryptographic verification is covered by
# release_tools tests; the smoke isolates interrupted symlink restoration behavior.
raise SystemExit(0)
