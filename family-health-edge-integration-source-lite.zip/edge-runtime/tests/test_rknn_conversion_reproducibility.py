from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from scripts.run_rknn_conversion_reproducibility import (
    CASES,
    binary_diff_summary,
    changed_region_diagnostics,
    docker_command,
    notable_sdk_lines,
    sanitized_command,
)


class RknnConversionReproducibilityTests(unittest.TestCase):
    def test_commands_disable_network_and_use_read_only_workspace(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            command = docker_command("converter:test", CASES[0], Path(temporary))
            rendered = " ".join(command)
            self.assertIn("--network none", rendered)
            self.assertIn(":/workspace:ro", rendered)
            self.assertIn("--profile ppocrv4_det", rendered)

    def test_sanitized_command_does_not_disclose_host_paths(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            temporary_root = Path(temporary)
            command = docker_command("converter:test", CASES[0], temporary_root)
            rendered = " ".join(sanitized_command(command, temporary_root))
            self.assertIn("{WORKSPACE}", rendered)
            self.assertIn("{TEMP}", rendered)
            self.assertNotIn(str(temporary_root), rendered)

    def test_sanitized_command_marks_temp_inside_workspace(self) -> None:
        temporary_root = Path(__file__).resolve().parents[1] / ".artifact-work" / "sample"
        command = docker_command("converter:test", CASES[0], temporary_root)
        rendered = " ".join(sanitized_command(command, temporary_root))
        self.assertIn("{WORKSPACE}", rendered)
        self.assertIn("{TEMP}", rendered)
        self.assertNotIn(str(temporary_root), rendered)

    def test_notable_sdk_lines_are_deduplicated(self) -> None:
        output = "E RKNN: Unkown op target: 0\nE RKNN: Unkown op target: 0\nwarning: transpose"
        self.assertEqual(
            notable_sdk_lines(output),
            ["E RKNN: Unkown op target: 0", "warning: transpose"],
        )

    def test_binary_diff_reports_changed_span(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            first = Path(temporary) / "first.bin"
            second = Path(temporary) / "second.bin"
            first.write_bytes(b"abcXYZdef")
            second.write_bytes(b"abc123def")
            self.assertEqual(
                binary_diff_summary(first, second),
                {
                    "same_size": True,
                    "canonical_bytes": 9,
                    "replay_bytes": 9,
                    "common_prefix_bytes": 3,
                    "common_suffix_bytes": 3,
                    "canonical_changed_span_bytes": 3,
                    "replay_changed_span_bytes": 3,
                },
            )
            diagnostics = changed_region_diagnostics(
                first,
                second,
                binary_diff_summary(first, second),
            )
            self.assertEqual(diagnostics["different_byte_count_in_common_span"], 3)
            self.assertEqual(diagnostics["canonical_hex_preview"], b"XYZ".hex())
            self.assertEqual(diagnostics["replay_hex_preview"], b"123".hex())


if __name__ == "__main__":
    unittest.main()
