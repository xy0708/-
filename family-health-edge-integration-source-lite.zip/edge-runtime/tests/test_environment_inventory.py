from __future__ import annotations

import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from scripts import inventory_environment


class EnvironmentInventoryTests(unittest.TestCase):
    def test_non_gbk_tool_output_is_replaced_without_crashing(self) -> None:
        completed = subprocess.CompletedProcess(
            args=["tool", "--version"],
            returncode=0,
            stdout=b"tool \x90version\n",
            stderr=b"",
        )
        with patch.object(inventory_environment.subprocess, "run", return_value=completed):
            value = inventory_environment.first_version_line("tool")
        self.assertIsInstance(value, str)
        self.assertIn("tool", value)

    def test_main_writes_utf8_report_and_prints_ascii_safe_json(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report = Path(temporary) / "environment.json"
            with (
                patch.object(inventory_environment, "REPORT", report),
                patch.object(inventory_environment.shutil, "which", return_value="tool"),
                patch.object(
                    inventory_environment,
                    "first_version_line",
                    return_value="tool \ufffdversion",
                ),
                patch("builtins.print") as mocked_print,
            ):
                self.assertEqual(inventory_environment.main(), 0)
            self.assertIn("tool \ufffdversion", report.read_text(encoding="utf-8"))
            printed = mocked_print.call_args.args[0]
            printed.encode("ascii")


if __name__ == "__main__":
    unittest.main()
