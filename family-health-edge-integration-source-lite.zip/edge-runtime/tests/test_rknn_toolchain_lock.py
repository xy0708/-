from __future__ import annotations

import unittest

from scripts.verify_rknn_toolchain_lock import verify_matrix


class RknnToolchainLockTests(unittest.TestCase):
    def test_r02_environment_and_conversion_are_verified_without_overstating_product_readiness(self):
        result = verify_matrix()
        self.assertEqual(result["status"], "PASS_ENGINEERING_PARTIAL", result["errors"])
        self.assertEqual(result["phase"], "R02_IN_PROGRESS")
        self.assertEqual(result["verified_artifacts"], 9)
        self.assertTrue(result["conversion_environment_rebuilt"])
        self.assertTrue(result["official_sample_smoke_verified"])
        self.assertTrue(result["pc_simulator_alignment_verified"])
        self.assertTrue(result["dependency_artifact_hash_lock_complete"])
        self.assertFalse(result["real_rk3566_verified"])
        self.assertFalse(result["formal_release_allowed"])
