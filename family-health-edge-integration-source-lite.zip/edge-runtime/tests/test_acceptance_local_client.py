from __future__ import annotations

import hashlib
import sqlite3
import tempfile
import threading
import unittest
import wave
from pathlib import Path

from acceptance.local_client import run_asr_case, run_ocr_case
from device_service import DeviceApplication, TokenAuthorizer
from device_service.server import BoundedThreadingHTTPServer, DeviceRequestHandler
from storage import PlaintextEngineeringCodec, RecordStore


TOKEN = "acceptance-member-token-1234567890abcdef"
MEMBER = "member-acceptance"
PNG = (
    b"\x89PNG\r\n\x1a\n"
    + b"\x00\x00\x00\rIHDR"
    + (1).to_bytes(4, "big")
    + (1).to_bytes(4, "big")
)


class AcceptanceOcrAdapter:
    name = "ocr"

    def health(self):
        return {
            "ready": True,
            "contract_version": "1.0.0",
            "component_version": "0.1.0",
            "capabilities": ["ocr_task", "confirmation_required", "local_only"],
        }

    def create_task(self, member_id, payload):
        return {
            "fields": [
                {"field": "systolic", "value": "120"},
                {"field": "diastolic", "value": "80"},
            ],
            "input_sha256": payload["sha256"],
        }


class AcceptanceRecognizer:
    def feed_pcm(self, pcm_s16le):
        return "血压"

    def finish(self):
        return {
            "text": "血压一百二十，低压八十",
            "fields": {"systolic": 120, "diastolic": 80},
        }

    def close(self):
        return None


class AcceptanceAsrAdapter:
    name = "asr"

    def health(self):
        return {
            "ready": True,
            "contract_version": "1.0.0",
            "component_version": "0.1.0",
            "capabilities": [
                "asr_stream",
                "confirmation_required",
                "local_only",
                "raw_audio_memory_only",
            ],
        }

    def open_stream(self, member_id, config):
        return AcceptanceRecognizer()


class AcceptanceLocalClientTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.store = RecordStore(
            self.root / "records.db",
            PlaintextEngineeringCodec(),
            allow_unencrypted_engineering=True,
        )
        app = DeviceApplication(
            self.store,
            TokenAuthorizer({TOKEN: {MEMBER}}),
            ocr_adapter=AcceptanceOcrAdapter(),
            asr_adapter=AcceptanceAsrAdapter(),
        )
        self.server = BoundedThreadingHTTPServer(
            ("127.0.0.1", 0), DeviceRequestHandler
        )
        self.server.application = app  # type: ignore[attr-defined]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.port = self.server.server_address[1]

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        self.store.close()
        self.temporary.cleanup()

    def _task_statuses(self) -> list[str]:
        connection = sqlite3.connect(self.root / "records.db")
        try:
            return [row[0] for row in connection.execute("SELECT status FROM tasks")]
        finally:
            connection.close()

    def test_ocr_client_uses_real_http_and_cancels_unconfirmed_task(self) -> None:
        image = self.root / "report.png"
        image.write_bytes(PNG)
        rows = run_ocr_case(
            self.port,
            TOKEN,
            MEMBER,
            {
                "sample_id": "ocr-001",
                "path": image.name,
                "sha256": hashlib.sha256(PNG).hexdigest(),
                "media_type": "image/png",
                "ground_truth": [
                    {"field": "systolic", "truth": "120", "required": True},
                    {"field": "diastolic", "truth": "80", "required": True},
                ],
            },
            self.root,
        )
        self.assertEqual([row["prediction"] for row in rows], ["120", "80"])
        self.assertEqual(self.store.list_records(MEMBER), [])
        self.assertEqual(self._task_statuses(), ["cancelled"])

    def test_asr_client_uses_real_websocket_and_cancels_unconfirmed_task(self) -> None:
        audio_path = self.root / "utterance.wav"
        with wave.open(str(audio_path), "wb") as audio:
            audio.setnchannels(1)
            audio.setsampwidth(2)
            audio.setframerate(16000)
            audio.writeframes(b"\x00\x00" * 3200)
        data = audio_path.read_bytes()
        row = run_asr_case(
            self.port,
            TOKEN,
            MEMBER,
            {
                "sample_id": "asr-001",
                "path": audio_path.name,
                "sha256": hashlib.sha256(data).hexdigest(),
                "reference": "血压一百二十，低压八十",
                "expected_slots": {"systolic": 120, "diastolic": 80},
            },
            self.root,
        )
        self.assertEqual(row["prediction"], "血压一百二十，低压八十")
        self.assertEqual(row["predicted_slots"]["systolic"], 120)
        self.assertEqual(self.store.list_records(MEMBER), [])
        self.assertEqual(self._task_statuses(), ["cancelled"])

    def test_client_rejects_input_outside_pinned_root(self) -> None:
        outside = self.root.parent / "outside-acceptance.png"
        outside.write_bytes(PNG)
        try:
            with self.assertRaises(ValueError):
                run_ocr_case(
                    self.port,
                    TOKEN,
                    MEMBER,
                    {
                        "sample_id": "escape",
                        "path": "../outside-acceptance.png",
                        "sha256": hashlib.sha256(PNG).hexdigest(),
                        "media_type": "image/png",
                    },
                    self.root,
                )
        finally:
            outside.unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
