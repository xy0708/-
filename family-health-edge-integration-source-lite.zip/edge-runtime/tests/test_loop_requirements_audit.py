from __future__ import annotations

import unittest

from scripts.audit_loop_requirements import (
    arm64_asr_engineering_pass,
    audit_exit_code,
    component_integration_engineering_pass,
    pending_until_product,
    progressive_gate_status,
)


class LoopRequirementsAuditTests(unittest.TestCase):
    def test_arm64_asr_requires_fail_closed_real_model_evidence(self):
        asr = {"status": "PASS_ENGINEERING"}
        evidence = {
            "status": "PASS_ENGINEERING",
            "hardware_measured": False,
            "product_complete": False,
            "three_model_inference_verified": False,
            "errors": [],
        }
        integration = dict(evidence)
        self.assertTrue(arm64_asr_engineering_pass(asr, evidence, integration))
        self.assertFalse(arm64_asr_engineering_pass({}, evidence, integration))
        self.assertFalse(arm64_asr_engineering_pass(asr, {}, integration))
        self.assertFalse(arm64_asr_engineering_pass(asr, evidence, {}))
        self.assertFalse(
            arm64_asr_engineering_pass(
                asr, {**evidence, "three_model_inference_verified": True}, integration
            )
        )
        self.assertFalse(
            arm64_asr_engineering_pass(
                asr, evidence, {**integration, "hardware_measured": True}
            )
        )

    def test_component_integration_tracks_both_engineering_workers(self):
        component = {
            "status": "PASS_ENGINEERING",
            "process_supervisor_engineering_implemented": True,
            "engineering_asr_worker_registered": True,
            "engineering_ocr_worker_registered": True,
            "engineering_runtime_bootstrap_sha256": "a" * 64,
            "backend_registry_sha256": "b" * 64,
            "backend_selection_sha256": "c" * 64,
            "device_service_backend_registry_integrated": True,
            "product_native_workers_registered": False,
            "hardware_measured": False,
        }
        integration = {
            "status": "PASS_ENGINEERING",
            "hardware_measured": False,
            "product_complete": False,
        }

        self.assertTrue(component_integration_engineering_pass(component, integration))
        self.assertFalse(
            component_integration_engineering_pass(
                {**component, "engineering_ocr_worker_registered": False}, integration
            )
        )
        self.assertFalse(
            component_integration_engineering_pass(
                component, {**integration, "hardware_measured": True}
            )
        )
        self.assertTrue(
            component_integration_engineering_pass(
                {
                    **component,
                    "product_native_workers_registered": True,
                    "hardware_measured": True,
                },
                integration,
            )
        )

    def test_audit_exit_codes_distinguish_blocker_from_engineering_failure(self):
        self.assertEqual(audit_exit_code({"status": "BLOCKED_EXTERNAL"}), 2)
        self.assertEqual(audit_exit_code({"status": "FAIL_ENGINEERING"}), 1)
        self.assertEqual(audit_exit_code({"status": "FAIL_CONTRADICTION"}), 1)
        self.assertEqual(audit_exit_code({"status": "PASS_PRODUCT_GATE"}), 0)

    def test_progressive_gate_cannot_skip_engineering_or_keep_product_unmet(self):
        self.assertEqual(
            progressive_gate_status(engineering_pass=False, product_pass=True),
            "FAIL",
        )
        self.assertEqual(
            progressive_gate_status(engineering_pass=True, product_pass=False),
            "PASS_ENGINEERING",
        )
        self.assertEqual(
            progressive_gate_status(engineering_pass=True, product_pass=True),
            "PASS_PRODUCT_GATE",
        )
        self.assertEqual(pending_until_product(True, "external evidence"), [])
        self.assertEqual(
            pending_until_product(False, "external evidence"),
            ["external evidence"],
        )
