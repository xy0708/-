from __future__ import annotations

import unittest

from integration_adapter import ComponentContractError, normalize_component_health


class ComponentContractTests(unittest.TestCase):
    def test_compatible_health_is_sanitized_and_sorted(self) -> None:
        result = normalize_component_health(
            "ocr",
            {
                "ready": True,
                "contract_version": "1.3.0",
                "component_version": "2.1.0",
                "capabilities": ["ocr_task", "local_only"],
                "debug_detail": "must not escape",
            },
            required_capabilities={"local_only", "ocr_task"},
        )
        self.assertTrue(result["ready"])
        self.assertEqual(result["capabilities"], ["local_only", "ocr_task"])
        self.assertNotIn("debug_detail", result)

    def test_major_version_missing_capability_and_bad_hash_fail_closed(self) -> None:
        cases = [
            {
                "ready": True,
                "contract_version": "2.0.0",
                "component_version": "1.0.0",
                "capabilities": ["ocr_task"],
            },
            {
                "ready": True,
                "contract_version": "1.0.0",
                "component_version": "1.0.0",
                "capabilities": ["local_only"],
            },
            {
                "ready": True,
                "contract_version": "1.0.0",
                "component_version": "1.0.0",
                "capabilities": ["ocr_task"],
                "model_sha256": "not-a-hash",
            },
        ]
        for payload in cases:
            with self.subTest(payload=payload), self.assertRaises(ComponentContractError):
                normalize_component_health(
                    "ocr", payload, required_capabilities={"ocr_task"}
                )

    def test_nested_capability_from_child_process_fails_closed(self) -> None:
        payload = {
            "ready": True,
            "contract_version": "1.0.0",
            "component_version": "1.0.0",
            "capabilities": [{"nested": "invalid"}],
        }
        with self.assertRaisesRegex(ComponentContractError, "capabilities are invalid"):
            normalize_component_health(
                "ocr", payload, required_capabilities={"ocr_task"}
            )


if __name__ == "__main__":
    unittest.main()
