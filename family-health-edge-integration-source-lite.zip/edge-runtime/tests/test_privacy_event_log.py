from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from operations import PrivacySafeEventLog


class PrivacySafeEventLogTests(unittest.TestCase):
    def test_log_schema_cannot_receive_user_content(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "events.jsonl"
            log = PrivacySafeEventLog(path)
            log.request_completed(
                status=422,
                request_id="abc123",
                error_code="INPUT_INVALID",
                operation="RECORD_CORRECT",
            )
            text = path.read_text(encoding="utf-8")
            event = json.loads(text)
            self.assertEqual(
                set(event),
                {"timestamp", "event", "status", "request_id", "error_code", "operation"},
            )
            self.assertEqual(event["operation"], "RECORD_CORRECT")
            logged_labels = " ".join(
                str(event[field])
                for field in ("event", "request_id", "error_code", "operation")
            )
            for forbidden in ("member-a", "138", "/v1/", "Bearer", "weight"):
                self.assertNotIn(forbidden, logged_labels)

    def test_unsafe_event_values_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            log = PrivacySafeEventLog(Path(temporary) / "events.jsonl")
            with self.assertRaises(ValueError):
                log.request_completed(
                    status=200,
                    request_id="member-a /v1/health",
                    error_code=None,
                    operation="HEALTH_STATUS",
                )
            with self.assertRaises(ValueError):
                log.request_completed(
                    status=200,
                    request_id="safe",
                    error_code=None,
                    operation="/v1/members/member-a/records",
                )
