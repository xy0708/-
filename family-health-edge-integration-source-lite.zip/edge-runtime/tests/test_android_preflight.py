from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from collect_android_preflight import evaluate_properties, parse_adb_devices  # noqa: E402


class AndroidPreflightTests(unittest.TestCase):
    def test_parses_authorized_and_unauthorized_devices(self) -> None:
        output = """List of devices attached
ABC device product:board model:rk transport_id:1
XYZ unauthorized transport_id:2
"""
        devices = parse_adb_devices(output)
        self.assertEqual([device["state"] for device in devices], ["device", "unauthorized"])
        self.assertEqual(devices[0]["details"]["model"], "rk")

    def test_accepts_rk3576_android_14_but_keeps_hardening_separate(self) -> None:
        errors, blockers = evaluate_properties(
            {
                "ro.product.board": "rk3576",
                "ro.board.platform": "rk3576",
                "ro.hardware": "rockchip",
                "ro.product.cpu.abi": "arm64-v8a",
                "ro.build.version.release": "14",
                "ro.build.version.sdk": "34",
                "ro.build.fingerprint": "vendor/board/build:14/id:userdebug/test-keys",
                "ro.build.version.security_patch": "2024-01-05",
                "ro.build.type": "userdebug",
                "ro.debuggable": "1",
                "ro.secure": "1",
                "selinux": "Enforcing",
            }
        )
        self.assertEqual(errors, [])
        self.assertIn("build_type_not_user", blockers)
        self.assertIn("ro_debuggable_not_zero", blockers)

    def test_rejects_wrong_soc_or_abi(self) -> None:
        errors, _ = evaluate_properties(
            {
                "ro.product.board": "unknown",
                "ro.product.cpu.abi": "armeabi-v7a",
                "ro.build.version.release": "13",
                "ro.build.version.sdk": "25",
                "ro.build.fingerprint": "x",
            }
        )
        self.assertIn("soc_is_not_verified_as_rk3576", errors)
        self.assertIn("primary_abi_is_not_arm64_v8a", errors)
        self.assertIn("android_release_is_not_14", errors)
        self.assertIn("android_api_is_not_34", errors)


if __name__ == "__main__":
    unittest.main()
