from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from scripts.verify_arm64_runtime_tool import (
    EXPECTED_STATUS,
    elf_metadata,
    safe_path,
    verify,
)


ROOT = Path(__file__).resolve().parents[1]


class Arm64RuntimeToolVerificationTests(unittest.TestCase):
    def test_current_immutable_artifact_verifies(self) -> None:
        result = verify(ROOT)

        self.assertEqual(EXPECTED_STATUS, result["status"], result["errors"])
        self.assertFalse(result["hardware_measured"])
        self.assertFalse(result["product_accepted"])

    def test_safe_path_rejects_parent_escape(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)

            self.assertIsNone(safe_path(base, "../outside", kind="file"))

    def test_elf_parser_rejects_non_elf(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "not-elf"
            path.write_bytes(b"not an elf")

            with self.assertRaisesRegex(ValueError, "ARTIFACT_NOT_ELF"):
                elf_metadata(path)


if __name__ == "__main__":
    unittest.main()
