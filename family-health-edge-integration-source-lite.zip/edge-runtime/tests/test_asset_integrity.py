from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path

from scripts.asset_integrity import verify_file


class AssetIntegrityTests(unittest.TestCase):
    def test_size_and_sha256_are_both_required(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "asset.bin"
            path.write_bytes(b"edge-model")
            digest = hashlib.sha256(b"edge-model").hexdigest()
            self.assertTrue(verify_file(path, 10, digest)["passed"])
            self.assertFalse(verify_file(path, 11, digest)["passed"])
            self.assertFalse(verify_file(path, 10, "0" * 64)["passed"])


if __name__ == "__main__":
    unittest.main()
