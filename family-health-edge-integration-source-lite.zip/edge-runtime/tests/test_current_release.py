from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from scripts.verify_current_release import (
    canonical_current_release_id,
    resolve_current,
)


class CurrentReleaseTests(unittest.TestCase):
    def test_only_canonical_relative_release_target_is_accepted(self) -> None:
        self.assertEqual(
            canonical_current_release_id("releases/v1.2.3"), "v1.2.3"
        )
        for value in (
            "/opt/family-health-edge/releases/v1.2.3",
            "../releases/v1.2.3",
            "releases/../v1.2.3",
            "releases\\v1.2.3",
            "releases/.hidden",
            "other/v1.2.3",
        ):
            with self.subTest(value=value), self.assertRaisesRegex(
                ValueError, "not canonical"
            ):
                canonical_current_release_id(value)

    def test_current_and_releases_redirects_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "install"
            releases = root / "releases"
            release = releases / "v1.2.3"
            release.mkdir(parents=True)
            current = root / "current"
            try:
                current.symlink_to(Path("releases") / release.name, target_is_directory=True)
            except OSError:
                self.skipTest("symlink creation is unavailable on this host")
            self.assertEqual(resolve_current(current, root), release.resolve())

            current.unlink()
            current.symlink_to(release.resolve(), target_is_directory=True)
            with self.assertRaisesRegex(ValueError, "not canonical"):
                resolve_current(current, root)

    def test_releases_directory_redirect_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            root = base / "install"
            outside = base / "outside"
            root.mkdir()
            (outside / "v1.2.3").mkdir(parents=True)
            releases = root / "releases"
            current = root / "current"
            try:
                releases.symlink_to(outside, target_is_directory=True)
                current.symlink_to("releases/v1.2.3", target_is_directory=True)
            except OSError:
                self.skipTest("symlink creation is unavailable on this host")
            with self.assertRaisesRegex(ValueError, "releases directory"):
                resolve_current(current, root)


if __name__ == "__main__":
    unittest.main()
