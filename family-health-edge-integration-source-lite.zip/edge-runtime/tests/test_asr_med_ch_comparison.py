from __future__ import annotations

import unittest

from benchmarks.comparison.asr_med_ch import (
    candidate_report_is_current,
    normalize_for_cer,
    percentile,
    predictions_digest,
    validate_candidate_report,
)


class AsrMedChComparisonTests(unittest.TestCase):
    def test_normalization_matches_frozen_chinese_cer_policy(self) -> None:
        self.assertEqual(normalize_for_cer("Ａ 十，S N P。"), "a十snp")

    def test_percentile_interpolates_without_hiding_tail(self) -> None:
        self.assertEqual(percentile([1.0, 2.0, 3.0], 0.5), 2.0)
        self.assertAlmostEqual(percentile([1.0, 3.0], 0.95), 2.9)

    def test_candidate_validation_rejects_product_overstatement(self) -> None:
        predictions = [{"id": str(index)} for index in range(60)]
        report = {
            "schema_version": "1.0.0",
            "status": "PASS_ENGINEERING_PUBLIC_SET_EVALUATION_PRODUCT_BLOCKED",
            "scope": "MED_CH_60_RESEARCH_ENGINEERING_ONLY",
            "candidate_id": "candidate",
            "product_selection_allowed": False,
            "hardware_measured": False,
            "target_microphone_evidence": False,
            "dataset": {
                "usage": "research evaluation only; commercial license review required",
                "commercial_rights_cleared": False,
                "samples": 60,
            },
            "metrics": {
                "samples": 60,
                "cer": 0.2,
                "failures": 0,
                "empty_results": 0,
            },
            "predictions": predictions,
            "predictions_sha256": predictions_digest(predictions),
        }
        self.assertEqual(validate_candidate_report(report, "candidate"), [])
        report["product_selection_allowed"] = True
        self.assertIn(
            "CANDIDATE_BOUNDARY_INVALID",
            validate_candidate_report(report, "candidate"),
        )

    def test_resume_rejects_stale_dataset_or_model_identity(self) -> None:
        predictions = [{"id": str(index)} for index in range(60)]
        dataset = {
            "usage": "research evaluation only; commercial license review required",
            "commercial_rights_cleared": False,
            "samples": 60,
            "manifest_sha256": "manifest",
        }
        report = {
            "schema_version": "1.0.0",
            "status": "PASS_ENGINEERING_PUBLIC_SET_EVALUATION_PRODUCT_BLOCKED",
            "scope": "MED_CH_60_RESEARCH_ENGINEERING_ONLY",
            "candidate_id": "candidate",
            "product_selection_allowed": False,
            "hardware_measured": False,
            "target_microphone_evidence": False,
            "dataset": dataset,
            "metrics": {
                "samples": 60,
                "cer": 0.2,
                "failures": 0,
                "empty_results": 0,
            },
            "predictions": predictions,
            "predictions_sha256": predictions_digest(predictions),
            "model_sha256": "model-a",
        }
        self.assertTrue(
            candidate_report_is_current(
                report,
                candidate_id="candidate",
                expected_dataset=dataset,
                expected_identity={"model_sha256": "model-a"},
            )
        )
        self.assertFalse(
            candidate_report_is_current(
                report,
                candidate_id="candidate",
                expected_dataset={**dataset, "manifest_sha256": "changed"},
                expected_identity={"model_sha256": "model-a"},
            )
        )
        self.assertFalse(
            candidate_report_is_current(
                report,
                candidate_id="candidate",
                expected_dataset=dataset,
                expected_identity={"model_sha256": "model-b"},
            )
        )


if __name__ == "__main__":
    unittest.main()
