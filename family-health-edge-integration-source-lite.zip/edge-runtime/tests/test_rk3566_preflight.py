from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path

from scripts.collect_rk3566_preflight import validate_connection, validate_device_report


class Rk3566PreflightTests(unittest.TestCase):
    def test_connection_requires_real_files_and_pinned_known_hosts_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            identity = root / "id"
            known = root / "known_hosts"
            identity.write_text("test fixture only", encoding="utf-8")
            known.write_text("host key fixture", encoding="utf-8")
            config = {
                "host": "192.0.2.10",
                "port": 22,
                "user": "maintenance",
                "identity_file": str(identity),
                "known_hosts_file": str(known),
                "known_hosts_sha256": hashlib.sha256(known.read_bytes()).hexdigest(),
            }
            failures, _, _ = validate_connection(config)
            self.assertEqual(failures, [])
            config["known_hosts_sha256"] = "0" * 64
            failures, _, _ = validate_connection(config)
            self.assertIn("KNOWN_HOSTS_SHA256_MISMATCH", failures)

    def test_non_target_or_simulated_report_cannot_pass(self) -> None:
        fixture = {
            "evidence_origin": "ON_DEVICE_PREFLIGHT_SCRIPT",
            "hardware_measured": True,
            "rk3566_detected": True,
            "architecture_supported": True,
            "architecture": "aarch64",
            "simulation_detected": True,
            "passed": True,
        }
        self.assertIn("REMOTE_SIMULATION_DETECTED_OR_UNKNOWN", validate_device_report(fixture))
        fixture["simulation_detected"] = False
        fixture["rk3566_detected"] = False
        self.assertIn("REMOTE_REPORT_FALSE:rk3566_detected", validate_device_report(fixture))


if __name__ == "__main__":
    unittest.main()
