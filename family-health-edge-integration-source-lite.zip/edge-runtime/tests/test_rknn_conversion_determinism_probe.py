from __future__ import annotations

import unittest
from pathlib import Path

from scripts.run_rknn_conversion_determinism_probe import (
    FIXED_ENVIRONMENT,
    docker_command,
    probe_status,
)
from scripts.run_rknn_conversion_reproducibility import CASES, ROOT


class RknnConversionDeterminismProbeTests(unittest.TestCase):
    def test_command_fixes_common_environment_nondeterminism(self) -> None:
        command = docker_command(CASES[0], Path("C:/probe"), "a")
        pairs = list(zip(command, command[1:]))
        for variable in FIXED_ENVIRONMENT:
            self.assertIn(("--env", variable), pairs)
        self.assertIn(("--network", "none"), pairs)
        self.assertIn(("--volume", f"{Path('C:/probe')}:/evidence"), pairs)
        self.assertIn(("--volume", f"{ROOT}:/workspace:ro"), pairs)

    def test_unavailable_image_is_not_reported_as_hash_drift(self) -> None:
        self.assertEqual(
            probe_status(False, 0, 0),
            "BLOCKED_ENVIRONMENT_CONVERSION_IMAGE_UNAVAILABLE",
        )


if __name__ == "__main__":
    unittest.main()
