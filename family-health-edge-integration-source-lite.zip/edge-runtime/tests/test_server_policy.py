from __future__ import annotations

import json
import tempfile
import socket
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from device_service.server import (
    BoundedThreadingHTTPServer,
    DeviceRequestHandler,
    _close_server_resources,
    build_application,
    load_verified_release_id,
)
from storage import StoragePolicyError


class ServerPolicyTests(unittest.TestCase):
    def test_product_release_id_is_bound_to_resolved_release_directory(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            release = root / "release-1"
            release.mkdir()
            manifest = release / "manifest.json"
            manifest.write_text(
                json.dumps(
                    {
                        "schema_version": "1.0.0",
                        "release_id": "release-1",
                        "created_at": "2026-09-21T00:00:00+00:00",
                        "files": [{"path": "bin/family-health-edge"}],
                    }
                ),
                encoding="utf-8",
            )
            self.assertEqual(load_verified_release_id(manifest), "release-1")
            value = json.loads(manifest.read_text())
            value["release_id"] = "different-release"
            manifest.write_text(json.dumps(value), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "boundary"):
                load_verified_release_id(manifest)

    def test_event_log_failure_does_not_lose_response_and_degrades_health(self) -> None:
        class HealthApplication:
            contract_version = "1.0.0"
            component_version = "test"

            def dispatch(self, method, path, headers, body):
                return 200, {
                    "status": "success",
                    "request_id": "a" * 32,
                    "error": None,
                    "result": {"status": "ok_engineering"},
                }

        class FailingEventLog:
            def request_completed(self, **kwargs):
                raise OSError("simulated full disk")

        server = BoundedThreadingHTTPServer(("127.0.0.1", 0), DeviceRequestHandler)
        server.application = HealthApplication()  # type: ignore[attr-defined]
        server.event_log = FailingEventLog()  # type: ignore[attr-defined]
        server.event_log_healthy = True  # type: ignore[attr-defined]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{server.server_port}/v1/health"
            first = json.loads(urllib.request.urlopen(url, timeout=2).read())
            self.assertEqual(first["result"]["status"], "ok_engineering")
            second = json.loads(urllib.request.urlopen(url, timeout=2).read())
            self.assertEqual(second["result"]["status"], "degraded")
            self.assertEqual(
                second["result"]["event_log"]["reason"], "EVENT_LOG_UNAVAILABLE"
            )
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_ambiguous_or_truncated_http_bodies_are_rejected(self) -> None:
        class RejectIfCalledApplication:
            contract_version = "1.0.0"
            component_version = "test"

            def dispatch(self, method, path, headers, body):
                raise AssertionError("ambiguous input must not reach the application")

        server = BoundedThreadingHTTPServer(("127.0.0.1", 0), DeviceRequestHandler)
        server.application = RejectIfCalledApplication()  # type: ignore[attr-defined]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            requests = (
                (
                    "POST /v1/records/confirm HTTP/1.1\r\n"
                    f"Host: 127.0.0.1:{server.server_port}\r\n"
                    "Transfer-Encoding: chunked\r\n\r\n0\r\n\r\n"
                ).encode("ascii"),
                (
                    "POST /v1/records/confirm HTTP/1.1\r\n"
                    f"Host: 127.0.0.1:{server.server_port}\r\n"
                    "Content-Length: 20\r\n\r\n{}"
                ).encode("ascii"),
            )
            for index, request in enumerate(requests):
                with self.subTest(index=index):
                    sock = socket.create_connection(server.server_address, timeout=2)
                    try:
                        sock.sendall(request)
                        if index == 1:
                            sock.shutdown(socket.SHUT_WR)
                        response = sock.recv(4096)
                        self.assertIn(b" 422 ", response)
                        self.assertIn(b"Connection: close", response)
                    finally:
                        sock.close()
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_shutdown_drains_handlers_before_closing_storage(self) -> None:
        calls = []

        class FakeServer:
            def server_close(self):
                calls.append("server")

        class FakeStore:
            def close(self):
                calls.append("store")

        class FakeApplication:
            store = FakeStore()

        self.assertFalse(BoundedThreadingHTTPServer.daemon_threads)
        self.assertTrue(BoundedThreadingHTTPServer.block_on_close)
        _close_server_resources(FakeServer(), FakeApplication())  # type: ignore[arg-type]
        self.assertEqual(calls, ["server", "store"])

    def test_product_mode_refuses_unencrypted_sqlite(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(StoragePolicyError):
                build_application(Path(temporary) / "edge.db", "x" * 40, engineering=False)

    def test_unexpected_application_error_is_fixed_and_does_not_leak(self) -> None:
        class ExplodingApplication:
            contract_version = "1.0.0"
            component_version = "test"

            def dispatch(self, method, path, headers, body):
                raise RuntimeError("sensitive internal exception detail")

        server = BoundedThreadingHTTPServer(
            ("127.0.0.1", 0), DeviceRequestHandler, max_concurrent_requests=1
        )
        server.application = ExplodingApplication()  # type: ignore[attr-defined]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            request = urllib.request.Request(
                f"http://127.0.0.1:{server.server_port}/v1/version"
            )
            with self.assertRaises(urllib.error.HTTPError) as raised:
                urllib.request.urlopen(request, timeout=2)
            body = raised.exception.read().decode("utf-8")
            self.assertEqual(raised.exception.code, 500)
            self.assertIn("INTERNAL_ERROR", body)
            self.assertNotIn("sensitive internal exception detail", body)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
