from __future__ import annotations

import unittest

from scripts.verify_official_model_lock import verify_lock


class OfficialModelLockTests(unittest.TestCase):
    def test_all_official_candidate_assets_are_hash_locked(self):
        result = verify_lock()
        self.assertEqual(result["status"], "PASS_ENGINEERING", result["errors"])
        self.assertEqual(result["verified_files"], 21)
        self.assertEqual(result["verified_repositories"], 5)
        self.assertFalse(result["product_selected"])
        self.assertFalse(result["formal_release_allowed"])
        self.assertEqual(result["legal_review"], "BLOCKED_EXTERNAL")
