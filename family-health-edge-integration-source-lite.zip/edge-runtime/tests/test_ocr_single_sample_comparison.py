from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from benchmarks.comparison.ocr_single_sample import (
    REPORT_SCHEMA_VERSION,
    REPORT_SCOPE,
    REPORT_STATUS,
    ComparisonEvidenceError,
    compare_line_outputs,
    load_rknn_lines,
    text_digest,
    validate_report,
)


class OcrSingleSampleComparisonTests(unittest.TestCase):
    def test_pairwise_metric_is_not_labeled_as_accuracy(self) -> None:
        result = compare_line_outputs(["血糖 5.6", "正常"], ["血糖 5.8", "正常"])

        self.assertFalse(result["all_positioned_lines_exact_match"])
        self.assertEqual(result["positioned_line_exact_match_count"], 1)
        self.assertEqual(result["pairwise_character_edit_distance"], 1)
        self.assertIn("not OCR", result["metric_meaning"])

    def test_text_digest_is_nfkc_normalized(self) -> None:
        self.assertEqual(text_digest(["ＡＢＣ"]), text_digest(["ABC"]))

    def test_rknn_source_rejects_product_claim_or_wrong_image(self) -> None:
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as directory:
            report = Path(directory) / "rknn.json"
            report.write_text(
                json.dumps(
                    {
                        "status": "PASS_ENGINEERING_FUNCTIONAL_SIMULATION",
                        "scope": "PC_SIMULATOR_SINGLE_OFFICIAL_SAMPLE_ONLY",
                        "hardware_measured": False,
                        "product_accuracy_claim_allowed": True,
                        "ocr_metric_claim_allowed": False,
                        "inputs": {"image_sha256": "a" * 64},
                        "comparison": {"rknn_text": ["工程样例"]},
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaises(ComparisonEvidenceError):
                load_rknn_lines(report, "a" * 64)

    def test_report_validation_is_hash_bound_and_has_no_winner(self) -> None:
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as directory:
            root = Path(directory)
            image = root / "image.jpg"
            manifest = root / "manifest.json"
            rknn = root / "rknn.json"
            image.write_bytes(b"image")
            manifest.write_text("{}", encoding="utf-8")
            rknn.write_text("{}", encoding="utf-8")
            digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
            report = {
                "schema_version": REPORT_SCHEMA_VERSION,
                "status": REPORT_STATUS,
                "scope": REPORT_SCOPE,
                "ground_truth_available": False,
                "accuracy_claim_allowed": False,
                "product_selection_allowed": False,
                "hardware_measured": False,
                "host_timing_comparable_for_ranking": False,
                "authorized_health_report_data_used": False,
                "source_hashes": {
                    "image_sha256": digest(image),
                    "cpu_manifest_sha256": digest(manifest),
                    "rknn_simulator_report_sha256": digest(rknn),
                },
                "candidates": {
                    "ocr_paddle_cpu_ppocrv5": {},
                    "ocr_rknn_ppocrv4": {},
                },
                "comparison": {
                    "pairwise_character_disagreement_rate": 0.1,
                    "metric_meaning": "not accuracy",
                },
                "conclusion": {"result": "NO_PRODUCT_WINNER", "winner": None},
            }

            self.assertEqual(
                validate_report(
                    report,
                    image_path=image,
                    cpu_manifest_path=manifest,
                    rknn_report_path=rknn,
                ),
                [],
            )
            report["conclusion"]["winner"] = "ocr_rknn_ppocrv4"
            self.assertIn(
                "PRODUCT_WINNER_OVERSTATED",
                validate_report(
                    report,
                    image_path=image,
                    cpu_manifest_path=manifest,
                    rknn_report_path=rknn,
                ),
            )


if __name__ == "__main__":
    unittest.main()
