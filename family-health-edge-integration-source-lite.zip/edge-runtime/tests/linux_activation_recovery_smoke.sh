#!/usr/bin/env bash
set -euo pipefail

workspace="${EDGE_RECOVERY_TEST_WORKSPACE:-/workspace}"
test_root="$(mktemp -d /tmp/edge-activation-recovery.XXXXXX)"
install_root="$test_root/install"
state_root="$test_root/state"
tool_root="${EDGE_RECOVERY_TEST_TOOL_ROOT:-$test_root/tools}"
runtime_tool="${EDGE_RUNTIME_TOOL:?EDGE_RUNTIME_TOOL is required}"
expected_runtime_tool_sha256="${EDGE_RUNTIME_TOOL_SHA256:?EDGE_RUNTIME_TOOL_SHA256 is required}"
runtime_tmp="$test_root/runtime-tmp"
mkdir -p "$install_root/releases/v1" "$install_root/releases/v2" "$state_root" "$tool_root" "$runtime_tmp"
chmod 0700 "$state_root"
chmod 0700 "$runtime_tmp"
export EDGE_RUNTIME_TMPDIR="$runtime_tmp"
export TMPDIR="$runtime_tmp"
ln -s releases/v2 "$install_root/current"

if [ ! -x "$runtime_tool" ]; then
  echo '{"status":"FAIL","reason":"RUNTIME_TOOL_NOT_EXECUTABLE"}'
  exit 2
fi
actual_runtime_tool_sha256="$(sha256sum "$runtime_tool" | awk '{print $1}')"
if [ "$actual_runtime_tool_sha256" != "$expected_runtime_tool_sha256" ]; then
  echo '{"status":"FAIL","reason":"RUNTIME_TOOL_HASH_MISMATCH"}'
  exit 2
fi

test_adapter="$tool_root/family-health-edge-tool-test-adapter"
cat >"$test_adapter" <<EOF
#!/bin/sh
command="\$1"
shift
case "\$command" in
  activation-marker) exec "$runtime_tool" activation-marker "\$@" ;;
  verify-release-bundle|verify-current-release|check-release-health|check-rollback-transition) exit 0 ;;
  *) exit 2 ;;
esac
EOF
chmod 0755 "$test_adapter"

"$runtime_tool" activation-marker prepare \
  --marker "$state_root/pending-activation.json" \
  --candidate v2 \
  --previous v1 >/dev/null

EDGE_INSTALL_ROOT="$install_root" \
EDGE_STATE_ROOT="$state_root" \
EDGE_UPDATE_STATE_ROOT="$state_root" \
EDGE_RUNTIME_TOOL="$test_adapter" \
bash "$workspace/scripts/recover_pending_activation.sh" >/dev/null

if [ "$(readlink "$install_root/current")" != "releases/v1" ]; then
  echo '{"status":"FAIL","reason":"PREVIOUS_RELEASE_NOT_RESTORED"}'
  exit 2
fi
if [ -e "$state_root/pending-activation.json" ] || [ -L "$state_root/pending-activation.json" ]; then
  echo '{"status":"FAIL","reason":"PENDING_MARKER_NOT_CLEARED"}'
  exit 2
fi

resume_root="$test_root/resume"
resume_install="$resume_root/install"
resume_state="$resume_root/state"
incoming="$resume_root/incoming/v2"
mkdir -p \
  "$resume_install/releases/v1" \
  "$resume_install/releases/v2/signatures" \
  "$resume_state" \
  "$incoming/signatures" \
  "$resume_root/bin"
printf '%s\n' '{"signed":"fixture"}' >"$resume_install/releases/v2/manifest.json"
printf '%s\n' 'fixture-signature' >"$resume_install/releases/v2/signatures/manifest.sig"
cp "$resume_install/releases/v2/manifest.json" "$incoming/manifest.json"
cp "$resume_install/releases/v2/signatures/manifest.sig" "$incoming/signatures/manifest.sig"
ln -s /bin/true "$resume_root/bin/systemctl"
ln -s releases/v1 "$resume_install/current"

PATH="$resume_root/bin:$PATH" \
EDGE_INSTALL_ROOT="$resume_install" \
EDGE_STATE_ROOT="$resume_state" \
EDGE_UPDATE_STATE_ROOT="$resume_state" \
EDGE_RUNTIME_TOOL="$test_adapter" \
bash "$workspace/scripts/install_release.sh" "$incoming" >/dev/null

if [ "$(readlink "$resume_install/current")" != "releases/v2" ]; then
  echo '{"status":"FAIL","reason":"INTERRUPTED_DESTINATION_NOT_RESUMED"}'
  exit 2
fi
if [ -e "$resume_state/pending-activation.json" ] || [ -L "$resume_state/pending-activation.json" ]; then
  echo '{"status":"FAIL","reason":"RESUMED_INSTALL_MARKER_NOT_CLEARED"}'
  exit 2
fi
printf '{"status":"PASS_ENGINEERING","architecture":"%s","network":"none","hardware_measured":false,"signature_verifier_stubbed":true,"interrupted_destination_resume":true,"runtime_tool_real_arm64_artifact":true,"runtime_tool_hash_verified":true,"runtime_tool_activation_real":true}\n' "$(uname -m)"
