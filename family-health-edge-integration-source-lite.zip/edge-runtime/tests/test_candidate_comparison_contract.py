from __future__ import annotations

import unittest

from scripts.verify_candidate_comparison_contract import verify_contract


class CandidateComparisonContractTests(unittest.TestCase):
    def test_contract_is_ready_for_approval_but_cannot_select_a_winner(self) -> None:
        result = verify_contract()
        self.assertEqual(
            result["status"],
            "PASS_ENGINEERING_CONTRACT_SCAFFOLD_PRODUCT_BLOCKED",
            result["errors"],
        )
        self.assertEqual(result["active_comparison_candidate_count"], 4)
        self.assertEqual(result["metric_count"], 16)
        self.assertFalse(result["thresholds_approved"])
        self.assertFalse(result["selection_data_available"])
        self.assertFalse(result["real_rk3566_profile_available"])
        self.assertFalse(result["product_selection_allowed"])
        self.assertIsNone(result["winner"])


if __name__ == "__main__":
    unittest.main()
