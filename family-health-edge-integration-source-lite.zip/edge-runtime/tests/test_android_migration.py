from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from verify_android_migration import validate  # noqa: E402


class AndroidMigrationContractTests(unittest.TestCase):
    def test_active_android_contract_is_internally_consistent(self) -> None:
        errors, facts = validate(ROOT)
        self.assertEqual(errors, [])
        self.assertEqual(facts["target_os"], "Android")
        self.assertEqual(facts["target_soc"], "RK3576")
        self.assertEqual(facts["android_release"], "14")
        self.assertEqual(facts["target_abi"], "arm64-v8a")

    def test_release_remains_fail_closed(self) -> None:
        contract = json.loads(
            (ROOT / "configs" / "product_delivery_contract.json").read_text(
                encoding="utf-8"
            )
        )
        sdk = json.loads(
            (ROOT / "configs" / "wearable_sdk_source.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertFalse(contract["formal_release_allowed"])
        self.assertFalse(contract["debug_signing_allowed_for_release"])
        self.assertFalse(sdk["product_use_allowed"])
        self.assertFalse(sdk["license"]["commercial_redistribution_approved"])

        selected_sdk = json.loads(
            (ROOT / "configs" / "yucheng_android_sdk_source.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertFalse(selected_sdk["product_use_allowed"])
        self.assertFalse(
            selected_sdk["license"]["embedded_binary_redistribution_approved"]
        )


if __name__ == "__main__":
    unittest.main()
