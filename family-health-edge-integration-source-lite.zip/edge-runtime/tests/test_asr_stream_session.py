from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from asr_runtime import AsrStreamLimits, AsrStreamSession
from integration_adapter import ComponentOperationError
from storage import PlaintextEngineeringCodec, RecordStore, TaskStateError


class FakeRecognizer:
    def __init__(self) -> None:
        self.feed_calls = 0
        self.closed = False

    def feed_pcm(self, pcm_s16le: bytes) -> str | None:
        self.feed_calls += 1
        return "血压" if self.feed_calls == 1 else None

    def finish(self):
        return {"text": "血压一百二十", "fields": {"systolic": 120}}

    def close(self) -> None:
        self.closed = True


class FakeAdapter:
    def __init__(self) -> None:
        self.recognizer = FakeRecognizer()

    def open_stream(self, member_id, config):
        return self.recognizer


class FailingStore:
    def create_task(self, member_id, kind, result):
        raise OSError("injected storage failure")


class CircuitOpenRecognizer(FakeRecognizer):
    def feed_pcm(self, pcm_s16le: bytes) -> str | None:
        raise ComponentOperationError("COMPONENT_CIRCUIT_OPEN")


class CircuitOpenAdapter:
    def __init__(self) -> None:
        self.recognizer = CircuitOpenRecognizer()

    def open_stream(self, member_id, config):
        return self.recognizer


class AsrStreamSessionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.store = RecordStore(
            Path(self.temporary.name) / "records.db",
            PlaintextEngineeringCodec(),
            allow_unencrypted_engineering=True,
        )

    def tearDown(self) -> None:
        self.store.close()
        self.temporary.cleanup()

    def make_session(self, **kwargs):
        return AsrStreamSession(
            self.store,
            FakeAdapter(),
            "member-a",
            {"sample_rate_hz": 16000, "channels": 1, "sample_format": "s16le"},
            **kwargs,
        )

    def test_stream_returns_partial_then_memory_only_confirmation_task(self) -> None:
        session = self.make_session()
        partial = session.feed(b"\x00\x00" * 100)
        self.assertEqual(partial["type"], "partial")
        final = session.finish()
        self.assertEqual(final["type"], "final_pending_confirmation")
        self.assertFalse(final["raw_audio_persisted"])
        self.assertEqual(self.store.list_records("member-a"), [])
        task = self.store.get_task(final["task"]["task_id"], "member-a")
        self.assertEqual(task["result"]["fields"]["systolic"], 120)

    def test_transport_abandonment_cancels_final_pending_task(self) -> None:
        session = self.make_session()
        final = session.finish()
        task_id = final["task"]["task_id"]
        session.cancel()
        self.assertEqual(session.state, "cancelled")
        task = self.store.get_task(task_id, "member-a")
        self.assertEqual(task["status"], "cancelled")
        self.assertIsNone(task["result"])

    def test_format_odd_chunk_and_duration_limits_fail_closed(self) -> None:
        with self.assertRaises(TaskStateError):
            AsrStreamSession(
                self.store,
                FakeAdapter(),
                "member-a",
                {"sample_rate_hz": 8000, "channels": 1, "sample_format": "s16le"},
            )
        session = self.make_session()
        with self.assertRaises(TaskStateError):
            session.feed(b"\x00")
        tiny = self.make_session(limits=AsrStreamLimits(max_duration_seconds=1))
        with self.assertRaises(TaskStateError) as too_long:
            tiny.feed(b"\x00\x00" * 16001)
        self.assertEqual(too_long.exception.code, "INPUT_OUT_OF_RANGE")
        self.assertEqual(tiny.state, "cancelled")

    def test_storage_failure_closes_recognizer_and_cancels_session(self) -> None:
        adapter = FakeAdapter()
        session = AsrStreamSession(
            FailingStore(),  # type: ignore[arg-type]
            adapter,
            "member-a",
            {"sample_rate_hz": 16000, "channels": 1, "sample_format": "s16le"},
        )
        with self.assertRaises(OSError):
            session.finish()
        self.assertEqual(session.state, "cancelled")
        self.assertTrue(adapter.recognizer.closed)

    def test_supervisor_failure_preserves_fixed_code_and_cancels_stream(self) -> None:
        adapter = CircuitOpenAdapter()
        session = AsrStreamSession(
            self.store,
            adapter,
            "member-a",
            {"sample_rate_hz": 16000, "channels": 1, "sample_format": "s16le"},
        )
        with self.assertRaises(TaskStateError) as failed:
            session.feed(b"\x00\x00" * 10)
        self.assertEqual(failed.exception.code, "COMPONENT_CIRCUIT_OPEN")
        self.assertEqual(session.state, "cancelled")
        self.assertTrue(adapter.recognizer.closed)


if __name__ == "__main__":
    unittest.main()
