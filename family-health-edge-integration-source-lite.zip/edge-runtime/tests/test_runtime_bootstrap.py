from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from device_service.runtime_bootstrap import RuntimeBootstrapError, load_runtime_adapters
from release_tools import validate_product_runtime_bundle


class RuntimeBootstrapTests(unittest.TestCase):
    def fixture(self, root: Path) -> tuple[Path, Path, Path]:
        model_dir = root / "models" / "asr"
        model_dir.mkdir(parents=True)
        files = {}
        for name in ("decoder.onnx", "encoder.int8.onnx", "joiner.int8.onnx", "tokens.txt"):
            content = ("fixture-" + name).encode("ascii")
            path = model_dir / name
            path.write_bytes(content)
            files[name] = {"bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}
        digest = hashlib.sha256()
        for name in ("decoder.onnx", "encoder.int8.onnx", "joiner.int8.onnx", "tokens.txt"):
            digest.update(name.encode("utf-8"))
            digest.update(b"\0")
            digest.update(bytes.fromhex(files[name]["sha256"]))
        bundle = digest.hexdigest()
        manifest = {
            "schema_version": "1.0.0",
            "status": "ENGINEERING_MODEL_AVAILABLE_PRODUCT_LICENSE_PENDING",
            "product_accepted": False,
            "hardware_measured": False,
            "license_approved": False,
            "runtime_version": "1.13.7",
            "model_files": files,
            "model_bundle_sha256": bundle,
        }
        (root / "asr_runtime_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        config = {
            "schema_version": "1.0.0",
            "mode": "ENGINEERING_SELECTED_BACKENDS",
            "product_accepted": False,
            "asr": {
                "enabled": True,
                "backend_id": "asr_sherpa_cpu_xasr",
                "python_module": "asr_runtime.worker",
                "model_id": "xasr_streaming_int8",
                "model_dir": "models/asr",
                "manifest": "asr_runtime_manifest.json",
                "runtime_name": "sherpa_onnx",
                "runtime_version": "1.13.7",
                "contract_version": "1.0.0",
                "component_version": "1.0.0",
                "model_bundle_sha256": bundle,
                "operation_timeout_seconds": 10,
                "max_inflight_requests": 1,
                "circuit_failure_threshold": 3,
                "circuit_recovery_seconds": 30,
            },
            "ocr": {"enabled": False},
        }
        config_dir = root / "configs"
        config_dir.mkdir()
        path = config_dir / "runtime_adapters.json"
        path.write_text(json.dumps(config), encoding="utf-8")
        registry = {
            "schema_version": "1.0.0",
            "status": "ENGINEERING_REGISTRY_PRODUCT_BLOCKED",
            "product_complete": False,
            "fallback_policy": "EXPLICIT_SELECTION_NO_FALLBACK",
            "backends": [
                {
                    "backend_id": "asr_sherpa_cpu_xasr",
                    "component": "asr",
                    "engine": "sherpa_cpu",
                    "status": "ENGINEERING_READY",
                    "implementation_module": "asr_runtime.worker",
                    "contract_version": "1.0.0",
                    "component_version": "1.0.0",
                    "model_id": "xasr_streaming_int8",
                    "model_bundle_sha256": bundle,
                    "runtime_name": "sherpa_onnx",
                    "runtime_version": "1.13.7",
                    "capabilities": [
                        "asr_stream",
                        "confirmation_required",
                        "local_only",
                        "raw_audio_memory_only",
                    ],
                    "execution": "isolated_json_line_process",
                    "target": "arm64_cpu",
                    "product_accepted": False,
                    "hardware_validated": False,
                    "license_approved": False,
                    "unavailable_reasons": [],
                }
            ],
        }
        registry_path = root / "model_registry" / "backend_registry.json"
        registry_path.parent.mkdir()
        registry_path.write_text(json.dumps(registry), encoding="utf-8")
        selection = {
            "schema_version": "1.0.0",
            "mode": "ENGINEERING",
            "product_accepted": False,
            "fallback_allowed": False,
            "asr_backend_id": "asr_sherpa_cpu_xasr",
            "ocr_backend_id": None,
            "device_service_integration_verified": True,
            "meaning": "Test selection bound to the runtime fixture.",
        }
        selection_path = config_dir / "runtime_backend_selection.json"
        selection_path.write_text(json.dumps(selection), encoding="utf-8")
        return path, registry_path, selection_path

    def add_ocr_fixture(
        self,
        root: Path,
        config: Path,
        registry: Path,
        selection: Path,
    ) -> str:
        files = {}
        contents = {
            "detector": ("models/ocr/det.rknn", b"detector"),
            "recognizer": ("models/ocr/rec.rknn", b"recognizer"),
            "dictionary": ("post/model/keys.txt", b"a\nb\n"),
            "postprocess_init": ("post/python/utils/__init__.py", b""),
            "db_postprocess": ("post/python/utils/db_postprocess.py", b"db"),
            "operators": ("post/python/utils/operators.py", b"operators"),
            "rec_postprocess": ("post/python/utils/rec_postprocess.py", b"rec"),
        }
        for name, (relative, content) in contents.items():
            path = root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
            files[name] = {
                "path": relative,
                "bytes": len(content),
                "sha256": hashlib.sha256(content).hexdigest(),
            }
        bundle = hashlib.sha256(b"detector" + b"recognizer").hexdigest()
        ocr_manifest = {
            "schema_version": "1.0.0",
            "status": "ENGINEERING_WORKER_IMPLEMENTED_PRODUCT_BLOCKED",
            "target": "rk3566",
            "runtime_name": "rknn_toolkit_lite2",
            "runtime_version": "2.3.2",
            "source_commit": "a" * 40,
            "model_bundle_sha256": bundle,
            "product_accepted": False,
            "hardware_validated": False,
            "license_approved": False,
            "postprocess_root": "post/python",
            "pipeline": {
                "det_input_height": 480,
                "det_input_width": 480,
                "rec_input_height": 48,
                "rec_input_width": 320,
                "det_threshold": 0.3,
                "box_threshold": 0.6,
                "max_candidates": 1000,
                "unclip_ratio": 1.5,
                "use_dilation": False,
                "score_mode": "fast",
                "drop_score": 0.5,
            },
            "files": files,
        }
        manifest_path = root / "model_registry" / "ocr_worker.json"
        manifest_path.write_text(json.dumps(ocr_manifest), encoding="utf-8")

        registry_value = json.loads(registry.read_text())
        registry_value["backends"].append(
            {
                **registry_value["backends"][0],
                "backend_id": "ocr_rknn_ppocrv4",
                "component": "ocr",
                "engine": "rknn_ppocr",
                "implementation_module": "ocr_runtime.rknn_worker",
                "model_id": "ppocrv4_rknn",
                "model_bundle_sha256": bundle,
                "runtime_name": "rknn_runtime",
                "runtime_version": "2.3.2",
                "capabilities": ["confirmation_required", "local_only", "ocr_task"],
                "target": "rk3566_rknpu2",
            }
        )
        registry.write_text(json.dumps(registry_value), encoding="utf-8")
        selection_value = json.loads(selection.read_text())
        selection_value["ocr_backend_id"] = "ocr_rknn_ppocrv4"
        selection.write_text(json.dumps(selection_value), encoding="utf-8")
        config_value = json.loads(config.read_text())
        config_value["ocr"] = {
            "enabled": True,
            "backend_id": "ocr_rknn_ppocrv4",
            "python_module": "ocr_runtime.rknn_worker",
            "model_id": "ppocrv4_rknn",
            "manifest": "model_registry/ocr_worker.json",
            "runtime_name": "rknn_runtime",
            "runtime_version": "2.3.2",
            "contract_version": "1.0.0",
            "component_version": "1.0.0",
            "model_bundle_sha256": bundle,
            "operation_timeout_seconds": 30,
            "max_inflight_requests": 1,
            "circuit_failure_threshold": 3,
            "circuit_recovery_seconds": 30,
        }
        config.write_text(json.dumps(config_value), encoding="utf-8")
        return bundle

    def test_valid_engineering_config_builds_only_pinned_asr_adapter(self):
        with tempfile.TemporaryDirectory() as temporary:
            config, registry, selection = self.fixture(Path(temporary))
            adapters = load_runtime_adapters(
                config,
                engineering=True,
                registry_path=registry,
                selection_path=selection,
            )
            self.assertIsNotNone(adapters.asr)
            self.assertIsNone(adapters.ocr)
            self.assertEqual(adapters.asr.command[1:3], ("-m", "asr_runtime.worker"))
            self.assertEqual(adapters.asr.expected_model_sha256, json.loads(config.read_text())["asr"]["model_bundle_sha256"])

    def test_selected_ocr_builds_only_the_hash_locked_rknn_worker(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config, registry, selection = self.fixture(root)
            bundle = self.add_ocr_fixture(root, config, registry, selection)

            adapters = load_runtime_adapters(
                config,
                engineering=True,
                registry_path=registry,
                selection_path=selection,
            )
            self.assertIsNotNone(adapters.ocr)
            self.assertEqual(adapters.ocr.command[1:3], ("-m", "ocr_runtime.rknn_worker"))
            self.assertEqual(adapters.ocr.expected_model_sha256, bundle)

    def test_approved_product_boundary_builds_both_pinned_adapters(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config, registry, selection = self.fixture(root)
            self.add_ocr_fixture(root, config, registry, selection)

            registry_value = json.loads(registry.read_text())
            registry_value["status"] = "PRODUCT_REGISTRY_APPROVED"
            registry_value["product_complete"] = True
            for backend in registry_value["backends"]:
                backend["status"] = "PRODUCT_READY"
                backend["product_accepted"] = True
                backend["hardware_validated"] = True
                backend["license_approved"] = True
            registry.write_text(json.dumps(registry_value), encoding="utf-8")

            selection_value = json.loads(selection.read_text())
            selection_value["mode"] = "PRODUCT"
            selection_value["product_accepted"] = True
            selection.write_text(json.dumps(selection_value), encoding="utf-8")

            config_value = json.loads(config.read_text())
            config_value["mode"] = "PRODUCT_SELECTED_BACKENDS"
            config_value["product_accepted"] = True
            config.write_text(json.dumps(config_value), encoding="utf-8")

            asr_manifest = root / "asr_runtime_manifest.json"
            asr_value = json.loads(asr_manifest.read_text())
            asr_value["status"] = "PRODUCT_MODEL_APPROVED"
            asr_value["product_accepted"] = True
            asr_value["hardware_measured"] = True
            asr_value["license_approved"] = True
            asr_manifest.write_text(json.dumps(asr_value), encoding="utf-8")

            ocr_manifest = root / "model_registry" / "ocr_worker.json"
            ocr_value = json.loads(ocr_manifest.read_text())
            ocr_value["status"] = "PRODUCT_WORKER_APPROVED"
            ocr_value["product_accepted"] = True
            ocr_value["hardware_validated"] = True
            ocr_value["license_approved"] = True
            ocr_manifest.write_text(json.dumps(ocr_value), encoding="utf-8")

            adapters = load_runtime_adapters(
                config,
                engineering=False,
                registry_path=registry,
                selection_path=selection,
            )
            self.assertIn("--product-mode", adapters.asr.command)
            self.assertIsNotNone(adapters.ocr)
            self.assertIn("--product-mode", adapters.ocr.command)
            (root / "configs" / "backend_registry.json").write_bytes(
                registry.read_bytes()
            )
            validate_product_runtime_bundle(root)

    def test_product_config_rejects_engineering_manifests(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config, registry, selection = self.fixture(root)
            self.add_ocr_fixture(root, config, registry, selection)
            registry_value = json.loads(registry.read_text())
            registry_value["status"] = "PRODUCT_REGISTRY_APPROVED"
            registry_value["product_complete"] = True
            for backend in registry_value["backends"]:
                backend.update(
                    status="PRODUCT_READY",
                    product_accepted=True,
                    hardware_validated=True,
                    license_approved=True,
                )
            registry.write_text(json.dumps(registry_value), encoding="utf-8")
            selection_value = json.loads(selection.read_text())
            selection_value.update(mode="PRODUCT", product_accepted=True)
            selection.write_text(json.dumps(selection_value), encoding="utf-8")
            config_value = json.loads(config.read_text())
            config_value.update(
                mode="PRODUCT_SELECTED_BACKENDS",
                product_accepted=True,
            )
            config.write_text(json.dumps(config_value), encoding="utf-8")

            with self.assertRaisesRegex(RuntimeBootstrapError, "manifest verification"):
                load_runtime_adapters(
                    config,
                    engineering=False,
                    registry_path=registry,
                    selection_path=selection,
                )

    def test_product_mode_and_unapproved_flag_fail_closed(self):
        with tempfile.TemporaryDirectory() as temporary:
            config, registry, selection = self.fixture(Path(temporary))
            with self.assertRaises(RuntimeBootstrapError):
                load_runtime_adapters(
                    config,
                    engineering=False,
                    registry_path=registry,
                    selection_path=selection,
                )
            value = json.loads(config.read_text())
            value["product_accepted"] = True
            config.write_text(json.dumps(value), encoding="utf-8")
            with self.assertRaises(RuntimeBootstrapError):
                load_runtime_adapters(
                    config,
                    engineering=True,
                    registry_path=registry,
                    selection_path=selection,
                )

    def test_release_path_escape_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            config, registry, selection = self.fixture(Path(temporary))
            value = json.loads(config.read_text())
            value["asr"]["model_dir"] = "../outside"
            config.write_text(json.dumps(value), encoding="utf-8")
            with self.assertRaises(RuntimeBootstrapError):
                load_runtime_adapters(
                    config,
                    engineering=True,
                    registry_path=registry,
                    selection_path=selection,
                )

    def test_runtime_hash_must_match_explicit_backend_selection(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config, registry, selection = self.fixture(root)
            value = json.loads(registry.read_text())
            value["backends"][0]["model_bundle_sha256"] = "0" * 64
            registry.write_text(json.dumps(value), encoding="utf-8")
            with self.assertRaisesRegex(RuntimeBootstrapError, "do not match"):
                load_runtime_adapters(
                    config,
                    engineering=True,
                    registry_path=registry,
                    selection_path=selection,
                )

    def test_blocked_backend_selection_does_not_fall_back(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config, registry, selection = self.fixture(root)
            value = json.loads(registry.read_text())
            value["backends"].append(
                {
                    **value["backends"][0],
                    "backend_id": "asr_rknn_zipformer",
                    "engine": "rknn_zipformer",
                    "status": "BLOCKED_ENGINEERING",
                    "implementation_module": None,
                    "model_id": "zipformer_rknn",
                    "runtime_name": "rknn_runtime",
                    "runtime_version": "2.3.2",
                    "target": "rk3566_rknpu2",
                    "unavailable_reasons": [
                        "product_worker_missing",
                        "real_device_validation_missing",
                    ],
                }
            )
            registry.write_text(json.dumps(value), encoding="utf-8")
            selected = json.loads(selection.read_text())
            selected["asr_backend_id"] = "asr_rknn_zipformer"
            selection.write_text(json.dumps(selected), encoding="utf-8")
            with self.assertRaisesRegex(RuntimeBootstrapError, "BACKEND_NOT_ENGINEERING_READY"):
                load_runtime_adapters(
                    config,
                    engineering=True,
                    registry_path=registry,
                    selection_path=selection,
                )


if __name__ == "__main__":
    unittest.main()
