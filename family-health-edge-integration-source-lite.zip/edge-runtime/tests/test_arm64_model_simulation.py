from __future__ import annotations

import unittest

from scripts.build_arm64_wheelhouse_manifest import normalized
from scripts.run_arm64_model_simulation import validate_model_guest
from scripts.verify_model_simulation_evidence import evaluate


class Arm64ModelSimulationTests(unittest.TestCase):
    def test_distribution_names_are_normalized(self):
        self.assertEqual(normalized("sherpa_onnx.core"), "sherpa-onnx-core")

    def test_only_partial_real_model_evidence_is_accepted(self):
        requirements = {"onnxruntime": "1.28.0", "sherpa-onnx": "1.13.7"}
        valid = {
            "status": "PASS_AVAILABLE_REAL_MODELS", "system": "Linux", "machine": "aarch64",
            "bits": 64, "simulated": True, "hardware_measured": False,
            "product_complete": False, "three_model_inference_verified": False,
            "requirements": requirements,
            "health": {"status": "PASS_ARM64_REAL_INFERENCE", "product_model": False,
                       "probability_exposed_to_product": False},
            "asr": {"status": "PASS_ARM64_REAL_INFERENCE", "matches_host_reference": True,
                    "product_accepted": False},
        }
        self.assertTrue(validate_model_guest(valid, requirements))
        self.assertFalse(validate_model_guest({**valid, "three_model_inference_verified": True},
                                              requirements))
        self.assertFalse(validate_model_guest({**valid, "machine": "x86_64"}, requirements))

    def test_missing_report_cannot_pass_evidence_audit(self):
        errors = evaluate({})
        self.assertIn("AVAILABLE_MODEL_SIMULATION_NOT_PASS", errors)
        self.assertIn("OCR_BLOCKER_PROVENANCE_INVALID", errors)
        self.assertIn("MODEL_SOURCE_HASHES_MISSING", errors)
