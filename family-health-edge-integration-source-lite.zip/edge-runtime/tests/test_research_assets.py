from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from research_assets import ResearchAssetPathError, resolve_locked_artifact


class ResearchAssetPathTests(unittest.TestCase):
    def test_official_models_resolve_from_sibling_archive(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            workspace = Path(temporary)
            project = workspace / "端侧上线"
            project.mkdir()
            archived = (
                workspace
                / "官方模型对比实验"
                / "artifacts"
                / "official_models"
                / "model.rknn"
            )
            archived.parent.mkdir(parents=True)
            archived.write_bytes(b"model")
            self.assertEqual(
                resolve_locked_artifact(
                    project, "artifacts/official_models/model.rknn"
                ),
                archived.resolve(),
            )

    def test_project_evidence_stays_in_project(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            project = Path(temporary) / "端侧上线"
            report = project / "reports" / "result.json"
            report.parent.mkdir(parents=True)
            report.write_text("{}", encoding="utf-8")
            self.assertEqual(
                resolve_locked_artifact(project, "reports/result.json"),
                report.resolve(),
            )

    def test_escape_and_windows_separator_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            project = Path(temporary) / "端侧上线"
            project.mkdir()
            for relative in ("../secret", "reports\\secret.json", "/absolute"):
                with self.subTest(relative=relative):
                    with self.assertRaises(ResearchAssetPathError):
                        resolve_locked_artifact(project, relative)


if __name__ == "__main__":
    unittest.main()
