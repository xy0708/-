from __future__ import annotations

import base64
import hashlib
import json
import unittest

from ocr_runtime import normalize_ocr_input, validate_ocr_result
from storage import TaskStateError


PNG = b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + (2).to_bytes(4, "big") + (3).to_bytes(4, "big")


class OcrInputValidationTests(unittest.TestCase):
    def test_png_magic_dimensions_and_hash_are_verified(self) -> None:
        digest = hashlib.sha256(PNG).hexdigest()
        value = normalize_ocr_input(
            {
                "image": {
                    "media_type": "image/png",
                    "data_base64": base64.b64encode(PNG).decode("ascii"),
                    "sha256": digest,
                }
            }
        )
        self.assertEqual(value.sha256, digest)
        self.assertEqual(value.data, PNG)
        adapter_payload = value.adapter_payload()
        self.assertEqual(base64.b64decode(adapter_payload["image_base64"]), PNG)
        json.dumps(adapter_payload, allow_nan=False)

    def test_invalid_base64_magic_and_hash_fail_closed(self) -> None:
        for image in (
            {"media_type": "image/png", "data_base64": "%%%"},
            {"media_type": "image/png", "data_base64": base64.b64encode(b"not-png").decode("ascii")},
            {"media_type": "image/png", "data_base64": base64.b64encode(PNG).decode("ascii"), "sha256": "0" * 64},
        ):
            with self.subTest(image=image):
                with self.assertRaises(TaskStateError):
                    normalize_ocr_input({"image": image})

    def test_adapter_cannot_return_binary_or_oversized_result(self) -> None:
        with self.assertRaises(TaskStateError):
            validate_ocr_result({"raw_image": b"secret"})
        with self.assertRaises(TaskStateError):
            validate_ocr_result({"text": "x" * (300 * 1024)})


if __name__ == "__main__":
    unittest.main()
