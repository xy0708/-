from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from storage import (
    PlaintextEngineeringCodec,
    RecordStore,
    StoragePolicyError,
    restore_database_from_backup,
    sha256,
)


class DatabaseRecoveryTests(unittest.TestCase):
    def test_verified_backup_atomically_replaces_database_and_preserves_previous(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            live = root / "live.db"
            backup = root / "backups" / "good.db"
            store = RecordStore(
                live,
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
            )
            task = store.create_task("member-a", "ocr", {})
            store.confirm_task(task["task_id"], "member-a", "idem", {"weight": 70})
            store.create_backup(backup, allowed_root=root)
            store.close()

            replacement = RecordStore(
                live,
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
            )
            replacement.withdraw_member("member-a")
            replacement.close()

            previous = restore_database_from_backup(
                live,
                backup,
                expected_backup_sha256=sha256(backup),
                allowed_root=root,
            )
            self.assertIsNotNone(previous)
            self.assertTrue(previous.is_file())
            restored = RecordStore(
                live,
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
            )
            try:
                self.assertEqual(restored.list_records("member-a")[0]["payload"], {"weight": 70})
            finally:
                restored.close()

    def test_hash_mismatch_and_wal_sidecar_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            live = root / "live.db"
            backup = root / "backup.db"
            store = RecordStore(
                live,
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
            )
            store.create_backup(backup, allowed_root=root)
            store.close()
            with self.assertRaises(StoragePolicyError):
                restore_database_from_backup(
                    live, backup, expected_backup_sha256="0" * 64, allowed_root=root
                )
            Path(str(live) + "-wal").write_bytes(b"active")
            with self.assertRaises(StoragePolicyError):
                restore_database_from_backup(
                    live,
                    backup,
                    expected_backup_sha256=sha256(backup),
                    allowed_root=root,
                )

    def test_redirected_database_or_backup_paths_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            live = root / "live.db"
            backup = root / "backup.db"
            store = RecordStore(
                live,
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
            )
            store.create_backup(backup, allowed_root=root)
            store.close()
            backup_link = root / "backup-link.db"
            database_link = root / "database-link.db"
            try:
                backup_link.symlink_to(backup)
                database_link.symlink_to(live)
            except OSError:
                self.skipTest("symlink creation is unavailable on this host")
            with self.assertRaisesRegex(StoragePolicyError, "redirected"):
                restore_database_from_backup(
                    live,
                    backup_link,
                    expected_backup_sha256=sha256(backup),
                    allowed_root=root,
                )
            with self.assertRaisesRegex(StoragePolicyError, "redirected"):
                restore_database_from_backup(
                    database_link,
                    backup,
                    expected_backup_sha256=sha256(backup),
                    allowed_root=root,
                )

    def test_non_file_database_or_backup_fails_with_policy_error(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            live = root / "live.db"
            backup = root / "backup.db"
            store = RecordStore(
                live,
                PlaintextEngineeringCodec(),
                allow_unencrypted_engineering=True,
            )
            store.create_backup(backup, allowed_root=root)
            store.close()
            backup_directory = root / "backup-dir"
            backup_directory.mkdir()
            with self.assertRaisesRegex(StoragePolicyError, "backup must be a regular file"):
                restore_database_from_backup(
                    live,
                    backup_directory,
                    expected_backup_sha256="0" * 64,
                    allowed_root=root,
                )
            database_directory = root / "database-dir"
            database_directory.mkdir()
            with self.assertRaisesRegex(StoragePolicyError, "database must be a regular file"):
                restore_database_from_backup(
                    database_directory,
                    backup,
                    expected_backup_sha256=sha256(backup),
                    allowed_root=root,
                )


if __name__ == "__main__":
    unittest.main()
