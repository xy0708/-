from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from scripts.run_engineering_loop import (
    acceptance_metrics_result_is_consistent,
    gate_report_is_consistent,
    loop_audit_is_expected,
    snapshot_outputs,
)
from scripts.verify_loop_run_evidence import sha256, verify_payload


class EngineeringEvidenceSnapshotTests(unittest.TestCase):
    def test_terminal_gate_reports_support_blocked_and_product_pass_states(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report = Path(temporary) / "gate.json"
            report.write_text(
                json.dumps(
                    {
                        "status": "BLOCKED_EXTERNAL",
                        "hardware_measured": False,
                        "acceptance_executed": False,
                        "blockers": ["missing device"],
                    }
                ),
                encoding="utf-8",
            )
            self.assertTrue(gate_report_is_consistent(report, 2, "device"))
            self.assertFalse(gate_report_is_consistent(report, 0, "device"))
            report.write_text(
                json.dumps(
                    {
                        "status": "PASS_PRODUCT_GATE",
                        "release_allowed": True,
                        "formal_release_verified": True,
                        "blockers": [],
                    }
                ),
                encoding="utf-8",
            )
            self.assertTrue(gate_report_is_consistent(report, 0, "release"))

    def test_acceptance_metric_exit_code_and_report_must_agree(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report = Path(temporary) / "metrics.json"
            report.write_text(
                json.dumps(
                    {
                        "status": "FAIL_OR_BLOCKED",
                        "metrics": None,
                        "failures": ["missing external evidence"],
                    }
                ),
                encoding="utf-8",
            )
            self.assertTrue(acceptance_metrics_result_is_consistent(report, 2))
            self.assertFalse(acceptance_metrics_result_is_consistent(report, 0))
            report.write_text(
                json.dumps(
                    {
                        "status": "PASS_COMPUTED_REAL_EVIDENCE",
                        "metrics": {"asr_cer": 0.1},
                        "failures": [],
                    }
                ),
                encoding="utf-8",
            )
            self.assertTrue(acceptance_metrics_result_is_consistent(report, 0))
            self.assertFalse(acceptance_metrics_result_is_consistent(report, 2))

    def test_loop_audit_report_rejects_hidden_engineering_failure(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "audit.json"
            valid = {
                "status": "BLOCKED_EXTERNAL",
                "goal_complete": False,
                "product_release_allowed": False,
                "contradictions": [],
                "engineering_failures": [],
            }
            path.write_text(json.dumps(valid), encoding="utf-8")
            self.assertTrue(loop_audit_is_expected(path))

            valid["engineering_failures"] = ["E08"]
            path.write_text(json.dumps(valid), encoding="utf-8")
            self.assertFalse(loop_audit_is_expected(path))

            product_pass = {
                "status": "PASS_PRODUCT_GATE",
                "goal_complete": True,
                "product_release_allowed": True,
                "contradictions": [],
                "engineering_failures": [],
            }
            path.write_text(json.dumps(product_pass), encoding="utf-8")
            self.assertTrue(loop_audit_is_expected(path))

    def test_snapshot_remains_verifiable_after_live_report_changes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            report = root / "reports" / "example.json"
            report.parent.mkdir(parents=True)
            report.write_bytes(b'{"status":"PASS_ENGINEERING"}\n')
            run_dir = root / "reports" / "loop_runs" / "run-1"
            run_dir.mkdir(parents=True)

            outputs, evidence, errors = snapshot_outputs(
                root, run_dir, ["reports/example.json"]
            )
            self.assertEqual(errors, [])
            self.assertEqual(
                outputs["reports/example.json"],
                evidence["reports/example.json"]["snapshot_sha256"],
            )
            snapshot = root / evidence["reports/example.json"]["snapshot"]
            self.assertEqual(snapshot.read_bytes(), report.read_bytes())

            report.write_bytes(b'{"status":"REFRESHED"}\n')
            self.assertNotEqual(snapshot.read_bytes(), report.read_bytes())

    def test_unsafe_output_path_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run_dir = root / "run"
            run_dir.mkdir()
            outputs, evidence, errors = snapshot_outputs(
                root, run_dir, ["../outside.json"]
            )
            self.assertEqual(outputs, {})
            self.assertEqual(evidence, {})
            self.assertEqual(errors, ["unsafe_output_path:../outside.json"])

    def test_missing_expected_output_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run_dir = root / "run"
            run_dir.mkdir()
            outputs, evidence, errors = snapshot_outputs(
                root, run_dir, ["reports/missing.json"]
            )
            self.assertEqual(outputs, {})
            self.assertEqual(evidence, {})
            self.assertEqual(errors, ["missing_output:reports/missing.json"])

    def test_verifier_uses_immutable_snapshot_not_mutable_live_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source.py"
            source.write_text("value = 1\n", encoding="utf-8")
            live = root / "reports" / "example.json"
            live.parent.mkdir(parents=True)
            live.write_text('{"status":"old"}\n', encoding="utf-8")
            run_dir = root / "reports" / "loop_runs" / "20260911T010203Z"
            run_dir.mkdir(parents=True)
            outputs, evidence, snapshot_errors = snapshot_outputs(
                root, run_dir, ["reports/example.json"]
            )
            self.assertEqual(snapshot_errors, [])
            payload = {
                "run_id": "20260911T010203Z",
                "status": "PASS_ENGINEERING_PRODUCT_BLOCKED",
                "formal_release_created": False,
                "unexpected_checks": [],
                "snapshot_integrity_verified": True,
                "input_sha256": {"source.py": sha256(source)},
                "output_sha256": outputs,
                "output_evidence": evidence,
            }
            live.write_text('{"status":"new"}\n', encoding="utf-8")
            self.assertEqual(verify_payload(root, payload), [])
            snapshot = root / evidence["reports/example.json"]["snapshot"]
            snapshot.write_text('{"status":"tampered"}\n', encoding="utf-8")
            self.assertIn(
                "output_snapshot_hash_mismatch:reports/example.json",
                verify_payload(root, payload),
            )

    def test_product_run_requires_three_consistent_terminal_snapshots(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source.py"
            source.write_text("value = 1\n", encoding="utf-8")
            reports = {
                "reports/device_acceptance.json": {
                    "status": "PASS_PRODUCT_GATE",
                    "hardware_measured": True,
                    "acceptance_executed": True,
                    "blockers": [],
                },
                "reports/final_release_verification.json": {
                    "status": "PASS_PRODUCT_GATE",
                    "release_allowed": True,
                    "formal_release_verified": True,
                    "blockers": [],
                },
                "reports/loop_requirements_audit.json": {
                    "status": "PASS_PRODUCT_GATE",
                    "goal_complete": True,
                    "product_release_allowed": True,
                    "contradictions": [],
                    "engineering_failures": [],
                },
            }
            for relative, value in reports.items():
                path = root / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(value), encoding="utf-8")
            run_dir = root / "reports" / "loop_runs" / "20260922T010203Z"
            run_dir.mkdir(parents=True)
            outputs, evidence, snapshot_errors = snapshot_outputs(
                root,
                run_dir,
                list(reports),
            )
            self.assertEqual(snapshot_errors, [])
            payload = {
                "run_id": "20260922T010203Z",
                "status": "PASS_PRODUCT_GATE",
                "formal_release_created": True,
                "unexpected_checks": [],
                "snapshot_integrity_verified": True,
                "input_sha256": {"source.py": sha256(source)},
                "output_sha256": outputs,
                "output_evidence": evidence,
            }
            self.assertEqual(verify_payload(root, payload), [])

            audit_snapshot = root / evidence["reports/loop_requirements_audit.json"]["snapshot"]
            audit = json.loads(audit_snapshot.read_text())
            audit["engineering_failures"] = ["E08"]
            audit_snapshot.write_text(json.dumps(audit), encoding="utf-8")
            errors = verify_payload(root, payload)
            self.assertTrue(
                any(error.startswith("output_snapshot_hash_mismatch") for error in errors)
            )
            self.assertIn(
                "product_terminal_snapshot_has_engineering_failures:reports/loop_requirements_audit.json",
                errors,
            )


if __name__ == "__main__":
    unittest.main()
