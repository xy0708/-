from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from release_tools import BundleVerification, ReleaseInputError
from release_tools.product_runtime import verify_product_release_bundle


class ProductReleaseVerificationTests(unittest.TestCase):
    def test_signed_bundle_with_engineering_runtime_fails_before_activation(self) -> None:
        signed = BundleVerification(True, "v1.2.3", (), 12, True)
        with tempfile.TemporaryDirectory() as temporary, patch(
            "release_tools.product_runtime.verify_release_bundle",
            return_value=signed,
        ), patch(
            "release_tools.product_runtime.validate_product_runtime_bundle",
            side_effect=ReleaseInputError("PRODUCT_RUNTIME_BUNDLE_INVALID"),
        ):
            result = verify_product_release_bundle(
                Path(temporary) / "v1.2.3", Path(temporary) / "public.pem"
            )

        self.assertFalse(result.passed)
        self.assertTrue(result.signature_verified)
        self.assertEqual(result.failures, ("PRODUCT_RUNTIME_BUNDLE_INVALID",))

    def test_invalid_signature_does_not_attempt_runtime_loading(self) -> None:
        unsigned = BundleVerification(
            False, "v1.2.3", ("MANIFEST_SIGNATURE_INVALID",), 12, False
        )
        with tempfile.TemporaryDirectory() as temporary, patch(
            "release_tools.product_runtime.verify_release_bundle",
            return_value=unsigned,
        ), patch(
            "release_tools.product_runtime.validate_product_runtime_bundle"
        ) as runtime_validation:
            result = verify_product_release_bundle(
                Path(temporary) / "v1.2.3", Path(temporary) / "public.pem"
            )

        self.assertEqual(result, unsigned)
        runtime_validation.assert_not_called()

    def test_signed_product_runtime_bundle_passes(self) -> None:
        signed = BundleVerification(True, "v1.2.3", (), 12, True)
        with tempfile.TemporaryDirectory() as temporary, patch(
            "release_tools.product_runtime.verify_release_bundle",
            return_value=signed,
        ), patch(
            "release_tools.product_runtime.validate_product_runtime_bundle"
        ):
            result = verify_product_release_bundle(
                Path(temporary) / "v1.2.3", Path(temporary) / "public.pem"
            )

        self.assertEqual(result, signed)
