from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from benchmarks.comparison.asr_single_sample import (
    REPORT_SCHEMA_VERSION,
    REPORT_SCOPE,
    REPORT_STATUS,
    ComparisonEvidenceError,
    disagreement,
    fold_for_pairwise_comparison,
    load_rknn_transcript,
    validate_report,
)


class AsrSingleSampleComparisonTests(unittest.TestCase):
    def test_pairwise_disagreement_preserves_literal_and_folded_views(self) -> None:
        result = disagreement("血糖， 5.6。", "血糖5.8")

        self.assertFalse(result["literal_nfkc_exact_match"])
        self.assertFalse(result["folded_alphanumeric_exact_match"])
        self.assertEqual(fold_for_pairwise_comparison("血糖， 5.6。"), "血糖56")
        self.assertIn("not CER", result["metric_meaning"])

    def test_rknn_evidence_rejects_cer_claim(self) -> None:
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as directory:
            path = Path(directory) / "rknn.json"
            path.write_text(
                json.dumps(
                    {
                        "status": "PASS_ENGINEERING_FUNCTIONAL_SIMULATION",
                        "scope": "PC_SIMULATOR_SINGLE_OFFICIAL_SAMPLE_ONLY",
                        "exported_rknn_loaded_by_simulator": False,
                        "hardware_measured": False,
                        "product_accuracy_claim_allowed": False,
                        "wer_or_cer_claim_allowed": True,
                        "sample": {"audio_sha256": "a" * 64},
                        "rknn_pc_simulator": {"text": "测试", "host_seconds": 1.0},
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaises(ComparisonEvidenceError):
                load_rknn_transcript(path, "a" * 64)

    def test_report_validation_is_hash_bound_and_has_no_winner(self) -> None:
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as directory:
            root = Path(directory)
            paths = [root / name for name in ("audio.wav", "manifest.json", "rknn.json", "registry.json", "verify.py")]
            for index, path in enumerate(paths):
                path.write_bytes(f"value-{index}".encode())
            wheel = root / "runtime.whl"
            wheel.write_bytes(b"wheel")
            digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
            report = {
                "schema_version": REPORT_SCHEMA_VERSION,
                "status": REPORT_STATUS,
                "scope": REPORT_SCOPE,
                "reference_transcript_available": False,
                "cer_or_wer_claim_allowed": False,
                "accuracy_claim_allowed": False,
                "product_selection_allowed": False,
                "hardware_measured": False,
                "host_timing_comparable_for_ranking": False,
                "target_microphone_data_used": False,
                "source_hashes": {
                    "audio_sha256": digest(paths[0]),
                    "cpu_manifest_sha256": digest(paths[1]),
                    "rknn_simulator_report_sha256": digest(paths[2]),
                    "backend_registry_sha256": digest(paths[3]),
                    "cpu_verifier_sha256": digest(paths[4]),
                    "host_wheel_sha256": {wheel.name: digest(wheel)},
                },
                "candidates": {
                    "asr_sherpa_cpu_xasr": {},
                    "asr_rknn_zipformer": {},
                },
                "comparison": {
                    "literal_nfkc_disagreement_rate": 0.2,
                    "folded_alphanumeric_disagreement_rate": 0.1,
                    "metric_meaning": "not CER and not a product ranking",
                },
                "conclusion": {"result": "NO_PRODUCT_WINNER", "winner": None},
            }

            self.assertEqual(
                validate_report(
                    report,
                    audio_path=paths[0],
                    cpu_manifest_path=paths[1],
                    rknn_report_path=paths[2],
                    registry_path=paths[3],
                    host_wheels=[wheel],
                    verifier_path=paths[4],
                ),
                [],
            )
            report["hardware_measured"] = True
            self.assertIn(
                "UNSAFE_TRUE_FLAG:hardware_measured",
                validate_report(
                    report,
                    audio_path=paths[0],
                    cpu_manifest_path=paths[1],
                    rknn_report_path=paths[2],
                    registry_path=paths[3],
                    host_wheels=[wheel],
                    verifier_path=paths[4],
                ),
            )


if __name__ == "__main__":
    unittest.main()
