from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

from scripts import runtime_tool


ROOT = Path(__file__).resolve().parents[1]


class RuntimeToolingContractTests(unittest.TestCase):
    def test_product_lifecycle_entrypoints_do_not_require_global_python(self) -> None:
        entrypoints = (
            ROOT / "scripts" / "install_release.sh",
            ROOT / "scripts" / "rollback_release.sh",
            ROOT / "scripts" / "recover_pending_activation.sh",
            ROOT / "systemd" / "family-health-edge.service",
        )
        for path in entrypoints:
            with self.subTest(path=path.name):
                content = path.read_text(encoding="utf-8").casefold()
                self.assertNotIn("python3", content)
                self.assertNotIn("/usr/bin/python", content)
                self.assertNotIn(".py", content)

    def test_lifecycle_scripts_require_self_contained_tool_executables(self) -> None:
        required = {
            "install_release.sh": (
                "verify-release-bundle",
                "verify-current-release",
                "check-release-health",
                "activation-marker",
            ),
            "rollback_release.sh": (
                "verify-release-bundle",
                "verify-current-release",
                "check-rollback-transition",
                "check-release-health",
                "activation-marker",
            ),
            "recover_pending_activation.sh": (
                "verify-release-bundle",
                "activation-marker",
            ),
        }
        for name, tools in required.items():
            content = (ROOT / "scripts" / name).read_text(encoding="utf-8")
            with self.subTest(script=name):
                self.assertIn('[ -x "$runtime_tool" ]', content)
                self.assertIn("family-health-edge-tool", content)
                for tool in tools:
                    self.assertIn(tool, content)

        service = (ROOT / "systemd" / "family-health-edge.service").read_text(
            encoding="utf-8"
        )
        self.assertIn(
            "ExecStartPre=/opt/family-health-edge/tools/family-health-edge-tool "
            "verify-current-release",
            service,
        )

    def test_runtime_tool_dispatches_one_allowlisted_command(self) -> None:
        received: list[list[str]] = []

        def command() -> int:
            import sys

            received.append(list(sys.argv))
            return 7

        with patch.dict(runtime_tool.COMMANDS, {"probe": command}, clear=True):
            self.assertEqual(runtime_tool.main(["probe", "--value", "x"]), 7)
        self.assertEqual(
            received,
            [["family-health-edge-tool probe", "--value", "x"]],
        )

    def test_runtime_tool_rejects_missing_or_unknown_command(self) -> None:
        self.assertEqual(runtime_tool.main([]), 2)
        self.assertEqual(runtime_tool.main(["unknown"]), 2)


if __name__ == "__main__":
    unittest.main()
