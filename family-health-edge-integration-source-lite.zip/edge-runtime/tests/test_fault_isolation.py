from __future__ import annotations

import base64
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from device_service import DeviceApplication, TokenAuthorizer
from integration_adapter import ComponentOperationError
from storage import PlaintextEngineeringCodec, RecordStore


TOKEN = "fault-isolation-token-1234567890abcdef"
AUTH = {"authorization": f"Bearer {TOKEN}"}
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + (1).to_bytes(4, "big") + (1).to_bytes(4, "big")


class CrashingOcrAdapter:
    name = "ocr"

    def health(self):
        return {
            "ready": True,
            "contract_version": "1.0.0",
            "component_version": "1.0.0",
            "capabilities": ["ocr_task", "confirmation_required", "local_only"],
        }

    def create_task(self, member_id, payload):
        raise RuntimeError("sensitive engine detail must not escape")


class CrashingHealthAdapter(CrashingOcrAdapter):
    def health(self):
        raise RuntimeError("sensitive health probe detail must not escape")


class IncompatibleOcrAdapter:
    name = "ocr"

    def health(self):
        return {
            "ready": True,
            "contract_version": "2.0.0",
            "component_version": "1.0.0",
            "capabilities": ["ocr_task", "confirmation_required", "local_only"],
        }

    def create_task(self, member_id, payload):
        raise AssertionError("an incompatible adapter must never be called")


class CircuitOpenOcrAdapter(CrashingOcrAdapter):
    def create_task(self, member_id, payload):
        raise ComponentOperationError("COMPONENT_CIRCUIT_OPEN")


class FaultIsolationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.store = RecordStore(
            Path(self.temporary.name) / "records.db",
            PlaintextEngineeringCodec(),
            allow_unencrypted_engineering=True,
        )
        self.app = DeviceApplication(
            self.store,
            TokenAuthorizer({TOKEN: {"member-a"}}),
            ocr_adapter=CrashingOcrAdapter(),
        )

    def tearDown(self) -> None:
        try:
            self.store.close()
        except Exception:
            pass
        self.temporary.cleanup()

    def test_ocr_crash_returns_fixed_error_and_health_rules_continue(self) -> None:
        status, failed = self.app.dispatch(
            "POST",
            "/v1/ocr/tasks",
            AUTH,
            {
                "member_id": "member-a",
                "image": {
                    "media_type": "image/png",
                    "data_base64": base64.b64encode(PNG).decode("ascii"),
                },
            },
        )
        self.assertEqual(status, 503)
        self.assertEqual(failed["error"]["code"], "COMPONENT_NOT_READY")
        self.assertNotIn("sensitive engine detail", str(failed))
        status, health = self.app.dispatch(
            "POST",
            "/v1/health/evaluate",
            {**AUTH, "X-Edge-Member-Id": "member-a"},
            {
                "confirmed": True,
                "measurements": [
                    {
                        "metric": "weight",
                        "value": 70,
                        "unit": "kg",
                        "measured_at": datetime.now(timezone.utc).isoformat(),
                        "confirmed": True,
                    }
                ],
            },
        )
        self.assertEqual(status, 200)
        self.assertIsNone(health["result"]["diagnosis"])

    def test_closed_database_returns_storage_unavailable_without_trace(self) -> None:
        self.store.close()
        status, failed = self.app.dispatch(
            "GET", "/v1/members/member-a/records", AUTH
        )
        self.assertEqual(status, 503)
        self.assertEqual(failed["error"]["code"], "STORAGE_UNAVAILABLE")

    def test_crashing_health_probe_degrades_without_leaking_or_crashing_service(self) -> None:
        app = DeviceApplication(
            self.store,
            TokenAuthorizer({TOKEN: {"member-a"}}),
            ocr_adapter=CrashingHealthAdapter(),
        )
        status, health = app.dispatch("GET", "/v1/health")
        self.assertEqual(status, 200)
        self.assertEqual(health["result"]["status"], "degraded")
        self.assertEqual(health["result"]["ocr"]["reason"], "COMPONENT_NOT_READY")
        self.assertNotIn("sensitive engine detail", str(health))

    def test_incompatible_component_is_blocked_before_inference(self) -> None:
        app = DeviceApplication(
            self.store,
            TokenAuthorizer({TOKEN: {"member-a"}}),
            ocr_adapter=IncompatibleOcrAdapter(),
        )
        status, failed = app.dispatch(
            "POST",
            "/v1/ocr/tasks",
            AUTH,
            {
                "member_id": "member-a",
                "image": {
                    "media_type": "image/png",
                    "data_base64": base64.b64encode(PNG).decode("ascii"),
                },
            },
        )
        self.assertEqual(status, 503)
        self.assertEqual(failed["error"]["code"], "COMPONENT_CONTRACT_INCOMPATIBLE")

    def test_supervisor_error_code_is_preserved_without_worker_detail(self) -> None:
        app = DeviceApplication(
            self.store,
            TokenAuthorizer({TOKEN: {"member-a"}}),
            ocr_adapter=CircuitOpenOcrAdapter(),
        )
        status, failed = app.dispatch(
            "POST",
            "/v1/ocr/tasks",
            AUTH,
            {
                "member_id": "member-a",
                "image": {
                    "media_type": "image/png",
                    "data_base64": base64.b64encode(PNG).decode("ascii"),
                },
            },
        )
        self.assertEqual(status, 503)
        self.assertEqual(failed["error"]["code"], "COMPONENT_CIRCUIT_OPEN")
        self.assertTrue(failed["error"]["retryable"])


if __name__ == "__main__":
    unittest.main()
