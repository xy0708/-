from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from device_service import TokenAuthorizer


class AuthConfigTests(unittest.TestCase):
    def test_same_secret_cannot_receive_multiple_or_wildcard_scopes(self) -> None:
        token = "d" * 40
        with self.assertRaises(ValueError):
            TokenAuthorizer(
                {token: {"member-a"}},
                engineering_wildcard_tokens={token},
            )

    def write(self, temporary: str, value: dict) -> Path:
        path = Path(temporary) / "auth.json"
        path.write_text(json.dumps(value), encoding="utf-8")
        return path

    def test_environment_tokens_receive_only_configured_member_scope(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = self.write(
                temporary,
                {"grants": [{"token_env": "EDGE_MEMBER_TOKEN_A", "member_ids": ["member-a"]}]},
            )
            token = "secure-local-token-a" * 2
            authorizer = TokenAuthorizer.from_environment_config(
                path, {"EDGE_MEMBER_TOKEN_A": token}
            )
            principal = authorizer.authenticate({"authorization": f"Bearer {token}"})
            self.assertIsNotNone(principal)
            self.assertTrue(principal.permits("member-a"))
            self.assertFalse(principal.permits("member-b"))

    def test_raw_token_in_config_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = self.write(
                temporary,
                {"grants": [{"token": "x" * 40, "member_ids": ["member-a"]}]},
            )
            with self.assertRaises(ValueError):
                TokenAuthorizer.from_environment_config(path, {})

    def test_duplicate_environment_secrets_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = self.write(
                temporary,
                {
                    "grants": [
                        {"token_env": "EDGE_MEMBER_TOKEN_A", "member_ids": ["member-a"]},
                        {"token_env": "EDGE_MEMBER_TOKEN_B", "member_ids": ["member-b"]},
                    ]
                },
            )
            shared = "shared-local-token" * 3
            with self.assertRaises(ValueError):
                TokenAuthorizer.from_environment_config(
                    path,
                    {
                        "EDGE_MEMBER_TOKEN_A": shared,
                        "EDGE_MEMBER_TOKEN_B": shared,
                    },
                )


if __name__ == "__main__":
    unittest.main()
