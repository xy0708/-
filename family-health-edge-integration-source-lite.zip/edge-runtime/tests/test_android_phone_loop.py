from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from run_rk3576_phone_edge_loop import classify_checks  # noqa: E402
from verify_rk3576_phone_edge_integration import validate  # noqa: E402


class AndroidPhoneLoopTests(unittest.TestCase):
    def test_phone_watch_default_fails_closed(self) -> None:
        errors, facts = validate()
        self.assertEqual(errors, [])
        self.assertEqual(
            facts["watch_gateway"],
            "PHONE_LOCAL_FAIL_CLOSED_WITH_EXPLICIT_SIMULATED_ADAPTER",
        )

    def test_phone_release_requires_formal_signing(self) -> None:
        source = (
            ROOT.parent
            / "FamilyHealthPhone-main"
            / "FamilyHealthPhone-main"
            / "android"
            / "app"
            / "build.gradle.kts"
        ).read_text(encoding="utf-8")
        self.assertIn("Release signing is incomplete", source)
        self.assertNotIn('signingConfigs.getByName("debug")', source)

    def test_flutter_sandbox_failure_is_not_reported_as_code_failure(self) -> None:
        checks = [
            {"name": "rk3576_phone_edge_contract", "exit_code": 0},
            {"name": "phone_flutter_test", "exit_code": 1,
             "stderr_tail": "Failed to canonicalize path 'C:\\flutter\\bin\\cache'"},
        ]
        self.assertEqual(classify_checks(checks), "PARTIAL_ENGINEERING_ENV_BLOCKED")
        checks[1]["stderr_tail"] = "test expectation failed"
        self.assertEqual(classify_checks(checks), "FAIL_ENGINEERING")


if __name__ == "__main__":
    unittest.main()
