import subprocess
import unittest
from unittest.mock import patch

from scripts.verify_deployment_scripts import find_bash


class BashDiscoveryTests(unittest.TestCase):
    @patch('scripts.verify_deployment_scripts.platform.system', return_value='Windows')
    @patch('scripts.verify_deployment_scripts.Path.is_file', return_value=True)
    @patch('scripts.verify_deployment_scripts.shutil.which', return_value='C:/WindowsApps/bash.exe')
    @patch('scripts.verify_deployment_scripts.subprocess.run')
    def test_git_bash_wins_over_wsl_placeholder(self, run, which, exists, system):
        run.return_value = subprocess.CompletedProcess([], 0)
        self.assertIn('Git', find_bash())
        self.assertIn('Git', run.call_args.args[0][0])

    @patch('scripts.verify_deployment_scripts.platform.system', return_value='Windows')
    @patch('scripts.verify_deployment_scripts.Path.is_file', return_value=False)
    @patch('scripts.verify_deployment_scripts.shutil.which', return_value='C:/WindowsApps/bash.exe')
    def test_placeholder_does_not_count_as_working_bash(self, which, exists, system):
        self.assertIsNone(find_bash())

    @patch('scripts.verify_deployment_scripts.platform.system', return_value='Linux')
    @patch('scripts.verify_deployment_scripts.shutil.which', return_value='/usr/bin/bash')
    @patch('scripts.verify_deployment_scripts.subprocess.run', side_effect=OSError('unavailable'))
    def test_unlaunchable_binary_fails_closed(self, run, which, system):
        self.assertIsNone(find_bash())
