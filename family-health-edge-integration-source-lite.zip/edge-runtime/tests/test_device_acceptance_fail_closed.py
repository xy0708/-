from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from acceptance.contract import (
    REQUIRED_PRODUCT_SCENARIOS,
    acceptance_contract_scenario_errors,
)
from scripts.run_device_acceptance import evaluate, safe_project_file


class DeviceAcceptanceFailClosedTests(unittest.TestCase):
    def test_contract_requires_every_product_lifecycle_scenario(self) -> None:
        contract = {"required_scenarios": sorted(REQUIRED_PRODUCT_SCENARIOS)}
        self.assertEqual(acceptance_contract_scenario_errors(contract), [])
        contract["required_scenarios"].remove("automatic_rollback")
        self.assertEqual(
            acceptance_contract_scenario_errors(contract),
            ["ACCEPTANCE_REQUIRED_SCENARIO_MISSING:automatic_rollback"],
        )
        contract["required_scenarios"].append(contract["required_scenarios"][0])
        self.assertEqual(
            acceptance_contract_scenario_errors(contract),
            ["ACCEPTANCE_REQUIRED_SCENARIOS_INVALID"],
        )

    def test_malformed_control_files_return_blockers_instead_of_crashing(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "configs").mkdir()
            (root / "configs" / "acceptance_contract.json").write_text(
                "not json", encoding="utf-8"
            )
            (root / "configs" / "device_profile.json").write_text(
                "[]", encoding="utf-8"
            )
            result = evaluate(root)
        self.assertEqual(result["status"], "BLOCKED_EXTERNAL")
        self.assertIn("ACCEPTANCE_CONTRACT_INVALID_OR_MISSING", result["blockers"])
        self.assertIn("DEVICE_PROFILE_INVALID_OR_MISSING", result["blockers"])
        self.assertFalse(result["hardware_measured"])

    def test_project_file_rejects_traversal_and_absolute_paths(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            inside = root / "inside.json"
            inside.write_text("{}", encoding="utf-8")
            self.assertEqual(safe_project_file(root, "inside.json"), inside.resolve())
            self.assertIsNone(safe_project_file(root, "../outside.json"))
            self.assertIsNone(safe_project_file(root, inside.resolve()))


if __name__ == "__main__":
    unittest.main()
