from __future__ import annotations

import unittest

from scripts import verify_product_scope


class ProductScopeTests(unittest.TestCase):
    def test_product_scope_and_api_contract_are_fail_closed(self) -> None:
        self.assertEqual(verify_product_scope.main(), 0)


if __name__ == "__main__":
    unittest.main()
