from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from scripts.run_rknn_exported_artifact_capability_probe import (
    REPORT,
    docker_command,
)
from scripts.verify_rknn_exported_artifact_capability_probe import evaluate


class RknnExportedArtifactCapabilityProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.report = json.loads(REPORT.read_text(encoding="utf-8"))

    def test_current_report_passes_independent_verification(self) -> None:
        self.assertEqual(evaluate(copy.deepcopy(self.report)), [])

    def test_product_or_hardware_claims_fail_closed(self) -> None:
        for field in ("hardware_measured", "product_selection_allowed"):
            with self.subTest(field=field):
                changed = copy.deepcopy(self.report)
                changed[field] = True
                self.assertIn(f"FLAG_INVALID:{field}", evaluate(changed))

    def test_docker_command_is_offline_and_read_only(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            command = docker_command("docker", Path(folder))
        self.assertIn("--rm", command)
        self.assertEqual(command[command.index("--network") + 1], "none")
        self.assertTrue(any(value.endswith(":/workspace:ro") for value in command))


if __name__ == "__main__":
    unittest.main()
