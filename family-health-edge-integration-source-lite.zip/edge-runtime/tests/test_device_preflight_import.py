from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from scripts.import_device_preflight import build_profile


class DevicePreflightImportTests(unittest.TestCase):
    def test_false_or_simulated_report_is_rejected(self) -> None:
        report = {
            "status": "PASS_REAL_DEVICE_PREFLIGHT",
            "script_sha256": "script-hash",
            "known_hosts_sha256": "host-hash",
            "remote_stdout_sha256": "stdout-hash",
            "hardware_evidence": {
                "hardware_measured": True,
                "rk3566_detected": True,
                "simulation_detected": True,
                "passed": True,
            },
        }
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "report.json"
            with mock.patch("scripts.import_device_preflight.sha256", return_value="script-hash"):
                with self.assertRaises(ValueError):
                    build_profile(path, report, {})


if __name__ == "__main__":
    unittest.main()
