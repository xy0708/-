from __future__ import annotations

import hashlib
import json
import re
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Callable

from acceptance.paths import has_redirected_component, is_redirected


# A release ID is also a directory name. Requiring alphanumeric endpoints
# excludes aliases such as "." and ".." and hidden/option-looking names.
RELEASE_ID = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$")
REQUIRED_DIRECTORIES = {
    "bin",
    "models",
    "configs",
    "lib",
    "systemd",
    "migrations",
    "licenses",
    "sbom",
    "reports",
    "signatures",
}
REQUIRED_PRODUCT_FILES = frozenset(
    {
        "bin/family-health-edge",
        "bin/update-agent",
        "configs/api_contract.json",
        "configs/backend_registry.json",
        "configs/runtime_adapters.json",
        "configs/runtime_backend_selection.json",
        "systemd/family-health-edge.service",
        "systemd/family-health-edge-recovery.service",
    }
)
REQUIRED_PRODUCT_PREFIXES = frozenset(
    {
        "models/health/",
        "models/ocr/",
        "models/asr/",
        "lib/",
        "migrations/",
        "licenses/",
        "sbom/",
        "reports/",
    }
)
FORBIDDEN_PRODUCT_SEGMENTS = frozenset(
    {".git", ".pytest_cache", ".venv", "__pycache__", "checkpoints", "demo", "tests"}
)
EXCLUDED_FROM_MANIFEST = {"manifest.json", "signatures/manifest.sig"}
MAX_MANIFEST_BYTES = 4 * 1024 * 1024
MAX_ROLLBACK_BYTES = 64 * 1024
MAX_MANIFEST_FILES = 10_000
MANIFEST_FIELDS = {"schema_version", "release_id", "created_at", "files"}
MANIFEST_ENTRY_FIELDS = {"path", "size", "sha256"}
ROLLBACK_FIELDS = {
    "schema_version",
    "previous_release_id",
    "database_rollback_compatible",
}


@dataclass(frozen=True)
class BundleVerification:
    passed: bool
    release_id: str | None
    failures: tuple[str, ...]
    files_verified: int
    signature_verified: bool

    def as_dict(self) -> dict:
        return {
            "status": "PASS" if self.passed else "FAIL",
            "release_id": self.release_id,
            "failures": list(self.failures),
            "files_verified": self.files_verified,
            "signature_verified": self.signature_verified,
        }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _iter_bundle_entries(bundle: Path):
    pending = [bundle]
    while pending:
        directory = pending.pop()
        for path in directory.iterdir():
            yield path
            if not is_redirected(path) and path.is_dir():
                pending.append(path)


def product_release_content_failures(paths: set[str]) -> tuple[str, ...]:
    failures = [
        f"PRODUCT_REQUIRED_FILE_MISSING:{path}"
        for path in sorted(REQUIRED_PRODUCT_FILES - paths)
    ]
    for prefix in sorted(REQUIRED_PRODUCT_PREFIXES):
        if not any(path.startswith(prefix) and len(path) > len(prefix) for path in paths):
            failures.append(f"PRODUCT_REQUIRED_CONTENT_MISSING:{prefix}")
    for path in sorted(paths):
        parts = PurePosixPath(path).parts
        if any(part.lower() in FORBIDDEN_PRODUCT_SEGMENTS for part in parts):
            failures.append(f"PRODUCT_FORBIDDEN_CONTENT:{path}")
        if path.lower().endswith((".pyc", ".pyo")):
            failures.append(f"PRODUCT_FORBIDDEN_CONTENT:{path}")
    return tuple(failures)


def openssl_signature_verifier(manifest: Path, signature: Path, public_key: Path) -> bool:
    completed = subprocess.run(
        [
            "openssl",
            "dgst",
            "-sha256",
            "-verify",
            str(public_key),
            "-signature",
            str(signature),
            str(manifest),
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=15,
        check=False,
    )
    return completed.returncode == 0


def verify_release_bundle(
    bundle: Path,
    public_key: Path,
    *,
    signature_verifier: Callable[[Path, Path, Path], bool] = openssl_signature_verifier,
) -> BundleVerification:
    failures: list[str] = []
    files_verified = 0
    signature_verified = False
    if is_redirected(bundle) or not bundle.is_dir():
        return BundleVerification(False, None, ("BUNDLE_NOT_REGULAR_DIRECTORY",), 0, False)
    bundle = bundle.resolve(strict=True)
    release_id = bundle.name
    if not RELEASE_ID.fullmatch(release_id):
        failures.append("RELEASE_ID_INVALID")
    for directory in REQUIRED_DIRECTORIES:
        path = bundle / directory
        if is_redirected(path) or not path.is_dir():
            failures.append(f"REQUIRED_DIRECTORY_MISSING_OR_REDIRECT:{directory}")
    manifest_path = bundle / "manifest.json"
    rollback_path = bundle / "rollback.json"
    signature_path = bundle / "signatures" / "manifest.sig"
    if not manifest_path.is_file() or has_redirected_component(manifest_path, bundle):
        failures.append("MANIFEST_MISSING_OR_REDIRECT")
        manifest = {}
    elif manifest_path.stat().st_size > MAX_MANIFEST_BYTES:
        failures.append("MANIFEST_TOO_LARGE")
        manifest = {}
    else:
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            failures.append("MANIFEST_INVALID_JSON")
            manifest = {}
    if not isinstance(manifest, dict) or set(manifest) != MANIFEST_FIELDS:
        failures.append("MANIFEST_SCHEMA_INVALID")
        manifest = {}
    if manifest.get("schema_version") != "1.0.0":
        failures.append("MANIFEST_SCHEMA_VERSION_UNSUPPORTED")
    if manifest.get("release_id") != release_id:
        failures.append("MANIFEST_RELEASE_ID_MISMATCH")
    created_at = manifest.get("created_at")
    if not isinstance(created_at, str) or len(created_at) > 64:
        failures.append("MANIFEST_CREATED_AT_INVALID")
    else:
        try:
            parsed_created_at = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        except ValueError:
            failures.append("MANIFEST_CREATED_AT_INVALID")
        else:
            if parsed_created_at.tzinfo is None:
                failures.append("MANIFEST_CREATED_AT_INVALID")
    entries = manifest.get("files")
    expected: dict[str, dict] = {}
    if (
        not isinstance(entries, list)
        or not entries
        or len(entries) > MAX_MANIFEST_FILES
    ):
        failures.append("MANIFEST_FILES_EMPTY_OR_INVALID")
    else:
        for entry in entries:
            if not isinstance(entry, dict) or set(entry) != MANIFEST_ENTRY_FIELDS:
                failures.append("MANIFEST_ENTRY_INVALID")
                continue
            relative = entry.get("path")
            if not isinstance(relative, str) or "\\" in relative:
                failures.append("MANIFEST_PATH_INVALID")
                continue
            pure = PurePosixPath(relative)
            if (
                pure.is_absolute()
                or ".." in pure.parts
                or not pure.parts
                or pure.parts[0] not in REQUIRED_DIRECTORIES | {"rollback.json"}
                or (pure.parts[0] == "rollback.json" and len(pure.parts) != 1)
                or relative in expected
            ):
                failures.append(f"MANIFEST_PATH_UNSAFE_OR_DUPLICATE:{relative}")
                continue
            expected[relative] = entry
    actual: set[str] = set()
    for path in _iter_bundle_entries(bundle):
        redirected = is_redirected(path)
        if redirected:
            failures.append(
                f"BUNDLE_REDIRECT_FORBIDDEN:{path.relative_to(bundle).as_posix()}"
            )
        if not redirected and not path.is_file() and not path.is_dir():
            failures.append(
                f"BUNDLE_ENTRY_NOT_REGULAR:{path.relative_to(bundle).as_posix()}"
            )
        if not redirected and path.is_file():
            relative = path.relative_to(bundle).as_posix()
            if relative not in EXCLUDED_FROM_MANIFEST:
                actual.add(relative)
    if set(expected) != actual:
        for missing in sorted(set(expected) - actual):
            failures.append(f"MANIFEST_FILE_MISSING:{missing}")
        for extra in sorted(actual - set(expected)):
            failures.append(f"UNMANIFESTED_FILE:{extra}")
    failures.extend(product_release_content_failures(actual))
    for relative, entry in expected.items():
        path = bundle / Path(*PurePosixPath(relative).parts)
        if not path.is_file() or has_redirected_component(path, bundle):
            continue
        size = entry.get("size")
        digest = entry.get("sha256")
        if (
            isinstance(size, bool)
            or not isinstance(size, int)
            or size < 0
            or path.stat().st_size != size
        ):
            failures.append(f"FILE_SIZE_MISMATCH:{relative}")
            continue
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            failures.append(f"FILE_HASH_INVALID:{relative}")
            continue
        if _sha256(path) != digest:
            failures.append(f"FILE_HASH_MISMATCH:{relative}")
            continue
        files_verified += 1
    if has_redirected_component(rollback_path, bundle) or not rollback_path.is_file():
        failures.append("ROLLBACK_METADATA_MISSING_OR_REDIRECT")
    elif rollback_path.stat().st_size > MAX_ROLLBACK_BYTES:
        failures.append("ROLLBACK_METADATA_TOO_LARGE")
    else:
        try:
            rollback = json.loads(rollback_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            failures.append("ROLLBACK_METADATA_INVALID")
            rollback = {}
        if not isinstance(rollback, dict) or set(rollback) != ROLLBACK_FIELDS:
            failures.append("ROLLBACK_METADATA_SCHEMA_INVALID")
            rollback = {}
        if rollback.get("schema_version") != "1.0.0":
            failures.append("ROLLBACK_SCHEMA_VERSION_UNSUPPORTED")
        if rollback.get("database_rollback_compatible") is not True:
            failures.append("DATABASE_ROLLBACK_COMPATIBILITY_NOT_APPROVED")
        previous = rollback.get("previous_release_id")
        if previous is not None and (
            not isinstance(previous, str)
            or not RELEASE_ID.fullmatch(previous)
            or previous == release_id
        ):
            failures.append("PREVIOUS_RELEASE_ID_INVALID")
    if not public_key.is_file() or is_redirected(public_key):
        failures.append("TRUSTED_PUBLIC_KEY_MISSING_OR_REDIRECT")
    elif not signature_path.is_file() or has_redirected_component(
        signature_path, bundle
    ):
        failures.append("MANIFEST_SIGNATURE_MISSING_OR_REDIRECT")
    elif not failures:
        try:
            signature_verified = signature_verifier(
                manifest_path, signature_path, public_key
            )
        except (OSError, subprocess.SubprocessError):
            signature_verified = False
        if not signature_verified:
            failures.append("MANIFEST_SIGNATURE_INVALID")
    return BundleVerification(
        not failures,
        release_id,
        tuple(sorted(set(failures))),
        files_verified,
        signature_verified,
    )
