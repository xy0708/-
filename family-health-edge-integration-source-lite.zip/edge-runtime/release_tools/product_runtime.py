from __future__ import annotations

from pathlib import Path

from acceptance.paths import is_redirected

from .bundle import BundleVerification, verify_release_bundle
from .inputs import ReleaseInputError


def validate_product_runtime_bundle(bundle_root: Path) -> None:
    """Validate product runtime pins without starting native model processes."""

    root_input = bundle_root.absolute()
    if is_redirected(root_input) or not root_input.is_dir():
        raise ReleaseInputError("PRODUCT_RUNTIME_BUNDLE_ROOT_UNSAFE")
    root = root_input.resolve(strict=True)
    from device_service.runtime_bootstrap import (
        RuntimeBootstrapError,
        load_runtime_adapters,
    )

    try:
        adapters = load_runtime_adapters(
            root / "configs" / "runtime_adapters.json",
            engineering=False,
            registry_path=root / "configs" / "backend_registry.json",
            selection_path=root / "configs" / "runtime_backend_selection.json",
        )
    except (OSError, RuntimeBootstrapError, ValueError) as exc:
        raise ReleaseInputError("PRODUCT_RUNTIME_BUNDLE_INVALID") from exc
    if not adapters.product_mode or adapters.asr is None or adapters.ocr is None:
        raise ReleaseInputError("PRODUCT_RUNTIME_BUNDLE_INCOMPLETE")


def verify_product_release_bundle(
    bundle_root: Path, public_key: Path
) -> BundleVerification:
    """Require both signed file integrity and product runtime semantics."""

    verification = verify_release_bundle(bundle_root, public_key)
    if not verification.passed:
        return verification
    try:
        validate_product_runtime_bundle(bundle_root)
    except (OSError, ReleaseInputError, ValueError):
        return BundleVerification(
            False,
            verification.release_id,
            ("PRODUCT_RUNTIME_BUNDLE_INVALID",),
            verification.files_verified,
            verification.signature_verified,
        )
    return verification
