from __future__ import annotations

import hashlib
import re
import shutil
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from acceptance.paths import has_redirected_component, is_redirected

from .bundle import (
    RELEASE_ID,
    REQUIRED_DIRECTORIES,
    product_release_content_failures,
)


MAX_RELEASE_INPUT_FILES = 10_000
_INPUT_FIELDS = {
    "schema_version",
    "frozen",
    "release_id",
    "previous_release_id",
    "database_rollback_compatible",
    "files",
}
_FILE_FIELDS = {"source", "destination", "sha256"}
_RELEASE_COLLECTIONS = {"release", "release_candidates"}


class ReleaseInputError(ValueError):
    pass


@dataclass(frozen=True)
class ReleaseInputFile:
    source: Path
    destination: PurePosixPath
    sha256: str
    size: int


def controlled_release_path(
    root: Path,
    collection: str,
    release_id: str,
    *,
    require_collection: bool = False,
) -> Path:
    """Return a direct release child while refusing path and parent redirection."""
    if collection not in _RELEASE_COLLECTIONS:
        raise ReleaseInputError("RELEASE_COLLECTION_INVALID")
    if not isinstance(release_id, str) or RELEASE_ID.fullmatch(release_id) is None:
        raise ReleaseInputError("RELEASE_ID_INVALID")
    resolved_root = root.resolve(strict=True)
    collection_path = root / collection
    if is_redirected(collection_path):
        raise ReleaseInputError("RELEASE_COLLECTION_REDIRECT_FORBIDDEN")
    if collection_path.exists():
        if not collection_path.is_dir():
            raise ReleaseInputError("RELEASE_COLLECTION_NOT_DIRECTORY")
        if collection_path.resolve(strict=True) != resolved_root / collection:
            raise ReleaseInputError("RELEASE_COLLECTION_ESCAPES_ROOT")
    elif require_collection:
        raise ReleaseInputError("RELEASE_COLLECTION_MISSING")
    target = collection_path / release_id
    if is_redirected(target):
        raise ReleaseInputError("RELEASE_TARGET_REDIRECT_FORBIDDEN")
    return target


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_release_inputs(payload: Any, root: Path) -> tuple[ReleaseInputFile, ...]:
    if not isinstance(payload, dict) or set(payload) != _INPUT_FIELDS:
        raise ReleaseInputError("RELEASE_INPUT_SCHEMA_INVALID")
    if payload.get("schema_version") != "1.0.0" or payload.get("frozen") is not True:
        raise ReleaseInputError("RELEASE_INPUT_NOT_FROZEN_OR_VERSION_UNSUPPORTED")
    release_id = payload.get("release_id")
    if not isinstance(release_id, str) or RELEASE_ID.fullmatch(release_id) is None:
        raise ReleaseInputError("RELEASE_ID_INVALID")
    previous = payload.get("previous_release_id")
    if previous is not None and (
        not isinstance(previous, str)
        or RELEASE_ID.fullmatch(previous) is None
        or previous == release_id
    ):
        raise ReleaseInputError("PREVIOUS_RELEASE_ID_INVALID")
    if payload.get("database_rollback_compatible") is not True:
        raise ReleaseInputError("DATABASE_ROLLBACK_COMPATIBILITY_NOT_APPROVED")
    files = payload.get("files")
    if not isinstance(files, list) or not files or len(files) > MAX_RELEASE_INPUT_FILES:
        raise ReleaseInputError("RELEASE_INPUT_FILES_INVALID")

    resolved_root = root.resolve(strict=True)
    destinations: set[str] = set()
    validated: list[ReleaseInputFile] = []
    for item in files:
        if not isinstance(item, dict) or set(item) != _FILE_FIELDS:
            raise ReleaseInputError("RELEASE_INPUT_FILE_SCHEMA_INVALID")
        source_raw = item.get("source")
        destination_raw = item.get("destination")
        expected_hash = item.get("sha256")
        if (
            not isinstance(source_raw, str)
            or not source_raw
            or "\\" in source_raw
            or not isinstance(destination_raw, str)
            or not destination_raw
            or "\\" in destination_raw
            or not isinstance(expected_hash, str)
            or re.fullmatch(r"[0-9a-f]{64}", expected_hash) is None
        ):
            raise ReleaseInputError("RELEASE_INPUT_FILE_VALUE_INVALID")
        source_pure = PurePosixPath(source_raw)
        destination = PurePosixPath(destination_raw)
        if source_pure.is_absolute() or ".." in source_pure.parts or not source_pure.parts:
            raise ReleaseInputError("RELEASE_INPUT_SOURCE_PATH_UNSAFE")
        if (
            destination.is_absolute()
            or ".." in destination.parts
            or not destination.parts
            or destination.parts[0] not in REQUIRED_DIRECTORIES
            or destination_raw == "signatures/manifest.sig"
            or destination_raw in destinations
        ):
            raise ReleaseInputError("RELEASE_INPUT_DESTINATION_UNSAFE_OR_DUPLICATE")
        source = resolved_root.joinpath(*source_pure.parts)
        if (
            has_redirected_component(source, resolved_root)
            or not source.is_file()
            or not source.resolve().is_relative_to(resolved_root)
        ):
            raise ReleaseInputError("RELEASE_INPUT_SOURCE_MISSING_OR_UNSAFE")
        if sha256(source) != expected_hash:
            raise ReleaseInputError("RELEASE_INPUT_SOURCE_HASH_MISMATCH")
        destinations.add(destination_raw)
        validated.append(
            ReleaseInputFile(source, destination, expected_hash, source.stat().st_size)
        )
    return tuple(validated)


def validate_product_release_contents(
    files: tuple[ReleaseInputFile, ...],
) -> None:
    failures = product_release_content_failures(
        {item.destination.as_posix() for item in files}
    )
    if failures:
        raise ReleaseInputError(";".join(failures))


def copy_verified_release_input(item: ReleaseInputFile, staging: Path) -> Path:
    if is_redirected(staging) or not staging.is_dir():
        raise ReleaseInputError("RELEASE_STAGING_ROOT_UNSAFE")
    target = staging.joinpath(*item.destination.parts)
    if has_redirected_component(target.parent, staging) or not target.resolve().is_relative_to(
        staging.resolve()
    ):
        raise ReleaseInputError("RELEASE_INPUT_DESTINATION_ESCAPES_STAGING")
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(item.source, target)
    if (
        has_redirected_component(target, staging)
        or target.stat().st_size != item.size
        or sha256(target) != item.sha256
    ):
        raise ReleaseInputError("COPIED_RELEASE_INPUT_HASH_MISMATCH")
    return target
