from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath

from acceptance.paths import has_redirected_component, is_redirected

from .inputs import ReleaseInputError


MAX_SIGNING_POLICY_BYTES = 64 * 1024
SIGNING_POLICY_FIELDS = {
    "schema_version",
    "approval_status",
    "algorithm",
    "trusted_public_key_file",
    "trusted_public_key_sha256",
    "private_key_on_device_forbidden",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def approved_public_key(root: Path, requested_key: Path | None = None) -> Path:
    """Return the hash-bound approved release key, rejecting caller substitution."""

    workspace = root.resolve(strict=True)
    policy_path = workspace / "configs" / "signing_policy.json"
    if (
        not policy_path.is_file()
        or has_redirected_component(policy_path, workspace)
        or policy_path.stat().st_size > MAX_SIGNING_POLICY_BYTES
    ):
        raise ReleaseInputError("SIGNING_POLICY_MISSING_OR_UNSAFE")
    try:
        policy = json.loads(policy_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ReleaseInputError("SIGNING_POLICY_INVALID_JSON") from exc
    if not isinstance(policy, dict) or set(policy) != SIGNING_POLICY_FIELDS:
        raise ReleaseInputError("SIGNING_POLICY_SCHEMA_INVALID")
    if (
        policy.get("schema_version") != "1.0.0"
        or policy.get("approval_status") != "APPROVED"
        or policy.get("algorithm") != "RSA_SHA256_OPENSSL_DGST"
        or policy.get("private_key_on_device_forbidden") is not True
    ):
        raise ReleaseInputError("SIGNING_POLICY_NOT_APPROVED")

    relative = policy.get("trusted_public_key_file")
    expected_hash = policy.get("trusted_public_key_sha256")
    if (
        not isinstance(relative, str)
        or "\\" in relative
        or not isinstance(expected_hash, str)
        or len(expected_hash) != 64
        or any(character not in "0123456789abcdef" for character in expected_hash)
    ):
        raise ReleaseInputError("TRUSTED_PUBLIC_KEY_NOT_CONFIGURED")
    relative_path = PurePosixPath(relative)
    if relative_path.is_absolute() or ".." in relative_path.parts or not relative_path.parts:
        raise ReleaseInputError("TRUSTED_PUBLIC_KEY_PATH_INVALID")

    candidate = workspace.joinpath(*relative_path.parts)
    if (
        has_redirected_component(candidate, workspace)
        or not candidate.is_file()
        or is_redirected(candidate)
    ):
        raise ReleaseInputError("TRUSTED_PUBLIC_KEY_MISSING_OR_UNSAFE")
    trusted_key = candidate.resolve(strict=True)
    if _sha256(trusted_key) != expected_hash:
        raise ReleaseInputError("TRUSTED_PUBLIC_KEY_HASH_MISMATCH")

    if requested_key is not None:
        requested = requested_key.absolute()
        if (
            has_redirected_component(requested, workspace)
            or not requested.is_file()
            or requested.resolve(strict=True) != trusted_key
        ):
            raise ReleaseInputError("PROMOTION_PUBLIC_KEY_NOT_APPROVED")
    return trusted_key
