from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Any


COMPONENT_CONTRACT_VERSION = "1.0.0"
_SEMVER = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
_ERROR_CODE = re.compile(r"^[A-Z][A-Z0-9_]{2,63}$")
_CAPABILITY = re.compile(r"^[a-z][a-z0-9_]{1,63}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")


class ComponentContractError(ValueError):
    """Raised when an adapter cannot satisfy the frozen local component contract."""


def _major(version: str) -> int:
    match = _SEMVER.fullmatch(version)
    if match is None:
        raise ComponentContractError("component version must use semantic versioning")
    return int(match.group(1))


def normalize_component_health(
    name: str,
    payload: Any,
    *,
    required_capabilities: Iterable[str],
    required_contract_major: int = 1,
) -> dict[str, Any]:
    """Validate and sanitize a component handshake before it reaches callers.

    Only non-sensitive, bounded metadata is returned. Arbitrary adapter error text is
    deliberately discarded so native/runtime details cannot leak through the product API.
    """

    required = frozenset(required_capabilities)
    if not isinstance(payload, dict):
        raise ComponentContractError("component health response must be an object")
    ready = payload.get("ready")
    contract_version = payload.get("contract_version")
    component_version = payload.get("component_version")
    capabilities = payload.get("capabilities")
    if not isinstance(ready, bool):
        raise ComponentContractError("component ready flag must be boolean")
    if not isinstance(contract_version, str) or _major(contract_version) != required_contract_major:
        raise ComponentContractError("component contract major version is incompatible")
    if not isinstance(component_version, str):
        raise ComponentContractError("component version is missing")
    _major(component_version)
    if (
        not isinstance(capabilities, list)
        or not all(isinstance(item, str) and _CAPABILITY.fullmatch(item) for item in capabilities)
        or len(capabilities) != len(set(capabilities))
    ):
        raise ComponentContractError("component capabilities are invalid")
    missing = required.difference(capabilities)
    if missing:
        raise ComponentContractError("component capabilities are incomplete")

    model_sha256 = payload.get("model_sha256")
    if model_sha256 is not None and (
        not isinstance(model_sha256, str) or _SHA256.fullmatch(model_sha256) is None
    ):
        raise ComponentContractError("component model hash is invalid")
    reason = payload.get("reason")
    if not isinstance(reason, str) or _ERROR_CODE.fullmatch(reason) is None:
        reason = None if ready else "COMPONENT_NOT_READY"
    return {
        "name": name,
        "ready": ready,
        "contract_version": contract_version,
        "component_version": component_version,
        "capabilities": sorted(capabilities),
        "model_sha256": model_sha256,
        "reason": reason,
    }
