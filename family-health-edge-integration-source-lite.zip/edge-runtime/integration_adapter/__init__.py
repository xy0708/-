"""Versioned contracts shared by edge-model adapters."""

from .contracts import (
    COMPONENT_CONTRACT_VERSION,
    ComponentContractError,
    normalize_component_health,
)
from .supervisor import (
    CircuitBreaker,
    CircuitBreakerPolicy,
    ComponentOperationError,
    JsonLineProcessAdapter,
    ProcessLimits,
)

__all__ = [
    "COMPONENT_CONTRACT_VERSION",
    "ComponentContractError",
    "normalize_component_health",
    "CircuitBreaker",
    "CircuitBreakerPolicy",
    "ComponentOperationError",
    "JsonLineProcessAdapter",
    "ProcessLimits",
]
