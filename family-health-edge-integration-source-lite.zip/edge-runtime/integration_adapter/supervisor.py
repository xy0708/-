from __future__ import annotations

import base64
import json
import os
import subprocess
import threading
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .contracts import ComponentContractError, normalize_component_health


_RUNTIME_ERROR_CODES = frozenset(
    {
        "COMPONENT_NOT_READY",
        "COMPONENT_TIMEOUT",
        "COMPONENT_BUSY",
        "COMPONENT_CIRCUIT_OPEN",
        "COMPONENT_CONTRACT_INCOMPATIBLE",
        "MODEL_HASH_MISMATCH",
    }
)


class ComponentOperationError(RuntimeError):
    """A bounded, non-sensitive failure reported by an isolated component."""

    def __init__(self, code: str) -> None:
        self.code = code if code in _RUNTIME_ERROR_CODES else "COMPONENT_NOT_READY"
        super().__init__(self.code)


@dataclass(frozen=True)
class CircuitBreakerPolicy:
    failure_threshold: int = 3
    recovery_timeout_seconds: float = 30.0

    def __post_init__(self) -> None:
        if (
            isinstance(self.failure_threshold, bool)
            or not isinstance(self.failure_threshold, int)
            or self.failure_threshold < 1
        ):
            raise ValueError("failure_threshold must be a positive integer")
        if (
            isinstance(self.recovery_timeout_seconds, bool)
            or not isinstance(self.recovery_timeout_seconds, (int, float))
            or not 0.01 <= float(self.recovery_timeout_seconds) <= 3600
        ):
            raise ValueError("recovery_timeout_seconds is outside the safe range")


class CircuitBreaker:
    """Thread-safe closed/open/half-open state with one bounded recovery probe."""

    def __init__(
        self,
        policy: CircuitBreakerPolicy = CircuitBreakerPolicy(),
        *,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.policy = policy
        self._clock = clock
        self._lock = threading.Lock()
        self._failures = 0
        self._opened_at: float | None = None
        self._half_open_probe = False

    def before_call(self) -> None:
        with self._lock:
            if self._opened_at is None:
                return
            elapsed = self._clock() - self._opened_at
            if elapsed < float(self.policy.recovery_timeout_seconds):
                raise ComponentOperationError("COMPONENT_CIRCUIT_OPEN")
            if self._half_open_probe:
                raise ComponentOperationError("COMPONENT_CIRCUIT_OPEN")
            self._half_open_probe = True

    def cancel_call(self) -> None:
        """Release a half-open reservation when no component call was attempted."""

        with self._lock:
            if self._opened_at is not None:
                self._half_open_probe = False

    def record_success(self) -> None:
        with self._lock:
            self._failures = 0
            self._opened_at = None
            self._half_open_probe = False

    def record_failure(self) -> None:
        with self._lock:
            if self._opened_at is not None or self._half_open_probe:
                self._failures = self.policy.failure_threshold
                self._opened_at = self._clock()
                self._half_open_probe = False
                return
            self._failures += 1
            if self._failures >= self.policy.failure_threshold:
                self._opened_at = self._clock()

    def snapshot(self) -> dict[str, int | str]:
        with self._lock:
            if self._opened_at is None:
                state = "closed"
            elif self._half_open_probe:
                state = "half_open"
            else:
                state = "open"
            return {"state": state, "consecutive_failures": self._failures}


@dataclass(frozen=True)
class ProcessLimits:
    operation_timeout_seconds: float
    max_inflight_requests: int = 1
    max_request_bytes: int = 12 * 1024 * 1024
    max_response_bytes: int = 512 * 1024

    def __post_init__(self) -> None:
        if (
            isinstance(self.operation_timeout_seconds, bool)
            or not isinstance(self.operation_timeout_seconds, (int, float))
            or not 0.01 <= float(self.operation_timeout_seconds) <= 120
        ):
            raise ValueError("operation_timeout_seconds is outside the safe range")
        if (
            isinstance(self.max_inflight_requests, bool)
            or not isinstance(self.max_inflight_requests, int)
            or not 1 <= self.max_inflight_requests <= 8
        ):
            raise ValueError("max_inflight_requests is outside the safe range")
        for name, value in (
            ("max_request_bytes", self.max_request_bytes),
            ("max_response_bytes", self.max_response_bytes),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1024:
                raise ValueError(f"{name} is outside the safe range")


def _bounded_json_line(payload: Mapping[str, Any], maximum: int) -> bytes:
    try:
        encoded = json.dumps(
            dict(payload), ensure_ascii=False, separators=(",", ":"), allow_nan=False
        ).encode("utf-8") + b"\n"
    except (TypeError, ValueError) as exc:
        raise ComponentOperationError("COMPONENT_NOT_READY") from exc
    if len(encoded) > maximum:
        raise ComponentOperationError("COMPONENT_NOT_READY")
    return encoded


def _terminate(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    try:
        process.terminate()
        process.wait(timeout=0.5)
    except (OSError, subprocess.SubprocessError):
        try:
            process.kill()
            process.wait(timeout=0.5)
        except (OSError, subprocess.SubprocessError):
            pass


def _close_pipes(process: subprocess.Popen[bytes]) -> None:
    for stream in (process.stdin, process.stdout):
        if stream is not None and not stream.closed:
            try:
                stream.close()
            except OSError:
                pass


def _read_bounded_line(
    process: subprocess.Popen[bytes], timeout_seconds: float, maximum: int
) -> bytes:
    if process.stdout is None:
        raise ComponentOperationError("COMPONENT_NOT_READY")
    result: list[bytes | BaseException] = []

    def read() -> None:
        try:
            result.append(process.stdout.readline(maximum + 1))
        except BaseException as exc:  # contained inside the reader thread
            result.append(exc)

    reader = threading.Thread(target=read, name="component-response-reader", daemon=True)
    reader.start()
    reader.join(timeout_seconds)
    if reader.is_alive():
        _terminate(process)
        reader.join(0.5)
        raise ComponentOperationError("COMPONENT_TIMEOUT")
    if not result or isinstance(result[0], BaseException):
        raise ComponentOperationError("COMPONENT_NOT_READY")
    raw = result[0]
    if len(raw) > maximum or not raw.endswith(b"\n"):
        raise ComponentOperationError("COMPONENT_NOT_READY")
    return raw


def _exchange(
    process: subprocess.Popen[bytes],
    request: Mapping[str, Any],
    limits: ProcessLimits,
) -> dict[str, Any]:
    if process.stdin is None:
        raise ComponentOperationError("COMPONENT_NOT_READY")
    encoded = _bounded_json_line(request, limits.max_request_bytes)
    try:
        process.stdin.write(encoded)
        process.stdin.flush()
    except (BrokenPipeError, OSError) as exc:
        raise ComponentOperationError("COMPONENT_NOT_READY") from exc
    raw = _read_bounded_line(
        process, float(limits.operation_timeout_seconds), limits.max_response_bytes
    )
    try:
        response = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ComponentOperationError("COMPONENT_NOT_READY") from exc
    if not isinstance(response, dict) or not isinstance(response.get("ok"), bool):
        raise ComponentOperationError("COMPONENT_NOT_READY")
    if response["ok"] is not True:
        error = response.get("error")
        code = error.get("code") if isinstance(error, dict) else None
        raise ComponentOperationError(code if isinstance(code, str) else "COMPONENT_NOT_READY")
    result = response.get("result")
    if not isinstance(result, dict):
        raise ComponentOperationError("COMPONENT_NOT_READY")
    return result


class JsonLineProcessAdapter:
    """Supervise one isolated stdio JSON-lines worker per non-streaming operation.

    This is transport and failure-containment infrastructure. Constructing it does not
    prove that a licensed model worker, ARM64 native library, or RK3566 device exists.
    """

    def __init__(
        self,
        name: str,
        command: Sequence[str],
        *,
        required_capabilities: Sequence[str],
        limits: ProcessLimits,
        breaker_policy: CircuitBreakerPolicy = CircuitBreakerPolicy(),
        expected_model_sha256: str | None = None,
        cwd: Path | None = None,
        environment: Mapping[str, str] | None = None,
    ) -> None:
        if name not in {"ocr", "asr"}:
            raise ValueError("only OCR and ASR native workers may use this adapter")
        if (
            isinstance(command, (str, bytes))
            or not command
            or not all(isinstance(item, str) and item and "\x00" not in item for item in command)
        ):
            raise ValueError("command must be a non-empty argv sequence")
        self.name = name
        self.command = tuple(command)
        self.required_capabilities = tuple(sorted(set(required_capabilities)))
        if not self.required_capabilities:
            raise ValueError("required_capabilities cannot be empty")
        self.limits = limits
        self.expected_model_sha256 = expected_model_sha256
        if expected_model_sha256 is not None and (
            len(expected_model_sha256) != 64
            or any(character not in "0123456789abcdef" for character in expected_model_sha256)
        ):
            raise ValueError("expected_model_sha256 must be lowercase SHA-256")
        self.cwd = cwd
        if environment is None:
            safe_environment = {
                key: os.environ[key]
                for key in (
                    "PATH",
                    "SystemRoot",
                    "WINDIR",
                    "TEMP",
                    "TMP",
                    "LD_LIBRARY_PATH",
                    "LANG",
                    "LC_ALL",
                )
                if key in os.environ
            }
        else:
            safe_environment = dict(environment)
        if any(
            marker in key.upper()
            for key in safe_environment
            for marker in ("TOKEN", "SECRET", "PASSWORD", "PRIVATE_KEY")
        ):
            raise ValueError("worker environment cannot contain secret-bearing names")
        safe_environment.update(PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
        self.environment = safe_environment
        self.breaker = CircuitBreaker(breaker_policy)
        self._capacity = threading.BoundedSemaphore(limits.max_inflight_requests)
        self._component_version = "0.0.0"

    def _spawn(self) -> subprocess.Popen[bytes]:
        try:
            return subprocess.Popen(
                self.command,
                cwd=self.cwd,
                env=self.environment,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                shell=False,
                bufsize=0,
            )
        except OSError as exc:
            raise ComponentOperationError("COMPONENT_NOT_READY") from exc

    def _begin(self) -> None:
        self.breaker.before_call()
        if not self._capacity.acquire(blocking=False):
            self.breaker.cancel_call()
            raise ComponentOperationError("COMPONENT_BUSY")

    def _failure(self, error: ComponentOperationError) -> None:
        if error.code not in {"COMPONENT_BUSY", "COMPONENT_CIRCUIT_OPEN"}:
            self.breaker.record_failure()

    def _invoke(self, request: Mapping[str, Any]) -> dict[str, Any]:
        self._begin()
        process: subprocess.Popen[bytes] | None = None
        try:
            process = self._spawn()
            result = _exchange(process, request, self.limits)
            self.breaker.record_success()
            return result
        except ComponentOperationError as exc:
            self._failure(exc)
            raise
        finally:
            if process is not None:
                if process.stdin is not None:
                    try:
                        process.stdin.close()
                    except OSError:
                        pass
                try:
                    process.wait(timeout=0.5)
                except (OSError, subprocess.SubprocessError):
                    _terminate(process)
                _close_pipes(process)
            self._capacity.release()

    def _unavailable_health(self, code: str) -> dict[str, Any]:
        return {
            "ready": False,
            "reason": code,
            "contract_version": "1.0.0",
            "component_version": self._component_version,
            "capabilities": list(self.required_capabilities),
            "model_sha256": None,
        }

    def health(self) -> dict[str, Any]:
        try:
            result = self._invoke({"op": "health"})
            normalized = normalize_component_health(
                self.name,
                result,
                required_capabilities=self.required_capabilities,
            )
            if (
                self.expected_model_sha256 is not None
                and normalized.get("model_sha256") != self.expected_model_sha256
            ):
                self.breaker.record_failure()
                return self._unavailable_health("MODEL_HASH_MISMATCH")
            self._component_version = normalized["component_version"]
            return normalized
        except ComponentContractError:
            self.breaker.record_failure()
            return self._unavailable_health("COMPONENT_CONTRACT_INCOMPATIBLE")
        except ComponentOperationError as exc:
            return self._unavailable_health(exc.code)

    def create_task(self, member_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self._invoke(
            {"op": "create_task", "member_id": member_id, "payload": payload}
        )

    def open_stream(self, member_id: str, config: dict[str, Any]) -> "ProcessStreamingRecognizer":
        self._begin()
        process: subprocess.Popen[bytes] | None = None
        try:
            process = self._spawn()
            startup = _exchange(
                process,
                {"op": "open_stream", "member_id": member_id, "config": config},
                self.limits,
            )
            if startup.get("started") is not True:
                raise ComponentOperationError("COMPONENT_CONTRACT_INCOMPATIBLE")
            try:
                normalized = normalize_component_health(
                    self.name,
                    startup,
                    required_capabilities=self.required_capabilities,
                )
            except ComponentContractError as exc:
                raise ComponentOperationError("COMPONENT_CONTRACT_INCOMPATIBLE") from exc
            if not normalized["ready"]:
                reason = normalized.get("reason")
                raise ComponentOperationError(
                    reason if isinstance(reason, str) else "COMPONENT_NOT_READY"
                )
            if (
                self.expected_model_sha256 is not None
                and normalized.get("model_sha256") != self.expected_model_sha256
            ):
                raise ComponentOperationError("MODEL_HASH_MISMATCH")
            self._component_version = normalized["component_version"]
            self.breaker.record_success()
            return ProcessStreamingRecognizer(self, process)
        except ComponentOperationError as exc:
            self._failure(exc)
            if process is not None:
                _terminate(process)
                _close_pipes(process)
            self._capacity.release()
            raise

    def circuit_snapshot(self) -> dict[str, int | str]:
        return self.breaker.snapshot()


class ProcessStreamingRecognizer:
    """One ASR stream bound to one isolated worker process."""

    def __init__(
        self, adapter: JsonLineProcessAdapter, process: subprocess.Popen[bytes]
    ) -> None:
        self._adapter = adapter
        self._process = process
        self._closed = False

    def _call(self, request: Mapping[str, Any]) -> dict[str, Any]:
        if self._closed:
            raise ComponentOperationError("COMPONENT_NOT_READY")
        try:
            return _exchange(self._process, request, self._adapter.limits)
        except ComponentOperationError as exc:
            self._adapter._failure(exc)
            self._cleanup()
            raise

    def feed_pcm(self, pcm_s16le: bytes) -> str | None:
        result = self._call(
            {
                "op": "feed_pcm",
                "pcm_s16le_base64": base64.b64encode(pcm_s16le).decode("ascii"),
            }
        )
        text = result.get("text")
        if text is not None and not isinstance(text, str):
            error = ComponentOperationError("COMPONENT_NOT_READY")
            self._adapter._failure(error)
            self._cleanup()
            raise error
        return text

    def finish(self) -> dict[str, Any]:
        result = self._call({"op": "finish"})
        self._adapter.breaker.record_success()
        self._cleanup()
        return result

    def close(self) -> None:
        if self._closed:
            return
        try:
            _exchange(self._process, {"op": "close"}, self._adapter.limits)
        except ComponentOperationError:
            pass
        finally:
            self._cleanup()

    def _cleanup(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._process.stdin is not None:
            try:
                self._process.stdin.close()
            except OSError:
                pass
        _terminate(self._process)
        _close_pipes(self._process)
        self._adapter._capacity.release()
