# Android 迁移依赖

## 只安装现成 APK

- Windows 10/11 64 位。
- Android SDK Platform-Tools，命令行可执行 `adb`。
- RK3566 Android 开发板已开启 USB 调试，连接状态为 `device`。

手动执行 `adb install` 不需要 Flutter、Java、Python、Docker、WSL 或 Linux 环境。
`install_android_debug.bat` 使用 Windows 自带 PowerShell 自动校验并生成 JSON 报告，
同样不需要 Python。Python 3.12 仅用于开发者运行迁移 Loop 和 Python 门禁。

## 从源码重新构建

- Flutter 3.41.7 stable，Dart 3.11.5。
- Java 21（可使用 Android Studio 自带 JBR）。
- Android SDK Platform 35/36，`compileSdk=36`、`targetSdk=35`。
- Android NDK `28.2.13676358`。
- 首次执行 `flutter pub get` 时需要访问 Flutter/Dart 依赖源；已有完整缓存后可离线构建。

检查命令：

```powershell
flutter --version
flutter doctor -v
java -version
adb version
```

构建命令：

```powershell
cd android_app
flutter pub get
flutter analyze --no-pub
flutter test --no-pub
flutter build apk --debug --target-platform android-arm64 --no-pub
```

## 已随源码提供

- Flutter/Android 工程和 Gradle Wrapper。
- 手表插件的 Android/Dart 工程代码及其 AAR/JAR。
- 离线 X-ASR 模型、词表、BPE、许可证和第三方 NOTICE。
- 健康非诊断规则配置。
- Android 迁移验证、设备预检和安装脚本。

## 不需要复制

- `.venv-edge`、`.dart_tool`、`.gradle`、`.kotlin`、`build` 和 pytest 缓存。
- Linux systemd、ALSA、Unix Socket、ELF/PyInstaller、Docker/WSL 模拟环境。
- iOS Framework、手表插件 example 工程和旧统一 Demo。

当前交付为 debug 签名 Android 工程包，不是正式商用 release。正式发布仍需公司签名、
厂商/模型商业分发审核和真机验收。
