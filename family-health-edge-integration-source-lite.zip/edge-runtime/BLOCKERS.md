# BLOCKERS

## 活动 RK3576 阻断（2026-10-15）

| ID | 状态 | 阻断项 | 影响 |
|---|---|---|---|
| W-B01 | BLOCKED_EXTERNAL | 无真实玉成手表型号/固件和 RK3576 Android 14 板卡，SDK 字段、BLE、NPU、性能及长稳无法验收 | W02/W03/W05/W09/W10 |
| W-B02 | BLOCKED_EXTERNAL | 固定的玉成 SDK 快照和 AAR 已落盘，但二进制商业再分发结论未获具名批准 | W01/W08/W10 |
| W-B03 | IN_PROGRESS | 手机健康/OCR/ASR HTTPS/WSS 协议客户端已通过工程测试；健康手工确认入口与 OCR 正式页面已接线并移除静默 Mock。手表自动输入、ASR 页面、厂家 SDK 真实适配器和 RK3576 Android HTTPS/WSS 监听认证服务尚未实现 | W02/W04/W05/W06 |
| W-B04 | RESOLVED_ENGINEERING | 已完成 analyze、151/151 测试和当前源码 arm64 Debug APK 重建/哈希/ABI/V2 调试签名校验；尚未安装到 Android 14 手机，且无正式公司签名 | W08 仅解除本机构建阻断，不代表安装、真机或正式签名通过 |
| W-B05 | BLOCKED_EXTERNAL | 正式包名/公司签名、独立真实报告与语音验收数据、模型/数据/隐私许可和具名批准未到位 | W08/W10 |
| W-B06 | IN_PROGRESS | 正式模式已禁止静默 Mock，但产品认证、设备身份、QR 配对与安全密钥存储尚未实现；当前调试 APK 在缺少认证服务时会诚实失败 | W02/W04/W08 |

以下 2026-10-11 的 RK3566 Android 和更早 Linux 阻断保留为历史基线。

## 活动 Android 阻断（2026-10-11）

| ID | 状态 | 阻断项 | 影响 |
|---|---|---|---|
| A-B01 | BLOCKED_EXTERNAL | ADB 当前无授权设备；缺板卡 SKU、Android API/指纹/安全补丁、RKNPU/RKNN、音频/相机与蓝牙硬件实证 | A10-A12 |
| A-B02 | BLOCKED_EXTERNAL | 手表插件仍为可变 master；内嵌 AAR/JAR/SO 无完整许可/NOTICE 和商业再分发具名结论 | A03/A09/A12 |
| A-B03 | IN_PROGRESS | 手表工程链路与非诊断健康规则已进入 Android App；ASR 的 arm64 JNI、冻结权重、运行时和 16 kHz PCM 麦克风入口已打入调试 APK并通过本地测试，但尚无 Android 执行和真机证据；OCR 仍无 Android runtime | A05-A08 |
| A-B04 | BLOCKED_EXTERNAL | 正式 applicationId 所有权、release keystore/公司签名、应用升级或厂商系统 OTA、工厂注入与回滚方案未批准 | A09/A11/A12 |
| A-B05 | BLOCKED_EXTERNAL | 真实报告、目标麦克风真人语音、健康规则、隐私/分类及各模型商业分发权利仍缺具名批准 | A06/A09-A12 |

以下 B01-B21 是旧 Linux Loop 和仍可复用的数据/模型阻断记录。凡涉及 Linux
镜像、SSH、systemd、ALSA 或 AArch64 ELF 的门禁均不得直接用于 Android 产品通过。

以下条件不能用代码、合成数据或 AI 文档替代。

| ID | 状态 | 阻断项 | 影响 |
|---|---|---|---|
| B01 | BLOCKED_EXTERNAL | 真 RK3566、唯一板卡 ARM64 Linux 镜像、内核/RKNPU 驱动、音频设备及受控 SSH/串口；官方 Lite2/Runtime/Server 2.3.2 制品已锁定但不能替代实机字段 | E04/E06/E07/E10-E12 |
| B02 | BLOCKED_EXTERNAL | Rockchip PP-OCRv4 Det/Rec 已完成工程转换和 PC 仿真；在修正为重叠切片后的 6 张合成体检报告同集中，当前 PP-OCRv5 CPU 完整字段 66/66，官方候选 28/66、必填字段召回 53/66。该结果不是产品准确率，但官方候选已延后，其模型二进制和历史 worker manifest 已归档到活动产品树之外，后端无实现模块且不可选择。Rec ONNX 缺标准输出 shape、Toolkit2 警告、授权真实报告同集验证、分发许可和真 RK3566 验收仍未关闭 | OCR 产品选型与 release |
| B03 | BLOCKED_EXTERNAL | 权利清晰、去标识的真实体检报告开发/校准集和独立验收集；需在 `ocr_acceptance_data_rights_approval` 中具名批准并绑定证据哈希 | OCR 校准与验收 |
| B04 | BLOCKED_EXTERNAL | 目标麦克风真人普通话、口音、老人语音、噪声和不同语速独立验收集；需在 `asr_acceptance_data_rights_approval` 中具名批准并绑定证据哈希 | ASR 产品验收 |
| B05 | BLOCKED_EXTERNAL | 健康提示规则来源、范围、阈值和文案具名批准 | 健康 V1 release |
| B06 | BLOCKED_EXTERNAL | 产品分类、隐私、敏感个人信息单独同意及数据生命周期法务意见；正式验收清单必须绑定隐私审批与对应数据权利审批；威胁模型还必须通过独立 `security_threat_model_approval` 具名 hash 审批 | 商业销售、数据处理与 E09 |
| B07 | BLOCKED_EXTERNAL | OCR/ASR/性能/温度/稳定性/恢复阈值在测试前具名批准并冻结；未冻结时验收客户端和发布门禁均失败关闭 | E10 |
| B08 | BLOCKED_EXTERNAL | 批准的静态加密 codec、设备密钥注入/轮换/恢复/撤销方案 | E08/E09 |
| B09 | BLOCKED_EXTERNAL | 确认服务端口仅本机、成员身份来自 App 登录/设备绑定，以及云同步/远程运维是否关闭 | 最终威胁模型 |
| B10 | PARTIAL_ENGINEERING | 现有 X-ASR CPU 已完成 ARM64 仿真和 S3 部分集成；Zipformer 工程 FP16 RKNN 已生成。同一 MED-CH 60 条研究工程集比较中，CPU CER 7.9161%/实体召回 9/36，RKNN PC 模拟器 CER 16.2613%/实体召回 1/36，均 0 失败、0 空结果；该观察不构成产品赢家。官方 ASR 候选已延后，模型二进制归档到活动产品树之外且后端不可选择。转换环境 126 项离线依赖制品 hash 锁已完成。仍缺商业分发批准、商业可用目标麦克风同集、统一内部切分、产品 worker 和真 RK3566 测量 | 模型选型与真机运行；转换环境正式 SBOM 输入已就绪，但不等于产品正式 SBOM 或 release |
| B11 | BLOCKED_EXTERNAL | 签名公钥设备注入、私钥保管和密钥轮换批准 | E09/E11/E12 |
| B12 | BLOCKED_EXTERNAL | 当前目标漏洞扫描、RK3566 镜像加固及生产调试口策略实证；正式验收合同已强制要求 `target_vulnerability_scan` 与 `rk3566_hardening` 场景通过 | E09/E10 |
| B13 | BLOCKED_EXTERNAL | 公开 CC0 DM/HT 工程候选已分别绑定 Rich Healthcare→DM、杭州 SUA/CVD→HT，模型 manifest、训练报告、数据 manifest、中央账本和原始文件来源链已核验且未融合；仍缺具名法务/产品批准、HT 独立地区验证、Heart/Stroke 合法中国数据 | 健康 ML 只能 shadow；V1 正式输出仍仅规则提示 |
| B15 | BLOCKED_EXTERNAL | RK3566/RK3568 ARM64 ONNX Runtime 冻结及 DM/HT 真机延迟、内存、温度、长稳证据 | 健康 ML 端侧产品启用 |
| B14 | BLOCKED_EXTERNAL | 严格产品健康、签名前序版本/数据库兼容、root-only 激活事务、开机恢复及安全续装已完成 ARM64 工程仿真；签名验证在恢复 smoke 中为显式测试桩，仍缺真签名 bundle 的安装、升级中断、断电、健康失败和回滚验收 | E11/E12 |
| B16 | BLOCKED_EXTERNAL | `1.0.0` 组件版本/能力合同已完成工程冻结，但尚无前后端/终端团队具名批准及真实联调验收；不要求 UI 源码位于模型工程 | E08/E10-E12 |
| B17 | BLOCKED_EXTERNAL | 唯一板卡 SKU、受控 ARM64 构建环境、工厂初始化、设备身份/每设备密钥、公司签名服务和 OTA 制品仓库未冻结 | E01/E08-E12 |
| B18 | RESOLVED_ENGINEERING | WSL、Docker Desktop 与本机 Linux 引擎已就绪；最新 ARM64 S1、S2 健康/ASR 真实推理及 ASR/设备服务 S3 部分集成已通过；OCR 工程 worker 已通过 ARM64 导入/契约测试但未执行 NPU 推理 | 仅解除模拟环境、运行主管和现有工程集成验证，不替代 OCR 商业批准、完整三模型 S3、RK3566 真机或产品门禁 |
| B19 | BLOCKED_EXTERNAL | 固定 Toolkit2 2.3.2 镜像断网重放 5/5 成功；进一步固定 hash seed、构建时间源、时区与数值库线程后，5 个候选各双重转换仍仅 Decoder/Joiner 2/5 逐字节复现，PP-OCRv4 Det/Rec 与 Zipformer Encoder 3/5 继续产生不同 SHA-256。漂移区域已记录；断网能力探针确认 5/5 导出 `.rknn` 虽可读取，但 PC 模拟器均拒绝初始化，因此不能在本机证明漂移只含无害元数据或比较导出制品输出 | 需真 RK3566 对固定制品/重放制品执行相同输入的逐输出等价验收，并冻结制品供应链与签名发布策略 |
| B20 | PASS_ENGINEERING_PRODUCT_BLOCKED | `family-health-edge-tool` ARM64 单文件已构建并锁定五个生命周期子命令；构建镜像、离线 wheel、来源、SBOM、许可证和制品 SHA-256 已独立复核，S1 实际调用该制品完成激活恢复。产品路径不依赖全局 Python，并使用受控 128 MiB 可执行临时目录 | E11/E12；仍缺 `management_runtime_distribution_opinion` 具名批准、真签名 bundle 和真实 RK3566 安装/升级/回滚/断电验收，不能发布 |
| B21 | BLOCKED_EXTERNAL | 已登记 37 个公开数据候选。Rich Healthcare DM 与杭州 SUA/CVD HT 两份中国健康工程原始数据已实际落盘并核对摘要，但仅为 shadow 工程候选，产品目的授权和独立验证仍缺失；四川卒中与北京心血管候选的 Dryad 文件流被 AWS WAF/API 令牌策略返回 403，且其高危人群/SNP或 hs-cTnT 设计不匹配当前普通家庭输入。Common Voice 27.0 zh-CN 仍需账号接受条款和具名法务复核；未找到许可清晰、可商用的真实中文体检报告 OCR 集。NC/权利链冲突数据已排除，CHARLS 永久排除 | B03/B04/B13 未解除；公开或已下载不等于产品授权、独立验收或具名批准 |

15 项外部批准登记在 `configs/product_gate_evidence.json`：必须同时有证据文件、SHA-256、批准人和时间；其中新增管理运行时商业分发意见。真机验收数据登记在 `configs/acceptance_evidence.json`，并绑定冻结合同和远程预检哈希。只改布尔值不能通过。CHARLS 排除不得修改。
