# Android 部署要求

## 直接安装 APK

- Windows 10/11 64 位电脑。
- 安装 Android SDK Platform-Tools，命令行能运行 `adb`。
- RK3566 开发板已安装 Android，Android API 不低于 26。
- 开发板开启 USB 调试，并在连接电脑时允许调试授权。
- 使用可传输数据的 USB 线；`adb devices -l` 中设备状态必须为 `device`。

解压 `Android真机安装包_*.zip` 后，双击：

```text
install_android_debug.bat
```

安装脚本使用 Windows PowerShell，不需要 Python。它会检查 RK3566、`arm64-v8a`、
APK 哈希，随后安装并启动应用。

如果脚本不能运行，可手动执行：

```powershell
adb install -r -t android_app\build\app\outputs\flutter-apk\app-debug.apk
adb shell am start -W -n com.familyhealth.edge.terminal/.MainActivity
```

## 从源码重新构建

- Flutter 3.41.7 stable / Dart 3.11.5。
- Java 21。
- Android SDK 35/36。
- Android NDK `28.2.13676358`。
- 首次下载 Flutter 依赖时需要联网。

```powershell
cd android_app
flutter pub get
flutter analyze
flutter test
flutter build apk --debug --target-platform android-arm64
```

## 不需要安装或复制

- 不需要 Linux、WSL、Docker、systemd、ALSA 或 PyInstaller。
- 不需要复制 `.venv`、`.dart_tool`、`.gradle`、`build` 等缓存目录。
- 只安装 APK 时不需要 Flutter、Java、NDK 或 Python。

当前交付是 Android debug 工程包，用于验证 Linux 到 Android 的迁移；不是正式商用
签名版本。真机安装后请按 `同事最终验收.md` 检查并回传报告。
