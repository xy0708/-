# PROGRESS

## 2026-10-15：手机三模型端侧协议客户端与完整回归

- 扩展正式手机 APP 的端侧 HTTP 客户端：健康测量继续强制成员范围和已确认状态；
  新增 OCR 任务创建、查询、取消与用户确认后幂等写入。OCR 上传改为契约要求的
  JSON/Base64，手机侧先检查 PNG/JPEG 签名、8 MiB 上限并发送 SHA-256。
- 新增独立 ASR WSS 客户端：握手携带 Bearer token 与成员头，固定 16 kHz、单声道、
  s16le；限制 64 KiB 分片和 120 秒总时长，支持 start/partial/stop/cancel，最终结果
  只接受 `final_pending_confirmation`，若端侧声称保存原始音频则失败关闭。
- 新增手机端内存态端侧会话：个人页手工输入 HTTPS 地址、运行期令牌和成员 ID，
  必须先通过 `/v1/version` 验证才可使用；失败后地址和令牌会清除，令牌不持久化。
  这是工程配对入口，正式产品仍需 QR/设备身份与安全密钥存储。
- OCR 正式页面已从旧 `/api/ai/ocr/upload` 和固定“张三/血糖”回退切换到真实端侧
  任务链：图片输入校验→创建任务→读取待确认结果→用户可编辑→幂等确认保存；
  取消、页面离开或中途失败会清理待确认任务，未配对时直接报错。
- 健康评估页已加入真实端侧非诊断入口：只发送用户明确确认的 20–250 bpm 脉搏值，
  会话成员不一致时拒绝请求；手机严格校验返回范围，若出现诊断或疾病概率字段则拒绝
  显示，并原样保留规则审批/产品发布门禁。手表自动输入仍等待真实 SDK 与真机。
- 将新能力写入 `configs/phone_edge_contract.json`，并扩展 RK3576 手机联动审计，
  明确健康/OCR/ASR 协议客户端已实现，但正式 UI 接线仍为 false。
- 正式模式已禁止健康、预警和登录在接口失败时静默回退 Mock；演示数据改为显式
  `ALLOW_DEMO_DATA=true` 才能启用并带全局角标。服务失败会明确提示，历史演示
  Token 会被清除，切换成员也不会展示上一位成员的残留健康数据。
- OCR/健康与 ASR 客户端定向测试 11/11 通过；最新总控 Run
  `20261015T132101Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：Flutter analyze 0 问题、
  Flutter 测试 151/151、Android 迁移 14/14、端侧应用 13/13、故障隔离 5/5 和
  loopback smoke 全部通过。
- 当前源码再次按 ABI 构建；arm64 Debug APK 为 132,230,166 字节，
  SHA-256 `b24f38742795b7d127e9ec05afd4810344e1fe3f2928b13418fbd908969bd25b`，ZIP 内容仅有
  `arm64-v8a`，V2 签名验证通过。签名者是 Android Debug，尚未安装到手机或板卡，
  因此登记为 `ENGINEERING_DEBUG_NOT_PRODUCT`。通用 APK 同时包含三种 ABI、体积
  174,584,984 字节，不作为精简交付候选。
- GitHub Actions 构建已改为依次执行依赖解析、静态分析、全量测试、按 ABI 构建并
  生成 SHA256SUMS；只上传 arm64 工程 APK 和校验和，防止未测试通用包混入验收。
- 本轮没有模型训练、权重修改或真机结果。真实玉成适配器、健康与 ASR 正式页面接线、
  RK3576 Android HTTPS/WSS 服务、APK 手机安装、真实 OCR/ASR 数据验收、
  商业授权与真机验收仍未完成；`product_complete=false`、正式发布仍关闭。

## 2026-10-14：RK3576 手机联动 Loop 继续执行

- 完成并运行 `RK3576_PHONE_WATCH_INTEGRATION_LOOP.md` 的总控入口；每次 Run
  单独归档，保留前两次执行环境失败的原始报告。
- 正式手机 APP 不再默认列出模拟手表；真实 SDK 未接入时明确显示错误。手表适配器
  测试已补充默认失败关闭用例。
- 修复正式手机工程 release 缺少密钥时回退 debug 签名的问题；签名门禁已写入
  Gradle，当前沙箱无法运行 Gradle/Flutter 来确认新源码构建，故不提升 W08。
- 端侧 `/v1/health/evaluate` 现在要求成员 ID 且核对令牌权限；缺成员和跨成员
  请求分别被拒绝，手机发送的 `X-Edge-Member-Id` 与端侧合同一致。
- loopback HTTP smoke 改为手机约定的已确认心率报文，并实际发送缺成员与跨成员
  请求验证 422/403；该测试仍使用工程明文存储与旧 Python 服务，不计 RK3576 验收。
- 定向测试：Android 14/14、端侧应用 13/13、故障隔离 5/5、真实 loopback HTTP
  smoke 通过。总控 Run `20261014T095121Z` 五个子检查通过，Flutter 两项因沙箱
  无法解析 `flutter_tools.snapshot` 被标为 `PARTIAL_ENGINEERING_ENV_BLOCKED`。
- 厂家真实适配器、手机到 RK3576 的 HTTPS 服务、三模型端到端闭环与真机验收
  仍未完成；旧 Debug APK 对当前源码已过期，不能交付为新候选。

## 2026-10-11：离线 ASR Android 工程运行时入包

- 固定 `sherpa_onnx 1.13.7`，将 X-ASR encoder/decoder/joiner、tokens、BPE、许可证与
  Android arm64 Sherpa/ONNX 原生库纳入 APK；资产逐项绑定大小和 SHA-256。
- 新增 Kotlin 私有模型目录供应桥：流式复制、fsync、大小/哈希/路径校验、原子替换，
  并修复 SHA-256 有符号字节格式与不支持原子移动文件系统的兼容问题。
- 新增 Dart ASR runtime：限制 16 kHz、有限 PCM、单会话/120 秒、取消与资源释放，
  输出只进入待确认对象且声明原始音频不落盘；UI 已接入 `record 6.1.2` 的 16 kHz、
  单声道 PCM16 麦克风采集、停止和取消链路。
- Flutter 静态分析 0 问题、测试 15/15；Android 迁移测试 10/10；仅 `arm64-v8a`
  调试 APK 构建成功，大小 248,231,253 字节，SHA-256
  `92225ad4428885f314a62322b80bbd8595853d7d15b0efe07ec5c2e8d6f499f7`。
- 该结果是开发机工程证据：ADB 无设备，ASR 未在 Android/RK3566 实际执行，OCR
  Android runtime 尚不存在，产品授权、签名、真机性能与独立数据验收仍阻断。
- Android 迁移 Loop `20261011T124232Z` 通过全部本地合同和 11/11 Python 门禁；ADB
  预检按设计返回 `BLOCKED_EXTERNAL/no_authorized_android_device`，正式发布仍关闭。
- 已生成并逐文件复核 `Android迁移源码` 与 `Android真机安装包` 两份 ZIP；139 个源码
  文件和 7 个安装文件的 CRC、大小、SHA-256 均通过，缓存和 Linux 运行目录未进入源码包。

## 2026-10-10：活动交付链迁移为 RK3566 Android

- 纠正目标系统：旧工程确认为 ARM64 Linux 路线；新建
  `ANDROID_EDGE_PRODUCTION_LOOP.md`，把 Linux 设备/交付合同封存为历史基线，
  活动合同改为 Android / `arm64-v8a`。
- 建立 Flutter Android 产品壳、最小 BLE 运行时权限、手表扫描/连接和有界的待确认
  健康字段适配层；供应商调试日志关闭，健康 Map 明文 `print` 已移除。
- 冻结手表插件快照 SHA-256，审计顶层 MIT、插件占位 LICENSE 和 9 个无内嵌
  NOTICE 的 AAR/JAR；商业再分发保持阻断。
- 实际修复中文路径门禁、Manifest 备份冲突、旧 support-v4 冲突和供应商 AAR
  过宽权限/可导出组件；没有用全局忽略或伪造构建结果绕过。
- 非诊断健康规则已迁入纯 Dart，增加确认、时间、单位、参考区间、趋势、输入上限
  与禁止诊断/疾病概率测试；Android 规则资产与根配置使用 SHA-256 绑定。
- 新增三运行时失败关闭注册表：健康仅为工程可用，OCR/ASR 明确为
  `BLOCKED_NO_ANDROID_RUNTIME`，禁止旧 Linux 结果冒充 Android 可用。
- 最终 Flutter 分析 0 问题、Flutter 测试 8/8、Android Python 门禁 7/7 通过；
  仅 `arm64-v8a` 调试 APK 构建成功，SHA-256
  `5ffa854b05903259ed797f65a539e4d8011611f2bb1f4079f6a2f4c141baa265`。
- 最新 Android Loop `20261010T155101Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`；
  ADB 无设备，真机、三模型 Android Runtime、release 签名与 SDK 分发许可仍阻断。

## 2026-09-24：补齐健康工程模型训练来源链门禁

- 未重新训练或融合权重；新增显式映射 Rich Healthcare→DM、杭州 SUA/CVD→HT，并把训练报告与数据 manifest 的 SHA-256 固定到端侧健康候选配置。
- `verify_health_ml_candidate.py` 现贯通模型 manifest、训练报告、数据 manifest、中央公开数据账本和本地原始文件，复核路径、大小、摘要、工程/产品边界、DM 地域留出证据、HT 无独立外部集事实及三分区人员指纹。
- 新增 5 项失败关闭测试：拒绝两个任务复用同一来源候选、原始数据摘要漂移、split 指纹复用和把工程报告改写成产品模型；当前验证 `training_source_lineage_verified=true`、`training_sources_fused=false`、`errors=[]`。
- 总控 Run `20260923T142431Z`：42/42 检查符合预期，端侧 279 项测试运行（272 通过、7 项 Windows 平台能力跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项回归均通过；285 个输入和 52 个输出完成哈希绑定，独立快照复验 `PASS_ENGINEERING`、`errors=[]`。仍未创建正式 release。

## 2026-09-23：公开数据落盘状态与训练优先级纠偏

- 纠正中央候选账本“已下载 0 份”与健康工程真实文件状态不一致的问题：登记 Rich Healthcare DM 原始 XLSX 与杭州 SUA/CVD HT 原始 CSV 为已落盘，分别用官方登记的 MD5/SHA-256 复核；当前下载计数为 2。
- `verify_public_dataset_candidates.py` 不再一律拒绝下载声明；只有工作区内注册路径存在且摘要匹配时才允许 `downloaded=true`，路径缺失、越界、摘要缺失或摘要不符均失败关闭。新增 3 项回归测试，公开数据策略测试共 11/11 通过。
- 训练顺序冻结：不重复训练已完成的 Rich DM/杭州 HT；Common Voice 27.0 zh-CN 仅在账号条款和具名许可复核后作为 ASR 通用普通话工程 pilot；OCR 继续使用自有合成材料做管线测试，正式训练等待商业授权真实中文体检报告。
- Dryad 四川高危卒中与北京 hs-cTnT 心血管候选的元数据/CC0 页面可核验，但 API 与真实 Chrome 下载均被 AWS WAF/短期令牌策略返回 403，未生成本地文件、未训练。两者的人群与特殊生物标志物设计也不足以直接覆盖普通家庭输入合同，未把下载失败包装成数据可用。
- 产品状态不变：两份已落盘健康数据仍无本项目具名产品目的授权；没有公开候选被选为产品数据，CHARLS 继续永久排除。
- 当前最新总控 Run 已推进为 `20260923T142431Z`：42/42 检查符合预期，端侧 279 项测试运行（272 通过、7 项 Windows 平台能力跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项回归均通过；285 个输入和 52 个输出完成哈希绑定，独立快照复验为 `PASS_ENGINEERING`、`errors=[]`。状态仍为 `PASS_ENGINEERING_PRODUCT_BLOCKED`，未创建正式 release。

## 2026-09-23：完成公开数据检索与四 Loop 汇总审计

- 检索并登记 12 个 ASR、OCR、健康公开数据候选，保存官方来源、许可证、领域匹配、下载状态和产品用途边界；CHARLS 继续永久排除，未申请、未下载、未训练。
- Common Voice 27.0 zh-CN 为当前唯一工程 pilot：官方标记 CC0-1.0、通用普通话朗读语音，但不是医疗语音或目标麦克风验收集；下载需负责人账号接受条款，当前未下载。MedDQA、MagicData-RAMC 和 longmaodata/Chinese-OCR 因非商业许可证排除产品，其余权利链不完整或领域不匹配候选保持暂停。
- 新增失败关闭验证器和 4 项公开数据回归测试；首次验证因过宽 `NC` 字符串误匹配 “acceptance” 如实失败，收紧为明确许可证标记后通过。
- 新增四 Loop 汇总审计器和 3 项回归测试。`EDGE_PRODUCTION_LOOP`、ARM64 模拟、OCR/ASR 选型和 RK3566 官方模型重构 4/4 均已推进到当前可本地完成的工程边界；`unfinished_without_external_inputs=[]`，但产品 Loop 仍因真机、合规真实数据、具名审批和密钥/签名基础设施阻断。
- 完成该阶段后的当前总控 Run 已更新为 `20260923T142431Z`：42/42 检查符合预期，279 项端侧测试运行（272 通过、7 项 Windows 平台能力跳过），285 个输入和 52 个输出完成哈希绑定，独立快照复验 `errors=[]`；状态 `PASS_ENGINEERING_PRODUCT_BLOCKED`，未创建正式 release。

## 2026-09-23：完成 ARM64 自包含管理工具工程闭环

- 新增统一多路复用入口 `family-health-edge-tool`，覆盖发布包校验、当前版本校验、启动健康检查、回滚转换和激活标记；安装、回滚、开机恢复与 systemd 启动前路径不再调用全局 Python。
- 使用摘要锁定的 Python 3.12.10 Bookworm ARM64 镜像、PyInstaller 6.22.3 和本地离线 wheelhouse 构建单文件；当前不可变制品为 `pyinstaller-6.22.3-bb05467d9bf7-b2574ff7e905`，20,159,600 字节，SHA-256 `16ba42ec6e60a152f0db1772a47e7066d5dce2233044c8161bb7509a511ab32f`，ELF64/AArch64。
- 构建过程中如实保留缺少 `objdump`、安全标记放在全员可写目录、临时盘不足三类失败证据；修复后五个子命令在断网、只读、降权 ARM64 容器中导入，激活标记回合通过。独立验证器复核源码、wheel、许可证、SBOM、ELF 和全部哈希。
- S1 `20260923T031750Z-a0cbeead` 在 ARM64 guest 完成 149/149 测试，并实际调用哈希绑定的工具执行激活恢复；签名验证仍为显式测试桩，`three_model_inference_verified=false`，不是 RK3566 或完整产品证据。
- 为 PyInstaller 单文件增加受控 `TMPDIR` 与至少 128 MiB 可执行临时空间合同；全量端侧单测共运行 260 项，其中 253 项通过、7 项仅因 Windows 平台能力跳过。
- 外部门禁新增 `management_runtime_distribution_opinion`。当前仅为工程制品：法务分发批准、公司签名/设备密钥、真签名包、完整三模型 ARM64 产品运行时和 RK3566 真机验收仍阻断发布。
- 当时总控 Run `20260923T032714Z`：40/40 检查符合预期，`unexpected_checks=[]`；277 个输入和 50 个输出完成哈希绑定，快照完整且独立复验 `errors=[]`。状态为 `PASS_ENGINEERING_PRODUCT_BLOCKED`，未创建正式 release。

## 2026-09-22：完成官方 OCR/ASR 同集工程比较并隔离劣化候选

- 在 6 张已登记的合成体检报告、66 个冻结字段上补齐 PP-OCRv5 CPU 与官方 PP-OCRv4 RKNN PC 仿真的同字节输入比较；发现原全页缩放预处理不公平后，改为 720 像素重叠切片和全局 IoU 去重并重跑。最终 CPU 完整字段 66/66，官方候选 28/66，官方必填字段召回 53/66；保留首次失败记录及修正后报告，均明确不属于产品指标。
- 官方 Zipformer 在 MED-CH 60 条研究集的 CER/实体召回仍弱于现有 X-ASR CPU；由于商业权利、目标麦克风、统一内部切分和真机资源证据缺失，只作工程观察，不宣布 CPU 为产品赢家。
- 按选型结论将 12 个官方 ONNX/RKNN 二进制（650,339,242 字节）迁出 `端侧上线`，存入同级 `官方模型对比实验`；新增安全路径解析、归档清单、独立哈希校验和 3 项路径逃逸测试。活动产品注册表中两个官方后端均保持 `BLOCKED_ENGINEERING`、无实现模块、不可静默回退。
- 迁移后重新执行 5 个禁网 RKNN 转换重放：5/5 转换成功，2/5 字节复现、3/5 漂移；重新执行导出制品能力探针：5/5 可加载但 PC 模拟器均不能初始化。该边界仍要求真 RK3566 做输出等价验证。
- 修复迁移引发的工具链锁、转换重放、能力探针、ASR 单样本证据哈希和 Docker 挂载路径；本项目最新 253 项测试运行（246 通过、7 项 Windows 平台能力跳过）。
- 刷新 ARM64 S1 `20260922T131441Z-0ca3db2a` 与 S3 `20260922T123504Z-fe0232c3`，独立证据校验均 `errors=[]`。
- 发现产品合同禁止全局 Python，但 systemd 启动前检查以及安装、回滚、开机恢复脚本仍直接调用 `python3`/`.py`。现已统一改为直接调用受信任的自包含工具入口，并增加可执行文件存在性门禁和 2 项回归测试。首次 ARM64 重跑 `20260922T131058Z-1b61ee7b` 因测试工具位于不可执行 tmpfs 如实失败；修正隔离挂载后 Run `20260922T131441Z-0ca3db2a` 为 `PASS_ARM64_SOFTWARE`，独立复验 `errors=[]`。真实 aarch64 工具二进制仍未构建，保持进行中。
- 最新总控 Run `20260922T131938Z`：39/39 检查符合预期、238 个输入和 49 个输出完成哈希绑定、三上游工程回归通过，最终状态 `PASS_ENGINEERING_PRODUCT_BLOCKED`；无产品赢家、无真机指标、无正式 release。

## 2026-09-22：正式发布终态、生命周期验收与隐私产品门禁闭环

- 发布输入收集、签名包校验及产品运行时校验现统一拒绝符号链接和 Windows junction/重解析点，且不会递归进入重定向目录；候选复制失败会清理 staging 并生成结构化 `BLOCKED_FAIL_CLOSED` 证据，不再只留下异常堆栈。
- 签名候选 promotion 不再信任调用者任意传入的公钥：必须与已批准 `signing_policy.json` 的受信路径和 SHA-256 完全一致；最终 release 复验也复用同一严格策略，避免提前产生“已签名提升”的假象。
- systemd 启动前的 current release 校验现强制相对链接格式 `releases/<release_id>`，拒绝绝对链接、非规范目标、重定向的安装根/releases 目录及重定向目标；对应校验器和 3 项测试已纳入 ARM64 受控构建上下文。
- 设备安装、回滚、开机恢复、签名前晋升、最终发布复验及 systemd 启动前现统一执行“签名/文件完整性 + 产品运行时语义”联合门禁；即使 bundle 签名正确，只要仍使用工程后端、工程 manifest 或不完整产品配置，也会在激活前失败关闭。无效签名会先短路，不加载任何运行时文件。
- 修复两个结构化输入崩溃点：后端注册表的 capability/reason 和原生子进程握手 capability 若含嵌套对象，现会返回明确的注册表/组件合同错误，不再因对不可哈希对象执行 `set()` 而泄漏 `TypeError` traceback；相应用例已纳入 Windows 全测与 ARM64 guest。
- 签名 bundle 的文件系统边界进一步失败关闭：除符号链接和 Windows 重解析点外，现也拒绝 FIFO、Unix 套接字和设备节点等非普通文件；真实 FIFO 用例已在 Linux/aarch64 guest 执行，避免特殊节点被 manifest 漏记后混入发布包。
- 独立 Run 快照验证器不再永久只接受工程阻断态；未来仅当设备验收、正式签名 release 与总 Gate 审计三份不可变快照同时为一致的 `PASS_PRODUCT_GATE` 时，才接受产品终态。当前仍为工程阻断，未修改任何外部证据。
- 发布构建在复制/hash、产品运行时校验或磁盘 I/O 失败时会写入 `BLOCKED_FAIL_CLOSED` 并删除半成品 staging，不再直接抛出无审计 traceback。候选构建、签名前晋升和正式 release 复验均强制校验产品 OCR/ASR 注册表、选择、manifest、模型 hash 与运行模式，签名正确但运行时无效的包不能上线。
- 正式验收合同新增干净设备安装、签名离线升级、自动回滚、旧版恢复、离线三运行时应用、工厂身份、每设备密钥、签名 OTA、跨 SKU 拒绝、目标漏洞扫描和 RK3566 加固等强制场景；遗漏任一场景即失败关闭。
- ASR 最终发布必须同时满足 ARM64 runtime ready 与产品 Gate；OCR 必须同时具备至少两份 ONNX、两份 RKNN 并通过产品 Gate。E02、E05-E09、E11 的审计状态现可在真实终态转换为 `PASS_PRODUCT_GATE`，且正式 release 通过但任一产品 Gate 未通过会被标记为矛盾。
- 隐私报告由永久 `product_privacy_gate=false` 改为可验证状态机：只有真实设备验收、非合成证据、隐私/加密/威胁模型三项具名 hash 审批和完整安全场景均通过时才可能为 true。新增 `security_threat_model_approval` 后，外部 Gate 共 14 项；当前三项安全审批和真机验收均未提供，所以继续诚实阻断。
- ARM64 S1 在受限执行账户下首次刷新 `20260922T025704Z-9b40314b` 因无 Docker 命名管道权限停在 S0，失败记录保留；后续 `20260922T083940Z-b16a7f6d` 又因 Docker Desktop 引擎已停止停在 S0，同样保留。`20260922T085922Z-b7b64fd5` 是未传 `--execute` 时仅完成预检的 `READY_TO_EXECUTE` S0 记录；`20260922T091739Z-8225ccf8` 与 `20260922T091849Z-aee00808` 分别暴露新增测试缺验证脚本、缺冻结配置的最小上下文白名单问题。补齐精确只读依赖后，最新 Run `20260922T094334Z-94330e4d` 为 `PASS_ARM64_SOFTWARE`，Linux/aarch64 guest 149/149、0 跳过、容器清理完成，独立验证 `errors=[]`。这不是 RK3566 真机证据。
- 运行时源码变化使旧 S3 哈希按设计失效，总控 `20260922T092306Z` 如实失败；受限账户误执行产生的 S3 环境阻断 `20260922T092721Z-b174f4ad` 也保留。获准权限下真实重跑 S3 `20260922T092755Z-d177f712` 完成现有 ASR V2 ARM64 WebSocket 集成，独立验证 `errors=[]`，仍不冒充 OCR 或 RK3566。
- 最终总控 Run `20260922T094640Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：37/37 检查符合预期，`unexpected_checks=[]`；端侧 245 项运行（238 通过、7 项 Windows 平台能力跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过，225 个输入及 45 份输出快照完成绑定，独立快照复验 `errors=[]`。未创建正式 release。

## 2026-09-22：产品运行时切换与发布包内容门禁补齐

- 修复“外部 Gate 即使全部通过，代码仍永远只能启动工程模式”的内部缺口：后端注册表现支持严格区分工程/产品边界，产品态必须同时存在 `PRODUCT_READY` 的 OCR 与 ASR，三项许可/验收/真机标志均为 true，且禁止静默回退；工程注册表不能夹带产品后端。
- 设备服务运行时现在将产品配置、产品选择、后端注册表、ASR/OCR 产品 manifest、模型/运行库/组件版本和 bundle SHA-256 逐层绑定；产品 worker 通过显式 `--product-mode` 启动。工程 manifest 冒充产品、缺 OCR、模式混用或任一哈希不符都会失败关闭。
- 健康接口不再永久硬编码 `product_complete=false`，但只有安全存储、产品运行时、合法 release ID 和 OCR/ASR 健康全部成立时才可能返回 true；当前因产品加密 codec/设备密钥未批准，仍保持 false。systemd 已显式传入三份运行控制文件和签名 release manifest。
- 发布包新增必需内容门禁：设备服务、更新代理、三模型资产、运行配置、systemd、迁移、库、许可证、SBOM 和验收报告缺一不可，禁止 Demo、测试、checkpoint、cache 和 pyc；构建候选时还会实际解析产品 runtime bundle 并核对两模型 manifest 与文件哈希，空壳签名包不能通过。
- 源码变更后，旧 S1/S3 证据被独立校验器按设计拒绝并保留；真实重跑 S1 `20260922T013333Z-5ffecb74` 为 Linux/aarch64 guest 129/129、0 跳过，S3 `20260922T013700Z-925c1f3d` 完成真实 ASR WebSocket 推理，两份独立验证均 `errors=[]`。一次错误的 `--help` 探测产生 `20260922T013619Z-696ff51d` 环境阻断记录，未覆盖或伪装。
- 最终总控 Run `20260922T014000Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：37/37 检查符合预期，`unexpected_checks=[]`；端侧 226 项运行（222 通过、4 项 Windows 权限跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过，220 个输入及 45 份输出快照完成绑定，独立快照复验 `errors=[]`。未创建正式 release。

## 2026-09-21：正式验收数据入口与外部审批证据加固

- 外部 Gate 改为 13 项精确注册表，删除必需 Gate 或添加未知 Gate 都会失败；任何已批准项必须同时具备非占位具名批准人、带时区批准时间、受控证据路径和匹配 SHA-256。新增 OCR/ASR 验收数据权利两项独立审批，未批准时产品继续阻断。
- OCR/ASR 正式验收清单必须绑定隐私审批和对应数据权利审批哈希；整批样本会在首次模型调用前完成 schema、去标识化声明、非合成/独立划分、路径、哈希、媒体和音频格式校验，避免执行到一半才发现坏样本。
- 输出限制在 `evidence/acceptance/`，该目录已排除 Git；证据以临时文件流式写入并通过不覆盖硬链接原子发布，模型中途失败不留下半成品，已有证据不会被覆盖。聚合指标入口增加文件/行/样本上限、物理数值边界、必需故障场景和符号链接拒绝。
- 新增失败安全 OCR、ASR 和汇总清单模板及 UTF-8 验收说明；模板默认 `rights_cleared=false`、`independent_split=false`、`direct_identifiers_removed=false`，不能被误当正式证据。验收入口结构核验为 `PASS_ENGINEERING`，13 项外部审批仍均为 `NOT_APPROVED`，没有伪造授权。
- `run_device_acceptance.py` 对损坏 JSON、越界路径、符号链接/Windows junction 和非有限指标改为明确阻断，不再异常退出；正式指标报告必须绑定实际 `acceptance_evidence.json` 的 SHA-256，不能替换原始证据后复用旧指标。端侧全量 218 项运行（214 通过、4 项 Windows 符号链接权限跳过）。
- 总控已加入同一次 Run 内的正式指标计算，指标、设备验收、发布构建和审计均校验“退出码与报告状态一致”；发布生命周期不再被硬编码为永远阻断，未来只有在全部真实产品 Gate 通过时才允许转换为 `PASS_PRODUCT_GATE`，当前不会误报。
- 源码变更使旧 S1 证据按设计失效后，已真实重跑 ARM64 S1 `20260921T141151Z-c25bb1ea`：Linux/aarch64 guest 123/123、0 跳过，独立验证 `errors=[]`。最终总控 Run `20260921T141434Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：37/37 检查符合预期，`unexpected_checks=[]`；健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过，219 个输入及 45 份输出快照完成绑定，独立快照复验 `errors=[]`。未创建正式 release，真 RK3566、授权数据、具名审批、产品密钥与签名仍为外部阻断。

## 2026-09-21：ASR CPU/RKNN 同一 MED-CH 60 条研究工程集比较完成

- 使用完全相同的 60 条音频字节、参考文本和样本边界，分别执行锁定的 X-ASR/Sherpa-ONNX 1.13.7 Windows CPU 推理与 Zipformer RKNN Toolkit2 2.3.2 x86_64 PC 模拟器；失败与空结果均保留在分母。
- CPU 结果为 CER 7.9161%、实体召回 9/36、0 失败、0 空结果；RKNN PC 模拟器为 CER 16.2613%、实体召回 1/36、0 失败、0 空结果。这里只能观察到 CPU 在该研究集质量更好，不能据此宣布产品赢家。
- MED-CH 标记为“仅研究评测，商业许可待审”；两候选内部特征切分不同，PC 模拟器耗时不代表 RK3566，且没有目标麦克风真人独立集或真机证据。`product_selection_allowed=false`、`hardware_measured=false`。
- 修复长任务 30 分钟硬超时导致容器孤立和 CPU 阶段结果丢失的问题：候选阶段现在独立原子保存、哈希一致时可恢复复用，RKNN 仿真上限改为 2 小时，异常路径按唯一容器名清理。4 项边界测试和独立比较校验通过，`errors=[]`。
- 报告已接入官方候选清单及总工程 Loop；R04/R06 保持 `IN_PROGRESS`，授权数据、统一切分、具名阈值、目标麦克风和真 RK3566 仍为上线阻断项，未创建正式 release。
- 对 5 个已导出 RKNN 制品执行断网 PC 模拟器能力探针：5/5 `load_rknn()` 成功、5/5 `init_runtime()` 被 Toolkit2 2.3.2 明确拒绝并要求目标设备。已增加独立 fail-closed 验证与 3 项测试；这证明 ONNX 重建仿真不能替代固定/重放 `.rknn` 输出等价验收，B19 收敛为真 RK3566 外部阻断。
- 后端决策更新后的首轮总控 Run `20260921T044804Z` 正确拒绝了哈希已过期的 ASR 单样本与 ARM64 集成证据；重新执行真实 CPU 单样本推理和 Linux/aarch64 S3 集成后，独立验证恢复为 `errors=[]`。失败 Run 被保留，没有覆盖或伪装。
- 全量端侧 202 项测试运行，198 通过、4 项仅因 Windows 无符号链接权限跳过；最终总控 Run `20260921T051006Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`，35/35 检查符合预期，205 个输入和 43 份输出快照完成绑定，独立复验 `errors=[]`，未创建正式 release。
- 基于当前同集观察，没有继续盲目实现 Zipformer RKNN 工程 worker：注册表新增“研究集质量回退、worker 暂缓”原因，X-ASR CPU 继续作为唯一工程 ASR 路由，但 `product_accepted=false`；授权集或真机资源证据改变结论后才重新开启。

## 2026-09-20：PP-OCRv4 RKNN 工程 Worker 与显式启动装配完成

- 实现 `ocr_runtime.rknn_worker`：在独立 JSON-line 进程内执行 PP-OCRv4 Det→裁剪→Rec→字典解码；输入由不可序列化的原始 `bytes` 改为有界 Base64 JSON，并在 Worker 内二次校验容器格式、大小和 SHA-256，输出不含原图且强制待确认。
- 新增工程 manifest，逐项锁定 Det/Rec RKNN、字典和 Rockchip 冻结后处理源码的大小与 SHA-256；模型 bundle 仍为 `990970c4...ca3c7f`。运行时只允许 Linux/aarch64、设备树含 RK3566、`rknn-toolkit-lite2==2.3.2` 且 SDK 版本匹配，否则失败关闭。
- 后端注册表现在能区分“工程 Worker 已实现但仍不可选择”和“Worker 缺失”；O2 登记 `ocr_runtime.rknn_worker`，但保持 `BLOCKED_ENGINEERING`，OCR 选择仍为空，产品 Worker/许可/真机/授权数据 Gate 均保持 false。
- 设备服务启动器由 ASR-only 重构为显式选择的 ASR/OCR 装配；配置、后端模块、模型 ID/bundle hash、运行库与契约版本必须完全一致。定向测试证明获准选择时只能构造哈希锁定的 OCR Worker，当前实际选择不会启用它，也不存在静默回退。
- ARM64 S1 Run `20260920T113436Z-406bcbb8` 为 `PASS_ARM64_SOFTWARE`，123/123、0 跳过；S3 Run `20260920T113555Z-ee21ed07` 为 `PARTIAL_PASS_PRODUCT_BLOCKED`，真实 ASR/设备服务集成继续通过，OCR 因非 RK3566、未选择及外部 Gate 未调用 NPU 推理。
- Windows 端侧全量 185 项测试运行，181 通过、4 项因符号链接权限跳过；工程总控 Run `20260920T114407Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`，31/31 检查符合预期、180 个输入和 33 份输出快照绑定、独立证据复验 `errors=[]`，未创建正式 release。


## 2026-09-19：R02 转换环境离线传递依赖锁完成

- 将 RKNN Toolkit2 2.3.2 转换环境的 103 个 Debian 包、20 个 Python 依赖 wheel、已登记 Toolkit2 wheel、离线 Dockerfile 与精确 requirements 共 126 项全部保存到本地并记录大小与 SHA-256；构建阶段不再访问软件源。
- 新镜像 `family-health-rknn-converter:2.3.2-cp38-offline-lock-v1` 使用固定本地 Ubuntu 基础镜像，以 `--network none --no-cache` 完整重建；构建日志和依赖 manifest 已归档，`pip check`、Python 3.8.10、RKNN Toolkit2 2.3.2 导入均通过。
- 新旧镜像的 194 个 Debian 包和 23 个 Python 包逐项一致；Toolkit2 wheel 使用矩阵登记的 `64442c...a90a` 制品，而不是仓库内另一份同名但哈希不同的 wheel。
- 依赖输入通过 BuildKit 只读临时挂载参与安装而不进入最终层；新镜像 1,274,992,336 字节，比原镜像 1,316,392,244 字节小 41,399,908 字节。
- fail-closed 验证器已校验构建命令、日志、manifest、126 个文件哈希、镜像身份/体积、包集合与 smoke；结果为 `PASS_ENGINEERING_PARTIAL`、`dependency_artifact_hash_lock_complete=true`、`errors=[]`。
- R02 仍为 `IN_PROGRESS`：3 个 RKNN 转换产物非确定性、板卡系统镜像/内核/RKNPU 驱动和真 RK3566 smoke 均未关闭；本结果不是产品选型、硬件测量或正式发布。
- 完整总控 Run `20260919T133447Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：30/30 检查行为符合预期，端侧 179 项测试运行（175 通过、4 项 Windows 符号链接权限跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；176 个输入与 32 份输出快照完成绑定，独立复验 `errors=[]`，没有创建正式 release。

## 2026-09-18：R05 注册表、选型与设备服务启动绑定（工程部分通过）

- 设备服务启动现在要求 runtime 配置、后端注册表和显式选型文件成组提供；缺任一文件、路径逃逸、被阻断/未知后端、模块、模型 ID、bundle SHA-256、运行库版本、契约版本或组件版本不一致时均失败关闭。
- 当前工程选型仍只有 `asr_sherpa_cpu_xasr`；OCR 为空，O2/A2/A3 继续不可选，`fallback_allowed=false`。接入注册表不等于选择官方 RKNN，更不等于产品批准。
- 新增模型哈希不一致和被阻断 Zipformer 不得回退的回归用例；端侧全量 179 项运行，175 通过、4 项 Windows 符号链接权限跳过。
- ARM64 基础仿真首次刷新暴露构建白名单漏装 `runtime_backends`；已补入隔离上下文并增加回归断言。刷新后的 S1 Run `20260918T094509Z-c2410244` 在 Linux/aarch64 中 122/122 通过，独立证据校验为 `errors=[]`。
- S2 Run `20260918T094803Z-56999ee8` 保持健康规则与真实 ASR ARM64 推理通过；S3 Run `20260918T095130Z-4c1b3120` 完成注册表选型、真实 ASR worker、WebSocket 推理、S2 文本哈希对齐、未确认数据不落库、任务取消和容器清理；OCR、真 RK3566 和产品批准仍阻断。
- 修复后完整总控 Run `20260918T095442Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：30/30 检查行为符合预期，端侧 179 项测试运行（175 通过、4 项 Windows 符号链接权限跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；171 个输入与 32 份输出快照完成绑定，独立复验 `errors=[]`，没有创建正式 release。

## 2026-09-18：RKNN 转换可复现性重放（工程审计通过，产物哈希部分漂移）

- 在固定镜像 `family-health-rknn-converter:2.3.2-cp38` 中以断网、工作区只读方式连续重放 O2/A2 共 5 个转换；每次转换均成功，原始 SDK 日志按 run ID 归档，临时 `.rknn` 已自动清理。
- Decoder 与 Joiner 2 个制品逐字节复现；PP-OCRv4 Det、Rec 和 Zipformer Encoder 3 个制品在相同输入、镜像及命令下仍产生不同 SHA-256，且第三次结果也不等于第二次结果。文件大小不变，变化集中在前部 1,150、40、3,158 字节跨度内。
- 变化区域未检出可确认的时间戳、UUID 或主机路径；现有证据不足以证明漂移仅为无害元数据，因此不做归一化、不覆盖已登记制品，也不把转换成功表述为可发布。
- 进一步固定 `PYTHONHASHSEED`、构建时间源、时区以及 OMP/BLAS/NumExpr 线程数后，对 5 个候选各执行两次转换；10/10 转换成功，但仍只有 Decoder/Joiner 2/5 两两一致，Det/Rec/Encoder 3/5 继续漂移。常见环境随机性已受控，工具链内部非确定性“疑似但未证明”。
- 本地 Rockchip 仓库、示例及 Toolkit2 2.3.2 wheel 的公开 Python `config()`/`build()` API 未发现 seed、deterministic 或 reproducible 参数；核心转换逻辑主要为已编译扩展，下一步需要厂商格式/确定性说明或真机输出等价证据，不能靠猜测参数关闭风险。
- 新增独立 fail-closed 校验器并接入总工程 loop；当前证据为 `PASS_ENGINEERING_REPLAY_AUDIT_PRODUCT_BLOCKED`，5/5 转换成功、2/5 字节复现、3/5 哈希漂移、`hardware_measured=false`、`product_selected=false`。
- 当前必须在真 RK3566 上比较冻结制品与重放制品的张量/解码输出，并决定发布是否采用固定已验收二进制或要求工具链产生确定性输出；未完成前保持产品阻断。
- 完整总控 Run `20260918T090033Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：30/30 检查行为符合预期，端侧 177 项测试运行（173 通过、4 项 Windows 符号链接权限跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；171 个输入与 32 份输出快照完成绑定，独立复验 `errors=[]`，没有创建正式 release。

## 2026-09-17：O2/A2 转换与 PC 仿真（工程部分通过）

- 固定并构建 RKNN Toolkit2 2.3.2 / Python 3.8.10 转换镜像 `family-health-rknn-converter:2.3.2-cp38`，image ID 为 `sha256:7f9aada37e75721b62de280c087d4457c2d9356afc47d7518aa5efdbf627f18e`；转换环境已可重建，但传递依赖离线 hash 锁仍未完成。
- O2 已生成 PP-OCRv4 Det/Rec 两个工程 `.rknn`，bundle SHA-256 为 `990970c4c8e34bdc9890bb56c10d1561b7a80dddddb83e69f674ad2f7aca3c7f`；Det/Rec 原始张量形状一致，且官方单图经 Det→裁剪→Rec→字典解码后，ONNX 与 RKNN PC 模拟器均得到 16 条完全相同文本。单图不是准确率数据，仍缺同集 OCR 对比和真实报告验收。
- A2 已生成 Zipformer Encoder/Decoder/Joiner 三个工程 `.rknn`，bundle SHA-256 为 `4fbc9f38d9f6f659fff77a2b8bd3c7542ad1ebf636fc40dfebfc50eb4a01b76e`；官方 5.6115 秒样例在 ONNX 与 RKNN PC 模拟器均解出 26 个相同 token 和文本。单条官方样例不能形成 CER/WER 或产品准确率。
- 仿真暴露并修复了 Python 3.8 `zip(strict=...)` 不兼容、Encoder rank-4 cache 的 NCHW/NHWC 输入适配、OCR 官方脚本隐式 `six` 依赖，以及 Kaldifeat 源码/CUDA 构建不适配问题；RKNN Toolkit2 的 Unknown-op-target/transpose 警告仍需真机复核。
- 候选制品验证器结果为 `PASS_ENGINEERING_PARTIAL`：2 个已执行候选、10 个制品、`errors=[]`。产品选型仍为 `NO_PRODUCT_WINNER`；授权同集、许可批准、产品 worker 与真 RK3566 均未通过。
- 新增机器可读候选比较合同与 fail-closed 校验：登记 O1/O2、A1/A2 和条件候选 A3，固定同输入、失败计入分母、PC 延迟不得排序、真机性能必需等规则；16 项指标已列出，但阈值、优先级、tie-breaker、数据 manifest 和批准人均保持空值，禁止在外部批准前选赢家。
- 完整总控 Run `20260917T122050Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：28/28 检查行为符合预期，端侧 166 项测试运行（162 通过、4 项 Windows 符号链接权限跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；161 个输入与 30 份输出快照完成绑定，独立复验 `errors=[]`，没有创建正式 release。

## 2026-09-17：R05 可插拔后端注册表（进行中）

- 新增严格机器可读注册表，登记现有 ASR CPU、现有 OCR CPU、PP-OCRv4 RKNN、Zipformer RKNN 和 Whisper RKNN 五个后端；禁止任意命令或未登记模块进入执行路径。
- 只有已通过 ARM64 工程集成的 `asr_sherpa_cpu_xasr` 可用于工程选择；产品可选后端仍为 0。O2/A2 的工程 RKNN bundle 已登记，但缺冻结同集验证、worker、许可或真机证据时仍一律失败关闭。
- 显式冻结 `fallback_allowed=false`，测试覆盖阻断后端、未知后端和产品模式拒绝，避免自动降级掩盖运行时错误；验证器结果为 `PASS_ENGINEERING_PARTIAL`、5 个已登记、1 个工程可选、`errors=[]`。
- 注册表尚未接入设备服务启动路径，所以 R05 仍为 `IN_PROGRESS`，不宣称已经完成 CPU/RKNN 切换。
- 总控 Run `20260917T072520Z` 如实保留为 `FAIL_ENGINEERING`：隐私日志测试把敏感数字 `138` 与时间戳微秒做原始文本子串比较，产生随机误报。测试已改为只检查可能承载调用方内容的白名单字段；隐私定向测试连续 50 轮零失败，全量 164 项随后通过。
- 修复后完整总控 Run `20260917T072912Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：26/26 检查行为符合预期，164 项端侧测试运行（160 项通过、4 项 Windows 符号链接权限跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；155 个输入和 28 份输出快照完成绑定，独立复验 `errors=[]`，没有创建正式 release。

## 2026-09-17：RK3566 官方候选 R02 工具链冻结（进行中）

- 从已固定的 `rknn-toolkit2@59a913d172e7f5ff03c9076e2ec7b1b1288ffd08` 保存 Toolkit2 cp38 x86_64、Lite2 cp38 aarch64、`librknnrt.so`、`rknn_server` 及官方构建文件；9 个制品均完成大小和 SHA-256 锁定。
- 冻结 Ubuntu 20.04 官方 image index 与 linux/amd64 manifest digest；兼容矩阵统一 Toolkit2/Lite2/Runtime/Server 为 2.3.2、目标为 `rk3566`，变更任一组件必须重跑转换、对齐和真机验收。
- 新增 fail-closed 验证器和单测；转换镜像已实际构建并记录 image ID，O2/A2 共 5 个 RKNN 制品完成转换和 hash 登记。明确保持 `real_rk3566_verified=false`、`formal_release_allowed=false`。
- 官方 requirements 仍含版本范围，传递依赖离线 hash 锁尚未完成；板卡系统镜像、内核和 RKNPU 驱动也仍为空，因此 R02 仍保持 `IN_PROGRESS`，不能把宿主 PC 仿真表述为真机验证。
- 完整总控 Run `20260917T071139Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：25/25 检查行为符合预期，端侧 161 项运行（157 项通过、4 项 Windows 符号链接权限跳过），健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；151 个输入和 27 份输出快照完成绑定，独立复验 `errors=[]`，未创建正式 release。

## 2026-09-16：R01 后全量总控复验

- 总控 Run `20260916T131735Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：24/24 检查行为符合预期，`unexpected_checks=[]`，没有创建正式 release。
- 端侧 160 项运行（156 项通过、4 项 Windows 符号链接权限跳过）；健康 21/21 个测试文件、OCR 105 项、ASR 111 项均退出码 0。
- 148 个输入及 26 份输出快照已绑定，`snapshot_integrity_verified=true`；独立快照复验为 `PASS_ENGINEERING`、`errors=[]`。
- 设备验收、发布验证、发布构建及 Loop 完成审计均按设计失败关闭：缺少真 RK3566、冻结且批准的验收合同/阈值、真实授权 OCR/ASR 验收数据、商业分发意见、签名密钥与正式批准。下一工程阶段为 R02 工具链及兼容矩阵冻结。

## 2026-09-16：统一展示改为真实实验证据口径

- 新增 `/api/metrics`，直接加载健康、OCR、ASR 现有评测 JSON，并返回来源路径和 SHA-256；报告边界不符合预期时失败关闭。
- 健康单次输出不再用百分号制造“正确率”印象，改称模型分数；页面独立展示真实测试集 ROC-AUC、PR-AUC、敏感度、样本量与阳性数。
- OCR 不再展示合成 100% 为真实性能，明确真实报告测试集为 0；ASR 同时展示 CER 7.773% 和医疗实体召回 25%，不以总体 CER 掩盖领域短板。
- 更新展示教程和 RK3566 重构 Loop 的展示证据门禁；统一 Demo 完整冒烟 7/7 通过，健康、OCR、ASR 均执行真实工程推理。
- 内置浏览器不可用，Playwright CLI 首次拉取在受控等待后未完成，因此本轮完成接口、静态资源、JavaScript 语法和真实模型冒烟验证，未伪造浏览器截图证据。

## 2026-09-16：RK3566 官方候选 R01 来源冻结

- 固定 `rknn_model_zoo@bad6c7334531becaf90a561988519b7bec34d0ab`、`rknn-toolkit2@59a913d172e7f5ff03c9076e2ec7b1b1288ffd08`，并固定 PaddleOCR、Zipformer 模型仓和 Whisper 上游 commit。
- 从 Rockchip 官方下载地址取得 PP-OCRv4 Det/Rec、Zipformer encoder/decoder/joiner、Whisper base encoder/decoder，共 7 个 ONNX、515,671,301 字节；全部登记 URL、大小和 SHA-256。
- 稀疏保存官方示例、完整许可证和上游模型卡，生成 `vendor/rockchip/model_zoo.lock.json` 与 `THIRD_PARTY_NOTICES.md`；工程许可识别不替代具名法务批准。
- ONNX 检查为 6 个通过、1 个失败：`ppocrv4_rec.onnx` 缺输出 shape。该缺陷进入 R03 兼容性门禁，不能静默修补或直接标记产品通过。
- 新增 fail-closed 离线验证器和单测；21 个文件、5 个仓库 commit 全部复验通过，workspace 验证通过。没有生成 `.rknn`、没有改变现有默认模型、没有放行正式 release。

## 2026-09-16：RK3566 官方模型路线纠正与重构 Loop

- 复核 Rockchip 官方 `rknn_model_zoo` 后确认：RK3566 已有 PP-OCRv4 Det/Rec、Zipformer、Whisper 和 wav2vec2 RKNN 候选。此前只围绕现有 PP-OCRv5 CPU 与 X-ASR CPU 推进，遗漏官方 NPU 路线；“尚无本地产品 RKNN”仍为真，但“没有官方候选”不成立。
- 新建 `RK3566_OFFICIAL_MODELS_PRODUCTION_LOOP.md`，把官方来源冻结、RKNN 工具链、OCR/ASR 同集比较、可插拔后端、真实数据、真机、三模块集成和发布回滚拆为 R00-R11。
- 不删除或覆盖现有模型及历史 ARM64 证据。官方模型只获得候选资格，必须与现有 CPU 后端在同一独立数据和真 RK3566 上比较；若效果退化允许继续使用 CPU，禁止为了 NPU 制造产品通过状态。
- 修正总 Loop 和阻断项：官方候选存在，但尚未固定 commit、下载、转换、登记、许可复核或真机验收；正式 release 仍未创建。

## 2026-09-13：待确认结果所有权与 TTL 加固

- 故障用例证明 `create_task` 原先保存调用方传入的可变字典引用，调用方可在校验后修改内部待确认内容；`get_task` 也直接返回该引用。现先规范化为独立 JSON 快照再进入内存，读取时返回深复制，确认和更正同样只使用校验后的独立对象。
- GET 原先只检查重启造成的结果丢失，没有按 `expires_at` 拒绝仍在内存的过期结果；现先持久化 `expired` 状态并清除敏感内存，再返回 `TASK_EXPIRED`。相关存储、应用、故障隔离和真实 loopback WebSocket 27 项定向测试通过。
- 为避免从未再次访问的任务把敏感结果留在内存，新增每个数据库实例唯一的后台清理线程；它只扫描独立的内存到期索引，不为每个任务创建线程，不接触原始音频/图片，周期被限制在 0.01–60 秒，关闭数据库时必须停止并回收。定向链路 32 项通过。
- ASR 在 `finish()` 创建待确认任务后若最终 WebSocket 写回失败，旧 `cancel()` 因状态已变为 `final_pending_confirmation` 不会清理该任务；现由会话跟踪任务 ID，传输放弃时立即取消，存储异常时由 TTL 清理器兜底。ASR/WebSocket 10 项定向测试通过。
- 总控 Run `20260912T162254Z` 如实保留为 `FAIL_ENGINEERING`：功能单测和三个上游工程回归均通过，但 ASR 会话源码改变后旧 S3 证据的源码哈希失效，`integration_simulation_evidence` 按设计拒绝陈旧证据，没有绕过门禁。
- 重跑 S3 Run `20260912T162550Z-d154032b` 为 `PARTIAL_PASS_PRODUCT_BLOCKED`：Linux/aarch64 中现有 ASR V2 经真实 loopback WebSocket/HTTP 再次完成推理、取消与清理，文本哈希保持与 S2 基准一致；独立验证 `errors=[]`。OCR 产品 worker、许可、目标麦克风验收和 RK3566 仍按事实阻断。
- WebSocket 帧解析原先未拒绝 RSV 保留位、超过 125 字节的控制帧或非最短长度编码，发送辅助函数也允许非法 opcode；现收发两端统一拒绝保留位、分片、未知 opcode、非规范长度、未掩码客户端帧和超限控制/数据帧。协议、真实 loopback 和 ASR 12 项定向测试通过。
- 刷新 S3 Run `20260912T163834Z-a5258efb`：现有 ASR V2 在 Linux/aarch64 中通过严格 WebSocket 解析器完成真实推理、取消和零确认前持久化，文本哈希继续与 S2 基准一致；独立验证 `errors=[]`，容器已清理。
- S1 Run `20260912T163519Z-e2f6f4d8` 为 `PASS_ARM64_SOFTWARE`：Linux/aarch64/64 位非 root guest 109/109、0 跳过、源码哈希一致；待确认结果生命周期和严格 WebSocket 帧协议通过，两个容器均已清理。该结果仍不代表三模型真实推理或 RK3566 产品验收。
- 最终总控 Run `20260912T164213Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：23/23 检查行为符合预期，端侧 148 项运行（144 项通过、4 项 Windows 符号链接权限跳过，ARM64 等价用例 109/109 无跳过）、健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；S1/S3 和 143 个输入、25 份输出快照独立复验均为 `errors=[]`。`product_complete=false`、`hardware_measured=false`，未创建正式 release。
- 后续协议审计发现底层帧读取把合法短读误判为断线，Close 帧未校验长度、状态码和 UTF-8 原因，握手也未强制 HTTP/1.1 `Connection: Upgrade`；现已失败关闭非法输入、重组短读，并回显已验证的关闭载荷。本机完整回归 151 项运行，147 项通过、4 项 Windows 权限跳过。
- 不带执行开关的 S0 Run `20260912T164749Z-01bcaee7` 仅为 `READY_TO_EXECUTE`；一次受限环境 S3 Run `20260912T165052Z-9328332f` 如实记录 `LOCAL_LINUX_DOCKER_NOT_READY`，均未冒充 ARM64 通过结果。
- 刷新 S1 Run `20260912T164823Z-c88dfb25`：Linux/aarch64/64 位非 root guest 112/112、0 跳过且源码哈希一致，更新恢复容器也通过，两个容器均已清理；独立验证 `errors=[]`。
- 刷新 S3 Run `20260912T165111Z-5c239489`：现有 ASR V2 经修复后的真实 loopback WebSocket 完成 ARM64 推理、取消和零确认前持久化，文本哈希与 S2 一致；独立验证 `errors=[]`，容器已清理。OCR、许可、目标麦克风和 RK3566 仍按事实阻断。
- 最终总控 Run `20260912T165515Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：23/23 检查行为符合预期，端侧 151 项运行（147 项通过、4 项 Windows 符号链接权限跳过，ARM64 等价用例 112/112 无跳过）、健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；S1/S3 和 143 个输入、25 份输出快照独立复验均为 `errors=[]`。`product_complete=false`、`hardware_measured=false`，未创建正式 release。
- 服务生命周期审计修复了 OTA/退出时的存储竞态：工作线程改为非 daemon 并受 socket/组件超时约束，先关闭监听并排空活动请求、再关闭共享数据库。HTTP 响应升级为 1.1；拒绝 Transfer-Encoding、重复 Content-Length 和截断请求体，WebSocket 关闭后不再回到 HTTP 解析器。
- 成员历史记录导出改为最多 100 条/页的严格游标分页，拒绝重复、未知、畸形参数并收紧成员、任务和记录 ID；任务取消及记录删除改为幂等 200 响应，丢失响应后的重试不会误报失败。
- 运维日志写入失败不再吞掉已完成业务的 HTTP 响应；只输出固定 `EVENT_LOG_UNAVAILABLE`，后续健康状态保持降级直至安全写入恢复。产品审计持久性和抗篡改仍保留为具名审批与实机验收项。
- 首次刷新 S1 Run `20260913T080315Z-8d122aad` 因本地 Docker 引擎未运行如实记录 `LOCAL_LINUX_DOCKER_NOT_READY`；恢复引擎后 S1 Run `20260913T080439Z-c6e83d22` 为 `PASS_ARM64_SOFTWARE`：Linux/aarch64 118/118、0 跳过、源码一致且两个容器均已清理。
- 刷新 S3 Run `20260913T080726Z-a268e6f2`：现有 ASR V2 经真实 ARM64 loopback WebSocket 完成推理、取消和确认前零落库，文本哈希与 S2 一致；独立验证 `errors=[]`、容器已清理，OCR、许可、目标麦克风和 RK3566 仍阻断。
- 故障复现确认旧数据库把幂等键错误地设为全局唯一，不同成员使用同一键会冲突。数据库升级为 schema 3，以 `(member_id, idempotency_key)` 复合唯一约束实现成员隔离；schema 2→3 在单事务内迁移并保留原记录，新增跨成员及迁移回归测试。
- 并发断连测试曾暴露客户端提前关闭时服务端打印 `ConnectionResetError`；响应写入现把对端断开视为预期网络事件并关闭连接，不再泄露线程异常，同时不吞掉应用内部错误。
- 刷新 S1 Run `20260913T082916Z-d1ba79d0`：受控构建上下文本机 120/120，真实 Linux/aarch64/64 位非 root 容器 120/120 且 0 跳过，schema 3 迁移、成员级幂等、严格网络输入和关机排空均通过；独立复验 `errors=[]`，两个容器均已清理。
- 刷新 S3 Run `20260913T083159Z-b64c5b1b`：现有 ASR V2 在真实 ARM64 guest 经 loopback WebSocket 完成推理、取消和确认前零落库；独立复验 `errors=[]`、容器已清理。该阶段仍不包含合法 OCR 产品权重、目标麦克风数据或 RK3566 实测。
- 最终总控 Run `20260913T081253Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：23/23 检查行为符合预期，端侧 157 项运行（153 项通过、4 项 Windows 符号链接权限跳过，ARM64 等价用例 118/118 无跳过）、健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；S1/S3 和 143 个输入、25 份输出快照独立复验均为 `errors=[]`。`product_complete=false`、`hardware_measured=false`，未创建正式 release。
- 刷新总控 Run `20260913T083802Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：23/23 检查行为符合预期，端侧 159 项运行（155 项通过、4 项 Windows 符号链接权限跳过，ARM64 等价用例 120/120 无跳过）、健康 21/21 个测试文件、OCR 105 项、ASR 111 项均通过；S1/S3 与 143 个输入、25 份输出快照独立复验均为 `errors=[]`。`product_complete=false`、`hardware_measured=false`，未创建正式 release。

## 2026-09-12：ASR 启动生命周期与更新健康门禁加固

- 确认首次 ASR 会话原先会先启动 worker 加载模型做健康检查，再启动第二个 worker 重新加载模型；改为流启动时由同一隔离 worker 返回完整版本、能力和模型哈希握手，主管验证通过后才接收音频，去掉有竞态且重复加载的预检。
- 失败测试暴露启动握手拒绝后管道句柄未关闭，已补齐终止与关闭；17 项定向测试在 `ResourceWarning` 视为错误时通过，本机端侧全量 110/110 通过。
- 重新执行 S1 Run `20260912T023750Z-5e540127`：Linux/aarch64/64 位容器内 68/68 通过、容器清理完成；重新执行 S3 Run `20260912T024135Z-646d2584`：现有 ASR V2 经真实 loopback WebSocket 推理并与 S2 文本哈希一致，独立证据复验无错误。
- 发现安装/回滚脚本只检查 `/v1/health` 的 HTTP 200，而降级服务也按合同返回 200。新增 `update_agent` 严格产品健康门禁：只允许 loopback，禁用环境代理，限制响应大小；必须 `product_complete=true`、产品加密存储、非诊断健康规则及 OCR/ASR 全部就绪才允许激活，否则恢复旧版本。
- 更新门禁 4 项测试及部署脚本校验通过；当前工程服务会被该门禁正确拒绝，不能借此宣称可上线。真签名包、工厂注入、断电升级/回滚和 RK3566 验收仍是外部阻断。
- 继续审计发现手动回滚原先只验目标包，未核对当前签名版本是否批准该回退。新增回滚转换门禁：当前与目标 bundle 均须复验，目标必须等于当前 `rollback.json` 指定的前序版本，且数据库回滚兼容必须显式为 true；任意跨版本或未知字段均失败关闭。
- 总控 Run `20260912T070304Z` 如实保留为 `FAIL_ENGINEERING`：OCR 隐私测试直接搜索整行日志，把 UTC 时间戳中的 `6.8` 数字组合误判为健康值泄露；失败汇总随后又因 Windows GBK 无法打印测试中的 Unicode 字符而崩溃。
- OCR 隐私断言现改为解析 JSON 并只检查非时间戳白名单元数据；回归汇总报告继续以 UTF-8 保存，但终端副本使用 ASCII 转义。定向 OCR 回归、更新/回滚门禁及控制台编码测试均通过。
- 继续检查发现 `systemctl restart` 返回后服务可能尚未监听，原健康门禁只请求一次，会把健康但启动较慢的新版本误回滚。现改为在 10 秒总期限内短间隔重试，每次仍要求完整产品健康；无合法状态时以 `HEALTH_STARTUP_TIMEOUT` 失败关闭，不降低任何产品条件。
- 发布包验证补齐 manifest/rollback 大小、对象类型、精确字段、版本和条目类型检查；未知字段、非对象 JSON、自指前序版本及不兼容 schema 均在安装前失败关闭。
- 增加 fsync 的待确认激活事务、开机前恢复 service、相同 manifest/签名的中断安装安全续装；锁和标记迁至独立 root-only `/var/lib/family-health-edge-update`，主应用无写权。三次 S1 失败 Run `20260912T073546Z-c1db2890`、`20260912T074425Z-1873e914`、`20260912T074728Z-fe6509c1` 分别保留了 POSIX 夹具权限、白名单漏项和 noexec 测试桩问题。
- 候选输入构建补齐精确 schema、数量上限、发布根内相对路径、重复目标、反斜杠/越界、源文件及父目录符号链接拒绝，并在复制前后复验大小与 SHA-256，避免输入声明与实际复制内容不一致；当前冻结输入仍不完整，因此构建入口按设计退出 2，未创建候选目录。
- 进一步发现发布 ID 旧正则接受 `.`/`..`，且 promotion CLI 直接参与路径拼接；现统一要求首尾为字母或数字，候选/正式发布根及目标符号链接均失败关闭，设备安装/回滚 shell 同步收紧。S1 Run `20260912T082645Z-48d6b7a9` 如实保留为受控上下文遗漏 promotion 脚本导致的 `STAGED_CONTEXT_HOST_TESTS_FAILED`，随后补齐明确白名单而非跳过测试。
- 故障注入复现并修复 SQLite 确认事务的内存/持久化次序：任务写入失败不再残留敏感待确认内容；`COMMIT` 失败时数据库回滚且内存结果保留，用户可用同一任务和幂等键重试；过期状态先提交再清除内存。相关 23 项测试在 `ResourceWarning` 视为错误时通过。
- 数据库恢复入口原先在检查符号链接前调用 `resolve()`，文档所述的拒绝实际可能失效；现按路径组件在规范化前拒绝符号链接/Windows junction，同时拒绝把目录等非普通文件当作数据库或备份。新增用例在 ARM64 Linux 中真实执行。
- 在线备份原先直接打开最终目标，复制失败会留下半成品，也可覆盖现有文件或跟随重定向路径；现要求显式受控根和唯一新路径，在私有临时文件完成 SQLite 完整性检查与落盘，再以不覆盖的硬链接原子发布，任何失败均清理临时文件。
- 最终 S1 Run `20260912T090913Z-a62a9c75` 为 `PASS_ARM64_SOFTWARE`：Linux/aarch64/64 位非 root guest 102/102、0 跳过；数据库备份/恢复重定向用例在该环境真实执行；独立最小 root guest 在断网、只读环境完成中断回退和已落盘目录续装，两个容器均清理。签名验证明确为测试桩，不能替代真签名和真机断电验收。
- 最终总控 Run `20260912T091305Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：23/23 检查符合预期，`unexpected_checks=[]`；端侧 141 项运行（137 项通过、Windows 无符号链接权限导致 4 项跳过；Linux/aarch64 同类用例 102/102 无跳过）、健康 21/21 个测试文件、OCR 105 项和 ASR 111 项均通过。143 个输入及 25 份输出快照已绑定，独立复验为 `errors=[]`；`product_complete=false`、`hardware_measured=false`，未创建正式 release。

## 2026-09-12：ASR V2 隔离 worker 与 ARM64 S3 部分集成

- 基于现有 ASR V2 和已锁定 Sherpa-ONNX 1.13.7 实现 `asr_runtime/worker.py`，没有寻找替代模型、重新训练或修改权重；worker 启动前逐文件校验模型大小、SHA-256 和组合哈希。
- 完成单行 JSON/stdio 流式协议、16 kHz 单声道 s16le 输入、分块/总时长上限、UTF-8、固定错误码、原始 PCM 仅内存和进程隔离；新增中文健康字段候选提取，所有字段必须人工确认，越界仅提示复核，不作诊断。
- 定向测试发现并修复非法日期导致字段提取异常及 Base64 异常类型不明确的问题；新增运行时装配器后端侧完整单测 109/109 通过。
- 最终 S1 Run `20260912T021837Z-509d220d` 在真实 Linux/aarch64/64 位容器内 67/67 测试通过，源码和方案哈希一致且容器已清理。
- S3 部分集成 Run `20260911T100057Z-987e7f03` 在 Linux/aarch64 guest 中通过设备服务调用真实 ASR worker；10.053125 秒公开样例文本 SHA-256 与 S2 同版本基准一致，确认前未落库、取消成功、原始 PCM 未持久化；健康真实非诊断规则同时通过。
- 随后把设备服务启动路径接到严格的运行时装配器：仅接受发布根目录内相对路径、固定 `asr_runtime.worker` 模块、模型逐文件/组合哈希和工程模式标志；产品模式、路径越界和未批准配置均失败关闭。
- 首次网络化 S3 Run `20260912T020737Z-607cae92` 暴露构建白名单漏拷隐私事件日志包，按失败保留；补齐显式白名单及源码哈希后，最终 Run `20260912T021017Z-a0247e9d` 经真实 loopback WebSocket/HTTP 完成 ASR、健康规则、取消及服务清理，独立证据校验通过。
- OCR 没有合规产品模型和许可，因此 S3 明确未调用 OCR worker、未使用测试替身；`hardware_measured=false`、`product_complete=false`、`three_model_inference_verified=false`。独立 S3 证据校验为 `PASS_ENGINEERING`、`errors=[]`。
- 最终总控 Run `20260912T022050Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：23/23 检查符合预期、端侧 109/109 单测及三个上游工程回归通过；25 份输出不可变快照完成并经独立复验，未创建正式 release。

## 2026-09-11：原生模型进程隔离与熔断工程实现

- 发现组件合同已经要求 OCR/ASR 原生运行时进程隔离、超时、并发限制、重启退避和重复失败熔断，但当前代码只有契约与异常降级，没有实际通用进程主管；未把配置声明误当实现证据。
- 新增 `integration_adapter/supervisor.py`：使用 `shell=false` 的单行 JSON/stdio 子进程协议，限制请求/响应大小、操作时间和并发数；支持 closed/open/half-open 熔断恢复，超时或异常会终止 worker，主设备服务保持可用。
- 子进程默认只继承必要系统环境并强制 UTF-8，拒绝带 token/secret/password/private-key 名称的显式环境，stderr 不进入产品响应；OCR/ASR 的超时、忙和熔断错误码可安全传到稳定 API。
- 首轮测试暴露 Windows 子进程中文编码错误及管道未关闭的资源警告，均已修复；定向测试 18/18、端侧完整单测 95/95 通过且在 `ResourceWarning` 视为错误时仍通过。
- 首次 S1 重跑 `20260911T091739Z-72876832` 因 Docker Linux 引擎未运行而停在 `BLOCKED_ENVIRONMENT`，证据保留；启动本机引擎后复跑 `20260911T092009Z-51471786`，真实 Linux/aarch64/64 位容器内 59/59 测试通过、容器已清理。
- 进程主管完成后的总控 Run `20260911T092251Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：22/22 项行为符合预期，端侧 95/95 单测、健康 21/21 个测试文件、OCR 全套、ASR 111 项均通过，`unexpected_checks=[]`。
- 随后发现历史总控只保存可变 `reports/*.json` 的哈希，后续单独复验刷新时间戳后会削弱 Run 的独立可复核性；新增逐 Run 输出快照、缺失/越界/复制/哈希失败关闭、总控脚本自哈希及独立 `verify_loop_run_evidence.py`，4 项证据测试通过。
- 新格式最终总控 Run `20260911T093524Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：22/22 项行为符合预期、端侧 99/99 单测及三个上游工程回归通过；23 份输出已原样保存到该 Run 的 `outputs/`，`snapshot_integrity_verified=true`，独立快照复验为 `PASS_ENGINEERING`、`errors=[]`。
- 当前只证明进程主管基础设施和工程测试 worker；尚未注册合法 OCR/ASR 产品 worker，也未证明三模型真实 ARM64 集成或 RK3566 硬件。正式 release 仍未创建。

## 2026-09-11：总控回归超时修复与最终工程复验

- 总控 Run `20260911T082441Z` 仅因健康 `tests/test_product_acceptance.py` 超过整文件 240 秒上限而失败；OCR 与 ASR 已通过，失败证据原样保留。
- 独立剖析确认该健康文件 26/26 用例通过、无挂死；最慢单项约 29.37 秒。只将该已确认的慢分片上限提高到 360 秒，其余健康分片及 OCR/ASR 继续使用 240 秒，未删除或跳过测试，并新增调度回归测试。
- 中间总控 Run `20260911T084316Z` 恢复工程通过；随后发现 E06 审计仍沿用笼统的“缺 ARM64 runtime”表述，继续加固为同时核对 ASR 资产状态与 S2 ARM64 真实模型证据，拒绝膨胀模拟完成标志。
- 新增 Loop Gate 审计单测并将审计脚本纳入总控输入哈希；E06 目前仅证明 ASR V2 + Sherpa-ONNX 1.13.7 的 ARM64 工程推理，仍缺真 RK3566 runtime 冻结和目标麦克风真人验收。
- 最终总控 Run `20260911T085706Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：22/22 项行为符合预期，`unexpected_checks=[]`；端侧 87/87 单测通过；健康 21/21 个测试文件、OCR 全套、ASR 111 项回归通过。
- 最终审计仍为 `goal_complete=false`、`product_release_allowed=false`、`contradictions=[]`、`engineering_failures=[]`；未创建正式 release。真实 RK3566、合法产品 OCR 模型与数据、具名审批、设备加密/签名/OTA 及真实产品验收仍是外部 Gate。

## 2026-09-10：ARM64 S2 健康/ASR 真实模型验证

- 新建锁版本离线 ARM64 wheelhouse、模型专用 Dockerfile、主机对照探针、ARM64 guest 探针、证据核验器及双击入口；构建/推理阶段断网、只读、非 root，并按 digest 运行。
- 首次发现并修复探针将 `tokens.txt` 错写为 `tokens` 的键名 bug；历史失败 Run 均保留且未改写为通过。
- 实测 sherpa-onnx 1.13.4 在 ARM64 中模型加载成功但返回空文本；1.13.3 不再为空但不适合作为当前跨平台候选；升级到 1.13.7，未更换或重训现有 ASR V2 权重。
- S2 Run `20260910T101755Z-f1f1aeb1` 为 `PARTIAL_PASS_PRODUCT_BLOCKED`：真实 Linux/aarch64/64 位 guest 中 DM/HT ONNX 推理与主机最大绝对误差 `5.960464477539063e-08`；ASR 1.13.7 对 10.053125 秒公开样例完成真实推理，结果 SHA-256 与同版本 Windows 基准一致，QEMU 解码约 55.27 秒。
- OCR 没有具名商业分发批准和登记的产品 ONNX/RKNN，未使用测试替身冒充真实推理；因此 `three_model_inference_verified=false`、`hardware_measured=false`、`product_complete=false`。
- 加固总 loop：模型证据会核对运行库版本、镜像 digest、跨架构输出哈希、关键源码/模型/wheel 哈希、容器与临时运行时清理，以及健康非诊断边界。
- 端侧单元测试增至 85/85 通过；模型证据核验为 `PASS_ENGINEERING`，只表示健康与 ASR 的 ARM64 工程推理通过。

## 2026-09-10：ARM64 S1 通过与回归调度加固

- Windows 重启后核验 WSL2 和本机 Docker Linux 引擎就绪；无远程 Docker 连接。
- 修复 Docker 29 多架构镜像索引兼容：显式选择 `linux/arm64` 子清单；候选容器改用仓库 digest 固定引用；保留含数字的安全错误码。
- ARM64 模拟 Run `20260910T051216Z-660cf5a1` 为 `PASS_ARM64_SOFTWARE`：Linux/aarch64/64 位、Python 3.12.10、容器内 51/51 测试通过、源码哈希一致、容器已清理。
- S1 仅证明端侧服务/规则/确认工作流的软件兼容；OCR/ASR 是测试替身，`three_model_inference_verified=false`、`hardware_measured=false`、`product_complete=false`。
- 健康完整回归原先以整仓 240 秒计时，会在慢验收夹具中误超时。将昂贵软件证据改为每进程构建一次、每用例复制隔离，并将健康测试按文件分片；没有删除或跳过测试。
- 分片回归 Run `20260910T054039Z`：健康 21/21 个测试文件、OCR 全套、ASR 111 项全部通过。
- 最终总控 Run `20260910T054838Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：21/21 检查行为符合预期，端侧 82/82 测试通过；正式发布仍被外部 Gate 阻断。

## 2026-09-07：模拟环境复查及回归修复

- 再次实际执行模拟入口，Run `20260907T035023Z-8f0d26b9` 仍为 S0 `BLOCKED_ENVIRONMENT`：Windows 待重启，本机 Linux Docker 引擎未就绪；未自动重启或重复安装。
- 发现上一轮总控 `20260906T094245Z` 为 `FAIL_ENGINEERING`：部署检查误选 WindowsApps 的 Bash 占位程序，健康工程回归超时；保留失败日志，不覆盖历史结论。
- 修复 Bash 发现逻辑：Windows 优先 Git Bash、排除 WindowsApps 占位、实际探测启动能力；新增 3 项回归测试，实际部署脚本检查通过。
- 独立复跑三工程回归 `20260907T035142Z` 全部退出码 0；健康约 128 秒、OCR 约 4 秒、ASR 约 2 秒，未提高超时阈值。
- 最终总控 `20260907T035413Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`：21/21 检查行为符合预期、端侧 77/77 测试通过、三工程回归均退出码 0。21 项包含产品缺失证据时的预期阻断，不能表述为产品验收通过。
- ARM64 容器、真实三模型 ARM64 推理及 RK3566 验收仍未完成；本轮未重新训练或修改模型权重。

## 2026-09-06：ARM64 模拟方案与可恢复 Loop

- 编写 `ARM64_SIMULATION_LOOP.md`，明确 S0 环境、S1 软件兼容、S2 三模型真实推理、S3 真实适配器集成、S4 RK3566 验收。
- 实现 Dockerfile、受控代码上下文、Linux/ARM64 架构校验、基础镜像 digest/候选 image ID 固定、断网非root只读容器及资源限制；使用唯一容器名，仅清理自己创建的容器。
- 实现证据核验：本机通过不能冒充 ARM64，模拟通过不能冒充三模型推理或真机产品通过；源码漂移会使门禁失败。
- 加入可双击的启动入口、主机预检和管理员 WSL 安装脚本；受控上下文本机执行 51 项测试通过，端侧全套 74 项测试通过。
- 实际安装 WSL 2.7.13、Docker Desktop 4.89.0；Docker CLI返回29.7.2，官方安装包经过winget哈希校验。原普通权限安装被拒绝，管理员安装成功。
- 修复安装包装脚本将原生stderr警告误当失败的问题，当前安装状态依据实时版本探测及安装退出码核验。
- 实际运行模拟 Run `20260906T094158Z-21243469`，停在 `BLOCKED_ENVIRONMENT / LOCAL_LINUX_DOCKER_NOT_READY`；系统待重启，未自动重启。
- ARM64 容器、三模型真实ARM64推理及真机验收均未通过，保留真实阻塞；当前只新增工程验证能力，无重新训练或修改模型权重。

## 2026-09-02：三模型端侧兼容与严重故障防线强化

- 新增 `integration_adapter` 组件握手：严格校验契约主版本、组件版本、能力列表和模型 SHA-256；不兼容组件在推理前拒绝。
- 健康探针异常改为整体服务 `degraded`，只返回固定原因码；OCR/ASR 单模块异常不再影响健康规则和其他模块。
- 修复撤回成员数据后待确认敏感结果仍可能留在内存的问题；ASR 完成或存储失败时会关闭识别器并进入取消态。
- 任务查询/取消改用 `X-Edge-Member-Id`，保留工程兼容回退；令牌重复授权或与工程通配权限冲突时启动即拒绝。
- 对待确认结果和确认记录增加 JSON 类型、有限数字、深度、节点数、字符串和总字节上限，降低内存/存储滥用风险。
- HTTP/WebSocket 未预期异常统一返回脱敏固定错误；新增组件超时、繁忙、熔断、契约不兼容错误码。
- 新增三模型统一回归脚本，使用各自隔离环境和项目本地唯一临时目录，规避 Windows 用户临时目录/`.pytest_cache` 权限故障。
- 端侧单元测试 68/68 通过；健康、OCR、ASR 完整回归均退出码 0。
- 总控 Run `20260902T133745Z` 的 20/20 检查符合预期，状态 `PASS_ENGINEERING_PRODUCT_BLOCKED`；关键接口、配置和源码 SHA-256 已绑定，没有生成正式 release。
- 正式产品仍缺 ARM64 隔离运行时、真实 RK3566、授权真实验收数据、产品加密与设备密钥、签名 OTA 和具名批准。

## 2026-09-01：端侧部署方案纠正为量产产品交付

- 冻结 `PRODUCT_EDGE_DEPLOYMENT_PLAN.md`：交付对象是安装在每台用户设备上的自包含 ARM64 产品，不是开发者网页或统一 Demo。
- 新增 `configs/product_delivery_contract.json` 和自动校验，正式方案禁止依赖开发电脑、绝对本机路径、Windows `.venv`、全局 Python、开发服务器及首次开机在线下载模型。
- 将稳定接口/SDK、设备服务、健康/OCR/ASR 运行时、加密存储、更新代理、许可、SBOM、签名和回滚定义为模型模块发布包的必备组成；UI 可由上层产品工程独立交付。
- 将工厂初始化、唯一设备身份、每设备数据密钥、公司 OTA 仓库、分批发布、暂停/撤回和签名离线升级纳入上线 Gate。
- 增加“干净设备、研发电脑关机、设备断网仍可完成核心流程”的产品验收条件。
- 纠正状态：E08/E11 从宽泛的工程通过改为 `IN_PROGRESS`；现有后端和脚本不能替代跨团队集成、自包含 ARM64 制品和量产基础设施。
- 当前机器计划校验 `PASS_ENGINEERING`，但 `formal_release_allowed=false`、`product_complete=false`。
- 全量端侧单元测试 58/58 通过；总控 Run `20260901T105600Z` 的 18/18 检查符合预期，设备验收与正式 release 仍按设计阻断。
- 根据用户澄清纠正比喻理解：不强制模型工程交付某种 UI；真正门槛是模块不能只在开发者环境成立，必须提供可复制、自包含、版本化并可被正式前后端/终端应用集成的接口或 SDK。

## 2026-08-31：健康 ML 端侧工程候选接入

- 将中国公开 CC0 数据训练的 DM/HT ONNX 登记为 `ENGINEERING_SHADOW_ONLY`，正式 V1 仍以非诊断规则/趋势为准。
- 冻结运行时、manifest、两个 ONNX 和开发机基准报告 SHA-256；总控 Loop 会实时复验，篡改即失败。
- 后端固定为 ONNX Runtime CPU，适配 RK3566/RK3568 ARM64；表格模型不强制转 RKNN，不伪造 NPU 产物。
- 开发机 1000 次基准：ONNX 总计 169,130 字节，P50 0.0779 ms、P95 0.0935 ms、RSS 增量 10.92 MB；真机成绩仍为空。
- 端侧单元测试 58/58 通过；总控 Run `20260831T153121Z` 的 17/17 检查符合预期，正式 release 继续 fail-closed。

## 已完成的工程基线

- 建立隔离项目、Python 环境、产品边界、非诊断健康规则、API 合同和 fail-closed 发布门禁。
- 实现成员级令牌授权、OCR/ASR 待确认结果仅驻内存、确认后持久化、更正/导出/删除/撤回、SQLite 备份与受控恢复。
- 实现 loopback HTTP 服务和 RFC6455 ASR 流；OCR 校验 PNG/JPEG、Base64、尺寸、大小和 SHA-256。
- 实现故障隔离、隐私安全操作日志、工程 SBOM、依赖审计、数据策略及 CHARLS 永久禁用检查。
- 实现不可变候选包、全文件哈希、外部签名验证、原子安装、启动前复验、失败回切和目标回滚。
- 强化 ARM64 构建：固定提交、工具链哈希、干净源码、离线依赖、非 root 构建及 aarch64 ELF 检查。

## 2026-08-25：真机与 E10 证据链强化

- 重写 RK3566 预检：只有 aarch64 + RK3566 + 非虚拟化 + NPU/RKNN + 音频设备等真实条件满足时才产生硬件通过证据；本机 x86 自测必须失败。
- 增加固定 known_hosts/哈希的批处理 SSH 远程预检、报告采集及设备配置导入；手改布尔值无法通过。
- 增加原始 OCR/ASR/性能/长稳/故障证据的哈希清单和自动指标计算，禁止手填指标。
- 增加真实 loopback HTTP OCR 和 WebSocket ASR 独立验收客户端；每个输入校验路径与哈希，输出取回后立即取消未确认任务，不产生正式健康记录。
- 把计算结果绑定到测试前冻结的验收合同 SHA-256 和已导入真机预检 SHA-256；测试后改阈值或换设备会失败。
- 新增独立验收证据格式、去标识化、授权、保管和执行说明。
- 全量单元测试 58/58 通过；总控 Run `20260825T091225Z` 的 16/16 检查符合预期，未创建 release/candidate。

## 下一阶段触发顺序

1. 冻结唯一板卡 SKU、ARM64 Linux 镜像和模型模块集成形态（本地服务、SDK 或进程内库）。
2. 建立受控 ARM64 构建环境、公司签名服务、OTA 制品仓库和工厂初始化流程。
3. 提供真 RK3566 的受控 SSH 入口、固定 host key、镜像/驱动/runtime 信息并导入预检报告。
4. 完成模型商业分发、产品分类、隐私、健康规则、加密和签名方案的具名审批。
5. 在测试前批准并冻结验收阈值；准备权利清晰的真实报告独立集和目标麦克风真人语音独立集。
6. 构建自包含设备服务、集成适配层、ARM64 ASR、健康 ONNX runtime 与产品 OCR RKNN，并交给正式产品应用联调。
7. 在干净真机执行离线、性能、温度、长稳、断电、升级、回滚和隐私验收。
8. 通过 E10 后构建、签名并复验首个正式 release，最后运行 E12 总门禁。
