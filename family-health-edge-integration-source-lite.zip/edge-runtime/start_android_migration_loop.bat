@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv-edge\Scripts\python.exe" (
  echo Missing .venv-edge\Scripts\python.exe
  exit /b 2
)
".venv-edge\Scripts\python.exe" "scripts\run_android_migration_loop.py"
set "LOOP_EXIT=%ERRORLEVEL%"
echo.
echo Android migration loop exit code: %LOOP_EXIT%
exit /b %LOOP_EXIT%
