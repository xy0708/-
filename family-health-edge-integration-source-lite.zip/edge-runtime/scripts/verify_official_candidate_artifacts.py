from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from research_assets import ResearchAssetPathError, resolve_locked_artifact


MANIFEST = ROOT / "model_registry" / "official_candidate_artifacts.json"
BACKEND_REGISTRY = ROOT / "model_registry" / "backend_registry.json"
REPORT = ROOT / "reports" / "official_candidate_artifacts_verification.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_file(relative: str) -> Path:
    try:
        return resolve_locked_artifact(ROOT, relative)
    except ResearchAssetPathError as exc:
        raise ValueError(relative) from exc


def load_json(relative: str, errors: list[str], label: str) -> dict[str, Any]:
    try:
        return json.loads(safe_file(relative).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError):
        errors.append(f"JSON_EVIDENCE_INVALID:{label}")
        return {}


def verify_artifacts(candidate: dict[str, Any], errors: list[str]) -> dict[str, dict[str, Any]]:
    candidate_id = str(candidate.get("candidate_id"))
    artifacts = candidate.get("artifacts")
    if not isinstance(artifacts, list):
        errors.append(f"ARTIFACT_LIST_INVALID:{candidate_id}")
        return {}
    records: dict[str, dict[str, Any]] = {}
    for record in artifacts:
        if not isinstance(record, dict):
            errors.append(f"ARTIFACT_RECORD_INVALID:{candidate_id}")
            continue
        role = record.get("role")
        relative = record.get("path")
        expected_bytes = record.get("bytes")
        expected_hash = record.get("sha256")
        if (
            not isinstance(role, str)
            or role in records
            or not isinstance(relative, str)
            or not isinstance(expected_bytes, int)
            or not isinstance(expected_hash, str)
        ):
            errors.append(f"ARTIFACT_RECORD_INVALID:{candidate_id}")
            continue
        try:
            path = safe_file(relative)
        except (OSError, ValueError):
            errors.append(f"ARTIFACT_PATH_INVALID:{candidate_id}:{role}")
            continue
        if path.stat().st_size != expected_bytes or sha256(path) != expected_hash:
            errors.append(f"ARTIFACT_MISMATCH:{candidate_id}:{role}")
            continue
        records[role] = record
    return records


def compute_bundle_hash(
    order: object, records: dict[str, dict[str, Any]], errors: list[str], candidate_id: str
) -> str | None:
    if not isinstance(order, list) or not order or not all(isinstance(role, str) for role in order):
        errors.append(f"BUNDLE_ORDER_INVALID:{candidate_id}")
        return None
    digest = hashlib.sha256()
    for role in order:
        record = records.get(role)
        if record is None or not role.endswith("_rknn"):
            errors.append(f"BUNDLE_ROLE_INVALID:{candidate_id}:{role}")
            return None
        digest.update(safe_file(record["path"]).read_bytes())
    return digest.hexdigest()


def verify_report_statuses(
    paths: object, expected_status: str, errors: list[str], label: str
) -> list[dict[str, Any]]:
    if not isinstance(paths, list) or not paths:
        errors.append(f"EVIDENCE_LIST_INVALID:{label}")
        return []
    reports = [load_json(path, errors, label) for path in paths if isinstance(path, str)]
    if len(reports) != len(paths):
        errors.append(f"EVIDENCE_PATH_INVALID:{label}")
    for report in reports:
        if report.get("status") != expected_status:
            errors.append(f"EVIDENCE_STATUS_INVALID:{label}")
    return reports


def verify_product_boundaries(candidate: dict[str, Any], errors: list[str]) -> None:
    candidate_id = str(candidate.get("candidate_id"))
    gates = candidate.get("gates")
    if not isinstance(gates, dict):
        errors.append(f"GATES_INVALID:{candidate_id}")
        return
    forbidden_true = (
        "authorized_selection_validation_complete",
        "sealed_product_test_complete",
        "license_approved",
        "real_rk3566_verified",
        "product_worker_registered",
        "product_ready",
    )
    if any(gates.get(field) is not False for field in forbidden_true):
        errors.append(f"PRODUCT_GATE_OVERSTATED:{candidate_id}")


def verify_exported_artifact_capability(
    candidate: dict[str, Any], errors: list[str]
) -> None:
    candidate_id = str(candidate.get("candidate_id"))
    evidence = candidate.get("evidence", {})
    path = evidence.get("exported_artifact_pc_simulator_capability")
    report = (
        load_json(path, errors, f"EXPORTED_RKNN_CAPABILITY:{candidate_id}")
        if isinstance(path, str)
        else {}
    )
    if (
        report.get("status")
        != "PASS_ENGINEERING_CAPABILITY_LIMIT_CONFIRMED_PRODUCT_BLOCKED"
        or report.get("scope")
        != "EXPORTED_RKNN_PC_SIMULATOR_CAPABILITY_ONLY"
        or report.get("network_disabled") is not True
        or report.get("hardware_measured") is not False
        or report.get("product_selection_allowed") is not False
        or report.get("pc_simulator_exported_rknn_inference_supported") is not False
        or report.get("target_device_required_for_artifact_equivalence") is not True
        or report.get("temporary_artifacts_deleted") is not True
        or report.get("errors") != []
        or candidate.get("gates", {}).get(
            "exported_artifact_pc_simulator_capability_audited"
        )
        is not True
    ):
        errors.append(f"EXPORTED_RKNN_CAPABILITY_INVALID:{candidate_id}")


def verify_ocr(candidate: dict[str, Any], errors: list[str]) -> None:
    verify_exported_artifact_capability(candidate, errors)
    evidence = candidate.get("evidence", {})
    conversion = verify_report_statuses(
        evidence.get("conversion"), "PASS_ENGINEERING_CONVERSION_ONLY", errors, "OCR_CONVERSION"
    )
    simulation = verify_report_statuses(
        evidence.get("pc_simulation"),
        "PASS_ENGINEERING_SIMULATOR_EXECUTION",
        errors,
        "OCR_SIMULATION",
    )
    if len(conversion) != 2 or len(simulation) != 2:
        errors.append("OCR_EVIDENCE_COUNT_INVALID")
    for report in simulation:
        if (
            report.get("hardware_measured") is not False
            or report.get("product_accuracy_claim_allowed") is not False
            or report.get("comparison", {}).get("same_shape") is not True
        ):
            errors.append("OCR_SIMULATION_SCOPE_INVALID")
    functional_path = evidence.get("single_official_sample_functional_simulation")
    functional = (
        load_json(functional_path, errors, "OCR_FUNCTIONAL_SIMULATION")
        if isinstance(functional_path, str)
        else {}
    )
    comparison = functional.get("comparison", {})
    if (
        functional.get("status") != "PASS_ENGINEERING_FUNCTIONAL_SIMULATION"
        or functional.get("scope") != "PC_SIMULATOR_SINGLE_OFFICIAL_SAMPLE_ONLY"
        or functional.get("official_postprocess_used") is not True
        or functional.get("exported_rknn_loaded_by_simulator") is not False
        or functional.get("hardware_measured") is not False
        or functional.get("product_accuracy_claim_allowed") is not False
        or functional.get("ocr_metric_claim_allowed") is not False
        or comparison.get("decoded_text_exact_match") is not True
        or not isinstance(comparison.get("onnx_detection_count"), int)
        or comparison.get("onnx_detection_count", 0) <= 0
        or comparison.get("onnx_detection_count")
        != comparison.get("rknn_detection_count")
    ):
        errors.append("OCR_FUNCTIONAL_SIMULATION_SCOPE_INVALID")
    cpu_comparison_path = evidence.get("current_cpu_same_image_comparison")
    cpu_comparison = (
        load_json(cpu_comparison_path, errors, "OCR_CPU_RKNN_SAME_IMAGE_COMPARISON")
        if isinstance(cpu_comparison_path, str)
        else {}
    )
    pairwise = cpu_comparison.get("comparison", {})
    conclusion = cpu_comparison.get("conclusion", {})
    if (
        cpu_comparison.get("status")
        != "PASS_ENGINEERING_SINGLE_SAMPLE_COMPARISON_PRODUCT_BLOCKED"
        or cpu_comparison.get("scope")
        != "SINGLE_OFFICIAL_NON_HEALTH_SAMPLE_ENGINEERING_ONLY"
        or cpu_comparison.get("ground_truth_available") is not False
        or cpu_comparison.get("accuracy_claim_allowed") is not False
        or cpu_comparison.get("product_selection_allowed") is not False
        or cpu_comparison.get("hardware_measured") is not False
        or pairwise.get("cpu_line_count") != 16
        or pairwise.get("rknn_line_count") != 16
        or pairwise.get("positioned_line_exact_match_count") != 14
        or pairwise.get("pairwise_character_edit_distance") != 3
        or conclusion.get("result") != "NO_PRODUCT_WINNER"
        or conclusion.get("winner") is not None
    ):
        errors.append("OCR_CPU_RKNN_SAME_IMAGE_COMPARISON_INVALID")
    synthetic_path = evidence.get("synthetic_health_report_same_set_comparison")
    synthetic = (
        load_json(synthetic_path, errors, "OCR_SYNTHETIC_SAME_SET_COMPARISON")
        if isinstance(synthetic_path, str)
        else {}
    )
    synthetic_verification_path = evidence.get(
        "synthetic_health_report_same_set_verification"
    )
    synthetic_verification = (
        load_json(
            synthetic_verification_path,
            errors,
            "OCR_SYNTHETIC_SAME_SET_VERIFICATION",
        )
        if isinstance(synthetic_verification_path, str)
        else {}
    )
    synthetic_candidates = synthetic.get("candidates", {})
    cpu_synthetic = synthetic_candidates.get("ocr_paddle_cpu_ppocrv5", {})
    rknn_synthetic = synthetic_candidates.get("ocr_rknn_ppocrv4", {})
    if (
        candidate.get("status")
        != "DEFERRED_AFTER_SYNTHETIC_ENGINEERING_REGRESSION_PRODUCT_BLOCKED"
        or synthetic.get("status")
        != "PASS_ENGINEERING_SYNTHETIC_COMPARISON_PRODUCT_BLOCKED"
        or synthetic.get("scope")
        != "SYNTHETIC_HEALTH_REPORT_ENGINEERING_ONLY_NOT_PRODUCT_METRICS"
        or synthetic.get("dataset", {}).get("sample_count") != 6
        or synthetic.get("dataset", {}).get("synthetic") is not True
        or synthetic.get("product_selection_allowed") is not False
        or synthetic.get("hardware_measured") is not False
        or synthetic.get("conclusion", {}).get("winner") is not None
        or cpu_synthetic.get("aggregate", {}).get("field_exact_match_rate") != 1.0
        or cpu_synthetic.get("aggregate", {}).get("failed_samples") != 0
        or rknn_synthetic.get("aggregate", {}).get("field_exact_match_rate")
        != 0.42424242424242425
        or rknn_synthetic.get("aggregate", {}).get("required_field_recall")
        != 0.803030303030303
        or rknn_synthetic.get("aggregate", {}).get("failed_samples") != 0
        or synthetic_verification.get("status")
        != "PASS_ENGINEERING_SYNTHETIC_PRODUCT_BLOCKED"
        or synthetic_verification.get("errors") != []
    ):
        errors.append("OCR_SYNTHETIC_RESEARCH_COMPARISON_INVALID")
    gates = candidate.get("gates", {})
    if (
        gates.get("conversion_complete") is not True
        or gates.get("component_simulator_execution_complete") is not True
        or gates.get("end_to_end_decoded_ocr_complete") is not True
        or gates.get("engineering_worker_implemented") is not True
        or gates.get("current_cpu_same_image_comparison_complete") is not True
        or gates.get("synthetic_health_report_comparison_complete") is not True
        or gates.get("engineering_selection_deferred_after_synthetic_regression")
        is not True
        or gates.get("engineering_assets_archived_outside_product_tree") is not True
    ):
        errors.append("OCR_ENGINEERING_GATES_INVALID")


def verify_asr(candidate: dict[str, Any], errors: list[str]) -> None:
    verify_exported_artifact_capability(candidate, errors)
    evidence = candidate.get("evidence", {})
    conversion = verify_report_statuses(
        evidence.get("conversion"), "PASS_ENGINEERING_CONVERSION_ONLY", errors, "ASR_CONVERSION"
    )
    components = verify_report_statuses(
        evidence.get("component_pc_simulation"),
        "PASS_ENGINEERING_SIMULATOR_EXECUTION",
        errors,
        "ASR_COMPONENT_SIMULATION",
    )
    audio_path = evidence.get("single_official_sample_functional_simulation")
    audio = load_json(audio_path, errors, "ASR_AUDIO_SIMULATION") if isinstance(audio_path, str) else {}
    if len(conversion) != 3 or len(components) != 3:
        errors.append("ASR_EVIDENCE_COUNT_INVALID")
    if (
        candidate.get("status")
        != "DEFERRED_AFTER_RESEARCH_ENGINEERING_REGRESSION_PRODUCT_BLOCKED"
        or audio.get("status") != "PASS_ENGINEERING_FUNCTIONAL_SIMULATION"
        or audio.get("scope") != "PC_SIMULATOR_SINGLE_OFFICIAL_SAMPLE_ONLY"
        or audio.get("comparison", {}).get("transcript_exact_match") is not True
        or audio.get("comparison", {}).get("token_sequence_exact_match") is not True
        or audio.get("hardware_measured") is not False
        or audio.get("product_accuracy_claim_allowed") is not False
        or audio.get("wer_or_cer_claim_allowed") is not False
    ):
        errors.append("ASR_AUDIO_SIMULATION_SCOPE_INVALID")
    cpu_comparison_path = evidence.get("current_cpu_same_audio_comparison")
    cpu_comparison = (
        load_json(cpu_comparison_path, errors, "ASR_CPU_RKNN_SAME_AUDIO_COMPARISON")
        if isinstance(cpu_comparison_path, str)
        else {}
    )
    pairwise = cpu_comparison.get("comparison", {})
    conclusion = cpu_comparison.get("conclusion", {})
    comparison_input = cpu_comparison.get("input", {})
    if (
        cpu_comparison.get("status")
        != "PASS_ENGINEERING_SINGLE_SAMPLE_COMPARISON_PRODUCT_BLOCKED"
        or cpu_comparison.get("scope") != "SINGLE_OFFICIAL_AUDIO_ENGINEERING_ONLY"
        or cpu_comparison.get("reference_transcript_available") is not False
        or cpu_comparison.get("cer_or_wer_claim_allowed") is not False
        or cpu_comparison.get("product_selection_allowed") is not False
        or cpu_comparison.get("hardware_measured") is not False
        or comparison_input.get("same_audio_bytes_for_both_candidates") is not True
        or comparison_input.get("same_segmentation_for_both_candidates") is not False
        or pairwise.get("literal_nfkc_edit_distance") != 4
        or pairwise.get("folded_alphanumeric_edit_distance") != 2
        or conclusion.get("result") != "NO_PRODUCT_WINNER"
        or conclusion.get("winner") is not None
    ):
        errors.append("ASR_CPU_RKNN_SAME_AUDIO_COMPARISON_INVALID")
    public_comparison_path = evidence.get(
        "research_public_set_same_60_audio_comparison"
    )
    public_comparison = (
        load_json(public_comparison_path, errors, "ASR_MED_CH_COMPARISON")
        if isinstance(public_comparison_path, str)
        else {}
    )
    public_verification_path = evidence.get(
        "research_public_set_same_60_audio_verification"
    )
    public_verification = (
        load_json(public_verification_path, errors, "ASR_MED_CH_VERIFICATION")
        if isinstance(public_verification_path, str)
        else {}
    )
    public_reports = public_comparison.get("candidate_reports", {})
    cpu_public = public_reports.get("asr_sherpa_cpu_xasr", {})
    rknn_public = public_reports.get("asr_rknn_zipformer", {})
    if (
        public_comparison.get("status")
        != "PASS_ENGINEERING_PUBLIC_SET_COMPARISON_PRODUCT_BLOCKED"
        or public_comparison.get("scope")
        != "MED_CH_60_RESEARCH_ENGINEERING_ONLY"
        or public_comparison.get("dataset", {}).get("samples") != 60
        or public_comparison.get("dataset", {}).get("commercial_rights_cleared")
        is not False
        or public_comparison.get("same_audio_bytes") is not True
        or public_comparison.get("same_reference_transcripts") is not True
        or public_comparison.get("same_internal_feature_chunking") is not False
        or public_comparison.get("product_selection_allowed") is not False
        or public_comparison.get("hardware_measured") is not False
        or public_comparison.get("winner") is not None
        or cpu_public.get("metrics", {}).get("cer") != 0.07916070577014783
        or cpu_public.get("metrics", {}).get("failures") != 0
        or rknn_public.get("metrics", {}).get("cer") != 0.1626132570338579
        or rknn_public.get("metrics", {}).get("failures") != 0
        or public_verification.get("status")
        != "PASS_ENGINEERING_PUBLIC_SET_PRODUCT_BLOCKED"
        or public_verification.get("errors") != []
    ):
        errors.append("ASR_MED_CH_RESEARCH_COMPARISON_INVALID")
    gates = candidate.get("gates", {})
    if (
        gates.get("conversion_complete") is not True
        or gates.get("component_simulator_execution_complete") is not True
        or gates.get("single_official_sample_transcript_exact_match") is not True
        or gates.get("current_cpu_same_audio_comparison_complete") is not True
        or gates.get("research_public_set_same_60_audio_comparison_complete")
        is not True
        or gates.get("engineering_worker_implemented") is not False
        or gates.get("engineering_worker_deferred_after_research_set_regression")
        is not True
        or gates.get("engineering_assets_archived_outside_product_tree") is not True
    ):
        errors.append("ASR_ENGINEERING_GATES_INVALID")


def registry_hashes(errors: list[str]) -> dict[str, str | None]:
    registry = load_json("model_registry/backend_registry.json", errors, "BACKEND_REGISTRY")
    backends = registry.get("backends")
    if not isinstance(backends, list):
        errors.append("BACKEND_REGISTRY_LIST_INVALID")
        return {}
    return {
        str(backend.get("backend_id")): backend.get("model_bundle_sha256")
        for backend in backends
        if isinstance(backend, dict)
    }


def verify_manifest(manifest_path: Path = MANIFEST) -> dict[str, Any]:
    errors: list[str] = []
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return {"status": "FAIL", "errors": ["CANDIDATE_MANIFEST_INVALID"]}
    if (
        manifest.get("schema_version") != "1.0.0"
        or manifest.get("status") != "ENGINEERING_CANDIDATES_PRODUCT_BLOCKED"
        or manifest.get("target") != "rk3566"
        or manifest.get("toolkit_version") != "2.3.2"
        or manifest.get("product_selected") is not False
        or manifest.get("formal_release_allowed") is not False
        or manifest.get("hardware_measured") is not False
        or manifest.get("bundle_hash_algorithm") != "SHA256_CONCAT_ORDERED_RKNN_BYTES"
    ):
        errors.append("CANDIDATE_MANIFEST_BOUNDARY_INVALID")
    simulator = manifest.get("functional_simulation_environment", {})
    if not isinstance(simulator, dict):
        simulator = {}
    image_id = simulator.get("image_id")
    if (
        not isinstance(image_id, str)
        or len(image_id) != 71
        or not image_id.startswith("sha256:")
        or simulator.get("image_bytes") != 1318815290
        or simulator.get("kaldifeat") != "1.25.4.dev20240223+cpu.torch1.10.1"
        or simulator.get("network_disabled_during_inference") is not True
        or simulator.get("scope") != "HOST_ENGINEERING_SIMULATOR_ONLY"
    ):
        errors.append("FUNCTIONAL_SIMULATOR_ENVIRONMENT_INVALID")
    ocr_simulator = manifest.get("ocr_functional_simulation_environment", {})
    if not isinstance(ocr_simulator, dict):
        ocr_simulator = {}
    ocr_image_id = ocr_simulator.get("image_id")
    if (
        not isinstance(ocr_image_id, str)
        or len(ocr_image_id) != 71
        or not ocr_image_id.startswith("sha256:")
        or ocr_simulator.get("image_bytes") != 1319837957
        or ocr_simulator.get("parent_image_id")
        != "sha256:7f9aada37e75721b62de280c087d4457c2d9356afc47d7518aa5efdbf627f18e"
        or ocr_simulator.get("pyclipper") != "1.3.0.post6"
        or ocr_simulator.get("shapely") != "2.0.7"
        or ocr_simulator.get("network_disabled_during_inference") is not True
        or ocr_simulator.get("scope") != "HOST_ENGINEERING_SIMULATOR_ONLY"
    ):
        errors.append("OCR_FUNCTIONAL_SIMULATOR_ENVIRONMENT_INVALID")

    candidates = manifest.get("candidates")
    if not isinstance(candidates, list):
        candidates = []
        errors.append("CANDIDATE_LIST_INVALID")
    by_id = {
        candidate.get("candidate_id"): candidate
        for candidate in candidates
        if isinstance(candidate, dict)
    }
    if set(by_id) != {"OCR-O2", "ASR-A2", "ASR-A3"}:
        errors.append("CANDIDATE_SET_INVALID")

    registry = registry_hashes(errors)
    verified_artifacts = 0
    for candidate_id in ("OCR-O2", "ASR-A2"):
        candidate = by_id.get(candidate_id, {})
        verify_product_boundaries(candidate, errors)
        records = verify_artifacts(candidate, errors)
        verified_artifacts += len(records)
        bundle_hash = compute_bundle_hash(
            candidate.get("bundle_order"), records, errors, candidate_id
        )
        if bundle_hash != candidate.get("bundle_sha256"):
            errors.append(f"BUNDLE_HASH_MISMATCH:{candidate_id}")
        if registry.get(str(candidate.get("backend_id"))) != bundle_hash:
            errors.append(f"BACKEND_REGISTRY_HASH_MISMATCH:{candidate_id}")

    if "OCR-O2" in by_id:
        verify_ocr(by_id["OCR-O2"], errors)
    if "ASR-A2" in by_id:
        verify_asr(by_id["ASR-A2"], errors)

    fallback = by_id.get("ASR-A3", {})
    verify_product_boundaries(fallback, errors)
    if (
        fallback.get("status") != "NOT_EXECUTED_FALLBACK_ONLY"
        or fallback.get("bundle_sha256") is not None
        or fallback.get("artifacts") != []
        or fallback.get("gates", {}).get("conversion_complete") is not False
    ):
        errors.append("ASR_A3_DEFERRED_BOUNDARY_INVALID")

    return {
        "status": "PASS_ENGINEERING_PARTIAL" if not errors else "FAIL",
        "phase": "C04_C05_IN_PROGRESS",
        "verified_candidates": 2 if not errors else 0,
        "verified_artifacts": verified_artifacts,
        "ocr_end_to_end_decoded": True,
        "asr_single_sample_functional_simulation": True,
        "authorized_selection_validation_complete": False,
        "real_rk3566_verified": False,
        "product_selected": False,
        "formal_release_allowed": False,
        "errors": errors,
    }


def main() -> int:
    result = verify_manifest()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS_ENGINEERING_PARTIAL" else 2


if __name__ == "__main__":
    raise SystemExit(main())
