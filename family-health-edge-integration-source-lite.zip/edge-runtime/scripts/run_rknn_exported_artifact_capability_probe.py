from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.run_rknn_conversion_reproducibility import (
    CASES,
    DEFAULT_IMAGE,
    EXPECTED_IMAGE_ID,
    ROOT,
    sha256,
)
from research_assets import official_research_root, resolve_locked_artifact


PROBE = ROOT / "conversion" / "toolchain" / "probe_exported_rknn_load.py"
REPORT = ROOT / "reports" / "rknn_exported_artifact_capability_probe.json"
LOG_ROOT = ROOT / "reports" / "rknn_exported_artifact_capability_probe_runs"


def expected_models() -> dict[str, Path]:
    return {
        case.name: resolve_locked_artifact(ROOT, case.canonical_output)
        for case in CASES
    }


def inspect_image(docker: str) -> tuple[str | None, str | None]:
    completed = subprocess.run(
        [docker, "image", "inspect", DEFAULT_IMAGE, "--format", "{{.Id}}"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    image_id = completed.stdout.strip() if completed.returncode == 0 else None
    error = None if image_id else (completed.stderr.strip() or "IMAGE_INSPECT_FAILED")
    return image_id, error


def docker_command(docker: str, temporary: Path) -> list[str]:
    research_root = official_research_root(ROOT)
    command = [
        docker,
        "run",
        "--rm",
        "--network",
        "none",
        "--volume",
        f"{ROOT}:/workspace:ro",
        "--volume",
        f"{research_root}:/research:ro",
        "--volume",
        f"{temporary}:/evidence",
        "--workdir",
        "/tmp",
        DEFAULT_IMAGE,
        "python",
        "/workspace/conversion/toolchain/probe_exported_rknn_load.py",
    ]
    for case in CASES:
        command.extend(("--model", f"/research/{case.canonical_output}"))
    command.extend(("--report", "/evidence/inner.json"))
    return command


def validate_inner_report(value: dict[str, object]) -> list[str]:
    errors: list[str] = []
    if value.get("schema_version") != "1.0.0":
        errors.append("INNER_SCHEMA_INVALID")
    if value.get("status") != "PC_SIMULATOR_EXPORTED_RKNN_INFERENCE_UNSUPPORTED":
        errors.append("UNEXPECTED_SIMULATOR_CAPABILITY")
    runtime = value.get("runtime")
    if not isinstance(runtime, dict) or runtime != {
        "name": "rknn-toolkit2",
        "version": "2.3.2",
    }:
        errors.append("INNER_RUNTIME_INVALID")

    records = value.get("records")
    if not isinstance(records, list) or len(records) != len(CASES):
        return [*errors, "INNER_RECORDS_INVALID"]
    by_file = {
        str(record.get("model")): record
        for record in records
        if isinstance(record, dict)
    }
    for name, model in expected_models().items():
        record = by_file.get(model.name)
        if record is None:
            errors.append(f"MODEL_RECORD_MISSING:{name}")
            continue
        if (
            record.get("bytes") != model.stat().st_size
            or record.get("sha256") != sha256(model)
        ):
            errors.append(f"MODEL_IDENTITY_MISMATCH:{name}")
        if record.get("load_code") != 0:
            errors.append(f"EXPORTED_RKNN_LOAD_FAILED:{name}")
        if record.get("init_code") == 0:
            errors.append(f"EXPORTED_RKNN_UNEXPECTEDLY_SIMULATED:{name}")
        if record.get("pc_simulator_exported_rknn_load_supported") is not False:
            errors.append(f"CAPABILITY_FLAG_INVALID:{name}")
    return errors


def public_command(command: list[str], temporary: Path) -> list[str]:
    research_root = official_research_root(ROOT)
    rendered: list[str] = []
    for argument in command:
        value = argument.replace(str(temporary), "{TEMP}")
        value = value.replace(str(research_root), "{RESEARCH}")
        value = value.replace(str(ROOT), "{PROJECT}")
        rendered.append(value)
    return rendered


def write_report(value: dict[str, object]) -> None:
    REPORT.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def main() -> int:
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    log_path = LOG_ROOT / f"{run_id}.log"
    docker = shutil.which("docker")
    if not docker and Path("C:/Program Files/Docker/Docker/resources/bin/docker.exe").is_file():
        docker = "C:/Program Files/Docker/Docker/resources/bin/docker.exe"
    image_id, image_error = inspect_image(docker) if docker else (None, "DOCKER_CLI_MISSING")
    result: dict[str, object] = {
        "schema_version": "1.0.0",
        "run_id": run_id,
        "status": "BLOCKED_ENVIRONMENT",
        "scope": "EXPORTED_RKNN_PC_SIMULATOR_CAPABILITY_ONLY",
        "image": DEFAULT_IMAGE,
        "expected_image_id": EXPECTED_IMAGE_ID,
        "actual_image_id": image_id,
        "image_id_matches": image_id == EXPECTED_IMAGE_ID,
        "network_disabled": True,
        "hardware_measured": False,
        "product_selection_allowed": False,
        "pc_simulator_exported_rknn_inference_supported": None,
        "target_device_required_for_artifact_equivalence": True,
        "errors": [],
    }
    if image_id != EXPECTED_IMAGE_ID:
        result["errors"] = [image_error or "CONVERSION_IMAGE_ID_MISMATCH"]
        write_report(result)
        print(json.dumps(result, ensure_ascii=True, indent=2))
        return 3

    work_root = ROOT / ".artifact-work"
    work_root.mkdir(parents=True, exist_ok=True)
    temporary_path: Path | None = None
    try:
        with tempfile.TemporaryDirectory(prefix="rknn-capability-", dir=work_root) as folder:
            temporary_path = Path(folder).resolve()
            if not temporary_path.is_relative_to(work_root.resolve()):
                raise RuntimeError("UNSAFE_TEMPORARY_DIRECTORY")
            command = docker_command(docker, temporary_path)
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=300,
                check=False,
            )
            log_path.write_text(completed.stdout + completed.stderr, encoding="utf-8")
            inner_path = temporary_path / "inner.json"
            inner = (
                json.loads(inner_path.read_text(encoding="utf-8"))
                if inner_path.is_file()
                else {}
            )
            errors = validate_inner_report(inner)
            if completed.returncode != 2:
                errors.append(f"UNEXPECTED_PROBE_EXIT_CODE:{completed.returncode}")
            result.update(
                {
                    "status": (
                        "PASS_ENGINEERING_CAPABILITY_LIMIT_CONFIRMED_PRODUCT_BLOCKED"
                        if not errors
                        else "FAIL_ENGINEERING_CAPABILITY_PROBE"
                    ),
                    "pc_simulator_exported_rknn_inference_supported": False,
                    "command": public_command(command, temporary_path),
                    "probe_exit_code": completed.returncode,
                    "records": inner.get("records", []),
                    "errors": errors,
                    "log": log_path.relative_to(ROOT).as_posix(),
                    "log_sha256": sha256(log_path),
                    "source_sha256": {
                        PROBE.relative_to(ROOT).as_posix(): sha256(PROBE),
                        **{
                            case.canonical_output: sha256(expected_models()[case.name])
                            for case in CASES
                        },
                    },
                }
            )
    finally:
        result["temporary_artifacts_deleted"] = (
            temporary_path is None or not temporary_path.exists()
        )

    if result["temporary_artifacts_deleted"] is not True:
        errors = result.get("errors")
        assert isinstance(errors, list)
        errors.append("TEMPORARY_ARTIFACTS_NOT_DELETED")
        result["status"] = "FAIL_ENGINEERING_CAPABILITY_PROBE"
    write_report(result)
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if result["status"].startswith("PASS_ENGINEERING") else 2


if __name__ == "__main__":
    raise SystemExit(main())
