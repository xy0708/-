[CmdletBinding()]
param(
    [string]$AdbPath = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$ApkPath = Join-Path $ProjectRoot "android_app\build\app\outputs\flutter-apk\app-debug.apk"
$ValidationPath = Join-Path $ProjectRoot "reports\android_flutter_validation.json"
$ReportPath = Join-Path $ProjectRoot "reports\android_device_install.json"
$PackageName = "com.familyhealth.edge.terminal"
$ComponentName = "$PackageName/.MainActivity"

function Write-InstallReport {
    param(
        [Parameter(Mandatory = $true)]
        [System.Collections.IDictionary]$Payload,
        [int]$ExitCode = 2
    )
    $reportDirectory = Split-Path -Parent $ReportPath
    New-Item -ItemType Directory -Path $reportDirectory -Force | Out-Null
    $Payload["schema_version"] = "1.0.0"
    $Payload["checked_at"] = [DateTime]::UtcNow.ToString("o")
    $Payload["product_release"] = $false
    $Payload["debug_signed"] = $true
    $Payload | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $ReportPath -Encoding UTF8
    $Payload | ConvertTo-Json -Depth 12
    exit $ExitCode
}

function Resolve-Adb {
    if ($AdbPath) {
        if (Test-Path -LiteralPath $AdbPath -PathType Leaf) {
            return (Resolve-Path -LiteralPath $AdbPath).Path
        }
        return $null
    }
    $command = Get-Command adb -ErrorAction SilentlyContinue
    if ($null -ne $command) {
        return $command.Source
    }
    $candidates = @()
    if ($env:ANDROID_HOME) {
        $candidates += Join-Path $env:ANDROID_HOME "platform-tools\adb.exe"
    }
    if ($env:ANDROID_SDK_ROOT) {
        $candidates += Join-Path $env:ANDROID_SDK_ROOT "platform-tools\adb.exe"
    }
    if ($env:LOCALAPPDATA) {
        $candidates += Join-Path $env:LOCALAPPDATA "Android\Sdk\platform-tools\adb.exe"
    }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    return $null
}

function Invoke-AdbText {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )
    $output = & $Executable @Arguments 2>&1 | Out-String
    return [ordered]@{
        exit_code = $LASTEXITCODE
        output = $output.Trim()
    }
}

if (-not (Test-Path -LiteralPath $ApkPath -PathType Leaf)) {
    Write-InstallReport ([ordered]@{
        status = "BLOCKED_ENVIRONMENT"
        reason = "debug_apk_missing"
        hardware_measured = $false
    })
}
if (-not (Test-Path -LiteralPath $ValidationPath -PathType Leaf)) {
    Write-InstallReport ([ordered]@{
        status = "BLOCKED_ENVIRONMENT"
        reason = "flutter_validation_report_missing"
        hardware_measured = $false
    })
}

$validation = Get-Content -LiteralPath $ValidationPath -Raw -Encoding UTF8 | ConvertFrom-Json
$apkHash = (Get-FileHash -LiteralPath $ApkPath -Algorithm SHA256).Hash.ToLowerInvariant()
$expectedHash = [string]$validation.apk.sha256
$abis = @($validation.apk_inspection.abis)
$apkEvidence = [ordered]@{
    path = "android_app/build/app/outputs/flutter-apk/app-debug.apk"
    bytes = (Get-Item -LiteralPath $ApkPath).Length
    sha256 = $apkHash
}
if (
    $validation.status -ne "PASS_ENGINEERING_DEBUG_APK" -or
    $expectedHash.ToLowerInvariant() -ne $apkHash -or
    $abis.Count -ne 1 -or
    $abis[0] -ne "arm64-v8a" -or
    $validation.apk_inspection.asr_assets_valid -ne $true
) {
    Write-InstallReport ([ordered]@{
        status = "BLOCKED_ENVIRONMENT"
        reason = "validated_arm64_debug_apk_unavailable"
        hardware_measured = $false
        apk = $apkEvidence
    })
}

$adb = Resolve-Adb
if (-not $adb) {
    Write-InstallReport ([ordered]@{
        status = "BLOCKED_ENVIRONMENT"
        reason = "adb_not_found"
        hardware_measured = $false
        apk = $apkEvidence
    })
}

$deviceListing = Invoke-AdbText -Executable $adb -Arguments @("devices", "-l")
$authorized = @()
if ($deviceListing.exit_code -eq 0) {
    foreach ($line in ($deviceListing.output -split "`r?`n")) {
        $trimmed = $line.Trim()
        if (-not $trimmed -or $trimmed.StartsWith("List of devices") -or $trimmed.StartsWith("*")) {
            continue
        }
        $parts = $trimmed -split "\s+"
        if ($parts.Count -ge 2 -and $parts[1] -eq "device") {
            $authorized += $parts[0]
        }
    }
}
if ($authorized.Count -ne 1) {
    $reason = if ($authorized.Count -eq 0) { "no_authorized_android_device" } else { "multiple_authorized_devices" }
    Write-InstallReport ([ordered]@{
        status = "BLOCKED_EXTERNAL"
        reason = $reason
        hardware_measured = $false
        apk = $apkEvidence
        adb_devices = $deviceListing.output
    })
}

$serial = $authorized[0]
$properties = [ordered]@{}
$propertyNames = @(
    "ro.product.board",
    "ro.board.platform",
    "ro.hardware",
    "ro.product.cpu.abi",
    "ro.build.version.release",
    "ro.build.version.sdk",
    "ro.build.version.security_patch",
    "ro.build.fingerprint",
    "ro.build.type",
    "ro.debuggable",
    "ro.secure"
)
foreach ($name in $propertyNames) {
    $result = Invoke-AdbText -Executable $adb -Arguments @("-s", $serial, "shell", "getprop", $name)
    if ($result.exit_code -ne 0) {
        Write-InstallReport ([ordered]@{
            status = "FAIL_TARGET_DEVICE"
            reason = "getprop_failed:$name"
            hardware_measured = $false
            apk = $apkEvidence
            serial = $serial
        }) 3
    }
    $properties[$name] = $result.output
}
$selinux = Invoke-AdbText -Executable $adb -Arguments @("-s", $serial, "shell", "getenforce")
$properties["selinux"] = $selinux.output
$socText = "$($properties['ro.product.board']) $($properties['ro.board.platform']) $($properties['ro.hardware'])".ToLowerInvariant()
$apiLevel = 0
[void][int]::TryParse([string]$properties["ro.build.version.sdk"], [ref]$apiLevel)
$targetErrors = @()
if (-not $socText.Contains("rk3576")) { $targetErrors += "soc_is_not_verified_as_rk3576" }
if ($properties["ro.product.cpu.abi"] -ne "arm64-v8a") { $targetErrors += "primary_abi_is_not_arm64_v8a" }
if ($properties["ro.build.version.release"] -ne "14") { $targetErrors += "android_release_is_not_14" }
if ($apiLevel -ne 34) { $targetErrors += "android_api_is_not_34" }
if (-not $properties["ro.build.fingerprint"]) { $targetErrors += "build_fingerprint_missing" }
if ($targetErrors.Count -gt 0) {
    Write-InstallReport ([ordered]@{
        status = "FAIL_TARGET_DEVICE"
        reason = "target_device_contract_failed"
        hardware_measured = $false
        errors = $targetErrors
        apk = $apkEvidence
        serial = $serial
        properties = $properties
    }) 3
}

$productBlockers = @()
if (-not $properties["ro.build.version.security_patch"]) { $productBlockers += "security_patch_missing" }
if ($properties["ro.build.type"] -ne "user") { $productBlockers += "build_type_not_user" }
if ($properties["ro.debuggable"] -ne "0") { $productBlockers += "ro_debuggable_not_zero" }
if ($properties["ro.secure"] -ne "1") { $productBlockers += "ro_secure_not_one" }
if ($properties["selinux"] -ne "Enforcing") { $productBlockers += "selinux_not_enforcing" }

$install = Invoke-AdbText -Executable $adb -Arguments @("-s", $serial, "install", "-r", "-t", $ApkPath)
if ($install.exit_code -ne 0 -or -not $install.output.ToLowerInvariant().Contains("success")) {
    Write-InstallReport ([ordered]@{
        status = "FAIL_INSTALL"
        reason = "adb_install_failed"
        hardware_measured = $true
        apk = $apkEvidence
        serial = $serial
        properties = $properties
        product_blockers = $productBlockers
        install_output = $install.output
    }) 3
}

$packagePath = Invoke-AdbText -Executable $adb -Arguments @("-s", $serial, "shell", "pm", "path", $PackageName)
if ($packagePath.exit_code -ne 0 -or -not $packagePath.output.StartsWith("package:")) {
    Write-InstallReport ([ordered]@{
        status = "FAIL_INSTALL_VERIFICATION"
        reason = "installed_package_not_found"
        hardware_measured = $true
        apk = $apkEvidence
        serial = $serial
        properties = $properties
        product_blockers = $productBlockers
        package_output = $packagePath.output
    }) 3
}

$launch = Invoke-AdbText -Executable $adb -Arguments @("-s", $serial, "shell", "am", "start", "-W", "-n", $ComponentName)
if ($launch.exit_code -ne 0 -or $launch.output -match "(?i)(error:|exception)") {
    Write-InstallReport ([ordered]@{
        status = "FAIL_LAUNCH"
        reason = "main_activity_launch_failed"
        hardware_measured = $true
        apk = $apkEvidence
        serial = $serial
        properties = $properties
        product_blockers = $productBlockers
        launch_output = $launch.output
    }) 3
}

Write-InstallReport ([ordered]@{
    status = "PASS_ENGINEERING_INSTALLED_PRODUCT_BLOCKED"
    reason = $null
    hardware_measured = $true
    apk = $apkEvidence
    serial = $serial
    properties = $properties
    package = $PackageName
    component = $ComponentName
    installed_package_path = $packagePath.output
    launch_output = $launch.output
    product_blockers = $productBlockers
    remaining_product_blockers = @(
        "debug_apk_is_not_formal_release",
        "release_signing_not_configured",
        "ocr_android_runtime_missing",
        "rk3576_performance_and_stability_acceptance_not_run"
    )
}) 0
