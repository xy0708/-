from __future__ import annotations

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.ocr_single_sample import validate_report


OCR_ROOT = ROOT.parent / "OCR"
REPORT = ROOT / "reports/ocr_cpu_rknn_single_sample_comparison.json"
VERIFICATION = ROOT / "reports/ocr_cpu_rknn_single_sample_comparison_verification.json"
IMAGE = (
    ROOT
    / "vendor/rockchip/rknn_model_zoo/examples/PPOCR/PPOCR-System/model/test.jpg"
)
CPU_MANIFEST = OCR_ROOT / "models/official_pretrained/manifest.json"
RKNN_REPORT = ROOT / "reports/rknn_simulation_ppocrv4_system.json"


def verify() -> dict[str, object]:
    try:
        report = json.loads(REPORT.read_text(encoding="utf-8"))
        errors = validate_report(
            report,
            image_path=IMAGE,
            cpu_manifest_path=CPU_MANIFEST,
            rknn_report_path=RKNN_REPORT,
        )
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        errors = [f"COMPARISON_EVIDENCE_UNREADABLE:{type(exc).__name__}"]
    return {
        "status": "PASS_ENGINEERING_SINGLE_SAMPLE_PRODUCT_BLOCKED"
        if not errors
        else "FAIL",
        "phase": "R03_ENGINEERING_COMPARISON_PARTIAL",
        "single_sample_only": True,
        "accuracy_claim_allowed": False,
        "product_selection_allowed": False,
        "hardware_measured": False,
        "errors": errors,
    }


def main() -> int:
    result = verify()
    VERIFICATION.parent.mkdir(parents=True, exist_ok=True)
    VERIFICATION.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not result["errors"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
