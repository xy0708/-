from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from acceptance.paths import has_redirected_component
from acceptance.contract import acceptance_contract_scenario_errors


REPORT = ROOT / "reports" / "computed_acceptance_metrics.json"
MAX_JSONL_BYTES = 64 * 1024 * 1024
MAX_JSON_BYTES = 4 * 1024 * 1024
MAX_JSONL_ROWS = 1_500_000
MAX_JSONL_LINE_BYTES = 1024 * 1024


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if path.stat().st_size > MAX_JSONL_BYTES:
        raise ValueError("JSONL evidence exceeds the size limit")
    rows = []
    with path.open("r", encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            if number > MAX_JSONL_ROWS:
                raise ValueError("JSONL evidence exceeds the row limit")
            if len(line.encode("utf-8")) > MAX_JSONL_LINE_BYTES:
                raise ValueError(f"JSONL row {number} exceeds the size limit")
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"JSONL row {number} is not an object")
            rows.append(value)
    return rows


def read_json_document(path: Path) -> dict[str, Any]:
    if path.stat().st_size > MAX_JSON_BYTES:
        raise ValueError("JSON evidence exceeds the size limit")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("JSON evidence must be an object")
    return value


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    failures: list[str] = []
    source_hashes: dict[str, str] = {}
    metrics = None
    try:
        manifest = json.loads(args.evidence.read_text(encoding="utf-8"))
        contract_path = ROOT / "configs" / "acceptance_contract.json"
        device_path = ROOT / "configs" / "device_profile.json"
        contract = json.loads(contract_path.read_text(encoding="utf-8"))
        device = json.loads(device_path.read_text(encoding="utf-8"))
        from acceptance.approvals import (
            acceptance_manifest_approval_errors,
            load_gate_registry,
        )

        approval_errors = acceptance_manifest_approval_errors(
            ROOT, manifest, load_gate_registry(ROOT), {"ocr", "asr"}
        )
        if approval_errors:
            raise ValueError("acceptance approvals invalid: " + ",".join(approval_errors))
        contract_hash = sha256(contract_path)
        preflight_hash = device.get("preflight_report_sha256")
        if (
            contract.get("frozen_before_testing") is not True
            or contract.get("approval_status") != "APPROVED"
            or any(value is None for value in contract.get("thresholds", {}).values())
        ):
            raise ValueError("acceptance contract must be complete, frozen, and approved before testing")
        scenario_errors = acceptance_contract_scenario_errors(contract)
        if scenario_errors:
            raise ValueError("acceptance contract scenarios invalid: " + ",".join(scenario_errors))
        if manifest.get("acceptance_contract_sha256") != contract_hash:
            raise ValueError("evidence manifest is not pinned to the current acceptance contract")
        if (
            not isinstance(preflight_hash, str)
            or not re.fullmatch(r"[0-9a-f]{64}", preflight_hash)
            or manifest.get("device_preflight_sha256") != preflight_hash
        ):
            raise ValueError("evidence manifest is not pinned to the imported real-device preflight")
        files = manifest.get("files")
        if not isinstance(files, list):
            raise ValueError("evidence manifest files must be a list")
        expected_kinds = {"ocr_jsonl", "asr_jsonl", "performance_jsonl", "soak_json", "scenarios_json"}
        by_kind = {}
        for item in files:
            if not isinstance(item, dict) or item.get("kind") in by_kind:
                raise ValueError("invalid or duplicate evidence item")
            kind = item.get("kind")
            if kind not in expected_kinds:
                raise ValueError("unexpected evidence kind")
            if (
                item.get("rights_cleared") is not True
                or item.get("synthetic") is not False
                or item.get("independent_split") is not True
                or item.get("direct_identifiers_removed") is not True
            ):
                raise ValueError(f"evidence policy failed: {kind}")
            relative = item.get("path")
            expected_hash = item.get("sha256")
            if not isinstance(relative, str) or not isinstance(expected_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
                raise ValueError(f"evidence path/hash invalid: {kind}")
            lowered = relative.lower()
            if any(value in lowered for value in ("charls", "nhanes", "synthetic")):
                raise ValueError(f"forbidden formal evidence path: {kind}")
            unresolved = ROOT / relative
            path = unresolved.resolve()
            evidence_root = (ROOT / "evidence" / "acceptance").resolve()
            if (
                has_redirected_component(unresolved, ROOT)
                or evidence_root not in path.parents
                or not path.is_file()
            ):
                raise ValueError(f"evidence file missing/outside controlled directory: {kind}")
            actual_hash = sha256(path)
            if actual_hash != expected_hash:
                raise ValueError(f"evidence hash mismatch: {kind}")
            source_hashes[kind] = actual_hash
            by_kind[kind] = path
        if set(by_kind) != expected_kinds:
            raise ValueError("required evidence kinds are incomplete")
        from acceptance import compute_metrics

        metrics = compute_metrics(
            read_jsonl(by_kind["ocr_jsonl"]),
            read_jsonl(by_kind["asr_jsonl"]),
            read_jsonl(by_kind["performance_jsonl"]),
            read_json_document(by_kind["soak_json"]),
            read_json_document(by_kind["scenarios_json"]),
        )
        required_scenarios = contract.get("required_scenarios")
        scenarios = metrics.get("scenarios")
        if (
            not isinstance(required_scenarios, list)
            or not required_scenarios
            or any(
                not isinstance(name, str)
                or not isinstance(scenarios, dict)
                or scenarios.get(name) != "PASS"
                for name in required_scenarios
            )
        ):
            raise ValueError("required acceptance scenarios are incomplete or not PASS")
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        failures.append(str(exc))
    result = {
        "schema_version": "1.0.0",
        "computed_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_COMPUTED_REAL_EVIDENCE" if not failures else "FAIL_OR_BLOCKED",
        "synthetic_evidence_used": False,
        "device_alias": locals().get("manifest", {}).get("device_alias") if isinstance(locals().get("manifest"), dict) else None,
        "acceptance_contract_sha256": locals().get("contract_hash"),
        "device_preflight_sha256": locals().get("preflight_hash"),
        "evidence_manifest_sha256": sha256(args.evidence) if args.evidence.is_file() else None,
        "source_sha256": source_hashes,
        "metrics": metrics,
        "failures": failures,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
