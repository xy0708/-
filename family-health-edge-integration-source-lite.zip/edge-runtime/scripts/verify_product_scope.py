from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "product_scope_verification.json"


def main() -> int:
    scope = (ROOT / "configs" / "product_scope.yaml").read_text(encoding="utf-8")
    api = json.loads((ROOT / "configs" / "api_contract.json").read_text(encoding="utf-8"))
    errors = json.loads((ROOT / "configs" / "error_codes.json").read_text(encoding="utf-8"))
    openapi = (ROOT / "configs" / "openapi.yaml").read_text(encoding="utf-8")

    failures: list[str] = []
    scope_requirements = (
        'medical_positioning: "NON_DIAGNOSTIC_HEALTH_MANAGEMENT"',
        "ml_disease_probability_enabled: false",
        "write_before_confirmation: false",
        "cloud_sync:\n  enabled: false",
    )
    for requirement in scope_requirements:
        if requirement not in scope:
            failures.append(f"scope_invariant_missing:{requirement}")

    endpoint_keys = {(item["method"], item["path"]) for item in api["endpoints"]}
    required_endpoints = {
        ("GET", "/v1/health"),
        ("GET", "/v1/version"),
        ("POST", "/v1/health/evaluate"),
        ("POST", "/v1/ocr/tasks"),
        ("WEBSOCKET", "/v1/asr/stream"),
        ("POST", "/v1/records/confirm"),
    }
    for missing in sorted(required_endpoints - endpoint_keys):
        failures.append(f"required_endpoint_missing:{missing[0]}:{missing[1]}")

    invariants = api.get("invariants", {})
    for key in ("ocr_confirmation_required", "asr_confirmation_required"):
        if invariants.get(key) is not True:
            failures.append(f"confirmation_invariant_not_true:{key}")
    if invariants.get("write_before_confirmation") is not False:
        failures.append("write_before_confirmation_must_be_false")
    if invariants.get("health_disease_probability_allowed") is not False:
        failures.append("health_disease_probability_must_be_false")

    required_error_codes = {
        "AUTH_REQUIRED",
        "INPUT_INVALID",
        "TASK_NOT_FOUND",
        "COMPONENT_NOT_READY",
        "MODEL_HASH_MISMATCH",
        "STORAGE_UNAVAILABLE",
        "PRIVACY_POLICY_BLOCKED",
    }
    missing_errors = sorted(required_error_codes - set(errors["errors"]))
    failures.extend(f"error_code_missing:{code}" for code in missing_errors)
    for path in ("/v1/health:", "/v1/health/evaluate:", "/v1/ocr/tasks:"):
        if path not in openapi:
            failures.append(f"openapi_path_missing:{path}")

    passed = not failures
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if passed else "FAIL",
        "named_approval_complete": False,
        "product_gate": "BLOCKED_EXTERNAL_NAMED_APPROVAL_REQUIRED",
        "failures": failures,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
