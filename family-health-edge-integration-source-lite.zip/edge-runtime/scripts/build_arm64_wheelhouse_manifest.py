from __future__ import annotations

import hashlib
import json
import re
import sys
import zipfile
from datetime import datetime, timezone
from email import policy
from email.parser import BytesParser
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "arm64_model_simulation.json"


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def normalized(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def wheel_record(path: Path) -> dict[str, object]:
    with zipfile.ZipFile(path) as archive:
        metadata_names = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
        if len(metadata_names) != 1:
            raise ValueError("WHEEL_METADATA_COUNT_INVALID")
        message = BytesParser(policy=policy.default).parsebytes(archive.read(metadata_names[0]))
    name = message.get("Name")
    version = message.get("Version")
    if not name or not version:
        raise ValueError("WHEEL_NAME_OR_VERSION_MISSING")
    return {
        "file": path.name,
        "name": normalized(str(name)),
        "version": str(version),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
        "license_expression": message.get("License-Expression"),
        "license_field": message.get("License"),
    }


def build_manifest(config: dict, wheelhouse: Path) -> dict:
    expected = {normalized(name): str(version) for name, version in config["requirements"].items()}
    records = []
    errors = []
    for path in sorted(wheelhouse.glob("*.whl")):
        if "aarch64" not in path.name and "none-any" not in path.name:
            errors.append("NON_ARM64_WHEEL:" + path.name)
            continue
        try:
            records.append(wheel_record(path))
        except (OSError, ValueError, zipfile.BadZipFile) as exc:
            errors.append(str(exc))
    actual = {record["name"]: record["version"] for record in records}
    if actual != expected:
        errors.append("WHEEL_SET_OR_VERSION_MISMATCH")
    return {
        "schema_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not errors else "FAIL",
        "scope": config["scope"],
        "platform": config["platform"],
        "python_version": config["python_version"],
        "source_index": "https://pypi.org/simple",
        "legal_approval": False,
        "product_complete": False,
        "files": records,
        "errors": errors,
    }


def main() -> int:
    config = json.loads(CONFIG.read_text(encoding="utf-8"))
    wheelhouse = (ROOT / config["wheelhouse"]).resolve()
    if not wheelhouse.is_dir() or not wheelhouse.is_relative_to(ROOT.resolve()):
        raise SystemExit("ARM64 wheelhouse missing or outside project")
    manifest = build_manifest(config, wheelhouse)
    output = wheelhouse / "manifest.json"
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": manifest["status"], "files": len(manifest["files"]),
                      "errors": manifest["errors"]}, ensure_ascii=True))
    return 0 if manifest["status"] == "PASS_ENGINEERING" else 2


if __name__ == "__main__":
    raise SystemExit(main())
