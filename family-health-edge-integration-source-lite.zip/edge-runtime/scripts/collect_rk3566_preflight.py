from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "preflight_rk3566.sh"
REPORT = ROOT / "reports" / "rk3566_remote_preflight.json"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def validate_connection(config: dict[str, Any]) -> tuple[list[str], Path, Path]:
    failures: list[str] = []
    host = config.get("host")
    user = config.get("user")
    port = config.get("port")
    if not isinstance(host, str) or not re.fullmatch(r"[A-Za-z0-9._:-]{1,255}", host):
        failures.append("SSH_HOST_INVALID")
    if not isinstance(user, str) or not re.fullmatch(r"[A-Za-z0-9._-]{1,64}", user):
        failures.append("SSH_USER_INVALID")
    if not isinstance(port, int) or not 1 <= port <= 65535:
        failures.append("SSH_PORT_INVALID")
    identity = Path(str(config.get("identity_file", ""))).expanduser()
    known_hosts = Path(str(config.get("known_hosts_file", ""))).expanduser()
    if not identity.is_file():
        failures.append("SSH_IDENTITY_FILE_MISSING")
    if not known_hosts.is_file():
        failures.append("SSH_KNOWN_HOSTS_FILE_MISSING")
    expected = config.get("known_hosts_sha256")
    if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        failures.append("KNOWN_HOSTS_SHA256_INVALID")
    elif known_hosts.is_file() and sha256_file(known_hosts) != expected:
        failures.append("KNOWN_HOSTS_SHA256_MISMATCH")
    return failures, identity, known_hosts


def validate_device_report(report: Any) -> list[str]:
    failures: list[str] = []
    if not isinstance(report, dict):
        return ["REMOTE_REPORT_NOT_OBJECT"]
    required_true = {
        "hardware_measured": report.get("hardware_measured"),
        "rk3566_detected": report.get("rk3566_detected"),
        "architecture_supported": report.get("architecture_supported"),
        "passed": report.get("passed"),
    }
    for key, value in required_true.items():
        if value is not True:
            failures.append(f"REMOTE_REPORT_FALSE:{key}")
    if report.get("simulation_detected") is not False:
        failures.append("REMOTE_SIMULATION_DETECTED_OR_UNKNOWN")
    if report.get("evidence_origin") != "ON_DEVICE_PREFLIGHT_SCRIPT":
        failures.append("REMOTE_EVIDENCE_ORIGIN_INVALID")
    if report.get("architecture") not in {"aarch64", "arm64"}:
        failures.append("REMOTE_ARCHITECTURE_INVALID")
    return failures


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--connection", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.connection.read_text(encoding="utf-8"))
    failures, identity, known_hosts = validate_connection(config)
    script_bytes = SCRIPT.read_bytes()
    remote_report: dict[str, Any] | None = None
    exit_code: int | None = None
    stdout = b""
    stderr = b""
    if not failures:
        command = [
            "ssh", "-T",
            "-o", "BatchMode=yes",
            "-o", "IdentitiesOnly=yes",
            "-o", "StrictHostKeyChecking=yes",
            "-o", f"UserKnownHostsFile={known_hosts}",
            "-o", "ConnectTimeout=10",
            "-o", "ConnectionAttempts=1",
            "-i", str(identity),
            "-p", str(config["port"]),
            f"{config['user']}@{config['host']}",
            "sh", "-s", "--", "-",
        ]
        try:
            completed = subprocess.run(
                command,
                input=script_bytes,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=60,
                check=False,
            )
            exit_code = completed.returncode
            stdout = completed.stdout
            stderr = completed.stderr
            try:
                remote_report = json.loads(stdout.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                failures.append("REMOTE_REPORT_INVALID_JSON")
            if exit_code != 0:
                failures.append(f"REMOTE_PREFLIGHT_EXIT:{exit_code}")
            if remote_report is not None:
                failures.extend(validate_device_report(remote_report))
        except (OSError, subprocess.SubprocessError) as exc:
            failures.append(f"SSH_EXECUTION_FAILED:{type(exc).__name__}")
    result = {
        "schema_version": "1.0.0",
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_REAL_DEVICE_PREFLIGHT" if not failures else "BLOCKED_OR_FAIL",
        "device_alias": config.get("expected_device_alias"),
        "connection": {"host": config.get("host"), "port": config.get("port"), "user": config.get("user")},
        "script_sha256": sha256_bytes(script_bytes),
        "known_hosts_sha256": sha256_file(known_hosts) if known_hosts.is_file() else None,
        "remote_stdout_sha256": sha256_bytes(stdout) if stdout else None,
        "remote_stderr_sha256": sha256_bytes(stderr) if stderr else None,
        "ssh_exit_code": exit_code,
        "hardware_evidence": remote_report,
        "failures": sorted(set(failures)),
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
