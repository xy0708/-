from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from health_rules import RuleInputError, evaluate_payload, load_rule_config


REPORT = ROOT / "reports" / "health_rules_verification.json"


def main() -> int:
    config = load_rule_config()
    failures: list[str] = []
    fixed_now = datetime(2026, 8, 25, tzinfo=timezone.utc)
    payload = {
        "confirmed": True,
        "measurements": [
            {
                "metric": "fasting_glucose",
                "value": 108,
                "unit": "mg/dL",
                "measured_at": "2026-08-24T08:00:00+08:00",
                "confirmed": True,
                "reference_low": 70,
                "reference_high": 100,
                "reference_source": "engineering_fixture_only",
            }
        ],
    }
    result = evaluate_payload(payload, config, now=fixed_now)
    measurement = result["measurements"][0]
    codes = {item["code"] for item in measurement["triggers"]}
    if "ABOVE_PROVIDED_REFERENCE" not in codes:
        failures.append("reference_comparison_not_triggered")
    if result["disease_probability"] is not None or result["diagnosis"] is not None:
        failures.append("medical_claim_field_must_be_null")
    if result["product_release_allowed"] is not False:
        failures.append("pending_rules_must_not_allow_product_release")
    try:
        evaluate_payload({"confirmed": False, "measurements": []}, config, now=fixed_now)
    except RuleInputError as exc:
        if exc.code != "TASK_NOT_CONFIRMED":
            failures.append("unconfirmed_input_wrong_error")
    else:
        failures.append("unconfirmed_input_was_accepted")

    status = "PASS_ENGINEERING" if not failures else "FAIL"
    report = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "product_gate": "BLOCKED_EXTERNAL_RULE_APPROVAL_REQUIRED",
        "product_release_allowed": False,
        "clinical_accuracy_claimed": False,
        "failures": failures,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
