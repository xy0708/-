from __future__ import annotations

import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / "configs" / "candidate_comparison_contract.json"
REPORT = ROOT / "reports" / "candidate_comparison_contract_verification.json"


def load_contract(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def verify_metrics(metrics: object, errors: list[str]) -> int:
    if not isinstance(metrics, dict) or set(metrics) != {"ocr", "asr", "device_common"}:
        errors.append("METRIC_GROUPS_INVALID")
        return 0
    count = 0
    for group, records in metrics.items():
        if not isinstance(records, list) or not records:
            errors.append(f"METRIC_GROUP_EMPTY:{group}")
            continue
        names: set[str] = set()
        for record in records:
            if not isinstance(record, dict):
                errors.append(f"METRIC_RECORD_INVALID:{group}")
                continue
            name = record.get("name")
            if not isinstance(name, str) or not name or name in names:
                errors.append(f"METRIC_NAME_INVALID:{group}")
                continue
            names.add(name)
            count += 1
            if record.get("threshold") is not None:
                errors.append(f"UNAPPROVED_THRESHOLD_PRESENT:{group}:{name}")
            if record.get("direction") not in {
                "higher_is_better",
                "lower_is_better",
                "report_components",
                "report_with_reason",
            }:
                errors.append(f"METRIC_DIRECTION_INVALID:{group}:{name}")
    return count


def verify_contract(path: Path = CONTRACT) -> dict[str, Any]:
    errors: list[str] = []
    try:
        contract = load_contract(path)
    except (OSError, UnicodeError, json.JSONDecodeError):
        return {"status": "FAIL", "errors": ["COMPARISON_CONTRACT_INVALID"]}

    if (
        contract.get("schema_version") != "1.0.0"
        or contract.get("status") != "DRAFT_EXTERNAL_APPROVAL_REQUIRED"
        or contract.get("purpose")
        != "OCR_ASR_BACKEND_SELECTION_NOT_PRODUCT_PERFORMANCE_CLAIM"
        or contract.get("product_selection_allowed") is not False
        or contract.get("winner") is not None
    ):
        errors.append("CONTRACT_BOUNDARY_INVALID")

    candidates = contract.get("candidate_sets", {})
    if not isinstance(candidates, dict) or candidates.get("ocr") != [
        "ocr_paddle_cpu_ppocrv5",
        "ocr_rknn_ppocrv4",
    ] or candidates.get("asr") != [
        "asr_sherpa_cpu_xasr",
        "asr_rknn_zipformer",
    ] or candidates.get("conditional_fallbacks") != ["asr_rknn_whisper"]:
        errors.append("CANDIDATE_SETS_INVALID")

    gates = contract.get("data_gates", {})
    selection = gates.get("selection_validation", {}) if isinstance(gates, dict) else {}
    sealed = gates.get("sealed_product_test", {}) if isinstance(gates, dict) else {}
    if (
        selection.get("manifest_path") is not None
        or selection.get("manifest_sha256") is not None
        or selection.get("rights_cleared") is not False
        or selection.get("synthetic_data_allowed_for_ranking") is not False
        or selection.get("same_inputs_for_all_candidates") is not True
        or selection.get("asr_split_isolation") != ["speaker"]
    ):
        errors.append("SELECTION_DATA_GATE_INVALID")
    if (
        sealed.get("manifest_path") is not None
        or sealed.get("manifest_sha256") is not None
        or sealed.get("rights_cleared") is not False
        or sealed.get("sealed") is not False
        or sealed.get("selection_use_prohibited") is not True
    ):
        errors.append("SEALED_TEST_GATE_INVALID")

    execution = contract.get("execution_contract", {})
    if (
        not isinstance(execution, dict)
        or execution.get("ocr_same_preprocess_boundary") is not True
        or execution.get("ocr_same_postprocess_scoring") is not True
        or execution.get("asr_same_audio_and_segmentation") is not True
        or execution.get("failures_included_in_denominator") is not True
        or execution.get("host_pc_latency_ranking_allowed") is not False
        or execution.get("rk3566_performance_ranking_required") is not True
        or execution.get("real_rk3566_device_profile_sha256") is not None
        or execution.get("candidate_workers_ready") is not False
    ):
        errors.append("EXECUTION_CONTRACT_INVALID")

    metric_count = verify_metrics(contract.get("metrics"), errors)
    ranking = contract.get("ranking_policy", {})
    if (
        not isinstance(ranking, dict)
        or ranking.get("approved_metric_priority") is not None
        or ranking.get("tie_breaker") is not None
        or ranking.get("missing_candidate_result") != "NO_PRODUCT_WINNER"
        or ranking.get("failed_required_gate") != "NO_PRODUCT_WINNER"
        or ranking.get("single_sample_or_synthetic_only") != "NO_PRODUCT_WINNER"
        or ranking.get("selection_validation_can_tune") is not True
        or ranking.get("sealed_product_test_can_tune") is not False
    ):
        errors.append("RANKING_POLICY_INVALID")

    approvals = contract.get("approvals", {})
    if not isinstance(approvals, dict) or set(approvals) != {
        "metric_thresholds",
        "dataset_and_rights",
        "device_profile",
    }:
        errors.append("APPROVAL_SET_INVALID")
    elif any(
        not isinstance(record, dict)
        or record.get("approved") is not False
        or record.get("approved_by") is not None
        or record.get("approved_at") is not None
        for record in approvals.values()
    ):
        errors.append("UNSUPPORTED_APPROVAL_CLAIM")

    return {
        "status": "PASS_ENGINEERING_CONTRACT_SCAFFOLD_PRODUCT_BLOCKED"
        if not errors
        else "FAIL",
        "phase": "C06_C07_BLOCKED_EXTERNAL",
        "candidate_count": 5,
        "active_comparison_candidate_count": 4,
        "metric_count": metric_count,
        "thresholds_approved": False,
        "selection_data_available": False,
        "real_rk3566_profile_available": False,
        "product_selection_allowed": False,
        "winner": None,
        "errors": errors,
    }


def main() -> int:
    result = verify_contract()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"].startswith("PASS_") else 2


if __name__ == "__main__":
    raise SystemExit(main())
