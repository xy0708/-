from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "component_contracts.json"
REPORT = ROOT / "reports" / "component_contract_verification.json"
SUPERVISOR = ROOT / "integration_adapter" / "supervisor.py"
ASR_WORKER = ROOT / "asr_runtime" / "worker.py"
OCR_WORKER = ROOT / "ocr_runtime" / "rknn_worker.py"
RUNTIME_BOOTSTRAP = ROOT / "device_service" / "runtime_bootstrap.py"
BACKEND_REGISTRY = ROOT / "model_registry" / "backend_registry.json"
BACKEND_SELECTION = ROOT / "configs" / "runtime_backend_selection.json"


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> int:
    config = json.loads(CONFIG.read_text(encoding="utf-8"))
    errors: list[str] = []
    if config.get("component_contract_version") != "1.0.0":
        errors.append("component_contract_version_not_frozen")
    if config.get("product_threshold_approved") is not False:
        errors.append("unapproved_product_threshold_claim")
    transport = config.get("transport", {})
    if transport.get("allowed") != ["unix_domain_socket", "loopback_tcp"]:
        errors.append("transport_scope_invalid")
    for field in (
        "external_bind_allowed",
        "network_model_download_allowed",
    ):
        if transport.get(field) is not False:
            errors.append(f"unsafe_transport_setting:{field}")
    for field in (
        "request_timeout_required",
        "process_isolation_required_for_native_models",
    ):
        if transport.get(field) is not True:
            errors.append(f"missing_transport_guard:{field}")

    supervisor = config.get("process_supervisor", {})
    expected_supervisor = {
        "implementation": "integration_adapter/supervisor.py",
        "protocol": "single_json_line_over_stdio",
        "shell_allowed": False,
        "secret_environment_inheritance_allowed": False,
        "bounded_request_bytes": 12 * 1024 * 1024,
        "bounded_response_bytes": 512 * 1024,
        "engineering_test_worker_available": True,
        "engineering_asr_worker_registered": True,
        "engineering_asr_worker_implementation": "asr_runtime/worker.py",
        "engineering_runtime_bootstrap": "device_service/runtime_bootstrap.py",
        "backend_registry": "model_registry/backend_registry.json",
        "backend_selection": "configs/runtime_backend_selection.json",
        "registered_backend_count": 5,
        "engineering_selectable_backend_count": 1,
        "silent_backend_fallback_allowed": False,
        "device_service_backend_registry_integrated": True,
        "engineering_ocr_worker_registered": True,
        "engineering_ocr_worker_implementation": "ocr_runtime/rknn_worker.py",
        "product_native_workers_registered": False,
        "hardware_measured": False,
    }
    for field, expected in expected_supervisor.items():
        if supervisor.get(field) != expected:
            errors.append(f"process_supervisor_invalid:{field}")
    if not SUPERVISOR.is_file():
        errors.append("process_supervisor_implementation_missing")
    if not ASR_WORKER.is_file():
        errors.append("engineering_asr_worker_implementation_missing")
    if not OCR_WORKER.is_file():
        errors.append("engineering_ocr_worker_implementation_missing")
    if not RUNTIME_BOOTSTRAP.is_file():
        errors.append("engineering_runtime_bootstrap_missing")
    if not BACKEND_REGISTRY.is_file():
        errors.append("backend_registry_missing")
    if not BACKEND_SELECTION.is_file():
        errors.append("backend_selection_missing")

    expected_capabilities = {
        "health": {"health_attention", "local_only"},
        "ocr": {"confirmation_required", "local_only", "ocr_task"},
        "asr": {
            "asr_stream",
            "confirmation_required",
            "local_only",
            "raw_audio_memory_only",
        },
    }
    components = config.get("components")
    if not isinstance(components, dict) or set(components) != set(expected_capabilities):
        errors.append("component_set_invalid")
        components = {}
    for name, required in expected_capabilities.items():
        item = components.get(name, {})
        if item.get("required_contract_major") != 1:
            errors.append(f"{name}:contract_major_invalid")
        if set(item.get("required_capabilities", [])) != required:
            errors.append(f"{name}:capabilities_invalid")
        timeout = item.get("operation_timeout_seconds")
        inflight = item.get("max_inflight_requests")
        if not isinstance(timeout, int) or isinstance(timeout, bool) or not 1 <= timeout <= 120:
            errors.append(f"{name}:timeout_invalid")
        if not isinstance(inflight, int) or isinstance(inflight, bool) or not 1 <= inflight <= 8:
            errors.append(f"{name}:max_inflight_invalid")
        if name in {"ocr", "asr"} and item.get("process_isolation_required") is not True:
            errors.append(f"{name}:process_isolation_missing")
        if name in {"ocr", "asr"}:
            if item.get("circuit_failure_threshold") != 3:
                errors.append(f"{name}:circuit_failure_threshold_invalid")
            if item.get("circuit_recovery_seconds") != 30:
                errors.append(f"{name}:circuit_recovery_invalid")
    restart = config.get("restart_policy", {})
    for field in (
        "native_runtime_restart_isolated_from_device_service",
        "bounded_restart_backoff_required",
        "repeated_failure_opens_circuit",
        "device_service_must_remain_available_when_one_model_fails",
    ):
        if restart.get(field) is not True:
            errors.append(f"restart_policy_missing:{field}")

    payload = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not errors else "FAIL",
        "product_complete": False,
        "product_threshold_approved": False,
        "component_contract_version": config.get("component_contract_version"),
        "process_supervisor_engineering_implemented": SUPERVISOR.is_file(),
        "process_supervisor_sha256": sha256(SUPERVISOR) if SUPERVISOR.is_file() else None,
        "engineering_test_worker_available": True,
        "engineering_asr_worker_registered": ASR_WORKER.is_file(),
        "engineering_asr_worker_sha256": sha256(ASR_WORKER) if ASR_WORKER.is_file() else None,
        "engineering_runtime_bootstrap_sha256": sha256(RUNTIME_BOOTSTRAP) if RUNTIME_BOOTSTRAP.is_file() else None,
        "backend_registry_sha256": sha256(BACKEND_REGISTRY) if BACKEND_REGISTRY.is_file() else None,
        "backend_selection_sha256": sha256(BACKEND_SELECTION) if BACKEND_SELECTION.is_file() else None,
        "silent_backend_fallback_allowed": False,
        "device_service_backend_registry_integrated": True,
        "engineering_ocr_worker_registered": OCR_WORKER.is_file(),
        "engineering_ocr_worker_sha256": sha256(OCR_WORKER) if OCR_WORKER.is_file() else None,
        "product_native_workers_registered": False,
        "hardware_measured": False,
        "errors": errors,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
