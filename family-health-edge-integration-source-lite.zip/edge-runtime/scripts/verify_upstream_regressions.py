from __future__ import annotations

import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
REPORT = ROOT / "reports" / "upstream_regression_verification.json"


PROJECTS = {
    "health": (
        WORKSPACE / "健康模型" / "health-risk-model",
        Path(".venv-health/Scripts/python.exe"),
        True,
    ),
    "ocr": (WORKSPACE / "OCR", Path(".venv-ocr/Scripts/python.exe"), False),
    "asr": (
        WORKSPACE
        / "语音转文字"
        / "家庭健康语音转文字_Codex_Goal_Loop"
        / "health_asr_codex_loop",
        Path(".venv-sherpa/Scripts/python.exe"),
        False,
    ),
}


def _safe_remove(test_root: Path, target: Path) -> None:
    root = test_root.resolve()
    resolved = target.resolve()
    if test_root.is_symlink() or resolved.parent != root or not resolved.name.startswith("edge-"):
        raise RuntimeError("refusing unsafe regression temporary-directory cleanup")
    if resolved.exists():
        shutil.rmtree(resolved)


def pytest_targets(project: Path, shard_by_file: bool) -> list[Path | None]:
    if not shard_by_file:
        return [None]
    test_root = project / "tests"
    targets = sorted(test_root.glob("test_*.py"), key=lambda path: path.name)
    if any(path.is_symlink() for path in targets):
        raise RuntimeError("refusing symlinked regression test target")
    return [path.relative_to(project) for path in targets if path.is_file()]


def shard_timeout(target: Path | None) -> int:
    # A profiled run of this 26-case release/ONNX/API file is slightly over
    # four minutes, while no individual case hangs. Keep all other shards at
    # the stricter default.
    if target is not None and target.as_posix() == "tests/test_product_acceptance.py":
        return 360
    return 240


def console_json(payload: object) -> str:
    """Return JSON that is safe to print through legacy Windows code pages."""
    return json.dumps(payload, ensure_ascii=True, indent=2)


def main() -> int:
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    records: list[dict[str, object]] = []
    failures: list[str] = []
    for name, (project, python_relative, shard_by_file) in PROJECTS.items():
        python = project / python_relative
        test_root = project / ".test-tmp"
        test_root.mkdir(parents=True, exist_ok=True)
        started = datetime.now(timezone.utc)
        shard_records: list[dict[str, object]] = []
        try:
            targets = pytest_targets(project, shard_by_file)
        except RuntimeError as exc:
            targets = []
            shard_records.append({"test_target": None, "exit_code": -1, "error": str(exc)})
        if not targets and not shard_records:
            shard_records.append({"test_target": None, "exit_code": -1,
                                  "error": "NO_TEST_TARGETS_DISCOVERED"})
        for index, target in enumerate(targets):
            label = target.stem if target is not None else "all"
            temporary = test_root / f"edge-{run_id}-{os.getpid()}-{name}-{index}-{label}"
            command = [str(python), "-m", "pytest", "-q", "-p", "no:cacheprovider",
                       f"--basetemp={temporary}"]
            if target is not None:
                command.append(target.as_posix())
            shard_started = datetime.now(timezone.utc)
            timeout_seconds = shard_timeout(target)
            try:
                completed = subprocess.run(
                    command, cwd=project, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    timeout=timeout_seconds, check=False,
                )
                output = completed.stdout.decode("utf-8", errors="replace")
                exit_code = completed.returncode
                error = None
            except subprocess.TimeoutExpired as exc:
                raw = exc.stdout or b""
                output = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else str(raw)
                exit_code = -1
                error = f"TIMEOUT_{timeout_seconds}_SECONDS"
            except OSError:
                output = ""
                exit_code = -1
                error = "PROJECT_RUNTIME_UNAVAILABLE"
            finally:
                _safe_remove(test_root, temporary)
            shard_records.append({
                "test_target": target.as_posix() if target is not None else "ALL",
                "command": command,
                "started_at": shard_started.isoformat(),
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "exit_code": exit_code,
                "timeout_seconds": timeout_seconds,
                "error": error,
                "output_tail": output[-4000:],
            })
        project_passed = bool(shard_records) and all(
            item.get("exit_code") == 0 for item in shard_records
        )
        if not project_passed:
            failures.append(name)
        records.append(
            {
                "project": name,
                "started_at": started.isoformat(),
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "exit_code": 0 if project_passed else 2,
                "error": None if project_passed else "ONE_OR_MORE_TEST_SHARDS_FAILED",
                "sharded_by_test_file": shard_by_file,
                "test_target_count": len(targets),
                "all_test_targets_passed": project_passed,
                "shards": shard_records,
                "cache_provider_disabled": True,
                "project_local_unique_basetemp": True,
            }
        )
    payload = {
        "schema_version": "1.0.0",
        "run_id": run_id,
        "status": "PASS_ENGINEERING" if not failures else "FAIL",
        "product_complete": False,
        "projects": records,
        "failures": failures,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(console_json(payload))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
