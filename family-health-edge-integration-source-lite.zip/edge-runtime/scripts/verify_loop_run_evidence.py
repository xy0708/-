from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
LATEST = ROOT / "reports" / "loop_run_latest.json"
REPORT = ROOT / "reports" / "loop_run_evidence_verification.json"
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_RUN_ID = re.compile(r"^[0-9]{8}T[0-9]{6}Z$")


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def safe_file(root: Path, relative: str) -> Path | None:
    path = Path(relative)
    if path.is_absolute() or ".." in path.parts:
        return None
    candidate = root / path
    if (
        not candidate.is_file()
        or candidate.is_symlink()
        or not candidate.resolve().is_relative_to(root.resolve())
    ):
        return None
    return candidate


def load_snapshot_json(
    root: Path,
    run_id: str,
    relative: str,
) -> dict[str, Any] | None:
    snapshot = (
        Path("reports") / "loop_runs" / run_id / "outputs" / Path(relative)
    ).as_posix()
    path = safe_file(root, snapshot)
    if path is None:
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def verify_payload(root: Path, payload: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(payload, dict):
        return ["loop_run_report_not_object"]
    run_id = payload.get("run_id")
    if not isinstance(run_id, str) or _RUN_ID.fullmatch(run_id) is None:
        errors.append("run_id_invalid")
        run_id = "invalid"
    status = payload.get("status")
    product_pass = status == "PASS_PRODUCT_GATE"
    engineering_pass = status == "PASS_ENGINEERING_PRODUCT_BLOCKED"
    if not (product_pass or engineering_pass):
        errors.append("latest_run_terminal_status_invalid")
    if product_pass and payload.get("formal_release_created") is not True:
        errors.append("product_run_missing_formal_release")
    if engineering_pass and payload.get("formal_release_created") is not False:
        errors.append("blocked_run_incorrectly_created_release")
    if payload.get("unexpected_checks") != []:
        errors.append("unexpected_checks_present")
    if payload.get("snapshot_integrity_verified") is not True:
        errors.append("snapshot_integrity_not_verified")

    inputs = payload.get("input_sha256")
    if not isinstance(inputs, dict) or not inputs:
        errors.append("input_hashes_missing")
        inputs = {}
    for relative, expected in inputs.items():
        if not isinstance(relative, str) or not isinstance(expected, str) or _SHA256.fullmatch(expected) is None:
            errors.append("input_hash_entry_invalid")
            continue
        source = safe_file(root, relative)
        if source is None:
            errors.append(f"input_missing_or_unsafe:{relative}")
        elif sha256(source) != expected:
            errors.append(f"input_hash_mismatch:{relative}")

    outputs = payload.get("output_sha256")
    evidence = payload.get("output_evidence")
    if not isinstance(outputs, dict) or not outputs:
        errors.append("output_hashes_missing")
        outputs = {}
    if not isinstance(evidence, dict) or set(evidence) != set(outputs):
        errors.append("output_evidence_set_mismatch")
        evidence = evidence if isinstance(evidence, dict) else {}
    for relative, expected in outputs.items():
        item = evidence.get(relative)
        if (
            not isinstance(relative, str)
            or not isinstance(expected, str)
            or _SHA256.fullmatch(expected) is None
            or not isinstance(item, dict)
        ):
            errors.append(f"output_evidence_invalid:{relative}")
            continue
        expected_snapshot = (
            Path("reports") / "loop_runs" / run_id / "outputs" / Path(relative)
        ).as_posix()
        if (
            item.get("source_sha256") != expected
            or item.get("snapshot_sha256") != expected
            or item.get("snapshot") != expected_snapshot
        ):
            errors.append(f"output_snapshot_metadata_mismatch:{relative}")
            continue
        snapshot = safe_file(root, expected_snapshot)
        if snapshot is None:
            errors.append(f"output_snapshot_missing_or_unsafe:{relative}")
        elif sha256(snapshot) != expected:
            errors.append(f"output_snapshot_hash_mismatch:{relative}")
    if product_pass:
        required_product_snapshots = {
            "reports/device_acceptance.json": (
                "PASS_PRODUCT_GATE",
                {"hardware_measured": True, "acceptance_executed": True},
            ),
            "reports/final_release_verification.json": (
                "PASS_PRODUCT_GATE",
                {"release_allowed": True, "formal_release_verified": True},
            ),
            "reports/loop_requirements_audit.json": (
                "PASS_PRODUCT_GATE",
                {"goal_complete": True, "product_release_allowed": True},
            ),
        }
        for relative, (expected_status, flags) in required_product_snapshots.items():
            report = load_snapshot_json(root, run_id, relative)
            if report is None:
                errors.append(f"product_terminal_snapshot_missing_or_invalid:{relative}")
                continue
            if report.get("status") != expected_status or any(
                report.get(key) is not value for key, value in flags.items()
            ):
                errors.append(f"product_terminal_snapshot_not_pass:{relative}")
            if report.get("blockers") not in (None, []):
                errors.append(f"product_terminal_snapshot_has_blockers:{relative}")
            if report.get("contradictions") not in (None, []):
                errors.append(f"product_terminal_snapshot_has_contradictions:{relative}")
            if report.get("engineering_failures") not in (None, []):
                errors.append(f"product_terminal_snapshot_has_engineering_failures:{relative}")
    return errors


def main() -> int:
    try:
        payload = json.loads(LATEST.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        payload = None
    errors = verify_payload(ROOT, payload)
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not errors else "FAIL",
        "meaning": "Per-run input hashes and immutable output snapshots only; not product acceptance",
        "run_id": payload.get("run_id") if isinstance(payload, dict) else None,
        "product_complete": bool(
            isinstance(payload, dict) and payload.get("status") == "PASS_PRODUCT_GATE"
        ),
        "hardware_measured": bool(
            isinstance(payload, dict) and payload.get("status") == "PASS_PRODUCT_GATE"
        ),
        "errors": errors,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
