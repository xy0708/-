from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / "configs" / "product_delivery_contract.json"
PLAN = ROOT / "PRODUCT_EDGE_DEPLOYMENT_PLAN.md"
REPORT = ROOT / "reports" / "product_delivery_plan_verification.json"


def main() -> int:
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    plan = PLAN.read_text(encoding="utf-8")
    errors: list[str] = []
    required_true = [
        "self_contained_arm64_release_required",
        "clean_device_install_required",
        "offline_core_operation_required",
        "product_integration_contract_required",
        "model_module_independent_of_demo",
        "device_internal_api_only",
        "signed_manifest_required",
        "atomic_activation_required",
        "automatic_rollback_required",
        "factory_provisioning_required",
        "unique_device_identity_required",
        "per_device_data_key_required",
    ]
    required_false = [
        "unified_demo_in_release",
        "product_ui_artifact_required_from_model_module",
        "first_boot_network_model_download_allowed",
        "developer_workstation_required_at_runtime",
        "global_python_required_at_runtime",
        "windows_venv_allowed_in_release",
        "absolute_developer_paths_allowed",
        "formal_release_allowed",
    ]
    for field in required_true:
        if contract.get(field) is not True:
            errors.append(f"required_true_missing:{field}")
    for field in required_false:
        if contract.get(field) is not False:
            errors.append(f"required_false_missing:{field}")
    if contract.get("deployment_mode") != "PHYSICAL_EDGE_PRODUCT":
        errors.append("deployment_mode_must_be_physical_edge_product")
    if contract.get("target_architecture") != "aarch64":
        errors.append("target_architecture_must_be_aarch64")
    if contract.get("status") != "PLAN_FROZEN_PRODUCT_BLOCKED":
        errors.append("plan_must_remain_product_blocked_until_real_evidence")
    management_runtime = contract.get("management_runtime", {})
    if (
        management_runtime.get("packaging") != "PyInstaller onefile ARM64"
        or management_runtime.get("engineering_artifact_built") is not True
        or management_runtime.get("system_python_required") is not False
        or management_runtime.get("executable_temporary_space_min_bytes") != 134217728
        or management_runtime.get("named_legal_approval_complete") is not False
        or management_runtime.get("real_rk3566_acceptance_complete") is not False
    ):
        errors.append("management_runtime_boundary_invalid")
    expected_components = {
        "integration_adapter",
        "device_service",
        "health_runtime",
        "ocr_runtime",
        "asr_runtime",
        "encrypted_storage",
        "update_agent",
    }
    if set(contract.get("required_runtime_components", [])) != expected_components:
        errors.append("runtime_components_incomplete")
    expected_directories = {
        "bin",
        "models",
        "lib",
        "configs",
        "migrations",
        "systemd",
        "licenses",
        "sbom",
        "reports",
        "signatures",
    }
    if set(contract.get("required_release_directories", [])) != expected_directories:
        errors.append("release_directories_incomplete")
    ota = contract.get("ota", {})
    if not all(
        ota.get(field) is True
        for field in [
            "company_controlled_artifact_repository_required",
            "signed_online_updates",
            "signed_offline_updates",
            "staged_rollout_required",
            "pause_and_revoke_required",
            "remote_shell_update_forbidden",
        ]
    ):
        errors.append("ota_contract_incomplete")
    privacy = contract.get("privacy", {})
    if any(
        privacy.get(field) is not False
        for field in [
            "raw_report_upload_default",
            "raw_ocr_text_upload_default",
            "raw_audio_upload_default",
            "health_value_upload_default",
        ]
    ) or privacy.get("cloud_sync_requires_separate_gate") is not True:
        errors.append("privacy_upload_boundary_invalid")
    forbidden_contract_markers = ["C:\\\\Users\\\\", "Desktop", ".venv-health", ".venv-edge"]
    serialized = json.dumps(contract, ensure_ascii=False)
    if any(marker.casefold() in serialized.casefold() for marker in forbidden_contract_markers):
        errors.append("developer_local_path_or_environment_in_delivery_contract")
    for phrase in [
        "不是开发者电脑上的网页",
        "统一 Demo 只用于研发回归",
        "断开开发电脑和互联网后仍可完整运行",
        "产品接口/SDK",
        "签名安装、升级、失败回滚",
    ]:
        if phrase not in plan:
            errors.append(f"plan_boundary_missing:{phrase}")
    payload = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not errors else "FAIL",
        "plan_frozen": not errors,
        "physical_edge_product_required": True,
        "developer_workstation_runtime_dependency_allowed": False,
        "unified_demo_product_dependency_allowed": False,
        "formal_release_allowed": False,
        "product_complete": False,
        "errors": errors,
    }
    REPORT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
