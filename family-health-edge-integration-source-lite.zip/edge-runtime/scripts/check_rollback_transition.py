from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from update_agent import check_rollback_transition


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--current", type=Path, required=True)
    parser.add_argument("--target", required=True)
    arguments = parser.parse_args()
    result = check_rollback_transition(arguments.current, arguments.target)
    print(json.dumps(result.as_dict(), ensure_ascii=True))
    return 0 if result.passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
