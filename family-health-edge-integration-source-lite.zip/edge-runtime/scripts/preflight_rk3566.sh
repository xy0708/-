#!/bin/sh
set -eu

EDGE_OUTPUT="${1:-reports/rk3566_preflight.json}"
EDGE_PYTHON=""
if command -v python3 >/dev/null 2>&1 && python3 -c 'import json' >/dev/null 2>&1; then
  EDGE_PYTHON=python3
elif command -v python >/dev/null 2>&1 && python -c 'import json' >/dev/null 2>&1; then
  EDGE_PYTHON=python
else
  printf '%s\n' 'A working Python 3 runtime is required to emit valid UTF-8 JSON evidence.' >&2
  exit 2
fi

EDGE_ARCH="$(uname -m 2>/dev/null || printf unknown)"
EDGE_COMPATIBLE=""
if [ -r /proc/device-tree/compatible ]; then
  EDGE_COMPATIBLE="$(tr '\000' ',' < /proc/device-tree/compatible)"
fi
EDGE_SOC_OK=false
case "$EDGE_COMPATIBLE" in *rk3566*) EDGE_SOC_OK=true ;; esac
EDGE_ARCH_OK=false
case "$EDGE_ARCH" in aarch64|arm64) EDGE_ARCH_OK=true ;; esac

EDGE_SIMULATION_DETECTED=false
EDGE_VIRTUAL_HINT="$(
  { cat /sys/class/dmi/id/product_name 2>/dev/null || true; cat /proc/cpuinfo 2>/dev/null || true; printf '%s' "$EDGE_COMPATIBLE"; } |
  tr '[:upper:]' '[:lower:]' | grep -E -m1 'qemu|kvm|virtualbox|vmware|hypervisor' || true
)"
if [ -n "$EDGE_VIRTUAL_HINT" ]; then EDGE_SIMULATION_DETECTED=true; fi

EDGE_HARDWARE_MEASURED=false
if [ "$EDGE_SOC_OK" = true ] && [ "$EDGE_ARCH_OK" = true ] && [ "$EDGE_SIMULATION_DETECTED" = false ]; then
  EDGE_HARDWARE_MEASURED=true
fi

EDGE_NPU_NODE=false
for EDGE_NODE in /dev/rknpu /dev/rknpu0; do
  if [ -c "$EDGE_NODE" ]; then EDGE_NPU_NODE=true; fi
done
EDGE_RKNN_RUNTIME_PATH=""
if command -v ldconfig >/dev/null 2>&1; then
  EDGE_RKNN_RUNTIME_PATH="$(ldconfig -p 2>/dev/null | awk '/librknnrt/{print $NF; exit}')"
fi
EDGE_RKNN_RUNTIME=false
EDGE_RKNN_RUNTIME_SHA256=""
if [ -n "$EDGE_RKNN_RUNTIME_PATH" ] && [ -f "$EDGE_RKNN_RUNTIME_PATH" ]; then
  EDGE_RKNN_RUNTIME=true
  if command -v sha256sum >/dev/null 2>&1; then
    EDGE_RKNN_RUNTIME_SHA256="$(sha256sum "$EDGE_RKNN_RUNTIME_PATH" | awk '{print $1}')"
  fi
fi
EDGE_RKNPU_DRIVER_VERSION=""
if [ -r /sys/module/rknpu/version ]; then
  EDGE_RKNPU_DRIVER_VERSION="$(cat /sys/module/rknpu/version)"
fi

EDGE_ARECORD=false
EDGE_APLAY=false
EDGE_CAPTURE_DEVICE_COUNT=0
EDGE_PLAYBACK_DEVICE_COUNT=0
if command -v arecord >/dev/null 2>&1; then
  EDGE_ARECORD=true
  EDGE_CAPTURE_DEVICE_COUNT="$(arecord -l 2>/dev/null | grep -c '^card ' || true)"
fi
if command -v aplay >/dev/null 2>&1; then
  EDGE_APLAY=true
  EDGE_PLAYBACK_DEVICE_COUNT="$(aplay -l 2>/dev/null | grep -c '^card ' || true)"
fi

EDGE_OS_ID="$(sed -n 's/^ID=//p' /etc/os-release 2>/dev/null | head -n1 | tr -d '"' || true)"
EDGE_OS_VERSION_ID="$(sed -n 's/^VERSION_ID=//p' /etc/os-release 2>/dev/null | head -n1 | tr -d '"' || true)"
EDGE_KERNEL="$(uname -r 2>/dev/null || printf unknown)"
EDGE_MEM_TOTAL_KIB="$(awk '/^MemTotal:/{print $2}' /proc/meminfo 2>/dev/null || printf 0)"
EDGE_ROOT_FS="$(df -PT / 2>/dev/null | awk 'NR==2{print $2}')"
EDGE_ROOT_FREE_KIB="$(df -Pk / 2>/dev/null | awk 'NR==2{print $4}')"
EDGE_MAX_TEMPERATURE_MILLIC="$(
  awk 'BEGIN{max=""} /^[0-9]+$/{if(max=="" || $1>max)max=$1} END{if(max=="")print -1;else print max}' \
    /sys/class/thermal/thermal_zone*/temp 2>/dev/null || printf '%s' -1
)"

EDGE_SYSTEMD=false
EDGE_FLOCK=false
EDGE_OPENSSL=false
EDGE_CURL=false
command -v systemctl >/dev/null 2>&1 && EDGE_SYSTEMD=true
command -v flock >/dev/null 2>&1 && EDGE_FLOCK=true
command -v openssl >/dev/null 2>&1 && EDGE_OPENSSL=true
command -v curl >/dev/null 2>&1 && EDGE_CURL=true
EDGE_TIME_SYNCHRONIZED="unknown"
if command -v timedatectl >/dev/null 2>&1; then
  EDGE_TIME_SYNCHRONIZED="$(timedatectl show -p NTPSynchronized --value 2>/dev/null || printf unknown)"
fi
EDGE_SERIAL_SHA256=""
if [ -r /proc/device-tree/serial-number ] && command -v sha256sum >/dev/null 2>&1; then
  EDGE_SERIAL_SHA256="$(tr -d '\000' < /proc/device-tree/serial-number | sha256sum | awk '{print $1}')"
fi

EDGE_PASSED=false
EDGE_TIME_OK=false
case "$EDGE_TIME_SYNCHRONIZED" in yes|true) EDGE_TIME_OK=true ;; esac
if [ "$EDGE_HARDWARE_MEASURED" = true ] && [ "$EDGE_NPU_NODE" = true ] && \
   [ "$EDGE_RKNN_RUNTIME" = true ] && [ "$EDGE_ARECORD" = true ] && \
   [ "$EDGE_APLAY" = true ] && [ "$EDGE_CAPTURE_DEVICE_COUNT" -gt 0 ] && \
   [ "$EDGE_PLAYBACK_DEVICE_COUNT" -gt 0 ] && [ "$EDGE_SYSTEMD" = true ] && \
   [ "$EDGE_FLOCK" = true ] && [ "$EDGE_OPENSSL" = true ] && [ "$EDGE_TIME_OK" = true ]; then
  EDGE_PASSED=true
fi

export EDGE_ARCH EDGE_COMPATIBLE EDGE_SOC_OK EDGE_ARCH_OK EDGE_SIMULATION_DETECTED
export EDGE_HARDWARE_MEASURED EDGE_NPU_NODE EDGE_RKNN_RUNTIME EDGE_RKNN_RUNTIME_PATH
export EDGE_RKNN_RUNTIME_SHA256 EDGE_RKNPU_DRIVER_VERSION EDGE_ARECORD EDGE_APLAY
export EDGE_CAPTURE_DEVICE_COUNT EDGE_PLAYBACK_DEVICE_COUNT EDGE_OS_ID EDGE_OS_VERSION_ID
export EDGE_KERNEL EDGE_MEM_TOTAL_KIB EDGE_ROOT_FS EDGE_ROOT_FREE_KIB
export EDGE_MAX_TEMPERATURE_MILLIC EDGE_SYSTEMD EDGE_FLOCK EDGE_OPENSSL EDGE_CURL
export EDGE_TIME_SYNCHRONIZED EDGE_SERIAL_SHA256 EDGE_PASSED

EDGE_JSON="$($EDGE_PYTHON - <<'PY'
import json, os
from datetime import datetime, timezone

def flag(name):
    return os.environ.get(name) == "true"

def integer(name, default=0):
    try:
        return int(os.environ.get(name, str(default)))
    except ValueError:
        return default

value = {
    "schema_version": "2.0.0",
    "collected_at": datetime.now(timezone.utc).isoformat(),
    "evidence_origin": "ON_DEVICE_PREFLIGHT_SCRIPT",
    "hardware_measured": flag("EDGE_HARDWARE_MEASURED"),
    "simulation_detected": flag("EDGE_SIMULATION_DETECTED"),
    "architecture": os.environ.get("EDGE_ARCH", "unknown"),
    "compatible": os.environ.get("EDGE_COMPATIBLE", ""),
    "rk3566_detected": flag("EDGE_SOC_OK"),
    "architecture_supported": flag("EDGE_ARCH_OK"),
    "device_serial_sha256": os.environ.get("EDGE_SERIAL_SHA256") or None,
    "os": {"id": os.environ.get("EDGE_OS_ID"), "version_id": os.environ.get("EDGE_OS_VERSION_ID"), "kernel": os.environ.get("EDGE_KERNEL")},
    "resources": {"mem_total_kib": integer("EDGE_MEM_TOTAL_KIB"), "root_filesystem": os.environ.get("EDGE_ROOT_FS"), "root_free_kib": integer("EDGE_ROOT_FREE_KIB"), "max_temperature_millic": integer("EDGE_MAX_TEMPERATURE_MILLIC", -1)},
    "npu": {"device_node": flag("EDGE_NPU_NODE"), "driver_version": os.environ.get("EDGE_RKNPU_DRIVER_VERSION") or None, "rknn_runtime_detected": flag("EDGE_RKNN_RUNTIME"), "rknn_runtime_path": os.environ.get("EDGE_RKNN_RUNTIME_PATH") or None, "rknn_runtime_sha256": os.environ.get("EDGE_RKNN_RUNTIME_SHA256") or None},
    "audio": {"arecord_detected": flag("EDGE_ARECORD"), "aplay_detected": flag("EDGE_APLAY"), "capture_device_count": integer("EDGE_CAPTURE_DEVICE_COUNT"), "playback_device_count": integer("EDGE_PLAYBACK_DEVICE_COUNT")},
    "operations": {"systemd": flag("EDGE_SYSTEMD"), "flock": flag("EDGE_FLOCK"), "openssl": flag("EDGE_OPENSSL"), "curl": flag("EDGE_CURL"), "time_synchronized": os.environ.get("EDGE_TIME_SYNCHRONIZED", "unknown")},
    "passed": flag("EDGE_PASSED"),
}
print(json.dumps(value, ensure_ascii=False, separators=(",", ":")))
PY
)"

if [ "$EDGE_OUTPUT" = "-" ]; then
  printf '%s\n' "$EDGE_JSON"
else
  mkdir -p "$(dirname "$EDGE_OUTPUT")"
  printf '%s\n' "$EDGE_JSON" > "$EDGE_OUTPUT"
fi
if [ "$EDGE_PASSED" != true ]; then
  printf '%s\n' 'RK3566 preflight failed; no product hardware gate was granted.' >&2
  exit 2
fi
printf '%s\n' 'RK3566 preflight passed on detected target hardware.' >&2
