from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from acceptance.local_client import run_ocr_case
from acceptance.approvals import (
    acceptance_manifest_approval_errors,
    load_gate_registry,
)
from acceptance.manifests import (
    controlled_output_path,
    validate_acceptance_cases,
    write_jsonl_atomically,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--port", type=int, default=18100)
    args = parser.parse_args()
    token = os.environ.get("EDGE_ACCEPTANCE_TOKEN")
    member_id = os.environ.get("EDGE_ACCEPTANCE_MEMBER_ID")
    if not token or not member_id:
        raise SystemExit("EDGE_ACCEPTANCE_TOKEN and EDGE_ACCEPTANCE_MEMBER_ID are required")
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    approval_errors = acceptance_manifest_approval_errors(
        ROOT, manifest, load_gate_registry(ROOT), {"ocr"}
    )
    if approval_errors:
        raise SystemExit("formal acceptance approvals invalid: " + ",".join(approval_errors))
    cases = validate_acceptance_cases(manifest, "ocr", args.input_root)
    output = controlled_output_path(ROOT, args.output)
    def result_rows():
        for case in cases:
            yield from run_ocr_case(args.port, token, member_id, case, args.input_root)

    row_count = write_jsonl_atomically(output, result_rows())
    print(json.dumps({"status": "COMPLETED_REAL_OCR_EVIDENCE", "rows": row_count, "output": str(output.relative_to(ROOT))}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
