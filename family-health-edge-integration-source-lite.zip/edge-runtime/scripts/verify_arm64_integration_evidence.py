from __future__ import annotations

import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
sys.path.insert(0, str(ROOT))

from scripts.run_arm64_integration_simulation import REPORT, sha256, validate_guest
from scripts.verify_model_simulation_evidence import evaluate as evaluate_s2


OUTPUT = ROOT / "reports" / "arm64_integration_simulation_verification.json"
EXPECTED_BLOCKERS = {
    "OCR_PRODUCT_WORKER_AND_LICENSE_REQUIRED",
    "ASR_PRODUCT_LICENSE_AND_TARGET_MIC_ACCEPTANCE_REQUIRED",
    "RK3566_NOT_TESTED",
}
EXPECTED_COMMANDS = {
    "docker_context",
    "docker_info",
    "pull_base",
    "inspect_base",
    "build_integration_image",
    "inspect_candidate",
    "create_integration_container",
    "run_integration_probe",
    "inspect_integration_guest",
    "cleanup_own_integration_container",
}
DIGEST = re.compile(r"[a-z0-9][a-z0-9._/-]*@sha256:[a-f0-9]{64}")


def _safe_file(base: Path, relative: object) -> Path | None:
    if not isinstance(relative, str) or not relative:
        return None
    path = (base / relative).resolve()
    return path if path.is_relative_to(base.resolve()) and path.is_file() else None


def evaluate(report: dict, *, root: Path = ROOT, workspace: Path = WORKSPACE) -> list[str]:
    errors: list[str] = []
    for field in (
        "hardware_measured",
        "product_complete",
        "three_model_inference_verified",
        "simulation_complete",
    ):
        if report.get(field) is not False:
            errors.append("UNSUPPORTED_COMPLETION_CLAIM:" + field)
    if report.get("simulated") is not True or report.get("stage") != "S3_ASR_DEVICE_SERVICE_PARTIAL":
        errors.append("INTEGRATION_SIMULATION_PROVENANCE_INVALID")
    if report.get("status") != "PARTIAL_PASS_PRODUCT_BLOCKED":
        errors.append("INTEGRATION_SIMULATION_NOT_PASS")
    if set(report.get("blockers", [])) != EXPECTED_BLOCKERS:
        errors.append("INTEGRATION_BLOCKERS_INVALID")
    if not DIGEST.fullmatch(str(report.get("base_image", {}).get("digest", ""))):
        errors.append("INTEGRATION_BASE_DIGEST_MISSING")
    if not DIGEST.fullmatch(str(report.get("candidate_image", {}).get("reference", ""))):
        errors.append("INTEGRATION_CANDIDATE_DIGEST_MISSING")

    requirements = report.get("guest", {}).get("requirements", {})
    if not isinstance(requirements, dict) or not validate_guest(report.get("guest", {}), requirements):
        errors.append("INTEGRATION_GUEST_EVIDENCE_INVALID")
    components = report.get("components", {})
    health = components.get("health", {})
    if (
        health.get("status") != "PASS_REAL_NON_DIAGNOSTIC_RULE_ENGINE"
        or health.get("loopback_http_verified") is not True
        or health.get("diagnosis_exposed") is not False
        or health.get("disease_probability_exposed") is not False
    ):
        errors.append("HEALTH_INTEGRATION_BOUNDARY_INVALID")
    asr = components.get("asr", {})
    if (
        asr.get("status") != "PASS_REAL_ISOLATED_WORKER_INTEGRATION"
        or asr.get("matches_s2_reference") is not True
        or asr.get("runtime_config_bootstrap_verified") is not True
        or asr.get("backend_registry_selection_verified") is not True
        or asr.get("loopback_websocket_verified") is not True
        or asr.get("raw_audio_persisted") is not False
        or asr.get("confirmed_record_count") != 0
        or asr.get("pending_task_cancelled") is not True
        or asr.get("product_accepted") is not False
    ):
        errors.append("ASR_INTEGRATION_EVIDENCE_INVALID")
    ocr = components.get("ocr", {})
    if (
        ocr.get("status") != "BLOCKED_EXTERNAL"
        or ocr.get("real_worker_invoked") is not False
        or ocr.get("test_double_used") is not False
    ):
        errors.append("OCR_BLOCKER_PROVENANCE_INVALID")

    if report.get("container_cleaned") is not True:
        errors.append("INTEGRATION_CONTAINER_CLEANUP_NOT_VERIFIED")
    if report.get("guest", {}).get("loopback_server_cleaned") is not True:
        errors.append("INTEGRATION_LOOPBACK_SERVER_CLEANUP_NOT_VERIFIED")
    commands = {
        item.get("name"): item
        for item in report.get("commands", [])
        if isinstance(item, dict) and isinstance(item.get("name"), str)
    }
    for name in sorted(EXPECTED_COMMANDS):
        if commands.get(name, {}).get("exit_code") != 0:
            errors.append("INTEGRATION_COMMAND_NOT_VERIFIED:" + name)

    s2 = report.get("s2_evidence", {})
    snapshot = _safe_file(root, s2.get("snapshot") if isinstance(s2, dict) else None)
    if snapshot is None or sha256(snapshot) != s2.get("sha256"):
        errors.append("S2_SNAPSHOT_INTEGRITY_INVALID")
    else:
        try:
            if evaluate_s2(json.loads(snapshot.read_text(encoding="utf-8"))):
                errors.append("S2_SNAPSHOT_EVIDENCE_INVALID")
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            errors.append("S2_SNAPSHOT_EVIDENCE_INVALID")

    hashes = report.get("source_sha256")
    required_sources = {
        "端侧上线/configs/arm64_integration_simulation.json",
        "端侧上线/simulation/IntegrationDockerfile",
        "端侧上线/simulation/integration_probe.py",
        "端侧上线/asr_runtime/worker.py",
        "端侧上线/asr_runtime/field_extraction.py",
        "端侧上线/asr_runtime/session.py",
        "端侧上线/runtime_backends/__init__.py",
        "端侧上线/runtime_backends/registry.py",
        "端侧上线/model_registry/backend_registry.json",
        "端侧上线/configs/runtime_backend_selection.json",
        "端侧上线/integration_adapter/supervisor.py",
        "端侧上线/device_service/application.py",
        "端侧上线/device_service/runtime_bootstrap.py",
        "端侧上线/device_service/server.py",
        "端侧上线/device_service/websocket.py",
        "端侧上线/operations/event_log.py",
        "端侧上线/scripts/run_arm64_integration_simulation.py",
        "端侧上线/scripts/verify_arm64_integration_evidence.py",
    }
    if not isinstance(hashes, dict) or not required_sources.issubset(hashes):
        errors.append("INTEGRATION_REQUIRED_SOURCE_HASHES_MISSING")
    else:
        for relative, digest in hashes.items():
            path = _safe_file(workspace, relative)
            if path is None or sha256(path) != digest:
                errors.append("INTEGRATION_SOURCE_CHANGED:" + str(relative))

    run_id = report.get("run_id")
    context_hashes = report.get("context_sha256")
    context = root / "reports" / "arm64_integration_simulation_runs" / str(run_id) / "context"
    if not isinstance(context_hashes, dict) or not context_hashes:
        errors.append("INTEGRATION_CONTEXT_HASHES_MISSING")
    else:
        for relative, digest in context_hashes.items():
            path = context / "Dockerfile" if relative == "simulation/IntegrationDockerfile" else context / "app" / relative
            resolved = path.resolve()
            if (
                not resolved.is_relative_to(context.resolve())
                or not resolved.is_file()
                or sha256(resolved) != digest
            ):
                errors.append("INTEGRATION_CONTEXT_CHANGED:" + str(relative))
    return errors


def main() -> int:
    report = json.loads(REPORT.read_text(encoding="utf-8")) if REPORT.is_file() else {}
    errors = evaluate(report)
    output = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not errors else "FAIL",
        "meaning": "Real ASR worker plus device-service integration on simulated ARM64 only; OCR, RK3566 and product acceptance remain blocked",
        "hardware_measured": False,
        "product_complete": False,
        "three_model_inference_verified": False,
        "errors": errors,
    }
    OUTPUT.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, ensure_ascii=True))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
