from __future__ import annotations

import json
import os
import platform
import sys
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

import cv2
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.ocr_single_sample import (
    REPORT_SCHEMA_VERSION,
    REPORT_SCOPE,
    REPORT_STATUS,
    compare_line_outputs,
    load_rknn_lines,
    sha256,
    text_digest,
    validate_report,
)


OCR_ROOT = ROOT.parent / "OCR"
IMAGE = (
    ROOT
    / "vendor/rockchip/rknn_model_zoo/examples/PPOCR/PPOCR-System/model/test.jpg"
)
CPU_MANIFEST = OCR_ROOT / "models/official_pretrained/manifest.json"
RKNN_REPORT = ROOT / "reports/rknn_simulation_ppocrv4_system.json"
OUTPUT = ROOT / "reports/ocr_cpu_rknn_single_sample_comparison.json"


@contextmanager
def working_directory(path: Path) -> Iterator[None]:
    previous = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(previous)


def load_image(path: Path) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(path.read_bytes(), dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None or image.ndim != 3:
        raise RuntimeError("frozen OCR comparison image is unreadable")
    return image


def run_cpu_candidate(image: np.ndarray) -> tuple[list[object], str, str, float]:
    source_root = OCR_ROOT / "src"
    if str(source_root) not in sys.path:
        sys.path.insert(0, str(source_root))
    os.environ["PADDLE_PDX_CACHE_HOME"] = str(OCR_ROOT / ".paddlex-cache")
    from health_ocr.ocr_engine import (  # noqa: PLC0415
        PaddleOCREngine,
        verify_official_model_files,
    )

    model_root = OCR_ROOT / "models/official_pretrained/paddlex_cache/official_models"
    detector = model_root / "PP-OCRv5_mobile_det"
    recognizer = model_root / "PP-OCRv5_mobile_rec"
    with working_directory(OCR_ROOT):
        model_bundle_sha256 = verify_official_model_files(
            detector, recognizer, CPU_MANIFEST
        )
        engine = PaddleOCREngine(
            detection_model_dir=detector,
            recognition_model_dir=recognizer,
            cache_dir=OCR_ROOT / ".paddlex-cache",
            manifest_path=CPU_MANIFEST,
        )
        started = time.perf_counter()
        lines = engine.recognize(image, page_number=1)
        elapsed_seconds = time.perf_counter() - started
    return lines, engine.version, model_bundle_sha256, elapsed_seconds


def build_report() -> dict[str, object]:
    image_hash = sha256(IMAGE)
    rknn_lines = load_rknn_lines(RKNN_REPORT, image_hash)
    cpu_results, cpu_version, cpu_bundle_hash, cpu_elapsed = run_cpu_candidate(
        load_image(IMAGE)
    )
    cpu_lines = [str(line.text) for line in cpu_results]
    mean_confidence = sum(float(line.confidence) for line in cpu_results) / max(
        len(cpu_results), 1
    )
    return {
        "schema_version": REPORT_SCHEMA_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": REPORT_STATUS,
        "scope": REPORT_SCOPE,
        "ground_truth_available": False,
        "accuracy_claim_allowed": False,
        "product_selection_allowed": False,
        "hardware_measured": False,
        "host_timing_comparable_for_ranking": False,
        "authorized_health_report_data_used": False,
        "input": {
            "kind": "Rockchip bundled non-health OCR sample",
            "bytes": IMAGE.stat().st_size,
            "same_image_bytes_for_both_candidates": True,
            "preprocess_boundary": (
                "identical source image bytes; each candidate uses its frozen native "
                "preprocessing"
            ),
        },
        "source_hashes": {
            "image_sha256": image_hash,
            "cpu_manifest_sha256": sha256(CPU_MANIFEST),
            "rknn_simulator_report_sha256": sha256(RKNN_REPORT),
        },
        "candidates": {
            "ocr_paddle_cpu_ppocrv5": {
                "execution": "WINDOWS_X86_64_CPU_REAL_INFERENCE",
                "runtime_version": cpu_version,
                "model_bundle_sha256": cpu_bundle_hash,
                "line_count": len(cpu_lines),
                "normalized_text_sha256": text_digest(cpu_lines),
                "mean_model_confidence_not_accuracy": mean_confidence,
                "host_elapsed_seconds_single_run_not_ranking": cpu_elapsed,
            },
            "ocr_rknn_ppocrv4": {
                "execution": "X86_64_PC_SIMULATOR_FROM_FROZEN_ONNX",
                "exported_target_rknn_loaded": False,
                "model_bundle_sha256": (
                    "990970c4c8e34bdc9890bb56c10d1561b7a80dddddb83e69f674ad2f7aca3c7f"
                ),
                "line_count": len(rknn_lines),
                "normalized_text_sha256": text_digest(rknn_lines),
                "host_elapsed_seconds_single_run_not_ranking": None,
            },
        },
        "comparison": compare_line_outputs(cpu_lines, rknn_lines),
        "conclusion": {
            "result": "NO_PRODUCT_WINNER",
            "winner": None,
            "reasons": [
                "one bundled non-health sample has no reference ground truth",
                "RKNN evidence is a PC simulator rebuild and not target RKNN execution",
                "host timing is incomplete and cannot rank RK3566 performance",
                "authorized real report validation and named license approval are absent",
            ],
        },
    }


def main() -> int:
    report = build_report()
    errors = validate_report(
        report,
        image_path=IMAGE,
        cpu_manifest_path=CPU_MANIFEST,
        rknn_report_path=RKNN_REPORT,
    )
    if errors:
        raise RuntimeError(",".join(errors))
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    safe_summary = {
        "status": report["status"],
        "report": OUTPUT.relative_to(ROOT).as_posix(),
        "report_sha256": sha256(OUTPUT),
        "comparison": report["comparison"],
        "conclusion": report["conclusion"],
        "host": {"system": platform.system(), "machine": platform.machine()},
    }
    print(json.dumps(safe_summary, ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
