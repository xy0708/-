from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REQUIRED = ROOT / "expected" / "required_files.json"
REPORT = ROOT / "reports" / "workspace_verification.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    contract = json.loads(REQUIRED.read_text(encoding="utf-8"))
    missing = [relative for relative in contract["required"] if not (ROOT / relative).is_file()]
    scope = (ROOT / "configs" / "product_scope.yaml").read_text(encoding="utf-8")
    boundary_errors = []
    for required_text in (
        'medical_positioning: "NON_DIAGNOSTIC_HEALTH_MANAGEMENT"',
        "ml_disease_probability_enabled: false",
        "write_before_confirmation: false",
        "enabled: false",
    ):
        if required_text not in scope:
            boundary_errors.append(f"missing_scope_boundary:{required_text}")

    device = json.loads((ROOT / "configs" / "device_profile.json").read_text(encoding="utf-8"))
    device_truth_errors = []
    if device.get("hardware_measured") is not False:
        device_truth_errors.append("unverified_hardware_must_not_be_marked_measured")
    if device.get("simulated") is not False:
        device_truth_errors.append("device_profile_must_not_claim_simulation_as_evidence")

    tracked = [
        "EDGE_PRODUCTION_LOOP.md",
        "configs/product_scope.yaml",
        "configs/device_profile.json",
        "configs/acceptance_contract.json",
        "configs/privacy_config.yaml",
        "configs/component_contracts.json",
    ]
    hashes = {
        relative: sha256(ROOT / relative)
        for relative in tracked
        if (ROOT / relative).is_file()
    }
    passed = not missing and not boundary_errors and not device_truth_errors
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if passed else "FAIL",
        "product_complete": False,
        "hardware_measured": False,
        "missing": missing,
        "boundary_errors": boundary_errors,
        "device_truth_errors": device_truth_errors,
        "hashes": hashes,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
