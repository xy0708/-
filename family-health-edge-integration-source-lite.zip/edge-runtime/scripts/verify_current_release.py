from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from acceptance.paths import is_redirected
from release_tools import verify_product_release_bundle
from release_tools.bundle import RELEASE_ID


def canonical_current_release_id(link_target: str) -> str:
    if "\\" in link_target:
        raise ValueError("current release link is not canonical")
    target = PurePosixPath(link_target)
    if (
        target.is_absolute()
        or len(target.parts) != 2
        or target.parts[0] != "releases"
        or RELEASE_ID.fullmatch(target.parts[1]) is None
    ):
        raise ValueError("current release link is not canonical")
    return target.parts[1]


def resolve_current(current: Path, install_root: Path) -> Path:
    root_input = install_root.absolute()
    if is_redirected(root_input) or not root_input.is_dir():
        raise ValueError("install root is missing or redirected")
    root = root_input.resolve(strict=True)
    current_input = current.absolute()
    if current_input.name != "current" or current_input.parent != root:
        raise ValueError("current link is outside the install root")
    if not current_input.is_symlink():
        raise ValueError("current must be a symbolic link")
    canonical_current_release_id(os.readlink(current_input))
    releases_input = root / "releases"
    if is_redirected(releases_input) or not releases_input.is_dir():
        raise ValueError("releases directory is missing or redirected")
    releases = releases_input.resolve(strict=True)
    bundle = current_input.resolve(strict=True)
    if bundle.parent != releases or is_redirected(bundle):
        raise ValueError("current release escapes the controlled releases directory")
    return bundle


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--current", type=Path, required=True)
    parser.add_argument("--install-root", type=Path, required=True)
    parser.add_argument("--public-key", type=Path, required=True)
    args = parser.parse_args()
    try:
        bundle = resolve_current(args.current, args.install_root)
        result = verify_product_release_bundle(bundle, args.public_key)
    except (OSError, ValueError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}))
        return 2
    print(json.dumps(result.as_dict(), ensure_ascii=True))
    return 0 if result.passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
