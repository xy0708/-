from __future__ import annotations

import hashlib
import json
import re
import struct
from datetime import datetime, timezone
from pathlib import Path


EXPECTED_STATUS = "PASS_ENGINEERING_ARM64_TOOL_PRODUCT_BLOCKED"
EXPECTED_SMOKE = {
    "status": "PASS_ENGINEERING",
    "architecture": "aarch64",
    "network": "none",
    "global_python_required": False,
    "commands_imported": 5,
    "activation_round_trip": True,
}
REQUIRED_BLOCKERS = {
    "NAMED_RUNTIME_DISTRIBUTION_LEGAL_APPROVAL_REQUIRED",
    "REAL_RK3566_EXECUTION_REQUIRED",
    "PRODUCT_SIGNING_AND_PROVISIONING_REQUIRED",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def aggregate_hash(records: dict[str, str]) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(records.items()):
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(value.encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON_OBJECT_REQUIRED:{path.name}")
    return value


def safe_path(base: Path, relative: object, *, kind: str) -> Path | None:
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        return None
    candidate = base / relative
    try:
        resolved = candidate.resolve(strict=True)
    except OSError:
        return None
    if not resolved.is_relative_to(base.resolve()) or candidate.is_symlink():
        return None
    if kind == "file" and not candidate.is_file():
        return None
    if kind == "directory" and not candidate.is_dir():
        return None
    return candidate


def elf_metadata(path: Path) -> dict[str, int]:
    header = path.read_bytes()[:20]
    if len(header) < 20 or header[:4] != b"\x7fELF":
        raise ValueError("ARTIFACT_NOT_ELF")
    elf_class = header[4]
    endianness = header[5]
    if endianness == 1:
        machine = struct.unpack("<H", header[18:20])[0]
    elif endianness == 2:
        machine = struct.unpack(">H", header[18:20])[0]
    else:
        raise ValueError("ELF_ENDIANNESS_INVALID")
    return {
        "elf_class": 64 if elf_class == 2 else 32 if elf_class == 1 else 0,
        "elf_machine": machine,
        "elf_endianness": endianness,
    }


def add_error(errors: list[str], condition: bool, code: str) -> None:
    if not condition:
        errors.append(code)


def verify(root: Path) -> dict:
    errors: list[str] = []
    config_path = root / "configs" / "arm64_runtime_tool_build.json"
    latest_path = root / "reports" / "arm64_runtime_tool_build_latest.json"
    artifacts_root = root / "artifacts" / "arm64_runtime_tools"
    try:
        config = load_json(config_path)
        latest = load_json(latest_path)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        return verification_result(errors=[f"CONTROL_EVIDENCE_INVALID:{type(exc).__name__}"])

    add_error(errors, latest.get("status") == EXPECTED_STATUS, "LATEST_STATUS_INVALID")
    add_error(errors, latest.get("errors") == [], "LATEST_ERRORS_NOT_EMPTY")
    add_error(errors, latest.get("simulated") is True, "SIMULATION_BOUNDARY_MISSING")
    add_error(errors, latest.get("hardware_measured") is False, "HARDWARE_BOUNDARY_INVALID")
    add_error(errors, latest.get("product_accepted") is False, "PRODUCT_BOUNDARY_INVALID")
    add_error(
        errors,
        latest.get("formal_release_created") is False,
        "FORMAL_RELEASE_BOUNDARY_INVALID",
    )

    artifact_directory = safe_path(
        root, latest.get("artifact_directory", ""), kind="directory"
    )
    if (
        artifact_directory is None
        or not artifact_directory.resolve().is_relative_to(artifacts_root.resolve())
    ):
        errors.append("ARTIFACT_DIRECTORY_MISSING_OR_UNSAFE")
        return verification_result(errors=errors)
    try:
        manifest = load_json(artifact_directory / "manifest.json")
        sbom = load_json(artifact_directory / "sbom.json")
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        errors.append(f"ARTIFACT_METADATA_INVALID:{type(exc).__name__}")
        return verification_result(errors=errors)

    add_error(errors, manifest.get("status") == EXPECTED_STATUS, "MANIFEST_STATUS_INVALID")
    add_error(
        errors,
        manifest.get("build_id") == artifact_directory.name == latest.get("build_id"),
        "BUILD_ID_MISMATCH",
    )
    add_error(
        errors,
        manifest.get("target_platform") == config.get("target_platform") == "linux/arm64",
        "TARGET_PLATFORM_MISMATCH",
    )
    add_error(errors, manifest.get("base_image") == config.get("base_image"), "BASE_IMAGE_MISMATCH")
    add_error(errors, manifest.get("builder") == config.get("builder"), "BUILDER_LOCK_MISMATCH")

    artifact_record = manifest.get("artifact")
    artifact: Path | None = None
    if not isinstance(artifact_record, dict):
        errors.append("ARTIFACT_RECORD_INVALID")
    else:
        artifact = safe_path(
            artifact_directory, artifact_record.get("path"), kind="file"
        )
        if artifact is None:
            errors.append("ARTIFACT_MISSING_OR_UNSAFE")
        else:
            add_error(
                errors,
                artifact_record.get("path") == config.get("artifact_name"),
                "ARTIFACT_NAME_MISMATCH",
            )
            add_error(errors, artifact.stat().st_size == artifact_record.get("size"), "ARTIFACT_SIZE_MISMATCH")
            add_error(errors, sha256(artifact) == artifact_record.get("sha256"), "ARTIFACT_SHA256_MISMATCH")
            try:
                actual_elf = elf_metadata(artifact)
            except (OSError, ValueError) as exc:
                errors.append(str(exc))
            else:
                add_error(errors, actual_elf == {key: artifact_record.get(key) for key in actual_elf}, "ELF_METADATA_MISMATCH")
                add_error(errors, actual_elf["elf_class"] == 64, "ELF_CLASS_NOT_64")
                add_error(errors, actual_elf["elf_machine"] == config.get("target_elf_machine") == 183, "ELF_MACHINE_NOT_AARCH64")

    source_records = manifest.get("source_sha256")
    if not isinstance(source_records, dict) or not source_records:
        errors.append("SOURCE_LOCK_INVALID")
    else:
        for relative, expected in source_records.items():
            source = safe_path(root, relative, kind="file")
            if source is None:
                errors.append(f"SOURCE_MISSING_OR_UNSAFE:{relative}")
            elif not isinstance(expected, str) or sha256(source) != expected:
                errors.append(f"SOURCE_SHA256_MISMATCH:{relative}")
        add_error(
            errors,
            aggregate_hash(source_records) == manifest.get("source_aggregate_sha256") == latest.get("source_aggregate_sha256"),
            "SOURCE_AGGREGATE_MISMATCH",
        )

    wheelhouse = safe_path(root, config.get("wheelhouse"), kind="directory")
    wheel_records = config.get("wheels")
    wheel_hashes: dict[str, str] = {}
    if wheelhouse is None or not isinstance(wheel_records, list) or not wheel_records:
        errors.append("WHEELHOUSE_OR_LOCK_INVALID")
    else:
        expected_names: set[str] = set()
        for record in wheel_records:
            if not isinstance(record, dict):
                errors.append("WHEEL_RECORD_INVALID")
                continue
            name = record.get("file")
            if not isinstance(name, str) or Path(name).name != name or name in expected_names:
                errors.append("WHEEL_NAME_INVALID")
                continue
            expected_names.add(name)
            wheel = safe_path(wheelhouse, name, kind="file")
            if wheel is None:
                errors.append(f"WHEEL_MISSING_OR_UNSAFE:{name}")
                continue
            add_error(errors, wheel.stat().st_size == record.get("size"), f"WHEEL_SIZE_MISMATCH:{name}")
            actual_hash = sha256(wheel)
            add_error(errors, actual_hash == record.get("sha256"), f"WHEEL_SHA256_MISMATCH:{name}")
            if isinstance(record.get("sha256"), str):
                wheel_hashes[name] = record["sha256"]
        actual_names = {path.name for path in wheelhouse.glob("*.whl") if path.is_file()}
        add_error(errors, actual_names == expected_names, "WHEELHOUSE_FILE_SET_MISMATCH")
        add_error(
            errors,
            aggregate_hash(wheel_hashes) == manifest.get("wheel_aggregate_sha256") == latest.get("wheel_aggregate_sha256"),
            "WHEEL_AGGREGATE_MISMATCH",
        )

    sbom_path = artifact_directory / "sbom.json"
    add_error(errors, sha256(sbom_path) == manifest.get("sbom_sha256"), "SBOM_SHA256_MISMATCH")
    expected_sbom = [
        {
            "wheel": record.get("file"),
            "sha256": record.get("sha256"),
            "license": record.get("license"),
            "runtime_distribution_approved": False,
        }
        for record in wheel_records
        if isinstance(record, dict)
    ] if isinstance(wheel_records, list) else []
    add_error(errors, sbom.get("packages") == expected_sbom, "SBOM_PACKAGE_LOCK_MISMATCH")

    license_records = manifest.get("license_files")
    covered_wheels: set[str] = set()
    if not isinstance(license_records, list) or not license_records:
        errors.append("LICENSE_EVIDENCE_EMPTY")
    else:
        for record in license_records:
            if not isinstance(record, dict):
                errors.append("LICENSE_RECORD_INVALID")
                continue
            license_file = safe_path(artifact_directory, record.get("path"), kind="file")
            if license_file is None:
                errors.append("LICENSE_FILE_MISSING_OR_UNSAFE")
                continue
            add_error(errors, license_file.stat().st_size == record.get("size"), f"LICENSE_SIZE_MISMATCH:{record.get('path')}")
            add_error(errors, sha256(license_file) == record.get("sha256"), f"LICENSE_SHA256_MISMATCH:{record.get('path')}")
            if isinstance(record.get("wheel"), str):
                covered_wheels.add(record["wheel"])
        add_error(errors, covered_wheels == set(wheel_hashes), "LICENSE_WHEEL_COVERAGE_MISMATCH")

    add_error(errors, manifest.get("arm64_smoke") == EXPECTED_SMOKE == latest.get("arm64_smoke"), "ARM64_SMOKE_MISMATCH")
    add_error(errors, manifest.get("build_network") == "none", "BUILD_NETWORK_NOT_NONE")
    add_error(errors, manifest.get("global_python_required_at_runtime") is False, "GLOBAL_PYTHON_BOUNDARY_INVALID")
    add_error(errors, manifest.get("hardware_measured") is False, "MANIFEST_HARDWARE_BOUNDARY_INVALID")
    add_error(errors, manifest.get("product_accepted") is False, "MANIFEST_PRODUCT_BOUNDARY_INVALID")
    add_error(errors, manifest.get("formal_release_allowed") is False, "FORMAL_RELEASE_ALLOWED_INVALID")
    blockers = set(manifest.get("blockers", [])) if isinstance(manifest.get("blockers"), list) else set()
    add_error(errors, REQUIRED_BLOCKERS.issubset(blockers), "REQUIRED_BLOCKERS_MISSING")
    add_error(errors, set(latest.get("blockers", [])) == blockers, "LATEST_BLOCKERS_MISMATCH")
    add_error(errors, config.get("builder", {}).get("named_legal_approval") is False, "LEGAL_APPROVAL_BOUNDARY_INVALID")
    add_error(errors, re.fullmatch(r"python@sha256:[0-9a-f]{64}", str(config.get("base_image"))) is not None, "BASE_IMAGE_NOT_DIGEST_PINNED")

    artifact_relative = artifact.relative_to(root).as_posix() if artifact is not None else None
    artifact_hash = sha256(artifact) if artifact is not None else None
    return verification_result(
        errors=errors,
        build_id=manifest.get("build_id"),
        artifact_relative_path=artifact_relative,
        artifact_sha256=artifact_hash,
        blockers=sorted(blockers),
    )


def verification_result(
    *,
    errors: list[str],
    build_id: object = None,
    artifact_relative_path: str | None = None,
    artifact_sha256: str | None = None,
    blockers: list[str] | None = None,
) -> dict:
    return {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": EXPECTED_STATUS if not errors else "FAIL",
        "build_id": build_id,
        "artifact_relative_path": artifact_relative_path,
        "artifact_sha256": artifact_sha256,
        "simulated": True,
        "hardware_measured": False,
        "product_accepted": False,
        "formal_release_allowed": False,
        "errors": errors,
        "blockers": blockers or sorted(REQUIRED_BLOCKERS),
    }


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    result = verify(root)
    output = root / "reports" / "arm64_runtime_tool_verification.json"
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == EXPECTED_STATUS else 2


if __name__ == "__main__":
    raise SystemExit(main())
