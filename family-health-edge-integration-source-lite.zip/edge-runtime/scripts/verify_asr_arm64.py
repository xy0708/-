from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.asset_integrity import verify_file


WORKSPACE = ROOT.parent
ASR_ROOT = (
    WORKSPACE
    / "语音转文字"
    / "家庭健康语音转文字_Codex_Goal_Loop"
    / "health_asr_codex_loop"
)
MODEL_MANIFEST = ASR_ROOT / "models" / "sherpa" / "model_manifest.json"
LICENSE_REPORT = ASR_ROOT / "reports" / "v3_commercial_license_review.json"
REPORT = ROOT / "reports" / "asr_arm64_verification.json"
ARM64_ROOT = ROOT / "artifacts" / "arm64" / "sherpa-onnx"


def main() -> int:
    failures: list[str] = []
    if not MODEL_MANIFEST.is_file():
        failures.append("asr_model_manifest_missing")
        manifest = {"files": [], "model_dir": ""}
    else:
        manifest = json.loads(MODEL_MANIFEST.read_text(encoding="utf-8"))
    model_dir = ASR_ROOT / manifest.get("model_dir", "")
    checks = [
        verify_file(
            model_dir / item["name"],
            int(item["bytes"]),
            item["sha256"],
        )
        for item in manifest.get("files", [])
    ]
    if not checks or not all(item["passed"] for item in checks):
        failures.append("asr_model_asset_integrity_failed")

    license_engineering_passed = False
    legal_opinion = False
    if LICENSE_REPORT.is_file():
        license_report = json.loads(LICENSE_REPORT.read_text(encoding="utf-8"))
        license_engineering_passed = license_report.get("passed") is True
        legal_opinion = license_report.get("legal_opinion") is True
    if not license_engineering_passed:
        failures.append("asr_engineering_license_audit_missing_or_failed")

    expected_arm64 = (
        ARM64_ROOT / "bin" / "sherpa-onnx",
        ARM64_ROOT / "lib" / "libsherpa-onnx-c-api.so",
    )
    arm64_runtime_ready = all(path.is_file() for path in expected_arm64)
    device = json.loads((ROOT / "configs" / "device_profile.json").read_text(encoding="utf-8"))
    hardware_measured = device.get("hardware_measured") is True

    engineering_passed = not failures
    product_gate_passed = (
        engineering_passed
        and arm64_runtime_ready
        and hardware_measured
        and legal_opinion
    )
    report = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if engineering_passed else "FAIL",
        "source_model_integrity": checks,
        "license_engineering_passed": license_engineering_passed,
        "legal_opinion": legal_opinion,
        "arm64_runtime_ready": arm64_runtime_ready,
        "hardware_measured": hardware_measured,
        "product_gate": (
            "PASS_PRODUCT_GATE"
            if product_gate_passed
            else "BLOCKED_EXTERNAL_ARM64_HARDWARE_AND_FINAL_LICENSE_REQUIRED"
        ),
        "training_performed": False,
        "failures": failures,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))
    return 0 if engineering_passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
