from __future__ import annotations

import sys
from collections.abc import Callable

from scripts.activation_marker import main as activation_marker
from scripts.check_release_health import main as check_release_health
from scripts.check_rollback_transition import main as check_rollback_transition
from scripts.verify_current_release import main as verify_current_release
from scripts.verify_release_bundle import main as verify_release_bundle


Command = Callable[[], int]
COMMANDS: dict[str, Command] = {
    "activation-marker": activation_marker,
    "check-release-health": check_release_health,
    "check-rollback-transition": check_rollback_transition,
    "verify-current-release": verify_current_release,
    "verify-release-bundle": verify_release_bundle,
}


def main(argv: list[str] | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if not arguments or arguments[0] not in COMMANDS:
        print(
            "usage: family-health-edge-tool "
            "{" + ",".join(sorted(COMMANDS)) + "} [arguments...]",
            file=sys.stderr,
        )
        return 2
    command_name, *command_arguments = arguments
    previous = sys.argv
    sys.argv = [f"family-health-edge-tool {command_name}", *command_arguments]
    try:
        return COMMANDS[command_name]()
    finally:
        sys.argv = previous


if __name__ == "__main__":
    raise SystemExit(main())
