from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "android_app"
REPORT = ROOT / "reports" / "android_flutter_validation.json"
ANDROID_NAMESPACE = "{http://schemas.android.com/apk/res/android}"
ASR_CONFIG = ROOT / "configs" / "android_asr_candidate.json"


def hash_zip_member(archive: zipfile.ZipFile, member: str) -> str:
    digest = hashlib.sha256()
    with archive.open(member) as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def inspect_apk(apk: Path) -> dict:
    if not apk.is_file():
        return {
            "exists": False,
            "abis": [],
            "merged_permissions": [],
            "forbidden_permissions": [],
            "missing_required_permissions": [
                "android.permission.BLUETOOTH_CONNECT",
                "android.permission.BLUETOOTH_SCAN",
                "android.permission.RECORD_AUDIO",
            ],
            "forbidden_components": [],
            "privacy_flags_valid": False,
        }
    with zipfile.ZipFile(apk) as archive:
        names = set(archive.namelist())
        abis = sorted(
            {
                name.split("/")[1]
                for name in archive.namelist()
                if name.startswith("lib/") and name.endswith(".so")
            }
        )
        native_libraries = sorted(
            name for name in names if name.startswith("lib/arm64-v8a/") and name.endswith(".so")
        )
        asr_native_libraries = [
            name
            for name in native_libraries
            if "sherpa" in name.lower() or "onnxruntime" in name.lower()
        ]
        asr_config = json.loads(ASR_CONFIG.read_text(encoding="utf-8"))
        asset_prefix = asr_config["model"]["asset_prefix"]
        model_assets = {}
        for filename, expected in asr_config["model"]["files"].items():
            member = f"assets/flutter_assets/{asset_prefix}/{filename}"
            present = member in names
            actual_size = archive.getinfo(member).file_size if present else None
            actual_hash = hash_zip_member(archive, member) if present else None
            model_assets[filename] = {
                "member": member,
                "present": present,
                "bytes": actual_size,
                "sha256": actual_hash,
                "valid": bool(
                    present
                    and actual_size == expected["bytes"]
                    and actual_hash == expected["sha256"]
                ),
            }
        notice_assets = {
            path: f"assets/flutter_assets/{path}" in names
            for path in asr_config["licenses"]["notice_assets"]
        }
        asr_assets_valid = bool(
            all(asset["valid"] for asset in model_assets.values())
            and all(notice_assets.values())
            and asr_native_libraries
        )
    manifests = list(
        (APP / "build" / "app" / "intermediates" / "merged_manifests" / "debug").rglob(
            "AndroidManifest.xml"
        )
    )
    if len(manifests) != 1:
        return {
            "exists": True,
            "abis": abis,
            "merged_permissions": [],
            "forbidden_permissions": ["merged_manifest_missing_or_ambiguous"],
            "missing_required_permissions": [
                "android.permission.BLUETOOTH_CONNECT",
                "android.permission.BLUETOOTH_SCAN",
                "android.permission.RECORD_AUDIO",
            ],
            "forbidden_components": [],
            "privacy_flags_valid": False,
        }
    root = ET.parse(manifests[0]).getroot()
    permissions = sorted(
        {
            node.attrib.get(f"{ANDROID_NAMESPACE}name", "")
            for node in root.findall("uses-permission")
        }
        - {""}
    )
    forbidden_permission_names = {
        "android.permission.ACCESS_BACKGROUND_LOCATION",
        "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.MANAGE_EXTERNAL_STORAGE",
        "android.permission.READ_CONTACTS",
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.READ_PHONE_STATE",
        "android.permission.SCHEDULE_EXACT_ALARM",
        "android.permission.WRITE_EXTERNAL_STORAGE",
        "android.permission.WRITE_SETTINGS",
    }
    required_permission_names = {
        "android.permission.BLUETOOTH_SCAN",
        "android.permission.BLUETOOTH_CONNECT",
        "android.permission.RECORD_AUDIO",
    }
    application = root.find("application")
    forbidden_component_names = {
        "com.yucheng.ycbtsdk.upgrade.utils.NotificationActivity",
        "com.yucheng.ycbtsdk.upgrade.utils.DfuService",
        "org.eclipse.paho.android.service.MqttService",
    }
    component_names = set()
    if application is not None:
        for tag in ("activity", "service", "receiver", "provider"):
            component_names.update(
                node.attrib.get(f"{ANDROID_NAMESPACE}name", "")
                for node in application.findall(tag)
            )
    privacy_flags_valid = bool(
        application is not None
        and application.attrib.get(f"{ANDROID_NAMESPACE}allowBackup") == "false"
        and application.attrib.get(f"{ANDROID_NAMESPACE}usesCleartextTraffic") == "false"
        and application.attrib.get(f"{ANDROID_NAMESPACE}largeHeap") == "false"
        and f"{ANDROID_NAMESPACE}networkSecurityConfig" not in application.attrib
    )
    return {
        "exists": True,
        "abis": abis,
        "native_libraries": native_libraries,
        "asr_native_libraries": asr_native_libraries,
        "asr_model_assets": model_assets,
        "asr_notice_assets": notice_assets,
        "asr_assets_valid": asr_assets_valid,
        "merged_permissions": permissions,
        "forbidden_permissions": sorted(set(permissions) & forbidden_permission_names),
        "missing_required_permissions": sorted(required_permission_names - set(permissions)),
        "forbidden_components": sorted(component_names & forbidden_component_names),
        "privacy_flags_valid": privacy_flags_valid,
    }


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(name: str, command: list[str], timeout: int) -> dict:
    try:
        completed = subprocess.run(
            command,
            cwd=APP,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
        )
        return {
            "name": name,
            "command": command,
            "exit_code": completed.returncode,
            "timed_out": False,
            "stdout_tail": completed.stdout[-6000:],
            "stderr_tail": completed.stderr[-6000:],
        }
    except subprocess.TimeoutExpired as error:
        return {
            "name": name,
            "command": command,
            "exit_code": None,
            "timed_out": True,
            "stdout_tail": (error.stdout or "")[-6000:],
            "stderr_tail": (error.stderr or "")[-6000:],
        }


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    flutter = shutil.which("flutter") or r"C:\flutter\bin\flutter.bat"
    checks = [
        run("pub_get", [flutter, "pub", "get"], 300),
        run("analyze", [flutter, "analyze", "--no-pub"], 300),
        run("test", [flutter, "test", "--no-pub"], 300),
        run(
            "debug_arm64_apk",
            [
                flutter,
                "build",
                "apk",
                "--debug",
                "--target-platform",
                "android-arm64",
                "--no-pub",
            ],
            900,
        ),
    ]
    apk = APP / "build" / "app" / "outputs" / "flutter-apk" / "app-debug.apk"
    inspection = inspect_apk(apk)
    tracked_inputs = [
        "android_app/pubspec.yaml",
        "android_app/pubspec.lock",
        "android_app/lib/main.dart",
        "android_app/lib/watch_bridge.dart",
        "android_app/lib/health_rules.dart",
        "android_app/lib/asr_model_assets.dart",
        "android_app/lib/asr_runtime.dart",
        "android_app/lib/asr_microphone.dart",
        "android_app/assets/asr_candidate.json",
        "android_app/android/app/build.gradle.kts",
        "android_app/android/app/src/main/AndroidManifest.xml",
        "android_app/android/app/src/main/kotlin/com/familyhealth/edge/family_health_edge_android/MainActivity.kt",
        "android_app/android/app/src/main/kotlin/com/familyhealth/edge/family_health_edge_android/ModelAssetChannel.kt",
        "configs/android_asr_candidate.json",
        "android_app/test/asr_microphone_test.dart",
    ]
    input_hashes = {
        relative: sha256(ROOT / relative)
        for relative in tracked_inputs
        if (ROOT / relative).is_file()
    }
    passed = bool(
        all(check["exit_code"] == 0 for check in checks)
        and apk.is_file()
        and inspection["abis"] == ["arm64-v8a"]
        and inspection["asr_assets_valid"]
        and not inspection["forbidden_permissions"]
        and not inspection["missing_required_permissions"]
        and not inspection["forbidden_components"]
        and inspection["privacy_flags_valid"]
    )
    payload = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING_DEBUG_APK" if passed else "FAIL_ENGINEERING",
        "product_release": False,
        "debug_signed": True if apk.is_file() else None,
        "hardware_measured": False,
        "input_hashes": input_hashes,
        "checks": checks,
        "apk_inspection": inspection,
        "apk": {
            "path": "android_app/build/app/outputs/flutter-apk/app-debug.apk",
            "exists": apk.is_file(),
            "bytes": apk.stat().st_size if apk.is_file() else None,
            "sha256": sha256(apk) if apk.is_file() else None,
        },
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
