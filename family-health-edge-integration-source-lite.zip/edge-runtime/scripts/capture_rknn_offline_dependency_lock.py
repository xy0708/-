from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
APT_DIR = ROOT / "artifacts" / "rknn_converter_dependencies" / "apt"
PIP_DIR = ROOT / "artifacts" / "rknn_converter_dependencies" / "pip"
MANIFEST = ROOT / "artifacts" / "rknn_converter_dependencies" / "manifest.json"
DOCKERFILE = ROOT / "conversion" / "toolchain" / "Dockerfile.offline-ubuntu20.04-cp38-rknn2.3.2"
PIP_LOCK = ROOT / "conversion" / "toolchain" / "pip-requirements.lock.txt"
TOOLKIT_DIR = (
    ROOT
    / "vendor"
    / "rockchip"
    / "rknn-toolkit2"
    / "rknn-toolkit2"
    / "docker"
    / "docker_file"
    / "ubuntu_20_04_cp38"
)
TOOLKIT_WHEEL = (
    TOOLKIT_DIR
    / "rknn_toolkit2-2.3.2-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl"
)
REPORT = ROOT / "reports" / "rknn_offline_dependency_lock.json"
RUNS = ROOT / "reports" / "rknn_offline_dependency_lock_runs"

BASE_IMAGE = "family-health-base:ubuntu20.04-amd64-8feb4d8c"
BASE_IMAGE_ID = "sha256:8feb4d8ca5354def3d8fce243717141ce31e2c428701f6682bd2fafe15388214"
REFERENCE_IMAGE = "family-health-rknn-converter:2.3.2-cp38"
OFFLINE_IMAGE = "family-health-rknn-converter:2.3.2-cp38-offline-lock-v1"
REFERENCE_IMAGE_ID = "sha256:7f9aada37e75721b62de280c087d4457c2d9356afc47d7518aa5efdbf627f18e"
TOOLKIT_WHEEL_SHA256 = "64442c852ef4bdf6a8b0ac35426a592c157c9365198d306078548359b030a90a"
EXPECTED_APT_ARTIFACTS = 103
EXPECTED_PIP_ARTIFACTS = 20
MAX_IMAGE_GROWTH_BYTES = 64 * 1024 * 1024


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def file_record(path: Path, kind: str) -> dict[str, Any]:
    resolved = path.resolve()
    resolved.relative_to(ROOT.resolve())
    if not resolved.is_file() or resolved.is_symlink():
        raise ValueError(f"unsafe or missing file: {path}")
    return {
        "kind": kind,
        "path": resolved.relative_to(ROOT.resolve()).as_posix(),
        "bytes": resolved.stat().st_size,
        "sha256": sha256(resolved),
    }


def dependency_records() -> list[dict[str, Any]]:
    records = [file_record(path, "apt_deb") for path in sorted(APT_DIR.glob("*.deb"))]
    records.extend(file_record(path, "pip_wheel") for path in sorted(PIP_DIR.glob("*.whl")))
    records.extend(
        (
            file_record(TOOLKIT_WHEEL, "rknn_toolkit2_wheel"),
            file_record(DOCKERFILE, "offline_dockerfile"),
            file_record(PIP_LOCK, "pip_requirements_lock"),
        )
    )
    return records


def find_docker() -> str:
    configured = os.environ.get("FAMILY_HEALTH_DOCKER")
    candidates = [
        configured,
        shutil.which("docker"),
        r"C:\Program Files\Docker\Docker\resources\bin\docker.exe",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(Path(candidate))
    raise RuntimeError("Docker CLI was not found")


def run_checked(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=ROOT,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=True,
    )


def inspect_image(docker: str, image: str) -> dict[str, Any]:
    completed = run_checked([docker, "image", "inspect", image])
    payload = json.loads(completed.stdout)
    if not isinstance(payload, list) or len(payload) != 1:
        raise RuntimeError(f"unexpected docker inspect response for {image}")
    return payload[0]


def image_lines(docker: str, image: str, command: list[str]) -> list[str]:
    completed = run_checked([docker, "run", "--rm", "--network", "none", image, *command])
    return sorted(line.strip() for line in completed.stdout.splitlines() if line.strip())


def portable_command(command: list[str]) -> list[str]:
    root = str(ROOT.resolve())
    return [item.replace(root, ".") for item in command]


def build_offline_image(docker: str, log_path: Path) -> list[str]:
    command = [
        docker,
        "build",
        "--no-cache",
        "--network",
        "none",
        "--progress",
        "plain",
        "--build-context",
        f"apt_lock={APT_DIR}",
        "--build-context",
        f"pip_lock={PIP_DIR}",
        "--build-context",
        f"toolkit_lock={TOOLKIT_DIR}",
        "-f",
        str(DOCKERFILE),
        "-t",
        OFFLINE_IMAGE,
        str(DOCKERFILE.parent),
    ]
    log_path.parent.mkdir(parents=True, exist_ok=False)
    with log_path.open("w", encoding="utf-8", newline="\n") as log:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
        assert process.stdout is not None
        for line in process.stdout:
            log.write(line)
            if line.startswith("#") and ("DONE" in line or "ERROR" in line or "exporting" in line):
                print(line.rstrip(), flush=True)
        return_code = process.wait()
    if return_code != 0:
        raise RuntimeError(f"offline docker build failed with exit code {return_code}")
    return portable_command(command)


def main() -> int:
    parser = argparse.ArgumentParser(description="Capture a fail-closed offline RKNN dependency lock")
    parser.add_argument(
        "--rebuild",
        action="store_true",
        help="perform a network-disabled, no-cache Docker rebuild before capture",
    )
    args = parser.parse_args()

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = RUNS / run_id
    build_log = run_dir / "build.log"
    errors: list[str] = []
    build_command: list[str] = []
    records_before: list[dict[str, Any]] = []
    records_after: list[dict[str, Any]] = []
    manifest_record: dict[str, Any] | None = None
    build_log_record: dict[str, Any] | None = None
    comparison: dict[str, Any] = {}
    images: dict[str, Any] = {}
    smoke_output: list[str] = []

    try:
        docker = find_docker()
        records_before = dependency_records()
        apt_count = sum(record["kind"] == "apt_deb" for record in records_before)
        pip_count = sum(record["kind"] == "pip_wheel" for record in records_before)
        if apt_count != EXPECTED_APT_ARTIFACTS:
            errors.append(f"APT_ARTIFACT_COUNT:{apt_count}")
        if pip_count != EXPECTED_PIP_ARTIFACTS:
            errors.append(f"PIP_ARTIFACT_COUNT:{pip_count}")
        toolkit_record = next(
            record for record in records_before if record["kind"] == "rknn_toolkit2_wheel"
        )
        if toolkit_record["sha256"] != TOOLKIT_WHEEL_SHA256:
            errors.append("TOOLKIT_WHEEL_HASH_MISMATCH")

        base = inspect_image(docker, BASE_IMAGE)
        reference = inspect_image(docker, REFERENCE_IMAGE)
        if base.get("Id") != BASE_IMAGE_ID:
            errors.append("BASE_IMAGE_ID_MISMATCH")
        if reference.get("Id") != REFERENCE_IMAGE_ID:
            errors.append("REFERENCE_IMAGE_ID_MISMATCH")

        if not args.rebuild:
            errors.append("NO_FRESH_OFFLINE_REBUILD")
        else:
            build_command = build_offline_image(docker, build_log)
            build_log_record = file_record(build_log, "offline_build_log")

        offline = inspect_image(docker, OFFLINE_IMAGE)
        images = {
            "base": {"name": BASE_IMAGE, "id": base.get("Id"), "bytes": base.get("Size")},
            "reference": {
                "name": REFERENCE_IMAGE,
                "id": reference.get("Id"),
                "bytes": reference.get("Size"),
            },
            "offline_rebuild": {
                "name": OFFLINE_IMAGE,
                "id": offline.get("Id"),
                "bytes": offline.get("Size"),
            },
        }
        if not isinstance(offline.get("Id"), str) or not offline["Id"].startswith("sha256:"):
            errors.append("INVALID_OFFLINE_IMAGE_ID")
        if not isinstance(offline.get("Size"), int) or offline["Size"] > reference["Size"] + MAX_IMAGE_GROWTH_BYTES:
            errors.append("OFFLINE_IMAGE_SIZE_REGRESSION")

        old_dpkg = image_lines(
            docker,
            REFERENCE_IMAGE,
            ["dpkg-query", "-W", "-f=${binary:Package}==${Version}\n"],
        )
        new_dpkg = image_lines(
            docker,
            OFFLINE_IMAGE,
            ["dpkg-query", "-W", "-f=${binary:Package}==${Version}\n"],
        )
        old_pip = image_lines(docker, REFERENCE_IMAGE, ["python3", "-m", "pip", "freeze", "--all"])
        new_pip = image_lines(docker, OFFLINE_IMAGE, ["python3", "-m", "pip", "freeze", "--all"])
        comparison = {
            "reference_dpkg_packages": len(old_dpkg),
            "offline_dpkg_packages": len(new_dpkg),
            "dpkg_exact_match": old_dpkg == new_dpkg,
            "dpkg_only_reference": sorted(set(old_dpkg) - set(new_dpkg)),
            "dpkg_only_offline": sorted(set(new_dpkg) - set(old_dpkg)),
            "reference_pip_packages": len(old_pip),
            "offline_pip_packages": len(new_pip),
            "pip_exact_match": old_pip == new_pip,
            "pip_only_reference": sorted(set(old_pip) - set(new_pip)),
            "pip_only_offline": sorted(set(new_pip) - set(old_pip)),
        }
        if not comparison["dpkg_exact_match"]:
            errors.append("DPKG_PACKAGE_SET_MISMATCH")
        if not comparison["pip_exact_match"]:
            errors.append("PIP_PACKAGE_SET_MISMATCH")

        smoke_output = image_lines(
            docker,
            OFFLINE_IMAGE,
            [
                "sh",
                "-ceu",
                "test -z \"$(dpkg --audit)\"; "
                "python3 -m pip check; "
                "python3 -c \"import importlib.metadata as m; "
                "from rknn.api import RKNN; "
                "print('python=3.8.10'); "
                "print('rknn-toolkit2=' + m.version('rknn-toolkit2')); "
                "print('rknn-import=PASS')\"",
            ],
        )
        expected_smoke = {
            "No broken requirements found.",
            "python=3.8.10",
            "rknn-toolkit2=2.3.2",
            "rknn-import=PASS",
        }
        if not expected_smoke.issubset(smoke_output):
            errors.append("OFFLINE_IMAGE_SMOKE_FAILED")

        records_after = dependency_records()
        if records_after != records_before:
            errors.append("DEPENDENCY_ARTIFACTS_CHANGED_DURING_BUILD")
        manifest_payload = {
            "schema_version": "1.0.0",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "artifact_counts": {
                "apt_deb": apt_count,
                "pip_wheel": pip_count,
                "rknn_toolkit2_wheel": 1,
                "build_inputs": 2,
                "total": len(records_after),
            },
            "total_bytes": sum(record["bytes"] for record in records_after),
            "artifacts": records_after,
        }
        MANIFEST.write_text(
            json.dumps(manifest_payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        manifest_record = file_record(MANIFEST, "dependency_manifest")
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        errors.append(f"CAPTURE_FAILED:{type(exc).__name__}:{exc}")

    report = {
        "schema_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "run_id": run_id,
        "status": "PASS_ENGINEERING_OFFLINE_DEPENDENCY_LOCK" if not errors else "FAIL",
        "scope": "RKNN Toolkit2 host conversion environment only",
        "network_mode": "none",
        "no_cache": True,
        "fresh_rebuild_executed": bool(args.rebuild and build_command),
        "dependency_artifact_hash_lock_complete": not errors,
        "build_command": build_command,
        "manifest": manifest_record,
        "build_log": build_log_record,
        "images": images,
        "comparison": comparison,
        "smoke_output": smoke_output,
        "hardware_measured": False,
        "real_rk3566_verified": False,
        "formal_release_allowed": False,
        "errors": errors,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
