from __future__ import annotations

import json
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "environment_report.json"
TOOLS = ("python", "git", "cmake", "gcc", "clang", "ssh", "wsl")


def first_version_line(executable: str) -> str | None:
    try:
        result = subprocess.run(
            [executable, "--version"],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    raw = result.stdout or result.stderr or b""
    text = raw.decode("utf-8", errors="replace").strip()
    return text.splitlines()[0] if text else None


def main() -> int:
    tools: dict[str, dict[str, str | None]] = {}
    for name in TOOLS:
        executable = shutil.which(name)
        tools[name] = {
            "path": executable,
            "version": first_version_line(executable) if executable else None,
        }

    payload = {
        "schema_version": "1.0.0",
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "host": {
            "platform": platform.platform(),
            "machine": platform.machine(),
            "python_version": platform.python_version(),
            "python_executable": sys.executable,
        },
        "tools": tools,
        "target": "RK3566_ARM64_LINUX_4GB",
        "hardware_measured": False,
        "simulated": False,
        "device_status": "BLOCKED_EXTERNAL_REAL_DEVICE_REQUIRED",
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(payload, ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
