from __future__ import annotations

import json
import os
import sys
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

import cv2
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.ocr_synthetic_batch import (
    REPORT_SCOPE,
    REPORT_STATUS,
    aggregate_sample_scores,
    score_extracted_indicators,
    sha256,
    validate_report,
)
from benchmarks.comparison.text import text_digest


OCR_ROOT = ROOT.parent / "OCR"
OCR_SOURCE = OCR_ROOT / "src"
GROUND_TRUTH = OCR_ROOT / "data/synthetic/synthetic_ground_truth.json"
CPU_MANIFEST = OCR_ROOT / "models/official_pretrained/manifest.json"
HEALTH_DICTIONARY = OCR_ROOT / "configs/health_indicator_dictionary.json"
RKNN_BATCH = ROOT / "reports/rknn_simulation_ppocrv4_synthetic_batch.json"
OUTPUT = ROOT / "reports/ocr_synthetic_candidate_comparison.json"
EXPECTED_SIMULATOR_IMAGE_ID = (
    "sha256:8e4d42a783beabb42f820013060eb5ff0eb5e59f43d803848bb901274ae9faaf"
)


@contextmanager
def working_directory(path: Path) -> Iterator[None]:
    previous = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(previous)


def load_image(path: Path) -> np.ndarray:
    image = cv2.imdecode(
        np.frombuffer(path.read_bytes(), dtype=np.uint8), cv2.IMREAD_COLOR
    )
    if image is None or image.ndim != 3:
        raise RuntimeError(f"SYNTHETIC_IMAGE_UNREADABLE:{path.name}")
    return image


def load_inputs() -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    ground_truth = json.loads(GROUND_TRUTH.read_text(encoding="utf-8"))
    if (
        ground_truth.get("scope") != "synthetic_engineering_only"
        or ground_truth.get("formal_training_allowed") is not False
        or ground_truth.get("formal_evaluation_allowed") is not False
        or ground_truth.get("source") != "locally_generated_no_real_person_data"
    ):
        raise RuntimeError("SYNTHETIC_GROUND_TRUTH_BOUNDARY_INVALID")
    indicators = ground_truth.get("indicators")
    artifacts = ground_truth.get("artifacts")
    if not isinstance(indicators, list) or not indicators:
        raise RuntimeError("SYNTHETIC_INDICATORS_INVALID")
    if not isinstance(artifacts, list):
        raise RuntimeError("SYNTHETIC_ARTIFACTS_INVALID")
    rasters: list[dict[str, Any]] = []
    for artifact in artifacts:
        if not isinstance(artifact, dict):
            raise RuntimeError("SYNTHETIC_ARTIFACT_INVALID")
        path = OCR_ROOT / str(artifact.get("path", ""))
        if path.suffix.lower() not in {".png", ".jpg", ".jpeg"}:
            continue
        if (
            artifact.get("synthetic_engineering_only") is not True
            or not path.is_file()
            or sha256(path) != artifact.get("sha256")
        ):
            raise RuntimeError(f"SYNTHETIC_ARTIFACT_INVALID:{path.name}")
        rasters.append({**artifact, "absolute_path": path})
    if len(rasters) < 2:
        raise RuntimeError("SYNTHETIC_RASTER_SET_TOO_SMALL")

    rknn = json.loads(RKNN_BATCH.read_text(encoding="utf-8"))
    samples = rknn.get("samples")
    expected = {item["absolute_path"].name: item["sha256"] for item in rasters}
    actual = {
        item.get("sample_id"): item.get("image_sha256")
        for item in samples
        if isinstance(item, dict)
    } if isinstance(samples, list) else {}
    if (
        rknn.get("status")
        != "PASS_ENGINEERING_SYNTHETIC_BATCH_SIMULATION_PRODUCT_BLOCKED"
        or rknn.get("scope")
        != "SYNTHETIC_ENGINEERING_IMAGES_ONLY_NOT_PRODUCT_METRICS"
        or rknn.get("simulator_image_id") != EXPECTED_SIMULATOR_IMAGE_ID
        or rknn.get("network_disabled") is not True
        or rknn.get("hardware_measured") is not False
        or rknn.get("product_accuracy_claim_allowed") is not False
        or rknn.get("product_selection_allowed") is not False
        or rknn.get("exported_target_rknn_loaded") is not False
        or rknn.get("preprocessing")
        != {
            "strategy": "overlapping_tiles_then_global_iou_deduplication",
            "tile_size_pixels": 720,
            "tile_overlap_pixels": 120,
            "model_input_pixels": [480, 480],
            "deduplication_iou_threshold": 0.5,
            "full_page_downscale_forbidden": True,
        }
        or rknn.get("failures") != []
        or actual != expected
    ):
        raise RuntimeError("RKNN_SYNTHETIC_BATCH_BOUNDARY_INVALID")
    return indicators, rasters, rknn


def build_provenance(
    source_hash: str, engine: str, version: str, dictionary_hash: str
):
    from health_ocr.schemas import Provenance

    return Provenance(
        source_sha256=source_hash,
        ocr_engine=engine,
        ocr_engine_version=version,
        preprocessing_version="ocr-synthetic-candidate-comparison-1.0.0",
        dictionary_sha256=dictionary_hash,
        synthetic_engineering_only=True,
    )


def score_lines(
    lines: list[Any], expected: list[dict[str, Any]], provenance: Any
) -> dict[str, Any]:
    from health_ocr.indicator_extractor import extract_indicators
    from health_ocr.layout_analysis import analyze_layout

    layout = analyze_layout(lines)
    extracted = extract_indicators(layout.ordered_lines, provenance)
    return {
        "metrics": score_extracted_indicators(extracted, expected),
        "extracted_indicator_count": len(extracted),
        "layout_table_like": layout.table_like,
    }


def cpu_samples(
    artifacts: list[dict[str, Any]], expected: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], str, str]:
    if str(OCR_SOURCE) not in sys.path:
        sys.path.insert(0, str(OCR_SOURCE))
    os.environ["PADDLE_PDX_CACHE_HOME"] = str(OCR_ROOT / ".paddlex-cache")
    from health_ocr.ocr_engine import PaddleOCREngine, verify_official_model_files

    model_root = OCR_ROOT / "models/official_pretrained/paddlex_cache/official_models"
    detector = model_root / "PP-OCRv5_mobile_det"
    recognizer = model_root / "PP-OCRv5_mobile_rec"
    with working_directory(OCR_ROOT):
        model_hash = verify_official_model_files(detector, recognizer, CPU_MANIFEST)
        engine = PaddleOCREngine(
            detection_model_dir=detector,
            recognition_model_dir=recognizer,
            cache_dir=OCR_ROOT / ".paddlex-cache",
            manifest_path=CPU_MANIFEST,
        )
        results: list[dict[str, Any]] = []
        for artifact in artifacts:
            path = artifact["absolute_path"]
            started = time.perf_counter()
            try:
                lines = engine.recognize(load_image(path), page_number=1)
                scored = score_lines(
                    lines,
                    expected,
                    build_provenance(
                        artifact["sha256"],
                        "ocr_paddle_cpu_ppocrv5",
                        engine.version,
                        sha256(HEALTH_DICTIONARY),
                    ),
                )
            except Exception as exc:  # Failed samples remain in the denominator.
                lines = []
                scored = {"metrics": score_extracted_indicators([], expected)}
                status = "FAIL_ENGINEERING_INFERENCE"
                error_type = type(exc).__name__
            else:
                status = "PASS_ENGINEERING_INFERENCE"
                error_type = None
            results.append(
                {
                    "sample_id": path.name,
                    "transformation": artifact["transformation"],
                    "status": status,
                    "error_type": error_type,
                    "elapsed_seconds_host_not_for_ranking": time.perf_counter()
                    - started,
                    "raw_line_count": len(lines),
                    "normalized_text_sha256": text_digest(
                        [str(line.text) for line in lines]
                    ),
                    **scored,
                }
            )
    return results, engine.version, model_hash


def rknn_samples(
    artifacts: list[dict[str, Any]],
    expected: list[dict[str, Any]],
    batch: dict[str, Any],
) -> list[dict[str, Any]]:
    if str(OCR_SOURCE) not in sys.path:
        sys.path.insert(0, str(OCR_SOURCE))
    from health_ocr.schemas import OCRLine

    by_name = {item["sample_id"]: item for item in batch["samples"]}
    results: list[dict[str, Any]] = []
    for artifact in artifacts:
        path = artifact["absolute_path"]
        source = by_name[path.name]["rknn_simulator"]
        try:
            lines = [
                OCRLine(
                    text=item["text"],
                    confidence=item["confidence"],
                    source_page=1,
                    source_box=item["source_box"],
                )
                for item in source["lines"]
            ]
            scored = score_lines(
                lines,
                expected,
                build_provenance(
                    artifact["sha256"],
                    "ocr_rknn_ppocrv4_pc_simulator",
                    "rknn-toolkit2-2.3.2",
                    sha256(HEALTH_DICTIONARY),
                ),
            )
        except Exception as exc:
            lines = []
            scored = {"metrics": score_extracted_indicators([], expected)}
            status = "FAIL_ENGINEERING_INFERENCE"
            error_type = type(exc).__name__
        else:
            status = str(source["status"])
            error_type = source["error_type"]
        results.append(
            {
                "sample_id": path.name,
                "transformation": artifact["transformation"],
                "status": status,
                "error_type": error_type,
                "elapsed_seconds_host_not_for_ranking": source[
                    "elapsed_seconds_host_not_for_ranking"
                ],
                "raw_line_count": len(lines),
                "normalized_text_sha256": text_digest(
                    [str(line.text) for line in lines]
                ),
                **scored,
            }
        )
    return results


def main() -> int:
    expected, artifacts, batch = load_inputs()
    cpu, cpu_version, cpu_model_hash = cpu_samples(artifacts, expected)
    rknn = rknn_samples(artifacts, expected, batch)
    cpu_aggregate = aggregate_sample_scores(cpu)
    rknn_aggregate = aggregate_sample_scores(rknn)
    observed = (
        "ocr_paddle_cpu_ppocrv5"
        if (
            cpu_aggregate["field_exact_match_rate"],
            cpu_aggregate["required_field_recall"],
        )
        > (
            rknn_aggregate["field_exact_match_rate"],
            rknn_aggregate["required_field_recall"],
        )
        else "ocr_rknn_ppocrv4"
        if (
            rknn_aggregate["field_exact_match_rate"],
            rknn_aggregate["required_field_recall"],
        )
        > (
            cpu_aggregate["field_exact_match_rate"],
            cpu_aggregate["required_field_recall"],
        )
        else "tie"
    )
    source_hashes = {
        "synthetic_ground_truth_sha256": sha256(GROUND_TRUTH),
        "cpu_manifest_sha256": sha256(CPU_MANIFEST),
        "health_dictionary_sha256": sha256(HEALTH_DICTIONARY),
        "rknn_batch_report_sha256": sha256(RKNN_BATCH),
    }
    report = {
        "schema_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": REPORT_STATUS,
        "scope": REPORT_SCOPE,
        "product_acceptance_evidence": False,
        "formal_data_used": False,
        "authorized_health_report_data_used": False,
        "hardware_measured": False,
        "product_selection_allowed": False,
        "accuracy_claim_allowed": False,
        "host_timing_comparable_for_ranking": False,
        "same_image_bytes": True,
        "candidate_native_preprocessing": True,
        "common_layout_and_indicator_postprocess": True,
        "failures_included_in_denominator": True,
        "source_hashes": source_hashes,
        "dataset": {
            "sample_count": len(artifacts),
            "expected_fields_per_sample": len(expected),
            "synthetic": True,
            "real_person_data": False,
            "commercial_product_selection_allowed": False,
        },
        "candidates": {
            "ocr_paddle_cpu_ppocrv5": {
                "execution": "WINDOWS_X86_64_CPU_REAL_INFERENCE",
                "runtime_version": cpu_version,
                "model_bundle_sha256": cpu_model_hash,
                "samples": cpu,
                "aggregate": cpu_aggregate,
            },
            "ocr_rknn_ppocrv4": {
                "execution": "X86_64_PC_SIMULATOR_FROM_FROZEN_ONNX",
                "runtime_version": "rknn-toolkit2-2.3.2",
                "exported_target_rknn_loaded": False,
                "simulator_image_id": EXPECTED_SIMULATOR_IMAGE_ID,
                "samples": rknn,
                "aggregate": rknn_aggregate,
            },
        },
        "comparison": {
            "synthetic_engineering_observation_only": observed,
            "field_exact_match_rate_delta_rknn_minus_cpu": rknn_aggregate[
                "field_exact_match_rate"
            ]
            - cpu_aggregate["field_exact_match_rate"],
            "required_field_recall_delta_rknn_minus_cpu": rknn_aggregate[
                "required_field_recall"
            ]
            - cpu_aggregate["required_field_recall"],
        },
        "conclusion": {
            "result": "NO_PRODUCT_WINNER",
            "winner": None,
            "reasons": [
                "synthetic reports are not authorized real health-report validation",
                "the RKNN evidence rebuilds from ONNX in a PC simulator",
                "host timing cannot rank RK3566 performance",
                "selection thresholds, license approval and real-device evidence are absent",
            ],
        },
    }
    errors = validate_report(report, source_hashes)
    if errors:
        raise RuntimeError(",".join(errors))
    temporary = OUTPUT.with_suffix(".tmp")
    temporary.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    temporary.replace(OUTPUT)
    print(
        json.dumps(
            {
                "status": report["status"],
                "samples": len(artifacts),
                "cpu": cpu_aggregate,
                "rknn": rknn_aggregate,
                "conclusion": report["conclusion"],
                "report_sha256": sha256(OUTPUT),
            },
            ensure_ascii=True,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
