from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_rknn_conversion_reproducibility import (
    CASES,
    DEFAULT_IMAGE,
    EXPECTED_IMAGE_ID,
    sha256,
)
from scripts.run_rknn_exported_artifact_capability_probe import (
    PROBE,
    REPORT,
    expected_models,
    validate_inner_report,
)


OUTPUT = ROOT / "reports" / "rknn_exported_artifact_capability_verification.json"


def evaluate(value: dict[str, object]) -> list[str]:
    errors: list[str] = []
    if value.get("schema_version") != "1.0.0":
        errors.append("SCHEMA_INVALID")
    if value.get("status") != "PASS_ENGINEERING_CAPABILITY_LIMIT_CONFIRMED_PRODUCT_BLOCKED":
        errors.append("STATUS_INVALID")
    if value.get("scope") != "EXPORTED_RKNN_PC_SIMULATOR_CAPABILITY_ONLY":
        errors.append("SCOPE_INVALID")
    if (
        value.get("image") != DEFAULT_IMAGE
        or value.get("expected_image_id") != EXPECTED_IMAGE_ID
        or value.get("actual_image_id") != EXPECTED_IMAGE_ID
        or value.get("image_id_matches") is not True
    ):
        errors.append("CONVERSION_IMAGE_IDENTITY_INVALID")
    expected_flags = {
        "network_disabled": True,
        "hardware_measured": False,
        "product_selection_allowed": False,
        "pc_simulator_exported_rknn_inference_supported": False,
        "target_device_required_for_artifact_equivalence": True,
        "temporary_artifacts_deleted": True,
    }
    for name, expected in expected_flags.items():
        if value.get(name) is not expected:
            errors.append(f"FLAG_INVALID:{name}")
    if value.get("probe_exit_code") != 2:
        errors.append("PROBE_EXIT_CODE_INVALID")
    if value.get("errors") != []:
        errors.append("PROBE_REPORTED_ERRORS")

    command = value.get("command")
    if not isinstance(command, list):
        errors.append("COMMAND_INVALID")
    else:
        rendered = [str(item) for item in command]
        if "run" not in rendered or "--rm" not in rendered:
            errors.append("COMMAND_CONTAINER_LIFECYCLE_INVALID")
        if "--network" not in rendered or "none" not in rendered:
            errors.append("COMMAND_NOT_NETWORK_ISOLATED")
        if "{PROJECT}:/workspace:ro" not in rendered:
            errors.append("PROJECT_MOUNT_NOT_READ_ONLY")
        if "{RESEARCH}:/research:ro" not in rendered:
            errors.append("RESEARCH_MOUNT_NOT_READ_ONLY")
        if "{TEMP}:/evidence" not in rendered:
            errors.append("EVIDENCE_MOUNT_NOT_ISOLATED")

    inner = {
        "schema_version": "1.0.0",
        "status": "PC_SIMULATOR_EXPORTED_RKNN_INFERENCE_UNSUPPORTED",
        "runtime": {"name": "rknn-toolkit2", "version": "2.3.2"},
        "records": value.get("records"),
    }
    errors.extend(validate_inner_report(inner))

    source_hashes = value.get("source_sha256")
    if not isinstance(source_hashes, dict):
        errors.append("SOURCE_HASHES_INVALID")
    else:
        expected_sources = {
            PROBE.relative_to(ROOT).as_posix(): sha256(PROBE),
            **{
                case.canonical_output: sha256(expected_models()[case.name])
                for case in CASES
            },
        }
        if source_hashes != expected_sources:
            errors.append("SOURCE_HASH_MISMATCH")

    log_name = value.get("log")
    log_path = ROOT / str(log_name) if isinstance(log_name, str) else None
    if (
        log_path is None
        or not log_path.is_file()
        or not log_path.resolve().is_relative_to(ROOT.resolve())
        or value.get("log_sha256") != sha256(log_path)
    ):
        errors.append("LOG_EVIDENCE_INVALID")
    return errors


def main() -> int:
    try:
        value = json.loads(REPORT.read_text(encoding="utf-8"))
        errors = evaluate(value)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        errors = [f"REPORT_READ_FAILED:{type(exc).__name__}"]
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING_PRODUCT_BLOCKED" if not errors else "FAIL",
        "meaning": (
            "Toolkit2 PC simulator cannot execute exported RKNN artifacts; "
            "functional equivalence of hash-drifted exports requires a real target device"
        ),
        "hardware_measured": False,
        "product_selection_allowed": False,
        "errors": errors,
    }
    OUTPUT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
