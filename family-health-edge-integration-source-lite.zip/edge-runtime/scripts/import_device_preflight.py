from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / "configs" / "device_profile.json"
SCRIPT = ROOT / "scripts" / "preflight_rk3566.sh"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_profile(report_path: Path, report: dict, current: dict) -> dict:
    evidence = report.get("hardware_evidence")
    if (
        report.get("status") != "PASS_REAL_DEVICE_PREFLIGHT"
        or not isinstance(evidence, dict)
        or evidence.get("hardware_measured") is not True
        or evidence.get("rk3566_detected") is not True
        or evidence.get("simulation_detected") is not False
        or evidence.get("passed") is not True
        or report.get("script_sha256") != sha256(SCRIPT)
        or not report.get("known_hosts_sha256")
        or not report.get("remote_stdout_sha256")
    ):
        raise ValueError("remote preflight report is not eligible for import")
    relative = report_path.resolve().relative_to(ROOT.resolve()).as_posix()
    updated = dict(current)
    updated.update(
        {
            "hardware_measured": True,
            "simulated": False,
            "device_connected": True,
            "system_image": evidence.get("os"),
            "kernel": evidence.get("os", {}).get("kernel"),
            "rknpu_driver": evidence.get("npu", {}).get("driver_version"),
            "rknn_runtime": {
                "path": evidence.get("npu", {}).get("rknn_runtime_path"),
                "sha256": evidence.get("npu", {}).get("rknn_runtime_sha256"),
            },
            "audio_capture_device": {"count": evidence.get("audio", {}).get("capture_device_count")},
            "audio_playback_device": {"count": evidence.get("audio", {}).get("playback_device_count")},
            "debug_transport": "SSH_STRICT_HOST_KEY",
            "preflight_report": relative,
            "preflight_report_sha256": sha256(report_path),
            "preflight_script_sha256": sha256(SCRIPT),
            "known_hosts_sha256": report.get("known_hosts_sha256"),
            "approval_status": "REAL_PREFLIGHT_IMPORTED_ACCEPTANCE_STILL_REQUIRED",
        }
    )
    return updated


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    try:
        report_path = args.report.resolve(strict=True)
        if ROOT.resolve() not in report_path.parents:
            raise ValueError("report must be stored inside the project evidence tree")
        report = json.loads(report_path.read_text(encoding="utf-8"))
        current = json.loads(PROFILE.read_text(encoding="utf-8"))
        updated = build_profile(report_path, report, current)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}))
        return 2
    PROFILE.write_text(json.dumps(updated, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "IMPORTED_REAL_PREFLIGHT_ACCEPTANCE_STILL_REQUIRED"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
