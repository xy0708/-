"""Audit simulation evidence without confusing an environment block with a pass."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.run_arm64_simulation_loop import (
    RUNTIME_TOOL_STATUS,
    sha256,
    validate_guest,
    validate_recovery_smoke,
)
from scripts.verify_arm64_runtime_tool import verify as verify_runtime_tool


def source_path(report: dict, relative: str, root: Path) -> Path | None:
    if relative != 'tools/family-health-edge-tool':
        candidate = root / relative
        return candidate if candidate.resolve().is_relative_to(root.resolve()) else None
    runtime = report.get('runtime_tool')
    if not isinstance(runtime, dict):
        return None
    source_relative = runtime.get('source_path')
    expected_hash = runtime.get('sha256')
    if not all(isinstance(value, str) for value in (source_relative, expected_hash)):
        return None
    candidate = root / source_relative
    artifact_root = (root / 'artifacts/arm64_runtime_tools').resolve()
    if (
        candidate.is_symlink()
        or not candidate.is_file()
        or not candidate.resolve().is_relative_to(artifact_root)
        or sha256(candidate) != expected_hash
    ):
        return None
    verification_value = verify_runtime_tool(root)
    if (
        verification_value.get('status') != RUNTIME_TOOL_STATUS
        or verification_value.get('errors') != []
        or verification_value.get('artifact_relative_path') != source_relative
        or verification_value.get('artifact_sha256') != expected_hash
        or verification_value.get('build_id') != runtime.get('build_id')
    ):
        return None
    return candidate


def evaluate(report: dict, root: Path = ROOT) -> list[str]:
    errors = []
    if report.get('simulated') is not True:
        errors.append('SIMULATION_PROVENANCE_MISSING')
    if report.get('host_context_tests_passed') is not True:
        errors.append('STAGED_CONTEXT_HOST_TESTS_NOT_PASS')
    if report.get('host_context_tests_are_arm64_evidence') is not False:
        errors.append('HOST_TESTS_MISLABELED_AS_ARM64')
    for field in ('hardware_measured', 'product_complete', 'simulation_complete', 'three_model_inference_verified'):
        if report.get(field) is not False:
            errors.append('UNSUPPORTED_COMPLETION_CLAIM:' + field)
    if report.get('status') not in {'BLOCKED_ENVIRONMENT', 'READY_TO_EXECUTE', 'PASS_ARM64_SOFTWARE'}:
        errors.append('SIMULATION_FAILED_OR_UNKNOWN')
    if report.get('status') == 'PASS_ARM64_SOFTWARE' and not validate_guest(report.get('guest', {})):
        errors.append('ARM64_EXECUTION_EVIDENCE_MISSING')
    if report.get('status') == 'PASS_ARM64_SOFTWARE':
        if not validate_recovery_smoke(report.get('activation_recovery_smoke', {})):
            errors.append('ARM64_ACTIVATION_RECOVERY_EVIDENCE_MISSING')
        if report.get('activation_recovery_container_cleaned') is not True:
            errors.append('ARM64_ACTIVATION_RECOVERY_CONTAINER_NOT_CLEANED')
    if report.get('status') == 'BLOCKED_ENVIRONMENT' and not report.get('blockers'):
        errors.append('BLOCK_REASON_MISSING')
    hashes = report.get('source_sha256', {})
    if not isinstance(hashes, dict) or not hashes:
        return errors + ['SOURCE_HASHES_MISSING']
    for relative, digest in hashes.items():
        path = source_path(report, relative, root)
        if path is None or not path.is_file() or sha256(path) != digest:
            errors.append('SOURCE_CHANGED:' + relative)
    if sha256(root / 'ARM64_SIMULATION_LOOP.md') != report.get('plan_sha256'):
        errors.append('SIMULATION_PLAN_CHANGED')
    return errors


def main() -> int:
    path = ROOT / 'reports/arm64_simulation_latest.json'
    report = json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {}
    errors = evaluate(report)
    output = dict(checked_at=datetime.now(timezone.utc).isoformat(),
                  status='PASS_ENGINEERING' if not errors else 'FAIL',
                  meaning='Evidence separation and source integrity only; not an ARM64 runtime pass',
                  simulation_status=report.get('status', 'NOT_RUN'),
                  hardware_measured=False, product_complete=False, errors=errors)
    (ROOT / 'reports/simulation_evidence_verification.json').write_text(
        json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(output, ensure_ascii=True))
    return 2 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
