from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "dependency_security.json"


def main() -> int:
    locked = (ROOT / "requirements" / "locked.txt").read_text(encoding="utf-8")
    active = [
        line.strip()
        for line in locked.splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    failures = []
    if active:
        failures.append("UNEXPECTED_UNPINNED_OR_UNAUDITED_PYTHON_DEPENDENCIES")
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not failures else "FAIL",
        "production_python_third_party_dependencies": active,
        "online_vulnerability_database_scan_performed": False,
        "product_gate": False,
        "failures": failures,
        "product_blockers": [
            "TARGET_ARM64_RUNTIME_AND_NATIVE_LIBRARIES_NOT_FROZEN",
            "FORMAL_RELEASE_SBOM_NOT_AVAILABLE",
            "CURRENT_ADVISORY_DATABASE_SCAN_NOT_RUN",
        ],
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
