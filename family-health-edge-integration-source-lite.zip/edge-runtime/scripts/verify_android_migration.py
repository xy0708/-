from __future__ import annotations

import hashlib
import json
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "android_migration_verification.json"
ANDROID_NAMESPACE = "{http://schemas.android.com/apk/res/android}"
TOOLS_NAMESPACE = "{http://schemas.android.com/tools}"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate(root: Path) -> tuple[list[str], dict]:
    errors: list[str] = []
    required_files = [
        "RK3576_PHONE_WATCH_INTEGRATION_LOOP.md",
        "ANDROID_EDGE_PRODUCTION_LOOP.md",
        "configs/device_profile.json",
        "configs/linux_device_profile.archive.json",
        "configs/product_delivery_contract.json",
        "configs/linux_product_delivery_contract.archive.json",
        "configs/wearable_sdk_source.json",
        "configs/android_runtime_registry.json",
        "configs/android_asr_candidate.json",
        "configs/phone_edge_contract.json",
        "configs/yucheng_android_sdk_source.json",
        "configs/wearable_measurement_contract.json",
        "docs/android_architecture.md",
        "docs/android_board_acceptance.md",
        "同事最终验收.md",
        "Android迁移依赖.md",
        "docs/compliance/yucheng_sdk_license_audit.md",
        "android_app/pubspec.yaml",
        "android_app/lib/main.dart",
        "android_app/lib/watch_bridge.dart",
        "android_app/lib/health_rules.dart",
        "android_app/lib/asr_model_assets.dart",
        "android_app/lib/asr_runtime.dart",
        "android_app/lib/asr_microphone.dart",
        "android_app/assets/health_rules.json",
        "android_app/assets/asr_candidate.json",
        "android_app/assets/asr/x_asr_streaming/encoder.int8.onnx",
        "android_app/assets/asr/x_asr_streaming/decoder.onnx",
        "android_app/assets/asr/x_asr_streaming/joiner.int8.onnx",
        "android_app/assets/asr/x_asr_streaming/tokens.txt",
        "android_app/assets/asr/x_asr_streaming/bpe.model",
        "android_app/test/health_rules_test.dart",
        "android_app/test/asr_runtime_test.dart",
        "android_app/test/asr_microphone_test.dart",
        "android_app/android/app/build.gradle.kts",
        "android_app/android/app/src/main/AndroidManifest.xml",
        "android_app/android/app/src/main/kotlin/com/familyhealth/edge/family_health_edge_android/ModelAssetChannel.kt",
        "scripts/stage_android_asr_assets.py",
        "scripts/install_android_debug.py",
        "scripts/install_android_debug.ps1",
        "scripts/build_android_migration_handoff.py",
        "scripts/verify_android_handoff_archives.py",
        "install_android_debug.bat",
        "start_android_migration_loop.bat",
    ]
    for relative in required_files:
        if not (root / relative).is_file():
            errors.append(f"missing:{relative}")

    if errors:
        return errors, {"required_files": required_files}

    device = load_json(root / "configs" / "device_profile.json")
    target = device.get("target", {})
    if target.get("os_family") != "Android":
        errors.append("active_device_os_must_be_android")
    if target.get("abi") != "arm64-v8a":
        errors.append("active_device_abi_must_be_arm64_v8a")
    if target.get("soc") != "RK3576":
        errors.append("active_device_soc_must_be_rk3576")
    if target.get("android_release") != "14":
        errors.append("active_device_android_release_must_be_14")
    if target.get("android_api_level") != 34:
        errors.append("active_device_android_api_level_must_be_34")
    if device.get("hardware_measured") is not False:
        errors.append("unverified_android_hardware_must_remain_false")
    if device.get("device_connected") is not False:
        errors.append("device_connected_requires_adb_evidence")
    if device.get("reported_by_hardware_team", {}).get("independently_verified") is not False:
        errors.append("reported_board_state_must_not_be_marked_independently_verified")

    contract = load_json(root / "configs" / "product_delivery_contract.json")
    if contract.get("deployment_mode") != "PHYSICAL_ANDROID_EDGE_PRODUCT":
        errors.append("deployment_mode_must_be_android_product")
    if contract.get("target_abi") != "arm64-v8a":
        errors.append("delivery_target_abi_must_be_arm64_v8a")
    if contract.get("target_soc") != "RK3576":
        errors.append("delivery_target_soc_must_be_rk3576")
    if contract.get("linux_service_runtime_allowed") is not False:
        errors.append("linux_service_runtime_must_be_disabled")
    if contract.get("debug_signing_allowed_for_release") is not False:
        errors.append("debug_release_signing_must_be_disabled")
    if contract.get("root_or_system_app_assumed") is not False:
        errors.append("system_privileges_must_not_be_assumed")
    if contract.get("formal_release_allowed") is not False:
        errors.append("formal_release_must_remain_blocked")
    release_contents = set(contract.get("required_release_contents", []))
    if "systemd" in release_contents or "signed_apk_or_vendor_payload" not in release_contents:
        errors.append("android_release_contents_invalid")

    sdk = load_json(root / "configs" / "wearable_sdk_source.json")
    archive = root / sdk.get("source", {}).get("archive_path", "")
    if not archive.is_file():
        errors.append("wearable_sdk_archive_missing")
    elif sha256(archive) != sdk["source"].get("archive_sha256"):
        errors.append("wearable_sdk_archive_hash_mismatch")
    if sdk.get("source", {}).get("immutable_upstream_reference") is not False:
        errors.append("mutable_master_must_not_be_marked_immutable")
    if sdk.get("license", {}).get("commercial_redistribution_approved") is not False:
        errors.append("wearable_binary_license_must_remain_unapproved")
    if sdk.get("product_use_allowed") is not False:
        errors.append("wearable_product_use_must_remain_blocked")

    selected_sdk = load_json(root / "configs" / "yucheng_android_sdk_source.json")
    if selected_sdk.get("source", {}).get("repository") != "https://gitee.com/yucheng_3/android-sdk-2.0":
        errors.append("selected_yucheng_sdk_repository_invalid")
    selected_source = selected_sdk.get("source", {})
    if selected_source.get("immutable_reference") is not True:
        errors.append("yucheng_sdk_snapshot_must_be_hash_frozen")
    selected_archive = root / selected_source.get("archive_path", "")
    if not selected_archive.is_file():
        errors.append("selected_yucheng_sdk_archive_missing")
    elif sha256(selected_archive) != selected_source.get("archive_sha256"):
        errors.append("selected_yucheng_sdk_archive_hash_mismatch")
    selected_aar = root / selected_sdk.get("sdk", {}).get("core_aar", "")
    if not selected_aar.is_file():
        errors.append("selected_yucheng_core_aar_missing")
    elif sha256(selected_aar) != selected_sdk.get("sdk", {}).get("core_aar_sha256"):
        errors.append("selected_yucheng_core_aar_hash_mismatch")
    if selected_sdk.get("license", {}).get("embedded_binary_redistribution_approved") is not False:
        errors.append("selected_yucheng_binary_redistribution_must_remain_unapproved")
    if selected_sdk.get("product_use_allowed") is not False:
        errors.append("selected_yucheng_sdk_product_use_must_remain_blocked")

    phone_edge = load_json(root / "configs" / "phone_edge_contract.json")
    if phone_edge.get("architecture", {}).get("watch_to_phone") != "BLE_VIA_YUCHENG_ANDROID_SDK_2_0":
        errors.append("phone_watch_transport_contract_invalid")
    if phone_edge.get("architecture", {}).get("phone_to_edge") != "HOME_WIFI_HTTPS":
        errors.append("phone_edge_transport_contract_invalid")
    if phone_edge.get("edge", {}).get("soc") != "RK3576":
        errors.append("phone_edge_contract_soc_invalid")
    if phone_edge.get("simulation", {}).get("counts_as_product_acceptance") is not False:
        errors.append("simulation_must_not_count_as_product_acceptance")
    if phone_edge.get("formal_release_allowed") is not False:
        errors.append("phone_edge_contract_must_block_release")

    runtime_registry = load_json(root / "configs" / "android_runtime_registry.json")
    runtimes = runtime_registry.get("runtimes", {})
    if runtime_registry.get("target") != {
        "os_family": "Android",
        "android_release": "14",
        "soc": "RK3576",
        "abi": "arm64-v8a",
    }:
        errors.append("android_runtime_registry_target_invalid")
    if runtimes.get("health", {}).get("status") != "ENGINEERING_READY_PRODUCT_BLOCKED":
        errors.append("android_health_runtime_status_invalid")
    ocr_runtime = runtimes.get("ocr", {})
    if ocr_runtime.get("status") != "BLOCKED_NO_ANDROID_RUNTIME":
        errors.append("ocr_must_remain_blocked_without_android_runtime")
    if ocr_runtime.get("implementation") is not None:
        errors.append("ocr_implementation_must_not_be_invented")
    if ocr_runtime.get("packaged_in_debug_apk") is not False:
        errors.append("ocr_must_not_be_marked_packaged")
    asr_runtime = runtimes.get("asr", {})
    if asr_runtime.get("status") != "ENGINEERING_PACKAGED_NOT_EXECUTED_ANDROID":
        errors.append("android_asr_runtime_status_invalid")
    if asr_runtime.get("implementation") != "android_app/lib/asr_runtime.dart":
        errors.append("android_asr_runtime_implementation_invalid")
    if asr_runtime.get("microphone_capture_implementation") != "android_app/lib/asr_microphone.dart":
        errors.append("android_asr_microphone_implementation_invalid")
    if asr_runtime.get("packaged_in_debug_apk") is not True:
        errors.append("android_asr_runtime_must_be_marked_packaged")
    if asr_runtime.get("microphone_capture_packaged") is not True:
        errors.append("android_asr_microphone_must_be_marked_packaged")
    if asr_runtime.get("product_enabled") is not False:
        errors.append("unverified_android_asr_must_not_be_product_enabled")
    if runtime_registry.get("all_three_android_runtimes_ready") is not False:
        errors.append("three_android_runtimes_must_remain_incomplete")
    if runtime_registry.get("formal_release_allowed") is not False:
        errors.append("android_runtime_registry_must_block_release")

    asr_candidate_path = root / "configs" / "android_asr_candidate.json"
    android_asr_asset_config = root / "android_app" / "assets" / "asr_candidate.json"
    asr_candidate = load_json(asr_candidate_path)
    if sha256(asr_candidate_path) != sha256(android_asr_asset_config):
        errors.append("android_asr_candidate_asset_hash_mismatch")
    if asr_candidate.get("target") != {"os_family": "Android", "abi": "arm64-v8a"}:
        errors.append("android_asr_candidate_target_invalid")
    if asr_candidate.get("runtime", {}).get("version") != "1.13.7":
        errors.append("android_asr_runtime_version_not_frozen")
    if asr_candidate.get("licenses", {}).get("commercial_distribution_approved") is not False:
        errors.append("android_asr_commercial_distribution_must_remain_unapproved")
    if asr_candidate.get("evidence", {}).get("android_runtime_executed") is not False:
        errors.append("android_asr_runtime_execution_must_remain_unverified")
    asset_prefix = asr_candidate.get("model", {}).get("asset_prefix", "")
    for filename, expected in asr_candidate.get("model", {}).get("files", {}).items():
        staged = root / "android_app" / asset_prefix / filename
        if not staged.is_file():
            errors.append(f"android_asr_asset_missing:{filename}")
            continue
        if staged.stat().st_size != expected.get("bytes"):
            errors.append(f"android_asr_asset_size_mismatch:{filename}")
        if sha256(staged) != expected.get("sha256"):
            errors.append(f"android_asr_asset_hash_mismatch:{filename}")
    staging_report = load_json(root / "reports" / "android_asr_asset_staging.json")
    if staging_report.get("status") != "PASS_ENGINEERING_ASSETS_STAGED":
        errors.append("android_asr_asset_staging_not_passed")

    gradle = (root / "android_app" / "android" / "app" / "build.gradle.kts").read_text(
        encoding="utf-8"
    )
    for marker in [
        'applicationId = "com.familyhealth.edge.terminal"',
        "compileSdk = 36",
        "minSdk = 26",
        "targetSdk = 35",
        'abiFilters += listOf("arm64-v8a")',
        '"lib/armeabi-v7a/**"',
        '"lib/x86_64/**"',
    ]:
        if marker not in gradle:
            errors.append(f"android_gradle_marker_missing:{marker}")
    if "signingConfigs.getByName(\"debug\")" in gradle:
        errors.append("android_release_uses_debug_signing")
    pubspec = (root / "android_app" / "pubspec.yaml").read_text(encoding="utf-8")
    if "sherpa_onnx: 1.13.7" not in pubspec:
        errors.append("android_sherpa_runtime_dependency_not_frozen")
    if "record: 6.1.2" not in pubspec:
        errors.append("android_microphone_dependency_not_frozen")

    vendor_gradle = (
        root
        / "vendor"
        / "yucheng"
        / "yc_product_plugin-master"
        / "code"
        / "android"
        / "build.gradle"
    ).read_text(encoding="utf-8")
    if 'abiFilters "arm64-v8a"' not in vendor_gradle:
        errors.append("vendor_plugin_not_restricted_to_arm64_v8a")
    if "signingConfig signingConfigs.debug" in vendor_gradle:
        errors.append("vendor_plugin_release_uses_debug_signing")

    manifest_path = root / "android_app" / "android" / "app" / "src" / "main" / "AndroidManifest.xml"
    manifest = ET.parse(manifest_path).getroot()
    permissions = {
        node.attrib.get(f"{ANDROID_NAMESPACE}name")
        for node in manifest.findall("uses-permission")
        if node.attrib.get(f"{TOOLS_NAMESPACE}node") != "remove"
    }
    expected_permissions = {
        "android.permission.BLUETOOTH",
        "android.permission.BLUETOOTH_ADMIN",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.BLUETOOTH_SCAN",
        "android.permission.BLUETOOTH_CONNECT",
        "android.permission.RECORD_AUDIO",
    }
    if permissions != expected_permissions:
        errors.append("android_manifest_permissions_not_minimal_runtime_set")
    forbidden_permissions = {
        "android.permission.ACCESS_BACKGROUND_LOCATION",
        "android.permission.MANAGE_EXTERNAL_STORAGE",
        "android.permission.READ_CONTACTS",
        "android.permission.READ_PHONE_STATE",
        "android.permission.WRITE_SETTINGS",
        "android.permission.INTERNET",
    }
    if permissions & forbidden_permissions:
        errors.append("android_manifest_contains_forbidden_permissions")
    manifest_text = manifest_path.read_text(encoding="utf-8")
    for removed_component in [
        "com.yucheng.ycbtsdk.upgrade.utils.NotificationActivity",
        "com.yucheng.ycbtsdk.upgrade.utils.DfuService",
        "org.eclipse.paho.android.service.MqttService",
    ]:
        if removed_component not in manifest_text:
            errors.append(f"vendor_component_removal_missing:{removed_component}")
    application = manifest.find("application")
    if application is None:
        errors.append("android_application_missing")
    else:
        if application.attrib.get(f"{ANDROID_NAMESPACE}allowBackup") != "false":
            errors.append("android_backup_must_be_disabled")
        if application.attrib.get(f"{ANDROID_NAMESPACE}usesCleartextTraffic") != "false":
            errors.append("android_cleartext_traffic_must_be_disabled")

    plugin_types = (
        root
        / "vendor"
        / "yucheng"
        / "yc_product_plugin-master"
        / "code"
        / "lib"
        / "yc_product_plugin_data_type.dart"
    ).read_text(encoding="utf-8")
    if 'print("map: $map")' in plugin_types:
        errors.append("vendor_plugin_logs_health_map")

    root_health_rules = root / "configs" / "health_rules.json"
    android_health_rules = root / "android_app" / "assets" / "health_rules.json"
    if sha256(root_health_rules) != sha256(android_health_rules):
        errors.append("android_health_rules_asset_hash_mismatch")
    health_config = load_json(android_health_rules)
    if health_config.get("approval_status") != "PENDING_NAMED_PRODUCT_AND_DOMAIN_REVIEW":
        errors.append("unapproved_health_rules_must_remain_pending")
    if health_config.get("scope") != "ENGINEERING_CANDIDATE_NON_DIAGNOSTIC":
        errors.append("android_health_rules_scope_must_remain_non_diagnostic")

    old_loop = (root / "EDGE_PRODUCTION_LOOP.md").read_text(encoding="utf-8")
    old_plan = (root / "PRODUCT_EDGE_DEPLOYMENT_PLAN.md").read_text(encoding="utf-8")
    if "历史 Linux Loop" not in old_loop:
        errors.append("linux_loop_not_marked_historical")
    if "历史 Linux 部署方案" not in old_plan:
        errors.append("linux_deployment_plan_not_marked_historical")

    facts = {
        "required_files": required_files,
        "target_os": target.get("os_family"),
        "target_soc": target.get("soc"),
        "android_release": target.get("android_release"),
        "target_abi": target.get("abi"),
        "device_connected": device.get("device_connected"),
        "hardware_measured": device.get("hardware_measured"),
        "wearable_product_use_allowed": sdk.get("product_use_allowed"),
        "selected_yucheng_product_use_allowed": selected_sdk.get("product_use_allowed"),
        "runtime_statuses": {
            name: runtime.get("status") for name, runtime in runtimes.items()
        },
        "health_rules_asset_sha256": sha256(android_health_rules),
        "health_rules_approval_status": health_config.get("approval_status"),
        "asr_candidate_status": asr_candidate.get("status"),
        "asr_android_runtime_executed": asr_candidate.get("evidence", {}).get(
            "android_runtime_executed"
        ),
        "manifest_permissions": sorted(permission for permission in permissions if permission),
    }
    return errors, facts


def main() -> int:
    errors, facts = validate(ROOT)
    payload = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING_PRODUCT_BLOCKED" if not errors else "FAIL_ENGINEERING",
        "active_target": "Android",
        "product_complete": False,
        "formal_release_allowed": False,
        "errors": errors,
        "facts": facts,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
