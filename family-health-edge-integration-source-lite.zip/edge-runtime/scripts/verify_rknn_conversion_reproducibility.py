from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from research_assets import ResearchAssetPathError, resolve_locked_artifact


SOURCE_REPORT = ROOT / "reports" / "rknn_conversion_reproducibility.json"
OUTPUT_REPORT = ROOT / "reports" / "rknn_conversion_reproducibility_verification.json"
EXPECTED_IMAGE_ID = (
    "sha256:7f9aada37e75721b62de280c087d4457c2d9356afc47d7518aa5efdbf627f18e"
)
EXPECTED_CASES = {
    "ppocrv4_det": (
        "artifacts/official_models/source_onnx/ppocrv4_det.onnx",
        "artifacts/official_models/rknn_engineering/ppocrv4_det_fp16.rknn",
    ),
    "ppocrv4_rec": (
        "artifacts/official_models/source_onnx/ppocrv4_rec.onnx",
        "artifacts/official_models/rknn_engineering/ppocrv4_rec_fp16.rknn",
    ),
    "zipformer_encoder": (
        "artifacts/official_models/source_onnx/zipformer_encoder_epoch_99_avg_1.onnx",
        "artifacts/official_models/rknn_engineering/zipformer_encoder_fp16.rknn",
    ),
    "zipformer_decoder": (
        "artifacts/official_models/source_onnx/zipformer_decoder_epoch_99_avg_1.onnx",
        "artifacts/official_models/rknn_engineering/zipformer_decoder_fp16.rknn",
    ),
    "zipformer_joiner": (
        "artifacts/official_models/source_onnx/zipformer_joiner_epoch_99_avg_1.onnx",
        "artifacts/official_models/rknn_engineering/zipformer_joiner_fp16.rknn",
    ),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_file(root: Path, relative: object) -> Path | None:
    if not isinstance(relative, str):
        return None
    try:
        path = resolve_locked_artifact(root, relative)
    except (OSError, ResearchAssetPathError):
        return None
    return path


def valid_sha256(value: object) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    return all(character in "0123456789abcdef" for character in value)


def command_is_isolated(command: object) -> bool:
    if not isinstance(command, list) or not all(isinstance(item, str) for item in command):
        return False
    pairs = list(zip(command, command[1:]))
    return (
        ("--network", "none") in pairs
        and ("--volume", "{WORKSPACE}:/workspace:ro") in pairs
        and ("--volume", "{RESEARCH}:/research:ro") in pairs
        and ("--volume", "{TEMP}:/evidence") in pairs
        and not any(":\\" in item or ":/Users/" in item for item in command)
    )


def verify_changed_region(record: dict[str, Any], errors: list[str]) -> None:
    name = str(record.get("name"))
    diff = record.get("binary_diff")
    diagnostics = record.get("binary_diff_diagnostics")
    if not isinstance(diff, dict) or not isinstance(diagnostics, dict):
        errors.append(f"DRIFT_DIAGNOSTIC_MISSING:{name}")
        return
    numeric_fields = (
        "canonical_bytes",
        "replay_bytes",
        "common_prefix_bytes",
        "common_suffix_bytes",
        "canonical_changed_span_bytes",
        "replay_changed_span_bytes",
    )
    if not all(isinstance(diff.get(field), int) for field in numeric_fields):
        errors.append(f"DRIFT_SUMMARY_INVALID:{name}")
        return
    if diff["canonical_bytes"] != diff["replay_bytes"] or diff.get("same_size") is not True:
        errors.append(f"DRIFT_SIZE_CHANGED:{name}")
    if (
        diff["common_prefix_bytes"]
        + diff["canonical_changed_span_bytes"]
        + diff["common_suffix_bytes"]
        != diff["canonical_bytes"]
    ):
        errors.append(f"DRIFT_SPAN_INVALID:{name}")
    for field in ("canonical_region_sha256", "replay_region_sha256"):
        if not valid_sha256(diagnostics.get(field)):
            errors.append(f"DRIFT_REGION_HASH_INVALID:{name}:{field}")
    different = diagnostics.get("different_byte_count_in_common_span")
    if not isinstance(different, int) or different <= 0:
        errors.append(f"DRIFT_BYTE_COUNT_INVALID:{name}")


def verify_payload(root: Path, payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if payload.get("scope") != "OFFLINE_HOST_CONVERSION_REPLAY_ONLY":
        errors.append("SCOPE_INVALID")
    if payload.get("expected_image_id") != EXPECTED_IMAGE_ID:
        errors.append("EXPECTED_IMAGE_ID_INVALID")
    if payload.get("actual_image_id") != EXPECTED_IMAGE_ID:
        errors.append("ACTUAL_IMAGE_ID_INVALID")
    if payload.get("image_id_matches") is not True:
        errors.append("IMAGE_ID_NOT_MATCHED")
    if payload.get("network_disabled") is not True:
        errors.append("NETWORK_NOT_DISABLED")
    if payload.get("temporary_artifacts_deleted") is not True:
        errors.append("TEMPORARY_ARTIFACTS_REMAIN")
    if payload.get("hardware_measured") is not False:
        errors.append("HARDWARE_SCOPE_INVALID")
    if payload.get("product_selection_allowed") is not False:
        errors.append("PRODUCT_SELECTION_SCOPE_INVALID")

    records = payload.get("records")
    if not isinstance(records, list):
        return errors + ["RECORDS_INVALID"]
    by_name = {
        record.get("name"): record
        for record in records
        if isinstance(record, dict) and isinstance(record.get("name"), str)
    }
    if len(by_name) != len(records) or set(by_name) != set(EXPECTED_CASES):
        errors.append("CANDIDATE_SET_INVALID")

    conversion_count = 0
    byte_count = 0
    drift_count = 0
    for name, expected_paths in EXPECTED_CASES.items():
        record = by_name.get(name)
        if record is None:
            continue
        expected_source, expected_canonical = expected_paths
        if record.get("source") != expected_source:
            errors.append(f"SOURCE_PATH_INVALID:{name}")
        if record.get("canonical_output") != expected_canonical:
            errors.append(f"CANONICAL_PATH_INVALID:{name}")
        source = safe_file(root, record.get("source"))
        canonical = safe_file(root, record.get("canonical_output"))
        if source is None or sha256(source) != record.get("source_sha256"):
            errors.append(f"SOURCE_HASH_MISMATCH:{name}")
        if canonical is None or sha256(canonical) != record.get("canonical_output_sha256"):
            errors.append(f"CANONICAL_HASH_MISMATCH:{name}")
        if not valid_sha256(record.get("replay_output_sha256")):
            errors.append(f"REPLAY_HASH_INVALID:{name}")
        if record.get("conversion_succeeded") is not True or record.get("exit_code") != 0:
            errors.append(f"CONVERSION_NOT_SUCCESSFUL:{name}")
        else:
            conversion_count += 1
        if not command_is_isolated(record.get("command")) or record.get("network_disabled") is not True:
            errors.append(f"COMMAND_NOT_ISOLATED:{name}")
        log = safe_file(root, record.get("log"))
        if log is None or sha256(log) != record.get("log_sha256"):
            errors.append(f"LOG_HASH_MISMATCH:{name}")

        byte_reproducible = record.get("byte_reproducible") is True
        if byte_reproducible:
            byte_count += 1
            if record.get("replay_output_sha256") != record.get("canonical_output_sha256"):
                errors.append(f"BYTE_REPRODUCIBILITY_CONTRADICTION:{name}")
            if record.get("status") != "PASS_ENGINEERING_BYTE_REPRODUCIBLE":
                errors.append(f"RECORD_STATUS_INVALID:{name}")
            if record.get("binary_diff") is not None or record.get("binary_diff_diagnostics") is not None:
                errors.append(f"UNEXPECTED_DIFF:{name}")
        else:
            drift_count += 1
            if record.get("replay_output_sha256") == record.get("canonical_output_sha256"):
                errors.append(f"HASH_DRIFT_CONTRADICTION:{name}")
            if record.get("status") != "PARTIAL_PASS_ENGINEERING_HASH_DRIFT":
                errors.append(f"RECORD_STATUS_INVALID:{name}")
            verify_changed_region(record, errors)
        previous = record.get("previous_replay_output_sha256")
        if previous is not None:
            expected_match = previous == record.get("replay_output_sha256")
            if record.get("matches_previous_replay") is not expected_match:
                errors.append(f"PREVIOUS_REPLAY_MATCH_INVALID:{name}")

    expected_count = len(EXPECTED_CASES)
    if payload.get("candidate_count") != expected_count:
        errors.append("CANDIDATE_COUNT_INVALID")
    if payload.get("conversion_success_count") != conversion_count or conversion_count != expected_count:
        errors.append("CONVERSION_COUNT_INVALID")
    if payload.get("byte_reproduced_count") != byte_count:
        errors.append("BYTE_REPRODUCED_COUNT_INVALID")
    if payload.get("hash_drift_count") != drift_count:
        errors.append("HASH_DRIFT_COUNT_INVALID")
    all_reproducible = byte_count == expected_count
    if payload.get("all_outputs_byte_reproducible") is not all_reproducible:
        errors.append("REPRODUCIBILITY_FLAG_INVALID")
    expected_status = (
        "PASS_ENGINEERING_CONVERSION_REPRODUCIBILITY"
        if all_reproducible
        else "PARTIAL_PASS_ENGINEERING_OUTPUT_HASH_DRIFT"
    )
    if payload.get("status") != expected_status:
        errors.append("SOURCE_STATUS_INVALID")
    return errors


def verify_report(root: Path = ROOT, report: Path = SOURCE_REPORT) -> dict[str, Any]:
    try:
        payload = json.loads(report.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        payload = {}
        errors = ["SOURCE_REPORT_INVALID"]
    else:
        errors = verify_payload(root, payload)
    byte_count = payload.get("byte_reproduced_count") if isinstance(payload, dict) else None
    drift_count = payload.get("hash_drift_count") if isinstance(payload, dict) else None
    return {
        "schema_version": "1.0.0",
        "status": "PASS_ENGINEERING_REPLAY_AUDIT_PRODUCT_BLOCKED" if not errors else "FAIL",
        "source_report": report.relative_to(root).as_posix() if report.is_relative_to(root) else str(report),
        "source_run_id": payload.get("run_id") if isinstance(payload, dict) else None,
        "conversion_success_count": payload.get("conversion_success_count") if isinstance(payload, dict) else None,
        "byte_reproduced_count": byte_count,
        "hash_drift_count": drift_count,
        "byte_reproducibility_state": "FULL" if drift_count == 0 else "PARTIAL",
        "hardware_measured": False,
        "product_selected": False,
        "formal_release_allowed": False,
        "errors": errors,
    }


def main() -> int:
    result = verify_report()
    OUTPUT_REPORT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_REPORT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS_ENGINEERING_REPLAY_AUDIT_PRODUCT_BLOCKED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
