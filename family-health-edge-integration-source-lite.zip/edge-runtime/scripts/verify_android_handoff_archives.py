from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = ROOT.parent / "Android迁移交付包"
BUILD_REPORT = OUTPUT_ROOT / "latest_build.json"
VERIFICATION_REPORT = OUTPUT_ROOT / "latest_verification.json"
FORBIDDEN_SOURCE_SEGMENTS = {
    ".dart_tool",
    ".gradle",
    ".idea",
    ".kotlin",
    ".pytest_cache",
    ".venv-edge",
    "__pycache__",
    "build",
    "systemd",
}
REQUIRED_SOURCE_MEMBERS = {
    "同事最终验收.md",
    "Android迁移依赖.md",
    "android_app/pubspec.yaml",
    "android_app/pubspec.lock",
    "android_app/lib/main.dart",
    "android_app/lib/asr_microphone.dart",
    "android_app/assets/asr/x_asr_streaming/encoder.int8.onnx",
    "android_app/android/gradlew.bat",
    "android_app/android/app/build.gradle.kts",
    "vendor/yucheng/yc_product_plugin-master/code/pubspec.yaml",
    "vendor/yucheng/yc_product_plugin-master/code/android/libs/ycbtsdk-release.aar",
    "vendor/yucheng/yc_product_plugin-master/code/lib/yc_product_plugin.dart",
}
REQUIRED_INSTALL_MEMBERS = {
    "同事最终验收.md",
    "Android迁移依赖.md",
    "install_android_debug.bat",
    "scripts/collect_android_preflight.py",
    "scripts/install_android_debug.py",
    "scripts/install_android_debug.ps1",
    "reports/android_flutter_validation.json",
    "android_app/build/app/outputs/flutter-apk/app-debug.apk",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_member(bundle: zipfile.ZipFile, member: str) -> str:
    digest = hashlib.sha256()
    with bundle.open(member) as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def relative_members(bundle: zipfile.ZipFile, prefix: str) -> set[str]:
    return {
        name[len(prefix) :]
        for name in bundle.namelist()
        if name.startswith(prefix) and not name.endswith("/")
    }


def verify_archive(summary: dict, package_type: str) -> dict:
    archive = Path(summary["archive"])
    errors: list[str] = []
    if not archive.is_file():
        return {"archive": str(archive), "errors": ["archive_missing"]}
    if sha256_file(archive) != summary.get("archive_sha256"):
        errors.append("archive_sha256_mismatch")

    prefix = f"{Path(summary['folder']).name}/"
    with zipfile.ZipFile(archive) as bundle:
        corrupt_member = bundle.testzip()
        if corrupt_member:
            errors.append(f"zip_crc_failed:{corrupt_member}")
        members = relative_members(bundle, prefix)
        manifest_member = f"{prefix}交付文件清单.json"
        if manifest_member not in bundle.namelist():
            errors.append("manifest_missing")
            return {
                "archive": str(archive),
                "archive_sha256": sha256_file(archive),
                "errors": errors,
            }
        manifest = json.loads(bundle.read(manifest_member).decode("utf-8"))
        if manifest.get("package_type") != package_type:
            errors.append("manifest_package_type_mismatch")
        expected_files = manifest.get("files", [])
        if manifest.get("file_count") != len(expected_files):
            errors.append("manifest_file_count_invalid")
        if summary.get("file_count") != len(expected_files):
            errors.append("build_report_file_count_mismatch")

        for item in expected_files:
            relative = item.get("path")
            member = f"{prefix}{relative}"
            if member not in bundle.namelist():
                errors.append(f"member_missing:{relative}")
                continue
            info = bundle.getinfo(member)
            if info.file_size != item.get("bytes"):
                errors.append(f"member_size_mismatch:{relative}")
            if sha256_member(bundle, member) != item.get("sha256"):
                errors.append(f"member_sha256_mismatch:{relative}")

        required = (
            REQUIRED_SOURCE_MEMBERS
            if package_type == "ANDROID_MIGRATION_SOURCE"
            else REQUIRED_INSTALL_MEMBERS
        )
        for relative in sorted(required - members):
            errors.append(f"required_member_missing:{relative}")

        if package_type == "ANDROID_MIGRATION_SOURCE":
            for relative in sorted(members):
                parts = set(PurePosixPath(relative).parts)
                if parts & FORBIDDEN_SOURCE_SEGMENTS:
                    errors.append(f"generated_or_linux_member_present:{relative}")
                if relative.endswith("/local.properties"):
                    errors.append(f"machine_local_file_present:{relative}")
        else:
            validation_member = f"{prefix}reports/android_flutter_validation.json"
            apk_member = f"{prefix}android_app/build/app/outputs/flutter-apk/app-debug.apk"
            if validation_member in bundle.namelist() and apk_member in bundle.namelist():
                validation = json.loads(bundle.read(validation_member).decode("utf-8"))
                if validation.get("apk", {}).get("sha256") != sha256_member(bundle, apk_member):
                    errors.append("install_apk_not_bound_to_flutter_validation")

    return {
        "archive": str(archive),
        "archive_bytes": archive.stat().st_size,
        "archive_sha256": sha256_file(archive),
        "verified_manifest_files": summary.get("file_count"),
        "errors": errors,
    }


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if not BUILD_REPORT.is_file():
        payload = {"status": "FAIL_HANDOFF_ARCHIVES", "errors": ["build_report_missing"]}
    else:
        build = json.loads(BUILD_REPORT.read_text(encoding="utf-8"))
        source = verify_archive(build["source"], "ANDROID_MIGRATION_SOURCE")
        install = verify_archive(build["install"], "ANDROID_ENGINEERING_INSTALL")
        payload = {
            "schema_version": "1.0.0",
            "status": (
                "PASS_HANDOFF_ARCHIVES_VERIFIED"
                if not source["errors"] and not install["errors"]
                else "FAIL_HANDOFF_ARCHIVES"
            ),
            "source": source,
            "install": install,
        }
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    VERIFICATION_REPORT.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["status"] == "PASS_HANDOFF_ARCHIVES_VERIFIED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
