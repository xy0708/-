from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.asset_integrity import verify_file


WORKSPACE = ROOT.parent
OCR_ROOT = WORKSPACE / "OCR"
MODEL_MANIFEST = OCR_ROOT / "models" / "official_pretrained" / "manifest.json"
REPORT = ROOT / "reports" / "ocr_rknn_verification.json"
PRODUCT_ONNX = ROOT / "artifacts" / "ocr" / "onnx"
PRODUCT_RKNN = ROOT / "artifacts" / "ocr" / "rknn"


def main() -> int:
    failures: list[str] = []
    checks: list[dict[str, object]] = []
    legal_final = False
    if not MODEL_MANIFEST.is_file():
        failures.append("ocr_model_manifest_missing")
        manifest = {"models": []}
    else:
        manifest = json.loads(MODEL_MANIFEST.read_text(encoding="utf-8"))
        legal_final = manifest.get("model_weight_license_review") == "APPROVED_FOR_PRODUCT_DISTRIBUTION"
    for model in manifest.get("models", []):
        model_root = OCR_ROOT / model["resolved_local_dir"]
        for item in model["files"]:
            checks.append(
                verify_file(
                    model_root / item["path"],
                    int(item["size_bytes"]),
                    item["sha256"],
                )
            )
    if not checks or not all(item["passed"] for item in checks):
        failures.append("ocr_pretrained_asset_integrity_failed")

    onnx_files = sorted(PRODUCT_ONNX.glob("*.onnx")) if PRODUCT_ONNX.is_dir() else []
    rknn_files = sorted(PRODUCT_RKNN.glob("*.rknn")) if PRODUCT_RKNN.is_dir() else []
    device = json.loads((ROOT / "configs" / "device_profile.json").read_text(encoding="utf-8"))
    hardware_measured = device.get("hardware_measured") is True
    engineering_passed = not failures
    product_gate_passed = (
        engineering_passed
        and legal_final
        and len(onnx_files) >= 2
        and len(rknn_files) >= 2
        and hardware_measured
    )
    report = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if engineering_passed else "FAIL",
        "pretrained_asset_integrity": checks,
        "weight_license_final": legal_final,
        "product_onnx_files": [str(path) for path in onnx_files],
        "product_rknn_files": [str(path) for path in rknn_files],
        "hardware_measured": hardware_measured,
        "product_gate": (
            "PASS_PRODUCT_GATE"
            if product_gate_passed
            else "BLOCKED_EXTERNAL_LICENSE_REAL_INPUTS_AND_RK3566_REQUIRED"
        ),
        "formal_finetuning_performed": False,
        "failures": failures,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))
    return 0 if engineering_passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
