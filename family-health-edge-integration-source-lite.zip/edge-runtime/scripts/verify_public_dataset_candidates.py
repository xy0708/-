from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = ROOT.parent.resolve()
CONFIG = ROOT / "configs" / "public_dataset_candidates.json"
REPORT = ROOT / "reports" / "public_dataset_candidates_verification.json"


NONCOMMERCIAL_MARKERS = (
    "CC-BY-NC",
    "CC BY-NC",
    "NONCOMMERCIAL",
    "NON-COMMERCIAL",
    "NON COMMERCIAL",
)


def file_digest(path: Path, algorithm: str) -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_download(candidate: dict) -> list[str]:
    candidate_id = candidate["id"]
    if candidate.get("downloaded") is False:
        return []
    if candidate.get("downloaded") is not True:
        return [f"DOWNLOADED_FLAG_INVALID:{candidate_id}"]

    failures: list[str] = []
    relative_path = candidate.get("local_artifact_path")
    algorithm = str(candidate.get("artifact_digest_type") or "").lower()
    expected_digest = str(candidate.get("artifact_digest") or "").lower()
    if not isinstance(relative_path, str) or not relative_path:
        return [f"DOWNLOADED_ARTIFACT_PATH_MISSING:{candidate_id}"]
    if algorithm not in hashlib.algorithms_available or not expected_digest:
        return [f"DOWNLOADED_ARTIFACT_DIGEST_MISSING:{candidate_id}"]

    artifact = (WORKSPACE_ROOT / relative_path).resolve()
    try:
        artifact.relative_to(WORKSPACE_ROOT)
    except ValueError:
        return [f"DOWNLOADED_ARTIFACT_OUTSIDE_WORKSPACE:{candidate_id}"]
    if not artifact.is_file():
        return [f"DOWNLOADED_ARTIFACT_NOT_FOUND:{candidate_id}"]
    if file_digest(artifact, algorithm) != expected_digest:
        failures.append(f"DOWNLOADED_ARTIFACT_DIGEST_MISMATCH:{candidate_id}")
    return failures


def download_evidence(candidate: dict) -> dict | None:
    if candidate.get("downloaded") is not True:
        return None
    relative_path = candidate.get("local_artifact_path")
    algorithm = str(candidate.get("artifact_digest_type") or "").lower()
    expected_digest = str(candidate.get("artifact_digest") or "").lower()
    if not isinstance(relative_path, str) or algorithm not in hashlib.algorithms_available:
        return None
    artifact = (WORKSPACE_ROOT / relative_path).resolve()
    if not artifact.is_file():
        return None
    actual_digest = file_digest(artifact, algorithm)
    return {
        "candidate_id": candidate["id"],
        "local_artifact_path": relative_path,
        "size_bytes": artifact.stat().st_size,
        "digest_type": algorithm,
        "expected_digest": expected_digest,
        "actual_digest": actual_digest,
        "integrity_verified": actual_digest == expected_digest,
    }


def candidates_by_id(payload: dict) -> tuple[dict[str, dict], list[str]]:
    failures: list[str] = []
    candidates = payload.get("candidates")
    if not isinstance(candidates, list) or not candidates:
        return {}, ["CANDIDATES_MISSING"]
    indexed: dict[str, dict] = {}
    for candidate in candidates:
        if not isinstance(candidate, dict) or not isinstance(candidate.get("id"), str):
            failures.append("CANDIDATE_ID_INVALID")
            continue
        candidate_id = candidate["id"]
        if candidate_id in indexed:
            failures.append(f"CANDIDATE_ID_DUPLICATE:{candidate_id}")
        indexed[candidate_id] = candidate
    return indexed, failures


def validate_candidate(candidate: dict) -> list[str]:
    candidate_id = candidate["id"]
    failures = validate_download(candidate)
    if candidate.get("commercial_product_use_approved") is not False:
        failures.append(f"UNSUPPORTED_COMMERCIAL_APPROVAL:{candidate_id}")
    if candidate.get("product_acceptance_evidence_allowed") is not False:
        failures.append(f"UNSUPPORTED_PRODUCT_ACCEPTANCE_USE:{candidate_id}")
    license_claim = str(candidate.get("license_claim") or "").upper()
    if any(marker in license_claim for marker in NONCOMMERCIAL_MARKERS):
        if not str(candidate.get("status", "")).startswith("EXCLUDED_COMMERCIAL"):
            failures.append(f"NONCOMMERCIAL_DATASET_NOT_EXCLUDED:{candidate_id}")
    return failures


def validate_policy(payload: dict) -> list[str]:
    indexed, failures = candidates_by_id(payload)
    for candidate in indexed.values():
        failures.extend(validate_candidate(candidate))

    charls = indexed.get("charls", {})
    if charls.get("status") != "PERMANENTLY_EXCLUDED":
        failures.append("CHARLS_NOT_PERMANENTLY_EXCLUDED")
    if charls.get("engineering_use_allowed") is not False:
        failures.append("CHARLS_ENGINEERING_USE_MUST_BE_FALSE")

    common_voice = indexed.get("mozilla_common_voice_27_zh_cn", {})
    common_voice_contract = {
        "license_claim": "CC0-1.0",
        "download_requires_account_and_terms": True,
        "redistribution_forbidden_by_terms": True,
        "engineering_use_allowed": True,
        "commercial_product_use_approved": False,
        "product_acceptance_evidence_allowed": False,
        "target_domain_match": False,
        "target_device_microphone_match": False,
    }
    for key, expected in common_voice_contract.items():
        if common_voice.get(key) != expected:
            failures.append(f"COMMON_VOICE_CONTRACT_INVALID:{key}")

    if payload.get("selected_engineering_pilot") != "mozilla_common_voice_27_zh_cn":
        failures.append("ENGINEERING_PILOT_NOT_FAIL_CLOSED")
    if payload.get("selected_product_dataset") is not None:
        failures.append("PRODUCT_DATASET_SELECTED_WITHOUT_APPROVAL")
    downloaded_count = sum(
        candidate.get("downloaded") is True for candidate in indexed.values()
    )
    if payload.get("downloaded_dataset_count") != downloaded_count:
        failures.append("DOWNLOADED_DATASET_COUNT_MISMATCH")
    gaps = payload.get("remaining_product_data_gaps")
    if not isinstance(gaps, list) or len(gaps) != 3:
        failures.append("PRODUCT_DATA_GAPS_INCOMPLETE")
    return sorted(set(failures))


def main() -> int:
    try:
        payload = json.loads(CONFIG.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        payload = {}
    failures = validate_policy(payload)
    downloaded_artifacts = [
        evidence
        for candidate in payload.get("candidates", [])
        if (evidence := download_evidence(candidate)) is not None
    ]
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING_PRODUCT_DATA_BLOCKED" if not failures else "FAIL",
        "candidate_count": len(payload.get("candidates", [])),
        "downloaded_dataset_count": payload.get("downloaded_dataset_count"),
        "downloaded_artifacts": downloaded_artifacts,
        "selected_engineering_pilot": payload.get("selected_engineering_pilot"),
        "selected_product_dataset": payload.get("selected_product_dataset"),
        "product_data_ready": False,
        "charls_used": False,
        "failures": failures,
        "remaining_product_data_gaps": payload.get("remaining_product_data_gaps", []),
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
