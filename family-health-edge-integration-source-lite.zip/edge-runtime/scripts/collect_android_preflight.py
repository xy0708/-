from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "android_device_preflight.json"


def parse_adb_devices(output: str) -> list[dict[str, object]]:
    devices: list[dict[str, object]] = []
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("List of devices") or line.startswith("*"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        details: dict[str, str] = {}
        for token in parts[2:]:
            if ":" in token:
                key, value = token.split(":", 1)
                details[key] = value
        devices.append({"serial": parts[0], "state": parts[1], "details": details})
    return devices


def evaluate_properties(properties: dict[str, str]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    product_blockers: list[str] = []
    soc_text = " ".join(
        properties.get(key, "")
        for key in ("ro.product.board", "ro.board.platform", "ro.hardware")
    ).casefold()
    if "rk3576" not in soc_text:
        errors.append("soc_is_not_verified_as_rk3576")
    if properties.get("ro.product.cpu.abi") != "arm64-v8a":
        errors.append("primary_abi_is_not_arm64_v8a")
    try:
        api_level = int(properties.get("ro.build.version.sdk", ""))
    except ValueError:
        api_level = 0
    if properties.get("ro.build.version.release") != "14":
        errors.append("android_release_is_not_14")
    if api_level != 34:
        errors.append("android_api_is_not_34")
    if not properties.get("ro.build.fingerprint"):
        errors.append("build_fingerprint_missing")
    if not properties.get("ro.build.version.security_patch"):
        product_blockers.append("security_patch_missing")
    if properties.get("ro.build.type") != "user":
        product_blockers.append("build_type_not_user")
    if properties.get("ro.debuggable") != "0":
        product_blockers.append("ro_debuggable_not_zero")
    if properties.get("ro.secure") != "1":
        product_blockers.append("ro_secure_not_one")
    if properties.get("selinux") != "Enforcing":
        product_blockers.append("selinux_not_enforcing")
    return errors, product_blockers


def find_adb() -> str | None:
    found = shutil.which("adb")
    if found:
        return found
    sdk_root = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
    if not sdk_root:
        return None
    candidate = Path(sdk_root) / "platform-tools" / "adb.exe"
    return str(candidate) if candidate.is_file() else None


def run(command: list[str], timeout: int = 20) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
    )


def write_report(payload: dict) -> None:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    checked_at = datetime.now(timezone.utc).isoformat()
    adb = find_adb()
    if adb is None:
        write_report(
            {
                "schema_version": "1.0.0",
                "checked_at": checked_at,
                "status": "BLOCKED_ENVIRONMENT",
                "reason": "adb_not_found",
                "hardware_measured": False,
            }
        )
        return 2
    listing = run([adb, "devices", "-l"])
    devices = parse_adb_devices(listing.stdout)
    authorized = [device for device in devices if device["state"] == "device"]
    if listing.returncode != 0 or len(authorized) != 1:
        reason = "no_authorized_android_device" if not authorized else "multiple_authorized_devices"
        write_report(
            {
                "schema_version": "1.0.0",
                "checked_at": checked_at,
                "status": "BLOCKED_EXTERNAL",
                "reason": reason,
                "hardware_measured": False,
                "devices": devices,
                "adb_stderr": listing.stderr[-2000:],
            }
        )
        return 2

    serial = str(authorized[0]["serial"])
    property_names = [
        "ro.product.board",
        "ro.board.platform",
        "ro.hardware",
        "ro.product.cpu.abi",
        "ro.build.version.release",
        "ro.build.version.sdk",
        "ro.build.version.security_patch",
        "ro.build.fingerprint",
        "ro.build.type",
        "ro.debuggable",
        "ro.secure",
    ]
    properties: dict[str, str] = {}
    command_errors: list[str] = []
    for name in property_names:
        result = run([adb, "-s", serial, "shell", "getprop", name])
        if result.returncode != 0:
            command_errors.append(f"getprop_failed:{name}")
        properties[name] = result.stdout.strip()
    selinux = run([adb, "-s", serial, "shell", "getenforce"])
    properties["selinux"] = selinux.stdout.strip()
    if selinux.returncode != 0:
        command_errors.append("getenforce_failed")

    errors, product_blockers = evaluate_properties(properties)
    errors.extend(command_errors)
    passed = not errors
    payload = {
        "schema_version": "1.0.0",
        "checked_at": checked_at,
        "status": (
            "PASS_ENGINEERING_DEVICE_CONNECTED_PRODUCT_BLOCKED"
            if passed
            else "FAIL_TARGET_DEVICE"
        ),
        "hardware_measured": passed,
        "product_hardening_complete": passed and not product_blockers,
        "serial": serial,
        "transport_details": authorized[0]["details"],
        "properties": properties,
        "errors": errors,
        "product_blockers": product_blockers,
    }
    write_report(payload)
    return 0 if passed else 3


if __name__ == "__main__":
    raise SystemExit(main())
