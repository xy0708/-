#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "usage: install_release.sh RELEASE_BUNDLE" >&2
  exit 2
fi
if [ "$(id -u)" -ne 0 ]; then
  echo "installation requires root" >&2
  exit 2
fi

bundle="$(realpath "$1")"
install_root="${EDGE_INSTALL_ROOT:-/opt/family-health-edge}"
state_root="${EDGE_STATE_ROOT:-/var/lib/family-health-edge}"
update_state_root="${EDGE_UPDATE_STATE_ROOT:-/var/lib/family-health-edge-update}"
public_key="${EDGE_RELEASE_PUBLIC_KEY:-/etc/family-health-edge/release-public.pem}"
runtime_tool="${EDGE_RUNTIME_TOOL:-$install_root/tools/family-health-edge-tool}"
runtime_tmp="${EDGE_RUNTIME_TMPDIR:-/run/family-health-edge-maintenance}"
marker="$update_state_root/pending-activation.json"
release_id="$(basename "$bundle")"
if [[ ! "$release_id" =~ ^[A-Za-z0-9]([A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$ ]]; then
  echo "invalid release id" >&2
  exit 2
fi

mkdir -p "$install_root/releases" "$state_root"
install -d -m 0700 -o root -g root "$update_state_root"
install -d -m 0700 -o root -g root "$runtime_tmp"
export TMPDIR="$runtime_tmp"
exec 9>"$update_state_root/release-install.lock"
flock -n 9 || { echo "another install or rollback is active" >&2; exit 2; }
[ -x "$runtime_tool" ] || { echo "required self-contained runtime tool is missing or not executable: $runtime_tool" >&2; exit 2; }
if [ -e "$marker" ] || [ -L "$marker" ]; then
  echo "pending activation must be recovered before installing" >&2
  exit 2
fi
"$runtime_tool" verify-release-bundle --bundle "$bundle" --public-key "$public_key"

previous=""
previous_id=""
if [ -L "$install_root/current" ]; then
  "$runtime_tool" verify-current-release --current "$install_root/current" --install-root "$install_root" --public-key "$public_key"
  previous="$(readlink "$install_root/current")"
  if [[ ! "$previous" =~ ^releases/[A-Za-z0-9]([A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$ ]]; then
    echo "current release link is not canonical" >&2
    exit 2
  fi
  previous_id="${previous#releases/}"
elif [ -e "$install_root/current" ]; then
  echo "current release is not a symbolic link" >&2
  exit 2
fi

switch_current() {
  local target="$1"
  local link_parent
  link_parent="$(mktemp -d "$install_root/.activation-link.XXXXXX")"
  ln -s "$target" "$link_parent/current"
  mv -Tf "$link_parent/current" "$install_root/current"
  rmdir "$link_parent"
}

destination="$install_root/releases/$release_id"
resume_existing=false
if [ -e "$destination" ] || [ -L "$destination" ]; then
  if [ "$previous" = "releases/$release_id" ]; then
    echo "requested release is already current" >&2
    exit 2
  fi
  "$runtime_tool" verify-release-bundle --bundle "$destination" --public-key "$public_key"
  if ! cmp -s "$bundle/manifest.json" "$destination/manifest.json" || \
     ! cmp -s "$bundle/signatures/manifest.sig" "$destination/signatures/manifest.sig"; then
    echo "existing release destination conflicts with requested signed bundle" >&2
    exit 2
  fi
  resume_existing=true
else
  staging_parent="$(mktemp -d "$install_root/releases/.staging.XXXXXX")"
  staging="$staging_parent/$release_id"
  mkdir "$staging"
  cleanup() {
    if [ -d "$staging_parent" ]; then
      find "$staging_parent" -depth -mindepth 1 -delete
      rmdir "$staging_parent"
    fi
  }
  trap cleanup EXIT
  cp -a "$bundle/." "$staging/"
  "$runtime_tool" verify-release-bundle --bundle "$staging" --public-key "$public_key"
  mv "$staging" "$destination"
  rmdir "$staging_parent"
  trap - EXIT
fi
marker_args=(prepare --marker "$marker" --candidate "$release_id")
if [ -n "$previous_id" ]; then
  marker_args+=(--previous "$previous_id")
fi
"$runtime_tool" activation-marker "${marker_args[@]}"
switch_current "releases/$release_id"

if ! systemctl restart family-health-edge.service || ! "$runtime_tool" check-release-health --url http://127.0.0.1:18100/v1/health --timeout 10; then
  if [ -n "$previous" ]; then
    switch_current "$previous"
    systemctl restart family-health-edge.service || true
  else
    unlink "$install_root/current"
    systemctl stop family-health-edge.service || true
  fi
  "$runtime_tool" activation-marker clear --marker "$marker" --candidate "$release_id"
  echo "health check failed; previous release restored" >&2
  exit 2
fi
"$runtime_tool" activation-marker clear --marker "$marker" --candidate "$release_id"
if [ "$resume_existing" = true ]; then
  echo "resumed and installed $release_id"
else
  echo "installed $release_id"
fi
