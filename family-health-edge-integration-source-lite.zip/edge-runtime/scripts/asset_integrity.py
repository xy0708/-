from __future__ import annotations

import hashlib
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().lower()


def verify_file(path: Path, expected_size: int, expected_sha256: str) -> dict[str, object]:
    exists = path.is_file()
    actual_size = path.stat().st_size if exists else None
    actual_sha256 = sha256(path) if exists else None
    passed = (
        exists
        and actual_size == expected_size
        and actual_sha256 == expected_sha256.lower()
    )
    return {
        "path": str(path),
        "exists": exists,
        "expected_size": expected_size,
        "actual_size": actual_size,
        "expected_sha256": expected_sha256.lower(),
        "actual_sha256": actual_sha256,
        "passed": passed,
    }
