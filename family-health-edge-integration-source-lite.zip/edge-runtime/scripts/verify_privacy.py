from __future__ import annotations

import json
import sys
import tempfile
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "privacy_verification.json"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from acceptance.approvals import (
    approval_gate_errors,
    gate_registry_errors,
    load_gate_registry,
)
from acceptance.contract import acceptance_contract_scenario_errors


SECURITY_APPROVAL_GATES = (
    "privacy_legal_review",
    "encryption_key_design_approval",
    "security_threat_model_approval",
)


def load_json_object(path: Path, blockers: list[str], code: str) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        blockers.append(code)
        return {}
    if not isinstance(value, dict):
        blockers.append(code)
        return {}
    return value


def product_privacy_blockers(root: Path) -> list[str]:
    blockers: list[str] = []
    try:
        registry = load_gate_registry(root)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError):
        registry = {}
        blockers.append("PRIVACY_EXTERNAL_GATE_REGISTRY_INVALID")
    blockers.extend(
        f"PRIVACY_EXTERNAL_GATE_{error}" for error in gate_registry_errors(registry)
    )
    for gate_name in SECURITY_APPROVAL_GATES:
        blockers.extend(
            f"PRIVACY_EXTERNAL_GATE_{error}:{gate_name}"
            for error in approval_gate_errors(root, registry, gate_name)
        )

    acceptance = load_json_object(
        root / "reports" / "device_acceptance.json",
        blockers,
        "PRIVACY_DEVICE_ACCEPTANCE_INVALID_OR_MISSING",
    )
    if (
        acceptance.get("status") != "PASS_PRODUCT_GATE"
        or acceptance.get("hardware_measured") is not True
        or acceptance.get("acceptance_executed") is not True
        or acceptance.get("synthetic_evidence_used") is not False
        or acceptance.get("blockers") != []
    ):
        blockers.append("PRIVACY_REAL_DEVICE_ACCEPTANCE_NOT_PASS")

    contract = load_json_object(
        root / "configs" / "acceptance_contract.json",
        blockers,
        "PRIVACY_ACCEPTANCE_CONTRACT_INVALID_OR_MISSING",
    )
    blockers.extend(acceptance_contract_scenario_errors(contract))
    return sorted(set(blockers))


def evaluate(root: Path = ROOT) -> dict:
    failures: list[str] = []
    config = (root / "configs" / "privacy_config.yaml").read_text(encoding="utf-8")
    for invariant in (
        "local_only: true",
        "raw_audio_persisted: false",
        "raw_report_uploaded: false",
        "health_values_in_application_logs: false",
        "member_isolation_required: true",
        "confirmation_before_storage: true",
        "encryption_at_rest_required: true",
        "device_key_hardcoding_forbidden: true",
        "cloud_sync_enabled: false",
    ):
        if invariant not in config:
            failures.append(f"privacy_config_invariant_missing:{invariant}")

    from operations import PrivacySafeEventLog
    from storage import PlaintextEngineeringCodec, RecordStore

    canaries = ["private-member-7", "systolic=138", "/v1/ocr/tasks", "Bearer secret"]
    with tempfile.TemporaryDirectory() as temporary:
        path = Path(temporary) / "events.jsonl"
        log = PrivacySafeEventLog(path)
        log.request_completed(
            status=422,
            request_id="safe-request-7",
            error_code="INPUT_INVALID",
            operation="HEALTH_EVALUATE",
        )
        text = path.read_text(encoding="utf-8")
        if any(canary in text for canary in canaries):
            failures.append("privacy_canary_leaked_to_operational_log")
        event = json.loads(text)
        allowed = {"timestamp", "event", "status", "request_id", "error_code", "operation"}
        if set(event) != allowed:
            failures.append("operational_log_schema_not_allow_listed")

    pending_canary = "PRIVATE_PENDING_OCR_RESULT_24680"
    with tempfile.TemporaryDirectory() as temporary:
        database = Path(temporary) / "pending.db"
        store = RecordStore(
            database,
            PlaintextEngineeringCodec(),
            allow_unencrypted_engineering=True,
        )
        task = store.create_task("privacy-member", "ocr", {"text": pending_canary})
        store.close()
        connection = sqlite3.connect(database)
        try:
            persisted = connection.execute(
                "SELECT result_blob FROM tasks WHERE task_id=?", (task["task_id"],)
            ).fetchone()[0]
        finally:
            connection.close()
        if pending_canary.encode("utf-8") in bytes(persisted):
            failures.append("unconfirmed_ocr_asr_result_persisted")

    server_source = (root / "device_service" / "server.py").read_text(encoding="utf-8")
    application_source = (root / "device_service" / "application.py").read_text(encoding="utf-8")
    storage_source = (root / "storage" / "database.py").read_text(encoding="utf-8")
    if 'args.host != "127.0.0.1"' not in server_source:
        failures.append("loopback_bind_refusal_missing")
    if "TokenAuthorizer" not in application_source or "_require_member_access" not in application_source:
        failures.append("member_scoped_authorization_missing")
    if "product storage requires an approved encryption-at-rest codec" not in storage_source:
        failures.append("unencrypted_product_storage_fail_closed_missing")

    blockers = product_privacy_blockers(root)
    product_privacy_gate = not failures and not blockers
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not failures else "FAIL",
        "product_privacy_gate": product_privacy_gate,
        "log_canary_scan_passed": not failures,
        "pending_result_persistence_scan_passed": "unconfirmed_ocr_asr_result_persisted" not in failures,
        "failures": failures,
        "product_blockers": blockers,
    }
    return result


def main() -> int:
    result = evaluate()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if result["status"] == "PASS_ENGINEERING" else 2


if __name__ == "__main__":
    raise SystemExit(main())
