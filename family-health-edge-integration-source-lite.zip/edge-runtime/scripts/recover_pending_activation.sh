#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 0 ]; then
  echo "usage: recover_pending_activation.sh" >&2
  exit 2
fi
if [ "$(id -u)" -ne 0 ]; then
  echo "activation recovery requires root" >&2
  exit 2
fi

install_root="${EDGE_INSTALL_ROOT:-/opt/family-health-edge}"
state_root="${EDGE_STATE_ROOT:-/var/lib/family-health-edge}"
update_state_root="${EDGE_UPDATE_STATE_ROOT:-/var/lib/family-health-edge-update}"
public_key="${EDGE_RELEASE_PUBLIC_KEY:-/etc/family-health-edge/release-public.pem}"
runtime_tool="${EDGE_RUNTIME_TOOL:-$install_root/tools/family-health-edge-tool}"
runtime_tmp="${EDGE_RUNTIME_TMPDIR:-/run/family-health-edge-maintenance}"
marker="$update_state_root/pending-activation.json"

mkdir -p "$install_root/releases" "$state_root"
install -d -m 0700 -o root -g root "$update_state_root"
install -d -m 0700 -o root -g root "$runtime_tmp"
export TMPDIR="$runtime_tmp"
exec 9>"$update_state_root/release-install.lock"
flock -n 9 || { echo "another install or rollback is active" >&2; exit 2; }
[ -x "$runtime_tool" ] || { echo "required self-contained runtime tool is missing or not executable: $runtime_tool" >&2; exit 2; }
if [ ! -e "$marker" ] && [ ! -L "$marker" ]; then
  exit 0
fi

candidate="$("$runtime_tool" activation-marker read --marker "$marker" --field candidate_release_id)"
previous="$("$runtime_tool" activation-marker read --marker "$marker" --field previous_release_id)"
current=""
if [ -L "$install_root/current" ]; then
  current="$(readlink "$install_root/current")"
  if [[ ! "$current" =~ ^releases/[A-Za-z0-9]([A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$ ]]; then
    echo "current release link is not canonical" >&2
    exit 2
  fi
elif [ -e "$install_root/current" ]; then
  echo "current release is not a symbolic link" >&2
  exit 2
fi

switch_current() {
  local target="$1"
  local link_parent
  link_parent="$(mktemp -d "$install_root/.recovery-link.XXXXXX")"
  ln -s "$target" "$link_parent/current"
  mv -Tf "$link_parent/current" "$install_root/current"
  rmdir "$link_parent"
}

if [ "$previous" = "-" ]; then
  if [ "$current" = "releases/$candidate" ]; then
    unlink "$install_root/current"
  elif [ -n "$current" ]; then
    echo "pending first activation does not match current release" >&2
    exit 2
  fi
else
  target="$install_root/releases/$previous"
  "$runtime_tool" verify-release-bundle --bundle "$target" --public-key "$public_key"
  if [ "$current" = "releases/$candidate" ] || [ -z "$current" ]; then
    switch_current "releases/$previous"
  elif [ "$current" != "releases/$previous" ]; then
    echo "pending activation does not match current or previous release" >&2
    exit 2
  fi
fi
"$runtime_tool" activation-marker clear --marker "$marker" --candidate "$candidate"
echo "recovered interrupted activation for $candidate"
