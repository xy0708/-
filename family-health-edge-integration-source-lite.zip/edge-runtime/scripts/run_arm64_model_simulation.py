from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
sys.path.insert(0, str(ROOT))
from scripts.run_arm64_simulation_loop import (
    ARM64_PLATFORM,
    BASE_TAG,
    image_inspect_arguments,
    local_endpoint,
    pinned_repository_digest,
    public_reason,
    run_command,
    sha256,
)
from scripts.build_arm64_wheelhouse_manifest import normalized, wheel_record


CONFIG = ROOT / "configs" / "arm64_model_simulation.json"
REPORT = ROOT / "reports" / "arm64_model_simulation_latest.json"


def workspace_path(relative: str, *, directory: bool = False) -> Path:
    path = (WORKSPACE / relative).resolve()
    if not path.is_relative_to(WORKSPACE.resolve()):
        raise ValueError("MODEL_SOURCE_OUTSIDE_WORKSPACE")
    if directory and not path.is_dir():
        raise ValueError("MODEL_SOURCE_DIRECTORY_MISSING")
    if not directory and not path.is_file():
        raise ValueError("MODEL_SOURCE_FILE_MISSING")
    return path


def project_directory(relative: str) -> Path:
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT.resolve()) or not path.is_dir():
        raise ValueError("PROJECT_DIRECTORY_MISSING")
    return path


def source_key(path: Path) -> str:
    return path.resolve().relative_to(WORKSPACE.resolve()).as_posix()


def ocr_blocker(config: dict) -> dict:
    registry_path = workspace_path(config["ocr"]["registry"])
    onnx_path = workspace_path(config["ocr"]["onnx_report"])
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    onnx = json.loads(onnx_path.read_text(encoding="utf-8"))
    correctly_blocked = (
        registry.get("product_candidates") == []
        and registry.get("product_model_frozen") is False
        and onnx.get("status") == "BLOCKED"
        and onnx.get("onnx_verified") is False
    )
    return {
        "status": "BLOCKED_EXTERNAL" if correctly_blocked else "FAIL",
        "real_arm64_inference_executed": False,
        "test_double_used": False,
        "registry_sha256": sha256(registry_path),
        "onnx_report_sha256": sha256(onnx_path),
        "reasons": config["ocr"]["required_before_real_arm64_inference"],
        "product_complete": False,
    }


def validate_model_guest(value: dict, requirements: dict[str, str]) -> bool:
    return (
        value.get("status") == "PASS_AVAILABLE_REAL_MODELS"
        and value.get("system") == "Linux"
        and str(value.get("machine", "")).lower() in {"aarch64", "arm64"}
        and value.get("bits") == 64
        and value.get("simulated") is True
        and value.get("hardware_measured") is False
        and value.get("product_complete") is False
        and value.get("three_model_inference_verified") is False
        and value.get("requirements") == requirements
        and value.get("health", {}).get("status") == "PASS_ARM64_REAL_INFERENCE"
        and value.get("health", {}).get("product_model") is False
        and value.get("health", {}).get("probability_exposed_to_product") is False
        and value.get("asr", {}).get("status") == "PASS_ARM64_REAL_INFERENCE"
        and value.get("asr", {}).get("matches_host_reference") is True
        and value.get("asr", {}).get("product_accepted") is False
    )


def main() -> int:
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    folder = ROOT / "reports" / "arm64_model_simulation_runs" / run_id
    folder.mkdir(parents=True, exist_ok=False)
    report = {
        "schema_version": "1.0.0", "run_id": run_id, "status": "FAIL",
        "stage": "S2_PARTIAL", "simulated": True, "hardware_measured": False,
        "product_complete": False, "three_model_inference_verified": False,
        "simulation_complete": False, "commands": [], "blockers": [],
        "resume_command": ".venv-edge/Scripts/python.exe scripts/run_arm64_model_simulation.py",
    }
    records = report["commands"]
    docker = shutil.which("docker")
    if not docker and os.name == "nt":
        candidate = Path("C:/Program Files/Docker/Docker/resources/bin/docker.exe")
        if candidate.is_file():
            docker = str(candidate)
    environment = dict(os.environ)
    environment.update(PYTHONUTF8="1")
    container_name = "edge-arm64-model-sim-" + run_id.lower()
    created_container = False
    host_runtime: Path | None = None
    return_code = 2
    try:
        config = json.loads(CONFIG.read_text(encoding="utf-8"))
        if config.get("platform") != ARM64_PLATFORM or config.get("base_image") != BASE_TAG:
            raise ValueError("MODEL_SIMULATION_CONFIG_INVALID")
        requirements = {str(name): str(version) for name, version in config["requirements"].items()}
        wheelhouse = (ROOT / config["wheelhouse"]).resolve()
        if not wheelhouse.is_dir() or not wheelhouse.is_relative_to(ROOT.resolve()):
            raise ValueError("ARM64_WHEELHOUSE_MISSING")
        wheel_manifest_path = wheelhouse / "manifest.json"
        wheel_manifest = json.loads(wheel_manifest_path.read_text(encoding="utf-8"))
        if (wheel_manifest.get("status") != "PASS_ENGINEERING" or
                {item["name"]: item["version"] for item in wheel_manifest.get("files", [])}
                != requirements):
            raise ValueError("ARM64_WHEELHOUSE_MANIFEST_INVALID")
        for item in wheel_manifest["files"]:
            wheel = wheelhouse / item["file"]
            if not wheel.is_file() or sha256(wheel) != item["sha256"]:
                raise ValueError("ARM64_WHEEL_HASH_MISMATCH")

        host_wheelhouse = project_directory(config["asr"]["host_wheelhouse"])
        host_wheels = sorted(host_wheelhouse.glob("*.whl"))
        host_records = [wheel_record(path) for path in host_wheels]
        expected_host = {
            "sherpa-onnx": requirements["sherpa-onnx"],
            "sherpa-onnx-core": requirements["sherpa-onnx-core"],
        }
        if ({record["name"]: record["version"] for record in host_records} != expected_host or
                any("win_amd64" not in path.name for path in host_wheels)):
            raise ValueError("HOST_SHERPA_WHEELHOUSE_INVALID")

        health_manifest = workspace_path(config["health"]["manifest"])
        health_dir = health_manifest.parent
        health_payload = json.loads(health_manifest.read_text(encoding="utf-8"))
        if (health_payload.get("product_model") is not False or
                health_payload.get("clinical_diagnosis") is not False or
                set(health_payload.get("models", {})) != {"dm", "ht"}):
            raise ValueError("HEALTH_ENGINEERING_BOUNDARY_INVALID")
        health_reference_path = folder / "health_host_reference.json"
        health_python = workspace_path("健康模型/health-risk-model/.venv-health/Scripts/python.exe")
        rc, _ = run_command(
            [str(health_python), str(ROOT / "simulation" / "health_reference.py"),
             "--manifest", str(health_manifest), "--output", str(health_reference_path)],
            ROOT, folder, records, "health_host_reference", 120, environment,
        )
        if rc or not health_reference_path.is_file():
            raise ValueError("HEALTH_HOST_REFERENCE_FAILED")
        health_reference = json.loads(health_reference_path.read_text(encoding="utf-8"))

        asr_dir = workspace_path(config["asr"]["model_dir"], directory=True)
        asr_manifest_path = workspace_path(config["asr"]["model_manifest"])
        asr_manifest = json.loads(asr_manifest_path.read_text(encoding="utf-8"))
        asr_files = {item["name"]: item for item in asr_manifest.get("files", [])}
        required_asr = {"encoder.int8.onnx", "decoder.onnx", "joiner.int8.onnx", "tokens.txt"}
        if asr_manifest.get("passed") is not True or not required_asr.issubset(asr_files):
            raise ValueError("ASR_MANIFEST_INVALID")
        for name in required_asr:
            if sha256(asr_dir / name).upper() != str(asr_files[name]["sha256"]).upper():
                raise ValueError("ASR_MODEL_HASH_MISMATCH")
        sample = asr_dir / config["asr"]["sample_wav"]
        if not sample.is_file():
            raise ValueError("ASR_SAMPLE_MISSING")
        asr_reference_path = folder / "asr_host_reference.json"
        asr_python = workspace_path(
            "语音转文字/家庭健康语音转文字_Codex_Goal_Loop/health_asr_codex_loop/.venv-sherpa/Scripts/python.exe"
        )
        asr_verifier = workspace_path(
            "语音转文字/家庭健康语音转文字_Codex_Goal_Loop/health_asr_codex_loop/scripts/verify_sherpa.py"
        )
        host_runtime = folder / "host_runtime_temp"
        rc, _ = run_command(
            [str(asr_python), "-m", "pip", "install", "--no-index", "--no-deps",
             "--target", str(host_runtime), *[str(path) for path in host_wheels]],
            ROOT, folder, records, "install_host_sherpa_runtime", 120, environment,
        )
        if rc:
            raise ValueError("HOST_SHERPA_RUNTIME_INSTALL_FAILED")
        host_environment = dict(environment)
        host_environment["PYTHONPATH"] = str(host_runtime)
        rc, _ = run_command(
            [str(asr_python), str(asr_verifier), "--model-dir", str(asr_dir),
             "--wav", str(sample), "--num-threads", "1", "--chunk-ms", "100",
             "--output", str(asr_reference_path)],
            ROOT, folder, records, "asr_host_reference", 300, host_environment,
        )
        if rc or not asr_reference_path.is_file():
            raise ValueError("ASR_HOST_REFERENCE_FAILED")
        asr_reference = json.loads(asr_reference_path.read_text(encoding="utf-8"))
        final_text = str(asr_reference.get("final_text", "")).strip()
        if (asr_reference.get("passed") is not True or not final_text or
                asr_reference.get("sherpa_onnx_version") != requirements["sherpa-onnx"]):
            raise ValueError("ASR_HOST_REFERENCE_INVALID")
        shutil.rmtree(host_runtime)
        host_runtime = None
        report["host_runtime_cleaned"] = True

        context = folder / "context"
        app = context / "app"
        app.mkdir(parents=True)
        shutil.copyfile(ROOT / "simulation" / "ModelDockerfile", context / "Dockerfile")
        shutil.copyfile(ROOT / "simulation" / "model_probe.py", app / "model_probe.py")
        evidence = {
            "schema_version": "1.0.0", "scope": config["scope"],
            "requirements": requirements, "health_reference": health_reference,
            "asr_files": {name: asr_files[name] for name in sorted(required_asr)},
            "asr_sample_sha256": sha256(sample),
            "asr_reference_text_sha256": hashlib.sha256(final_text.encode("utf-8")).hexdigest(),
            "product_complete": False,
        }
        (app / "evidence.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n",
                                           encoding="utf-8")
        sources = [CONFIG, ROOT / "simulation" / "ModelDockerfile",
                   ROOT / "simulation" / "model_probe.py", ROOT / "simulation" / "health_reference.py",
                   ROOT / "scripts" / "build_arm64_wheelhouse_manifest.py",
                   ROOT / "scripts" / "run_arm64_model_simulation.py",
                   ROOT / "scripts" / "verify_model_simulation_evidence.py",
                   wheel_manifest_path, health_manifest, sample, asr_manifest_path,
                   *host_wheels,
                   *[health_dir / f"{task}.onnx" for task in ("dm", "ht")],
                   *[asr_dir / name for name in sorted(required_asr)]]
        report["source_sha256"] = {source_key(path): sha256(path) for path in sources}
        report["wheel_sha256"] = {item["file"]: item["sha256"] for item in wheel_manifest["files"]}
        report["host_references"] = {
            "health": {"status": health_reference["status"],
                       "report_sha256": sha256(health_reference_path)},
            "asr": {"status": "PASS_HOST_REFERENCE", "report_sha256": sha256(asr_reference_path),
                    "runtime_version": asr_reference["sherpa_onnx_version"],
                    "final_text_sha256": evidence["asr_reference_text_sha256"]},
        }
        report["components"] = {"ocr": ocr_blocker(config)}

        if not docker:
            report["status"] = "BLOCKED_ENVIRONMENT"
            report["blockers"].append("DOCKER_CLI_MISSING")
            return_code = 3
            return return_code
        endpoint = environment.get("DOCKER_HOST")
        if environment.get("DOCKER_CONTEXT") or not endpoint:
            command = [docker, "context", "inspect"]
            if environment.get("DOCKER_CONTEXT"):
                command.append(environment["DOCKER_CONTEXT"])
            command += ["--format", "{{json .Endpoints.docker.Host}}"]
            rc, raw = run_command(command, ROOT, folder, records, "docker_context", 30, environment)
            if rc:
                raise ValueError("DOCKER_CONTEXT_UNAVAILABLE")
            endpoint = json.loads(raw)
        if not isinstance(endpoint, str) or not local_endpoint(endpoint):
            raise ValueError("REMOTE_DOCKER_REFUSED")
        environment.pop("DOCKER_CONTEXT", None)
        environment["DOCKER_HOST"] = endpoint

        def docker_run(arguments: list[str], name: str, timeout: int = 30):
            return run_command([docker, *arguments], ROOT, folder, records, name, timeout, environment)

        rc, raw = docker_run(["info", "--format", "{{json .OSType}}"], "docker_info")
        if rc or json.loads(raw) != "linux":
            raise ValueError("LOCAL_LINUX_DOCKER_NOT_READY")
        rc, _ = docker_run(["pull", "--platform", ARM64_PLATFORM, BASE_TAG], "pull_base", 600)
        if rc:
            raise ValueError("ARM64_BASE_PULL_FAILED")
        rc, raw = docker_run(image_inspect_arguments(BASE_TAG), "inspect_base")
        base = json.loads(raw)[0] if rc == 0 else {}
        if base.get("Architecture") != "arm64" or base.get("Os") != "linux":
            raise ValueError("BASE_IMAGE_NOT_ARM64_LINUX")
        pinned_base = pinned_repository_digest(base.get("RepoDigests"))
        if pinned_base is None:
            raise ValueError("BASE_DIGEST_MISSING")
        report["base_image"] = {"tag": BASE_TAG, "digest": pinned_base, "image_id": base["Id"]}

        tag = "family-health-arm64-model-simulation:" + run_id.lower()
        build = ["build", "--platform", ARM64_PLATFORM, "--network=none",
                 "--build-arg", "BASE_IMAGE=" + pinned_base,
                 "--build-context", "wheelhouse=" + str(wheelhouse),
                 "--build-context", "health=" + str(health_dir),
                 "--build-context", "asr=" + str(asr_dir),
                 "-t", tag, str(context)]
        rc, _ = docker_run(build, "build_model_image", 900)
        if rc:
            raise ValueError("ARM64_MODEL_BUILD_FAILED")
        if report["source_sha256"] != {source_key(path): sha256(path) for path in sources}:
            raise ValueError("MODEL_SOURCE_CHANGED_DURING_BUILD")
        rc, raw = docker_run(image_inspect_arguments(tag), "inspect_candidate")
        built = json.loads(raw)[0] if rc == 0 else {}
        if built.get("Architecture") != "arm64" or built.get("Os") != "linux":
            raise ValueError("MODEL_CANDIDATE_NOT_ARM64_LINUX")
        candidate_reference = pinned_repository_digest(built.get("RepoDigests"))
        if candidate_reference is None:
            raise ValueError("MODEL_CANDIDATE_DIGEST_MISSING")
        report["candidate_image"] = {"id": built["Id"], "reference": candidate_reference}
        rc, _ = docker_run([
            "create", "--name", container_name, "--platform", ARM64_PLATFORM,
            "--network=none", "--read-only", "--cap-drop=ALL",
            "--security-opt=no-new-privileges", "--memory=4g", "--memory-swap=4g",
            "--cpus=4", "--pids-limit=128",
            "--tmpfs", "/tmp:rw,nosuid,nodev,size=256m,mode=1777", candidate_reference,
        ], "create_model_container")
        if rc:
            raise ValueError("MODEL_CONTAINER_CREATE_FAILED")
        created_container = True
        rc, raw = docker_run(["start", "--attach", container_name], "run_model_probe", 900)
        if rc:
            raise ValueError("ARM64_MODEL_GUEST_FAILED")
        rc, state_raw = docker_run(["inspect", "--format", "{{json .State}}", container_name],
                                   "inspect_model_guest")
        state = json.loads(state_raw) if rc == 0 else {}
        if state.get("ExitCode") != 0 or state.get("Running") is not False or state.get("OOMKilled") is not False:
            raise ValueError("MODEL_GUEST_EXIT_OR_MEMORY_FAILURE")
        guest = json.loads(raw.strip().splitlines()[-1])
        report["guest"] = guest
        if not validate_model_guest(guest, requirements):
            raise ValueError("MODEL_GUEST_EVIDENCE_REJECTED")
        report["components"].update({"health": guest["health"], "asr": guest["asr"]})
        if report["components"]["ocr"]["status"] != "BLOCKED_EXTERNAL":
            raise ValueError("OCR_BLOCKER_EVIDENCE_INVALID")
        report["status"] = "PARTIAL_PASS_PRODUCT_BLOCKED"
        report["blockers"] = ["OCR_PRODUCT_MODEL_AND_LICENSE_REQUIRED", "RK3566_NOT_TESTED"]
        return_code = 3
        return return_code
    except (OSError, ValueError, KeyError, TypeError, IndexError, json.JSONDecodeError) as exc:
        report["status"] = "FAIL"
        report["blockers"].append(public_reason(exc))
        return_code = 2
        return return_code
    finally:
        if host_runtime is not None and host_runtime.is_relative_to(folder) and host_runtime.exists():
            shutil.rmtree(host_runtime, ignore_errors=True)
            report["host_runtime_cleaned"] = not host_runtime.exists()
        if created_container and docker:
            cleanup, _ = run_command([docker, "rm", "--force", container_name], ROOT, folder,
                                     records, "cleanup_own_model_container", 30, environment)
            report["container_cleaned"] = cleanup == 0
        report["finished_at"] = datetime.now(timezone.utc).isoformat()
        encoded = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
        (folder / "audit.json").write_text(encoded, encoding="utf-8")
        REPORT.write_text(encoded, encoding="utf-8")
        print(json.dumps({key: report.get(key) for key in (
            "run_id", "status", "stage", "blockers", "three_model_inference_verified"
        )}, ensure_ascii=True))


if __name__ == "__main__":
    raise SystemExit(main())
