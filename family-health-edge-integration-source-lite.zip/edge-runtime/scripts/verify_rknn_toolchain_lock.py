from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from research_assets import ResearchAssetPathError, resolve_locked_artifact


MATRIX = ROOT / "vendor" / "rockchip" / "toolkit_runtime_matrix.json"
REPORT = ROOT / "reports" / "rknn_toolchain_lock_verification.json"
SHA256_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
EXPECTED_DEPENDENCY_COUNTS = {
    "apt_deb": 103,
    "pip_wheel": 20,
    "rknn_toolkit2_wheel": 1,
    "build_inputs": 2,
    "total": 126,
}
EXPECTED_TOOLKIT_WHEEL_SHA256 = "64442c852ef4bdf6a8b0ac35426a592c157c9365198d306078548359b030a90a"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_file(relative: str) -> Path:
    try:
        return resolve_locked_artifact(ROOT, relative)
    except ResearchAssetPathError as exc:
        raise ValueError(relative) from exc


def _load_evidence(relative: object, expected_status: str, errors: list[str]) -> dict[str, Any]:
    if not isinstance(relative, str):
        errors.append("INVALID_EXECUTION_EVIDENCE_PATH")
        return {}
    try:
        path = _safe_file(relative)
        evidence = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, json.JSONDecodeError):
        errors.append(f"EXECUTION_EVIDENCE_READ_FAILED:{relative}")
        return {}
    if evidence.get("status") != expected_status:
        errors.append(f"EXECUTION_EVIDENCE_STATUS_MISMATCH:{relative}")
    return evidence


def _verify_file_record(record: object, errors: list[str], label: str) -> Path | None:
    if not isinstance(record, dict):
        errors.append(f"INVALID_FILE_RECORD:{label}")
        return None
    relative = record.get("path")
    expected_bytes = record.get("bytes")
    expected_hash = record.get("sha256")
    if not isinstance(relative, str) or not isinstance(expected_bytes, int) or not isinstance(expected_hash, str):
        errors.append(f"INVALID_FILE_RECORD:{label}")
        return None
    try:
        path = _safe_file(relative)
    except (ValueError, OSError):
        errors.append(f"UNSAFE_FILE_RECORD:{label}")
        return None
    if not path.is_file() or path.stat().st_size != expected_bytes or sha256(path) != expected_hash:
        errors.append(f"FILE_RECORD_MISMATCH:{label}")
        return None
    return path


def _wheel_version(path: Path) -> tuple[str | None, str | None]:
    with zipfile.ZipFile(path) as archive:
        metadata_names = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
        if len(metadata_names) != 1:
            return None, None
        metadata = archive.read(metadata_names[0]).decode("utf-8", errors="replace")
    name = None
    version = None
    for line in metadata.splitlines():
        if line.startswith("Name: "):
            name = line.removeprefix("Name: ").strip()
        elif line.startswith("Version: "):
            version = line.removeprefix("Version: ").strip()
    return name, version


def _verify_dependency_lock(
    relative: object,
    host: dict[str, Any],
    errors: list[str],
) -> dict[str, Any]:
    evidence = _load_evidence(relative, "PASS_ENGINEERING_OFFLINE_DEPENDENCY_LOCK", errors)
    if not evidence:
        return {}
    if evidence.get("network_mode") != "none" or evidence.get("no_cache") is not True:
        errors.append("OFFLINE_BUILD_CONTROLS_MISSING")
    if evidence.get("fresh_rebuild_executed") is not True:
        errors.append("FRESH_OFFLINE_REBUILD_MISSING")
    if evidence.get("dependency_artifact_hash_lock_complete") is not True:
        errors.append("DEPENDENCY_ARTIFACT_HASH_LOCK_INCOMPLETE")
    if evidence.get("hardware_measured") is not False:
        errors.append("OFFLINE_LOCK_HARDWARE_CLAIM_INVALID")
    if evidence.get("real_rk3566_verified") is not False:
        errors.append("OFFLINE_LOCK_REAL_BOARD_CLAIM_INVALID")
    if evidence.get("formal_release_allowed") is not False:
        errors.append("OFFLINE_LOCK_RELEASE_CLAIM_INVALID")

    command = evidence.get("build_command")
    if not isinstance(command, list) or not all(isinstance(item, str) for item in command):
        errors.append("INVALID_OFFLINE_BUILD_COMMAND")
    else:
        if "--no-cache" not in command:
            errors.append("OFFLINE_BUILD_NO_CACHE_MISSING")
        try:
            network_index = command.index("--network")
        except ValueError:
            errors.append("OFFLINE_BUILD_NETWORK_FLAG_MISSING")
        else:
            if network_index + 1 >= len(command) or command[network_index + 1] != "none":
                errors.append("OFFLINE_BUILD_NETWORK_NOT_NONE")

    _verify_file_record(evidence.get("build_log"), errors, "offline_build_log")
    manifest_path = _verify_file_record(evidence.get("manifest"), errors, "dependency_manifest")
    if manifest_path:
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            errors.append("DEPENDENCY_MANIFEST_READ_FAILED")
            manifest = {}
        if manifest.get("artifact_counts") != EXPECTED_DEPENDENCY_COUNTS:
            errors.append("DEPENDENCY_MANIFEST_COUNT_MISMATCH")
        records = manifest.get("artifacts")
        if not isinstance(records, list) or len(records) != EXPECTED_DEPENDENCY_COUNTS["total"]:
            errors.append("DEPENDENCY_MANIFEST_RECORD_COUNT_MISMATCH")
            records = []
        paths: set[str] = set()
        calculated_bytes = 0
        kinds: dict[str, int] = {}
        toolkit_hashes: list[str] = []
        for index, record in enumerate(records):
            path = _verify_file_record(record, errors, f"dependency_artifact_{index}")
            if not isinstance(record, dict):
                continue
            relative_path = record.get("path")
            kind = record.get("kind")
            if not isinstance(relative_path, str) or relative_path in paths:
                errors.append(f"DEPENDENCY_ARTIFACT_PATH_DUPLICATE_OR_INVALID:{index}")
            else:
                paths.add(relative_path)
            if not isinstance(kind, str):
                errors.append(f"DEPENDENCY_ARTIFACT_KIND_INVALID:{index}")
            else:
                kinds[kind] = kinds.get(kind, 0) + 1
                if kind == "rknn_toolkit2_wheel" and isinstance(record.get("sha256"), str):
                    toolkit_hashes.append(record["sha256"])
            if path and isinstance(record.get("bytes"), int):
                calculated_bytes += record["bytes"]
        expected_kinds = {
            "apt_deb": 103,
            "pip_wheel": 20,
            "rknn_toolkit2_wheel": 1,
            "offline_dockerfile": 1,
            "pip_requirements_lock": 1,
        }
        if kinds != expected_kinds:
            errors.append("DEPENDENCY_ARTIFACT_KIND_COUNT_MISMATCH")
        if toolkit_hashes != [EXPECTED_TOOLKIT_WHEEL_SHA256]:
            errors.append("DEPENDENCY_TOOLKIT_WHEEL_HASH_MISMATCH")
        if manifest.get("total_bytes") != calculated_bytes:
            errors.append("DEPENDENCY_MANIFEST_TOTAL_BYTES_MISMATCH")

    images = evidence.get("images", {})
    if not isinstance(images, dict):
        errors.append("OFFLINE_LOCK_IMAGE_EVIDENCE_MISSING")
        images = {}
    base = images.get("base", {})
    reference = images.get("reference", {})
    offline = images.get("offline_rebuild", {})
    if base.get("id") != host.get("official_image_index_digest"):
        errors.append("OFFLINE_LOCK_BASE_IMAGE_ID_MISMATCH")
    if reference.get("id") != host.get("conversion_image_id"):
        errors.append("OFFLINE_LOCK_REFERENCE_IMAGE_ID_MISMATCH")
    if offline.get("id") != host.get("offline_rebuild_image_id"):
        errors.append("OFFLINE_LOCK_REBUILD_IMAGE_ID_MISMATCH")
    if offline.get("name") != host.get("offline_rebuild_image"):
        errors.append("OFFLINE_LOCK_REBUILD_IMAGE_NAME_MISMATCH")
    if offline.get("bytes") != host.get("offline_rebuild_image_bytes"):
        errors.append("OFFLINE_LOCK_REBUILD_IMAGE_SIZE_MISMATCH")
    if not SHA256_RE.fullmatch(str(offline.get("id", ""))):
        errors.append("INVALID_OFFLINE_REBUILD_IMAGE_ID")
    if not isinstance(reference.get("bytes"), int) or not isinstance(offline.get("bytes"), int):
        errors.append("OFFLINE_LOCK_IMAGE_SIZE_INVALID")
    elif offline["bytes"] > reference["bytes"] + 64 * 1024 * 1024:
        errors.append("OFFLINE_LOCK_IMAGE_SIZE_REGRESSION")

    comparison = evidence.get("comparison", {})
    if not isinstance(comparison, dict):
        errors.append("OFFLINE_LOCK_COMPARISON_MISSING")
        comparison = {}
    expected_comparison = {
        "reference_dpkg_packages": 194,
        "offline_dpkg_packages": 194,
        "dpkg_exact_match": True,
        "dpkg_only_reference": [],
        "dpkg_only_offline": [],
        "reference_pip_packages": 23,
        "offline_pip_packages": 23,
        "pip_exact_match": True,
        "pip_only_reference": [],
        "pip_only_offline": [],
    }
    if comparison != expected_comparison:
        errors.append("OFFLINE_LOCK_PACKAGE_COMPARISON_MISMATCH")
    smoke = evidence.get("smoke_output")
    required_smoke = {
        "No broken requirements found.",
        "python=3.8.10",
        "rknn-toolkit2=2.3.2",
        "rknn-import=PASS",
    }
    if not isinstance(smoke, list) or not required_smoke.issubset(set(smoke)):
        errors.append("OFFLINE_LOCK_SMOKE_EVIDENCE_MISSING")
    if evidence.get("errors") != []:
        errors.append("OFFLINE_LOCK_REPORTED_ERRORS")
    return evidence


def verify_matrix(matrix_path: Path = MATRIX) -> dict[str, Any]:
    errors: list[str] = []
    try:
        contract = json.loads(matrix_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"status": "FAIL", "errors": [f"MATRIX_READ_FAILED:{type(exc).__name__}"]}

    if contract.get("phase") != "R02" or contract.get("target_platform") != "rk3566":
        errors.append("INVALID_PHASE_OR_TARGET")
    if contract.get("status") != "IN_PROGRESS_ENGINEERING_PRODUCT_BLOCKED":
        errors.append("R02_MUST_REMAIN_IN_PROGRESS")
    for key in ("product_selected", "formal_release_allowed", "hardware_measured"):
        if contract.get(key) is not False:
            errors.append(f"{key.upper()}_MUST_BE_FALSE")

    source = contract.get("source", {})
    checkout = (ROOT / str(source.get("local_checkout", ""))).resolve()
    expected_commit = source.get("commit")
    completed = subprocess.run(
        ["git", "-C", str(checkout), "rev-parse", "HEAD"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if completed.returncode != 0 or completed.stdout.strip().lower() != str(expected_commit).lower():
        errors.append("TOOLKIT_REPOSITORY_COMMIT_MISMATCH")

    host = contract.get("host_conversion_environment", {})
    if host.get("architecture") != "linux/amd64" or host.get("target") != "rk3566":
        errors.append("INVALID_HOST_CONVERSION_TARGET")
    if host.get("rknn_toolkit2") != "2.3.2" or host.get("python_abi") != "cp38":
        errors.append("INVALID_HOST_TOOLKIT_VERSION")
    for digest_key in ("official_image_index_digest", "official_image_amd64_manifest_digest"):
        if not SHA256_RE.fullmatch(str(host.get(digest_key, ""))):
            errors.append(f"INVALID_IMAGE_DIGEST:{digest_key}")
    if host.get("dependency_versions_complete") is not True:
        errors.append("DEPENDENCY_VERSIONS_NOT_CAPTURED")
    if host.get("dependency_lock_complete") is not True:
        errors.append("DEPENDENCY_LOCK_INCOMPLETE")
    if host.get("image_build_verified") is not True or host.get("official_sample_smoke_verified") is not True:
        errors.append("HOST_EXECUTION_EVIDENCE_MISSING")
    if host.get("pc_simulator_alignment_verified") is not True:
        errors.append("PC_SIMULATOR_ALIGNMENT_MISSING")
    if not SHA256_RE.fullmatch(str(host.get("conversion_image_id", ""))):
        errors.append("INVALID_CONVERSION_IMAGE_ID")
    if host.get("offline_rebuild_verified") is not True:
        errors.append("OFFLINE_REBUILD_NOT_VERIFIED")
    if not SHA256_RE.fullmatch(str(host.get("offline_rebuild_image_id", ""))):
        errors.append("INVALID_OFFLINE_REBUILD_IMAGE_ID")

    board = contract.get("board_runtime_environment", {})
    if board.get("architecture") != "linux/aarch64" or board.get("soc") != "RK3566":
        errors.append("INVALID_BOARD_TARGET")
    for missing_key in ("system_image", "kernel", "rknpu_driver"):
        if board.get(missing_key) is not None:
            errors.append(f"UNVERIFIED_BOARD_FIELD:{missing_key}")
    if board.get("real_board_smoke_verified") is not False:
        errors.append("UNVERIFIED_REAL_BOARD_SMOKE")

    compatibility = contract.get("compatibility_contract", {})
    version_fields = ("rknn_toolkit2", "rknn_toolkit_lite2", "librknnrt", "rknn_server")
    if any(compatibility.get(field) != "2.3.2" for field in version_fields):
        errors.append("RKNN_COMPONENT_VERSION_MISMATCH")
    if compatibility.get("target") != "rk3566" or not compatibility.get("invalidation_rule"):
        errors.append("COMPATIBILITY_INVALIDATION_RULE_MISSING")

    artifacts = contract.get("artifacts")
    verified_artifacts = 0
    resolved: dict[str, Path] = {}
    if not isinstance(artifacts, list) or len(artifacts) != 9:
        errors.append("EXPECTED_NINE_TOOLCHAIN_ARTIFACTS")
        artifacts = []
    for record in artifacts:
        relative = record.get("path") if isinstance(record, dict) else None
        expected_bytes = record.get("bytes") if isinstance(record, dict) else None
        expected_hash = record.get("sha256") if isinstance(record, dict) else None
        if not isinstance(relative, str) or not isinstance(expected_bytes, int) or not isinstance(expected_hash, str):
            errors.append("INVALID_ARTIFACT_RECORD")
            continue
        try:
            path = _safe_file(relative)
        except (ValueError, OSError):
            errors.append(f"UNSAFE_ARTIFACT_PATH:{relative}")
            continue
        if not path.is_file():
            errors.append(f"MISSING_ARTIFACT:{relative}")
            continue
        if path.stat().st_size != expected_bytes:
            errors.append(f"SIZE_MISMATCH:{relative}")
            continue
        if sha256(path) != expected_hash:
            errors.append(f"SHA256_MISMATCH:{relative}")
            continue
        resolved[str(record.get("role"))] = path
        verified_artifacts += 1

    wheel_expectations = {
        "rknn_toolkit2_cp38_x86_64_wheel": "rknn-toolkit2",
        "rknn_toolkit_lite2_cp38_aarch64_wheel": "rknn-toolkit-lite2",
    }
    for role, expected_name in wheel_expectations.items():
        path = resolved.get(role)
        if path:
            try:
                name, version = _wheel_version(path)
            except (OSError, zipfile.BadZipFile):
                name, version = None, None
            if name != expected_name or version != "2.3.2":
                errors.append(f"WHEEL_METADATA_MISMATCH:{role}")

    runtime = resolved.get("librknnrt_aarch64")
    if runtime and b"librknnrt version: 2.3.2" not in runtime.read_bytes():
        errors.append("RUNTIME_VERSION_STRING_MISMATCH")
    server = resolved.get("rknn_server_aarch64")
    if server and b"rknn_server version: 2.3.2" not in server.read_bytes():
        errors.append("SERVER_VERSION_STRING_MISMATCH")

    execution = contract.get("execution_evidence", {})
    if not isinstance(execution, dict):
        errors.append("EXECUTION_EVIDENCE_MISSING")
        execution = {}
    environment = _load_evidence(
        execution.get("environment"), "PASS_ENGINEERING_ENVIRONMENT_CAPTURE", errors
    )
    conversion = _load_evidence(
        execution.get("conversion"), "PASS_ENGINEERING_CONVERSION_ONLY", errors
    )
    simulation = _load_evidence(
        execution.get("pc_simulation"), "PASS_ENGINEERING_SIMULATOR_EXECUTION", errors
    )
    dependency_lock = _verify_dependency_lock(execution.get("dependency_lock"), host, errors)
    if environment:
        if environment.get("image_id") != host.get("conversion_image_id"):
            errors.append("CONVERSION_IMAGE_ID_MISMATCH")
        if environment.get("python") != host.get("python_patch"):
            errors.append("CONVERSION_PYTHON_VERSION_MISMATCH")
        if environment.get("rknn_toolkit2") != host.get("rknn_toolkit2"):
            errors.append("CONVERSION_TOOLKIT_VERSION_MISMATCH")
        if environment.get("dependency_artifact_hash_lock_complete") is not False:
            errors.append("DEPENDENCY_ARTIFACT_HASH_LOCK_OVERSTATED")
    if conversion:
        _verify_file_record(conversion.get("input"), errors, "conversion_input")
        _verify_file_record(conversion.get("output"), errors, "conversion_output")
        if conversion.get("target") != "rk3566" or conversion.get("hardware_measured") is not False:
            errors.append("INVALID_CONVERSION_SCOPE")
    if simulation:
        comparison = simulation.get("comparison", {})
        if comparison.get("same_shape") is not True:
            errors.append("SIMULATOR_OUTPUT_SHAPE_MISMATCH")
        if simulation.get("exported_rknn_loaded_by_simulator") is not False:
            errors.append("SIMULATOR_EXPORTED_RKNN_CLAIM_INVALID")
        if simulation.get("hardware_measured") is not False:
            errors.append("SIMULATOR_HARDWARE_CLAIM_INVALID")
        if conversion and simulation.get("inputs", {}).get("rknn_sha256") != conversion.get("output", {}).get("sha256"):
            errors.append("SIMULATOR_RKNN_HASH_MISMATCH")

    blockers = contract.get("blockers")
    if not isinstance(blockers, list) or len(blockers) < 5:
        errors.append("R02_BLOCKERS_NOT_EXPLICIT")

    return {
        "status": "PASS_ENGINEERING_PARTIAL" if not errors else "FAIL",
        "phase": "R02_IN_PROGRESS",
        "verified_artifacts": verified_artifacts,
        "conversion_environment_rebuilt": True,
        "official_sample_smoke_verified": True,
        "pc_simulator_alignment_verified": True,
        "dependency_artifact_hash_lock_complete": bool(dependency_lock) and not errors,
        "real_rk3566_verified": False,
        "formal_release_allowed": False,
        "errors": errors,
    }


def main() -> int:
    result = verify_matrix()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS_ENGINEERING_PARTIAL" else 2


if __name__ == "__main__":
    raise SystemExit(main())
