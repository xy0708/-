from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from research_assets import official_research_root


OCR_ROOT = ROOT.parent / "OCR"
RESEARCH_ROOT = official_research_root(ROOT)
MANIFEST = OCR_ROOT / "data/synthetic/synthetic_ground_truth.json"
OUTPUT = ROOT / "reports/rknn_simulation_ppocrv4_synthetic_batch.json"
IMAGE = "family-health-ppocr-simulator:2.3.2-cp38-postprocess1"
EXPECTED_IMAGE_ID = (
    "sha256:8e4d42a783beabb42f820013060eb5ff0eb5e59f43d803848bb901274ae9faaf"
)


def sha256(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def raster_inputs() -> list[Path]:
    payload = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if (
        payload.get("scope") != "synthetic_engineering_only"
        or payload.get("formal_evaluation_allowed") is not False
    ):
        raise RuntimeError("SYNTHETIC_MANIFEST_BOUNDARY_INVALID")
    paths: list[Path] = []
    for artifact in payload.get("artifacts", []):
        relative = artifact.get("path")
        digest = artifact.get("sha256")
        if not isinstance(relative, str) or not isinstance(digest, str):
            raise RuntimeError("SYNTHETIC_ARTIFACT_SCHEMA_INVALID")
        path = OCR_ROOT / relative
        if path.suffix.lower() not in {".png", ".jpg", ".jpeg"}:
            continue
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError(f"SYNTHETIC_ARTIFACT_HASH_MISMATCH:{path.name}")
        paths.append(path)
    if len(paths) < 2:
        raise RuntimeError("SYNTHETIC_RASTER_SET_TOO_SMALL")
    return paths


def inspect_image(docker: str) -> str:
    completed = subprocess.run(
        [docker, "image", "inspect", IMAGE, "--format", "{{.Id}}"],
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
        check=False,
    )
    image_id = completed.stdout.decode("utf-8", errors="replace").strip()
    if completed.returncode != 0 or image_id != EXPECTED_IMAGE_ID:
        raise RuntimeError("OCR_SIMULATOR_IMAGE_ID_MISMATCH_OR_MISSING")
    return image_id


def main() -> int:
    docker = shutil.which("docker")
    if docker is None:
        raise RuntimeError("DOCKER_CLI_MISSING")
    image_id = inspect_image(docker)
    images = raster_inputs()
    with tempfile.TemporaryDirectory(
        prefix="ocr-rknn-batch-", dir=ROOT / "reports"
    ) as directory:
        staging = Path(directory)
        command = [
            docker,
            "run",
            "--rm",
            "--network",
            "none",
            "--read-only",
            "--pids-limit",
            "256",
            "--memory",
            "8g",
            "--cpus",
            "4",
            "--security-opt",
            "no-new-privileges",
            "--tmpfs",
            "/tmp:rw,noexec,nosuid,size=2g",
            "--mount",
            f"type=bind,source={ROOT},target=/workspace/project,readonly",
            "--mount",
            f"type=bind,source={RESEARCH_ROOT},target=/workspace/research,readonly",
            "--mount",
            (
                "type=bind,source="
                f"{OCR_ROOT / 'data/synthetic'},target=/workspace/synthetic,readonly"
            ),
            "--mount",
            f"type=bind,source={staging},target=/workspace/output",
            IMAGE,
            "python3",
            "/workspace/project/conversion/ocr/simulate_ppocrv4_batch.py",
            "--det-onnx",
            "/workspace/research/artifacts/official_models/source_onnx/ppocrv4_det.onnx",
            "--rec-onnx",
            "/workspace/research/artifacts/official_models/source_onnx/ppocrv4_rec.onnx",
            "--det-rknn",
            "/workspace/research/artifacts/official_models/rknn_engineering/ppocrv4_det_fp16.rknn",
            "--rec-rknn",
            "/workspace/research/artifacts/official_models/rknn_engineering/ppocrv4_rec_fp16.rknn",
            "--dictionary",
            "/workspace/project/vendor/rockchip/rknn_model_zoo/examples/PPOCR/PPOCR-System/model/ppocr_keys_v1.txt",
            "--official-python",
            "/workspace/project/vendor/rockchip/rknn_model_zoo/examples/PPOCR/PPOCR-System/python",
            "--simulator-image-id",
            image_id,
            "--report",
            "/workspace/output/report.json",
        ]
        for path in images:
            command.extend(("--image", f"/workspace/synthetic/{path.name}"))
        completed = subprocess.run(
            command,
            cwd=ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=1800,
            check=False,
        )
        output = completed.stdout.decode("utf-8", errors="replace")
        report_path = staging / "report.json"
        if completed.returncode != 0 or not report_path.is_file():
            safe_tail = re.sub(r"[^\x20-\x7E\n]", "?", output[-4000:])
            raise RuntimeError(
                f"OCR_SYNTHETIC_BATCH_FAILED:{completed.returncode}:{safe_tail}"
            )
        report = json.loads(report_path.read_text(encoding="utf-8"))
        if (
            report.get("status")
            != "PASS_ENGINEERING_SYNTHETIC_BATCH_SIMULATION_PRODUCT_BLOCKED"
            or report.get("simulator_image_id") != EXPECTED_IMAGE_ID
            or report.get("preprocessing", {}).get("strategy")
            != "overlapping_tiles_then_global_iou_deduplication"
            or len(report.get("samples", [])) != len(images)
        ):
            raise RuntimeError("OCR_SYNTHETIC_BATCH_REPORT_INVALID")
        temporary = OUTPUT.with_suffix(".tmp")
        shutil.copyfile(report_path, temporary)
        temporary.replace(OUTPUT)
    print(
        json.dumps(
            {
                "status": report["status"],
                "samples": len(report["samples"]),
                "report": OUTPUT.relative_to(ROOT).as_posix(),
                "report_sha256": sha256(OUTPUT),
            },
            ensure_ascii=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
