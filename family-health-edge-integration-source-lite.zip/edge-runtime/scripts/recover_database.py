from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from storage import StoragePolicyError, restore_database_from_backup


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Restore a stopped edge SQLite database from a verified backup"
    )
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--backup", type=Path, required=True)
    parser.add_argument("--backup-sha256", required=True)
    parser.add_argument("--allowed-root", type=Path, required=True)
    parser.add_argument("--service-stopped-confirmed", action="store_true")
    args = parser.parse_args()
    if not args.service_stopped_confirmed:
        print(json.dumps({"status": "BLOCKED", "error": "SERVICE_STOP_NOT_CONFIRMED"}))
        return 2
    try:
        previous = restore_database_from_backup(
            args.database,
            args.backup,
            expected_backup_sha256=args.backup_sha256,
            allowed_root=args.allowed_root,
        )
    except (OSError, StoragePolicyError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}))
        return 2
    print(
        json.dumps(
            {
                "status": "RESTORED",
                "database": str(args.database),
                "previous_database": str(previous) if previous else None,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
