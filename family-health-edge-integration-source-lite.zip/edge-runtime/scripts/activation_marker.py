from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from update_agent.activation import (
    ActivationMarkerError,
    clear_activation_marker,
    prepare_activation_marker,
    read_activation_marker,
    require_root_owned_activation_path,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="operation", required=True)
    prepare = subparsers.add_parser("prepare")
    prepare.add_argument("--marker", type=Path, required=True)
    prepare.add_argument("--candidate", required=True)
    prepare.add_argument("--previous")
    read = subparsers.add_parser("read")
    read.add_argument("--marker", type=Path, required=True)
    read.add_argument(
        "--field",
        required=True,
        choices=("candidate_release_id", "previous_release_id"),
    )
    clear = subparsers.add_parser("clear")
    clear.add_argument("--marker", type=Path, required=True)
    clear.add_argument("--candidate", required=True)
    arguments = parser.parse_args()
    try:
        if arguments.operation == "prepare":
            require_root_owned_activation_path(arguments.marker, marker_required=False)
            record = prepare_activation_marker(
                arguments.marker, arguments.candidate, arguments.previous
            )
            output: object = {
                "status": "PENDING_ACTIVATION_RECORDED",
                "candidate_release_id": record.candidate_release_id,
            }
        elif arguments.operation == "read":
            require_root_owned_activation_path(arguments.marker, marker_required=True)
            record = read_activation_marker(arguments.marker)
            value = getattr(record, arguments.field)
            print("-" if value is None else value)
            return 0
        else:
            require_root_owned_activation_path(arguments.marker, marker_required=True)
            clear_activation_marker(arguments.marker, arguments.candidate)
            output = {"status": "PENDING_ACTIVATION_CLEARED"}
    except (ActivationMarkerError, OSError) as exc:
        print(json.dumps({"status": "FAIL_CLOSED", "error": str(exc)}))
        return 2
    print(json.dumps(output, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
