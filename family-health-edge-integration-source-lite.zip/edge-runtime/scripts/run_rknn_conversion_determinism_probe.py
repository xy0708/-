from __future__ import annotations

import json
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

if __package__:
    from .run_rknn_conversion_reproducibility import (
        CASES,
        DEFAULT_IMAGE,
        EXPECTED_IMAGE_ID,
        ROOT,
        binary_diff_summary,
        changed_region_diagnostics,
        load_report,
        sha256,
    )
else:
    from run_rknn_conversion_reproducibility import (
        CASES,
        DEFAULT_IMAGE,
        EXPECTED_IMAGE_ID,
        ROOT,
        binary_diff_summary,
        changed_region_diagnostics,
        load_report,
        sha256,
    )


REPORT = ROOT / "reports" / "rknn_conversion_determinism_probe.json"
FIXED_ENVIRONMENT = (
    "PYTHONHASHSEED=0",
    "SOURCE_DATE_EPOCH=0",
    "TZ=UTC",
    "OMP_NUM_THREADS=1",
    "OPENBLAS_NUM_THREADS=1",
    "MKL_NUM_THREADS=1",
    "NUMEXPR_NUM_THREADS=1",
)


def inspect_image_details() -> tuple[str | None, str | None]:
    completed = subprocess.run(
        ["docker", "image", "inspect", DEFAULT_IMAGE, "--format", "{{.Id}}"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    image_id = completed.stdout.strip() if completed.returncode == 0 else None
    error = None if image_id else (completed.stderr.strip() or "DOCKER_IMAGE_INSPECT_FAILED")
    return image_id, error


def probe_status(image_matches: bool, successful: int, reproducible: int) -> str:
    if not image_matches:
        return "BLOCKED_ENVIRONMENT_CONVERSION_IMAGE_UNAVAILABLE"
    if successful != len(CASES):
        return "FAIL_ENGINEERING_FIXED_ENVIRONMENT_CONVERSION"
    if reproducible == len(CASES):
        return "PASS_ENGINEERING_FIXED_ENVIRONMENT_BYTE_REPRODUCIBLE"
    return "PARTIAL_PASS_ENGINEERING_FIXED_ENVIRONMENT_HASH_DRIFT"


def docker_command(case: Any, temporary_root: Path, label: str) -> list[str]:
    command = ["docker", "run", "--rm", "--network", "none"]
    for variable in FIXED_ENVIRONMENT:
        command.extend(("--env", variable))
    command.extend(
        (
            "--volume",
            f"{ROOT}:/workspace:ro",
            "--volume",
            f"{temporary_root}:/evidence",
            "--workdir",
            "/tmp/rknn-run",
            DEFAULT_IMAGE,
            "python",
            "/workspace/conversion/toolchain/smoke_convert.py",
            "--input",
            f"/workspace/{case.source}",
            "--output",
            f"/evidence/{case.name}-{label}.rknn",
            "--report",
            f"/evidence/{case.name}-{label}.json",
            "--profile",
            case.profile,
        )
    )
    return command


def run_once(case: Any, temporary_root: Path, log_dir: Path, label: str) -> dict[str, Any]:
    command = docker_command(case, temporary_root, label)
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=600,
        check=False,
    )
    log_path = log_dir / f"{case.name}-{label}.log"
    log_path.write_text(completed.stdout + completed.stderr, encoding="utf-8")
    output_path = temporary_root / f"{case.name}-{label}.rknn"
    conversion_report = load_report(temporary_root / f"{case.name}-{label}.json")
    output_hash = sha256(output_path) if output_path.is_file() else None
    source_hash = sha256(ROOT / case.source)
    succeeded = (
        completed.returncode == 0
        and conversion_report.get("status") == "PASS_ENGINEERING_CONVERSION_ONLY"
        and conversion_report.get("input", {}).get("sha256") == source_hash
        and conversion_report.get("output", {}).get("sha256") == output_hash
    )
    return {
        "label": label,
        "succeeded": succeeded,
        "exit_code": completed.returncode,
        "output_path": output_path,
        "output_sha256": output_hash,
        "log": log_path.relative_to(ROOT).as_posix(),
        "log_sha256": sha256(log_path),
    }


def summarize_case(case: Any, first: dict[str, Any], second: dict[str, Any]) -> dict[str, Any]:
    canonical = ROOT / case.canonical_output
    pairwise_equal = (
        first["succeeded"]
        and second["succeeded"]
        and first["output_sha256"] == second["output_sha256"]
    )
    diff = None
    diagnostics = None
    if first["succeeded"] and second["succeeded"] and not pairwise_equal:
        diff = binary_diff_summary(first["output_path"], second["output_path"])
        diagnostics = changed_region_diagnostics(
            first["output_path"], second["output_path"], diff
        )
    return {
        "name": case.name,
        "source": case.source,
        "canonical_output": case.canonical_output,
        "canonical_output_sha256": sha256(canonical),
        "first_output_sha256": first["output_sha256"],
        "second_output_sha256": second["output_sha256"],
        "both_conversions_succeeded": first["succeeded"] and second["succeeded"],
        "fixed_environment_pairwise_byte_reproducible": pairwise_equal,
        "matches_canonical": pairwise_equal
        and first["output_sha256"] == sha256(canonical),
        "binary_diff": diff,
        "binary_diff_diagnostics": diagnostics,
        "logs": [first["log"], second["log"]],
        "log_sha256": [first["log_sha256"], second["log_sha256"]],
    }


def main() -> int:
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    image_id, image_inspect_error = inspect_image_details()
    log_dir = ROOT / "reports" / "rknn_determinism_probe_runs" / run_id
    log_dir.mkdir(parents=True, exist_ok=False)
    artifact_work = ROOT / ".artifact-work"
    artifact_work.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    temporary_path: Path | None = None
    if image_id == EXPECTED_IMAGE_ID:
        with tempfile.TemporaryDirectory(
            prefix="determinism-probe-", dir=artifact_work
        ) as temporary:
            temporary_path = Path(temporary).resolve()
            if not temporary_path.is_relative_to(artifact_work.resolve()):
                raise RuntimeError("Unsafe probe temporary directory")
            for case in CASES:
                first = run_once(case, temporary_path, log_dir, "a")
                second = run_once(case, temporary_path, log_dir, "b")
                records.append(summarize_case(case, first, second))
    temporary_deleted = temporary_path is None or not temporary_path.exists()
    successful = sum(record["both_conversions_succeeded"] for record in records)
    reproducible = sum(
        record["fixed_environment_pairwise_byte_reproducible"] for record in records
    )
    all_reproducible = (
        image_id == EXPECTED_IMAGE_ID
        and successful == len(CASES)
        and reproducible == len(CASES)
        and temporary_deleted
    )
    status = probe_status(image_id == EXPECTED_IMAGE_ID, successful, reproducible)
    result = {
        "schema_version": "1.0.0",
        "run_id": run_id,
        "status": status,
        "scope": "OFFLINE_HOST_CONVERSION_DETERMINISM_PROBE_ONLY",
        "image": DEFAULT_IMAGE,
        "expected_image_id": EXPECTED_IMAGE_ID,
        "actual_image_id": image_id,
        "image_inspect_error": image_inspect_error,
        "image_id_matches": image_id == EXPECTED_IMAGE_ID,
        "network_disabled": True,
        "fixed_environment": list(FIXED_ENVIRONMENT),
        "candidate_count": len(CASES),
        "double_conversion_success_count": successful,
        "pairwise_byte_reproducible_count": reproducible,
        "pairwise_hash_drift_count": successful - reproducible,
        "temporary_artifacts_deleted": temporary_deleted,
        "hardware_measured": False,
        "product_selection_allowed": False,
        "records": records,
        "log_directory": log_dir.relative_to(ROOT).as_posix(),
    }
    REPORT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in result.items() if key != "records"},
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0 if all_reproducible else (3 if image_id is None else 2)


if __name__ == "__main__":
    raise SystemExit(main())
