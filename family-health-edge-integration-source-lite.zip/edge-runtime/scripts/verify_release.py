from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from acceptance.approvals import (
    REQUIRED_EXTERNAL_GATES,
    approval_gate_errors,
    gate_registry_errors,
)
from acceptance.contract import acceptance_contract_scenario_errors


REPORT = ROOT / "reports" / "final_release_verification.json"


def load_json(relative: str, blockers: list[str]) -> dict[str, Any]:
    path = ROOT / relative
    if not path.is_file():
        blockers.append(f"MISSING_REPORT:{relative}")
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        blockers.append(f"INVALID_REPORT:{relative}")
        return {}
    if not isinstance(value, dict):
        blockers.append(f"INVALID_REPORT_OBJECT:{relative}")
        return {}
    return value


def evaluate(*, require_formal_release: bool = True) -> dict[str, Any]:
    blockers: list[str] = []
    evidence = load_json("configs/product_gate_evidence.json", blockers)
    blockers.extend(
        f"EXTERNAL_GATE_REGISTRY_{error}" for error in gate_registry_errors(evidence)
    )
    for gate_name in sorted(REQUIRED_EXTERNAL_GATES):
        blockers.extend(
            f"EXTERNAL_GATE_{error}:{gate_name}"
            for error in approval_gate_errors(ROOT, evidence, gate_name)
        )

    required_reports = {
        "reports/workspace_verification.json": "PASS_ENGINEERING",
        "reports/product_scope_verification.json": "PASS_ENGINEERING",
        "reports/health_rules_verification.json": "PASS_ENGINEERING",
        "reports/asr_arm64_verification.json": "PASS_ENGINEERING",
        "reports/ocr_rknn_verification.json": "PASS_ENGINEERING",
        "reports/privacy_verification.json": "PASS_ENGINEERING",
        "reports/dependency_security.json": "PASS_ENGINEERING",
        "reports/deployment_script_verification.json": "PASS_ENGINEERING",
        "reports/device_service_smoke.json": "PASS_ENGINEERING",
        "reports/data_policy_verification.json": "PASS_ENGINEERING",
    }
    reports: dict[str, dict[str, Any]] = {}
    for relative, expected_status in required_reports.items():
        report = load_json(relative, blockers)
        reports[relative] = report
        if report.get("status") != expected_status:
            blockers.append(f"ENGINEERING_GATE_NOT_PASS:{relative}")

    runtime_tool = load_json("reports/arm64_runtime_tool_verification.json", blockers)
    if (
        runtime_tool.get("status") != "PASS_ENGINEERING_ARM64_TOOL_PRODUCT_BLOCKED"
        or runtime_tool.get("errors") != []
    ):
        blockers.append("MANAGEMENT_RUNTIME_ENGINEERING_GATE_NOT_PASS")

    device_acceptance = load_json("reports/device_acceptance.json", blockers)
    if device_acceptance.get("status") != "PASS_PRODUCT_GATE":
        blockers.append("REAL_DEVICE_INDEPENDENT_ACCEPTANCE_NOT_PASS")
    if device_acceptance.get("hardware_measured") is not True:
        blockers.append("REAL_RK3566_EVIDENCE_FALSE_OR_MISSING")
    if device_acceptance.get("synthetic_evidence_used") is not False:
        blockers.append("SYNTHETIC_EVIDENCE_FORBIDDEN")

    asr = reports.get("reports/asr_arm64_verification.json", {})
    if (
        asr.get("hardware_measured") is not True
        or asr.get("legal_opinion") is not True
        or asr.get("arm64_runtime_ready") is not True
        or asr.get("product_gate") != "PASS_PRODUCT_GATE"
    ):
        blockers.append("ASR_PRODUCT_HARDWARE_OR_LICENSE_GATE_NOT_PASS")
    ocr = reports.get("reports/ocr_rknn_verification.json", {})
    if (
        ocr.get("hardware_measured") is not True
        or ocr.get("weight_license_final") is not True
        or ocr.get("product_gate") != "PASS_PRODUCT_GATE"
    ):
        blockers.append("OCR_PRODUCT_HARDWARE_OR_LICENSE_GATE_NOT_PASS")
    product_onnx_files = ocr.get("product_onnx_files")
    product_rknn_files = ocr.get("product_rknn_files")
    if (
        not isinstance(product_onnx_files, list)
        or len(product_onnx_files) < 2
        or not isinstance(product_rknn_files, list)
        or len(product_rknn_files) < 2
    ):
        blockers.append("OCR_PRODUCT_RKNN_ARTIFACTS_MISSING")
    privacy = reports.get("reports/privacy_verification.json", {})
    if privacy.get("product_privacy_gate") is not True:
        blockers.append("PRIVACY_PRODUCT_GATE_NOT_PASS")

    acceptance = load_json("configs/acceptance_contract.json", blockers)
    if acceptance.get("frozen_before_testing") is not True or acceptance.get("approval_status") != "APPROVED":
        blockers.append("ACCEPTANCE_CONTRACT_NOT_FROZEN_AND_APPROVED")
    thresholds = acceptance.get("thresholds")
    if not isinstance(thresholds, dict) or not thresholds or any(
        value is None for value in thresholds.values()
    ):
        blockers.append("ACCEPTANCE_THRESHOLDS_INCOMPLETE")
    blockers.extend(acceptance_contract_scenario_errors(acceptance))

    release_inputs = load_json("configs/release_inputs.json", blockers)
    release_id = release_inputs.get("release_id")
    if release_inputs.get("frozen") is not True or not release_inputs.get("files"):
        blockers.append("RELEASE_INPUT_MANIFEST_NOT_FROZEN_OR_EMPTY")
    else:
        from release_tools import (
            ReleaseInputError,
            validate_product_release_contents,
            validate_release_inputs,
        )

        try:
            validated_release_inputs = validate_release_inputs(release_inputs, ROOT)
            validate_product_release_contents(validated_release_inputs)
        except ReleaseInputError as exc:
            blockers.append(f"PRODUCT_RELEASE_INPUT_INVALID:{exc}")
    if release_inputs.get("database_rollback_compatible") is not True:
        blockers.append("DATABASE_ROLLBACK_COMPATIBILITY_NOT_APPROVED")

    formal_release_verified = False
    if require_formal_release:
        from release_tools import (
            ReleaseInputError,
            approved_public_key,
            controlled_release_path,
            verify_product_release_bundle,
        )

        key: Path | None = None
        try:
            key = approved_public_key(ROOT)
        except (OSError, ReleaseInputError) as exc:
            blockers.append(f"SIGNING_POLICY_INVALID:{exc}")
        if not isinstance(release_id, str):
            blockers.append("FORMAL_RELEASE_ID_NOT_CONFIGURED")
        elif key is not None:
            try:
                bundle = controlled_release_path(
                    ROOT, "release", release_id, require_collection=True
                )
            except ReleaseInputError as exc:
                blockers.append(f"FORMAL_RELEASE_PATH_INVALID:{exc}")
            else:
                bundle_result = verify_product_release_bundle(bundle, key)
                if bundle_result.passed:
                    formal_release_verified = True
                else:
                    blockers.extend(
                        f"FORMAL_RELEASE_INVALID:{item}"
                        for item in bundle_result.failures
                    )

    blockers = sorted(set(blockers))
    release_allowed = not blockers
    return {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_PRODUCT_GATE" if release_allowed else "BLOCKED_EXTERNAL",
        "software_engineering_status": "PASS_ENGINEERING" if not any(
            item.startswith(("MISSING_REPORT", "INVALID_REPORT", "ENGINEERING_GATE_NOT_PASS"))
            for item in blockers
        ) else "FAIL_OR_INCOMPLETE",
        "real_device_acceptance_status": device_acceptance.get("status", "MISSING"),
        "data_and_license_status": "PASS" if not any(
            "LICENSE" in item or "EXTERNAL_GATE" in item for item in blockers
        ) else "BLOCKED_EXTERNAL",
        "privacy_and_security_status": "PASS" if privacy.get("product_privacy_gate") is True else "BLOCKED_EXTERNAL",
        "classification_and_legal_status": "PASS" if not any(
            item.startswith("EXTERNAL_GATE_") for item in blockers
        ) else "BLOCKED_EXTERNAL",
        "known_limitations": [
            "Health V1 is a non-diagnostic rules-and-trends warning tool",
            "No disease probability output is permitted",
            "Engineering test success does not replace real RK3566 acceptance",
        ],
        "release_allowed": release_allowed,
        "formal_release_verified": formal_release_verified,
        "formal_release_id": release_id if formal_release_verified else None,
        "blockers": blockers,
    }


def main() -> int:
    result = evaluate()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if result["release_allowed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
