from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from collect_android_preflight import find_adb


ROOT = Path(__file__).resolve().parents[1]
APK = ROOT / "android_app" / "build" / "app" / "outputs" / "flutter-apk" / "app-debug.apk"
FLUTTER_REPORT = ROOT / "reports" / "android_flutter_validation.json"
PREFLIGHT_REPORT = ROOT / "reports" / "android_device_preflight.json"
INSTALL_REPORT = ROOT / "reports" / "android_device_install.json"
PACKAGE = "com.familyhealth.edge.terminal"
COMPONENT = f"{PACKAGE}/.MainActivity"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def display_path(path: Path) -> str:
    try:
        value = path.relative_to(ROOT)
    except ValueError:
        value = path
    return str(value).replace("\\", "/")


def run(command: list[str], timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=ROOT,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
    )


def validated_apk_evidence(apk: Path, validation_report: Path) -> tuple[list[str], dict]:
    errors: list[str] = []
    if not apk.is_file():
        return ["debug_apk_missing"], {}
    if not validation_report.is_file():
        return ["flutter_validation_report_missing"], {}

    report = load_json(validation_report)
    actual_sha256 = sha256(apk)
    expected_sha256 = report.get("apk", {}).get("sha256")
    if report.get("status") != "PASS_ENGINEERING_DEBUG_APK":
        errors.append("flutter_validation_not_passed")
    if expected_sha256 != actual_sha256:
        errors.append("debug_apk_hash_not_bound_to_validation")
    if report.get("apk_inspection", {}).get("abis") != ["arm64-v8a"]:
        errors.append("debug_apk_not_arm64_only")
    if report.get("apk_inspection", {}).get("asr_assets_valid") is not True:
        errors.append("debug_apk_asr_assets_not_validated")
    return errors, {
        "path": display_path(apk),
        "bytes": apk.stat().st_size,
        "sha256": actual_sha256,
        "validation_report_sha256": sha256(validation_report),
    }


def adb_result_ok(result: subprocess.CompletedProcess[str]) -> bool:
    combined = f"{result.stdout}\n{result.stderr}".casefold()
    return result.returncode == 0 and "error:" not in combined and "exception" not in combined


def write_report(payload: dict) -> None:
    INSTALL_REPORT.parent.mkdir(parents=True, exist_ok=True)
    INSTALL_REPORT.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def finish(status: str, reason: str | None, **evidence: object) -> int:
    payload = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "reason": reason,
        "product_release": False,
        "debug_signed": True,
        **evidence,
    }
    write_report(payload)
    return 0 if status == "PASS_ENGINEERING_INSTALLED_PRODUCT_BLOCKED" else 2


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    apk_errors, apk_evidence = validated_apk_evidence(APK, FLUTTER_REPORT)
    if apk_errors:
        return finish(
            "BLOCKED_ENVIRONMENT",
            "validated_debug_apk_unavailable",
            errors=apk_errors,
            apk=apk_evidence,
            hardware_measured=False,
        )

    adb = find_adb()
    if adb is None:
        return finish(
            "BLOCKED_ENVIRONMENT",
            "adb_not_found",
            apk=apk_evidence,
            hardware_measured=False,
        )

    preflight_result = run(
        [sys.executable, str(ROOT / "scripts" / "collect_android_preflight.py")],
        timeout=60,
    )
    preflight = load_json(PREFLIGHT_REPORT) if PREFLIGHT_REPORT.is_file() else {}
    if (
        preflight_result.returncode != 0
        or preflight.get("status") != "PASS_ENGINEERING_DEVICE_CONNECTED_PRODUCT_BLOCKED"
    ):
        return finish(
            "BLOCKED_EXTERNAL",
            str(preflight.get("reason") or "target_device_preflight_failed"),
            apk=apk_evidence,
            hardware_measured=False,
            preflight=preflight,
        )

    serial = str(preflight["serial"])
    install = run([adb, "-s", serial, "install", "-r", "-t", str(APK)], timeout=300)
    if not adb_result_ok(install) or "success" not in install.stdout.casefold():
        return finish(
            "FAIL_INSTALL",
            "adb_install_failed",
            apk=apk_evidence,
            hardware_measured=True,
            serial=serial,
            install_stdout=install.stdout[-4000:],
            install_stderr=install.stderr[-4000:],
            product_blockers=preflight.get("product_blockers", []),
        )

    installed_path = run([adb, "-s", serial, "shell", "pm", "path", PACKAGE], timeout=30)
    if not adb_result_ok(installed_path) or not installed_path.stdout.strip().startswith("package:"):
        return finish(
            "FAIL_INSTALL_VERIFICATION",
            "installed_package_not_found",
            apk=apk_evidence,
            hardware_measured=True,
            serial=serial,
            package_stdout=installed_path.stdout[-2000:],
            package_stderr=installed_path.stderr[-2000:],
            product_blockers=preflight.get("product_blockers", []),
        )

    launch = run([adb, "-s", serial, "shell", "am", "start", "-W", "-n", COMPONENT], timeout=60)
    if not adb_result_ok(launch):
        return finish(
            "FAIL_LAUNCH",
            "main_activity_launch_failed",
            apk=apk_evidence,
            hardware_measured=True,
            serial=serial,
            launch_stdout=launch.stdout[-4000:],
            launch_stderr=launch.stderr[-4000:],
            product_blockers=preflight.get("product_blockers", []),
        )

    return finish(
        "PASS_ENGINEERING_INSTALLED_PRODUCT_BLOCKED",
        None,
        apk=apk_evidence,
        hardware_measured=True,
        serial=serial,
        package=PACKAGE,
        component=COMPONENT,
        installed_package_path=installed_path.stdout.strip(),
        launch_stdout=launch.stdout[-4000:],
        product_blockers=preflight.get("product_blockers", []),
        remaining_product_blockers=[
            "debug_apk_is_not_formal_release",
            "release_signing_not_configured",
            "ocr_android_runtime_missing",
            "rk3576_performance_and_stability_acceptance_not_run",
        ],
    )


if __name__ == "__main__":
    raise SystemExit(main())
