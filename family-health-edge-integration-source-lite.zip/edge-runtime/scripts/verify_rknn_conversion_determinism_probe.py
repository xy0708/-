from __future__ import annotations

import json
from pathlib import Path
from typing import Any

if __package__:
    from .run_rknn_conversion_determinism_probe import FIXED_ENVIRONMENT
    from .verify_rknn_conversion_reproducibility import (
        EXPECTED_CASES,
        EXPECTED_IMAGE_ID,
        ROOT,
        safe_file,
        sha256,
        valid_sha256,
        verify_changed_region,
    )
else:
    from run_rknn_conversion_determinism_probe import FIXED_ENVIRONMENT
    from verify_rknn_conversion_reproducibility import (
        EXPECTED_CASES,
        EXPECTED_IMAGE_ID,
        ROOT,
        safe_file,
        sha256,
        valid_sha256,
        verify_changed_region,
    )


SOURCE_REPORT = ROOT / "reports" / "rknn_conversion_determinism_probe.json"
OUTPUT_REPORT = ROOT / "reports" / "rknn_conversion_determinism_probe_verification.json"


def verify_payload(root: Path, payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if payload.get("scope") != "OFFLINE_HOST_CONVERSION_DETERMINISM_PROBE_ONLY":
        errors.append("SCOPE_INVALID")
    if payload.get("expected_image_id") != EXPECTED_IMAGE_ID:
        errors.append("EXPECTED_IMAGE_ID_INVALID")
    if payload.get("actual_image_id") != EXPECTED_IMAGE_ID:
        errors.append("ACTUAL_IMAGE_ID_INVALID")
    if payload.get("image_id_matches") is not True or payload.get("image_inspect_error") is not None:
        errors.append("IMAGE_INSPECTION_INVALID")
    if payload.get("network_disabled") is not True:
        errors.append("NETWORK_NOT_DISABLED")
    if payload.get("fixed_environment") != list(FIXED_ENVIRONMENT):
        errors.append("FIXED_ENVIRONMENT_INVALID")
    if payload.get("temporary_artifacts_deleted") is not True:
        errors.append("TEMPORARY_ARTIFACTS_REMAIN")
    if payload.get("hardware_measured") is not False:
        errors.append("HARDWARE_SCOPE_INVALID")
    if payload.get("product_selection_allowed") is not False:
        errors.append("PRODUCT_SELECTION_SCOPE_INVALID")

    records = payload.get("records")
    if not isinstance(records, list):
        return errors + ["RECORDS_INVALID"]
    by_name = {
        record.get("name"): record
        for record in records
        if isinstance(record, dict) and isinstance(record.get("name"), str)
    }
    if len(by_name) != len(records) or set(by_name) != set(EXPECTED_CASES):
        errors.append("CANDIDATE_SET_INVALID")

    success_count = 0
    reproducible_count = 0
    for name, (_, canonical_relative) in EXPECTED_CASES.items():
        record = by_name.get(name)
        if record is None:
            continue
        if record.get("canonical_output") != canonical_relative:
            errors.append(f"CANONICAL_PATH_INVALID:{name}")
        canonical = safe_file(root, record.get("canonical_output"))
        if canonical is None or sha256(canonical) != record.get("canonical_output_sha256"):
            errors.append(f"CANONICAL_HASH_MISMATCH:{name}")
        first_hash = record.get("first_output_sha256")
        second_hash = record.get("second_output_sha256")
        if not valid_sha256(first_hash) or not valid_sha256(second_hash):
            errors.append(f"PROBE_HASH_INVALID:{name}")
        if record.get("both_conversions_succeeded") is not True:
            errors.append(f"DOUBLE_CONVERSION_NOT_SUCCESSFUL:{name}")
        else:
            success_count += 1
        logs = record.get("logs")
        log_hashes = record.get("log_sha256")
        if not isinstance(logs, list) or not isinstance(log_hashes, list) or len(logs) != 2 or len(log_hashes) != 2:
            errors.append(f"LOG_RECORD_INVALID:{name}")
        else:
            for index, (relative, expected_hash) in enumerate(zip(logs, log_hashes)):
                log = safe_file(root, relative)
                if log is None or sha256(log) != expected_hash:
                    errors.append(f"LOG_HASH_MISMATCH:{name}:{index}")
        reproducible = record.get("fixed_environment_pairwise_byte_reproducible") is True
        if reproducible:
            reproducible_count += 1
            if first_hash != second_hash:
                errors.append(f"PAIRWISE_REPRODUCIBILITY_CONTRADICTION:{name}")
            expected_canonical_match = first_hash == record.get("canonical_output_sha256")
            if record.get("matches_canonical") is not expected_canonical_match:
                errors.append(f"CANONICAL_MATCH_INVALID:{name}")
            if record.get("binary_diff") is not None or record.get("binary_diff_diagnostics") is not None:
                errors.append(f"UNEXPECTED_DIFF:{name}")
        else:
            if first_hash == second_hash:
                errors.append(f"PAIRWISE_HASH_DRIFT_CONTRADICTION:{name}")
            if record.get("matches_canonical") is not False:
                errors.append(f"CANONICAL_MATCH_INVALID:{name}")
            verify_changed_region(record, errors)

    expected_count = len(EXPECTED_CASES)
    drift_count = success_count - reproducible_count
    if payload.get("candidate_count") != expected_count:
        errors.append("CANDIDATE_COUNT_INVALID")
    if payload.get("double_conversion_success_count") != success_count or success_count != expected_count:
        errors.append("DOUBLE_CONVERSION_COUNT_INVALID")
    if payload.get("pairwise_byte_reproducible_count") != reproducible_count:
        errors.append("PAIRWISE_REPRODUCIBLE_COUNT_INVALID")
    if payload.get("pairwise_hash_drift_count") != drift_count:
        errors.append("PAIRWISE_DRIFT_COUNT_INVALID")
    expected_status = (
        "PASS_ENGINEERING_FIXED_ENVIRONMENT_BYTE_REPRODUCIBLE"
        if reproducible_count == expected_count
        else "PARTIAL_PASS_ENGINEERING_FIXED_ENVIRONMENT_HASH_DRIFT"
    )
    if payload.get("status") != expected_status:
        errors.append("SOURCE_STATUS_INVALID")
    return errors


def verify_report(root: Path = ROOT, report: Path = SOURCE_REPORT) -> dict[str, Any]:
    try:
        payload = json.loads(report.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        payload = {}
        errors = ["SOURCE_REPORT_INVALID"]
    else:
        errors = verify_payload(root, payload)
    return {
        "schema_version": "1.0.0",
        "status": "PASS_ENGINEERING_DETERMINISM_PROBE_PRODUCT_BLOCKED" if not errors else "FAIL",
        "source_report": report.relative_to(root).as_posix() if report.is_relative_to(root) else str(report),
        "source_run_id": payload.get("run_id") if isinstance(payload, dict) else None,
        "double_conversion_success_count": payload.get("double_conversion_success_count") if isinstance(payload, dict) else None,
        "pairwise_byte_reproducible_count": payload.get("pairwise_byte_reproducible_count") if isinstance(payload, dict) else None,
        "pairwise_hash_drift_count": payload.get("pairwise_hash_drift_count") if isinstance(payload, dict) else None,
        "common_environment_nondeterminism_controlled": True,
        "toolkit_internal_nondeterminism_suspected_not_proven": True,
        "hardware_measured": False,
        "product_selected": False,
        "formal_release_allowed": False,
        "errors": errors,
    }


def main() -> int:
    result = verify_report()
    OUTPUT_REPORT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_REPORT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS_ENGINEERING_DETERMINISM_PROBE_PRODUCT_BLOCKED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
