from __future__ import annotations

import json
import shutil
import subprocess
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.verify_arm64_runtime_tool import (
    EXPECTED_STATUS as RUNTIME_TOOL_STATUS,
    verify as verify_runtime_tool,
)

REPORT = ROOT / "reports" / "deployment_script_verification.json"


def find_bash() -> str | None:
    candidates = []
    # Installing WSL adds a WindowsApps bash launcher which is not Git Bash.
    # A present launcher is not evidence of a working shell or Linux distro.
    if platform.system() == 'Windows':
        windows_git_bash = Path('C:/Program Files/Git/bin/bash.exe')
        if windows_git_bash.is_file():
            candidates.append(str(windows_git_bash))
    discovered = shutil.which("bash")
    if discovered and 'windowsapps' not in discovered.lower():
        candidates.append(discovered)
    for candidate in dict.fromkeys(candidates):
        try:
            probe = subprocess.run([candidate, '--noprofile', '--norc', '-c', 'exit 0'],
                                   capture_output=True, timeout=5, check=False)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if probe.returncode == 0:
            return candidate
    return None


def main() -> int:
    scripts = [
        ROOT / "scripts" / "preflight_rk3566.sh",
        ROOT / "scripts" / "build_sherpa_arm64.sh",
        ROOT / "scripts" / "install_release.sh",
        ROOT / "scripts" / "rollback_release.sh",
        ROOT / "scripts" / "recover_pending_activation.sh",
    ]
    failures: list[str] = []
    runtime_tool = verify_runtime_tool(ROOT)
    runtime_tool_built = (
        runtime_tool.get("status") == RUNTIME_TOOL_STATUS
        and runtime_tool.get("errors") == []
        and runtime_tool.get("hardware_measured") is False
        and runtime_tool.get("product_accepted") is False
    )
    bash = find_bash()
    if bash is None:
        failures.append("BASH_NOT_AVAILABLE_FOR_SYNTAX_CHECK")
    else:
        for path in scripts:
            completed = subprocess.run(
                [bash, "-n", str(path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=15,
                check=False,
            )
            if completed.returncode != 0:
                failures.append(f"BASH_SYNTAX_FAILED:{path.name}")
    local_preflight = None
    if bash is not None:
        completed = subprocess.run(
            [bash, str(ROOT / "scripts" / "preflight_rk3566.sh"), "-"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30,
            check=False,
        )
        try:
            local_preflight = json.loads(completed.stdout.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            failures.append("PREFLIGHT_SELF_TEST_INVALID_JSON")
        if completed.returncode not in {0, 2}:
            failures.append(f"PREFLIGHT_SELF_TEST_UNEXPECTED_EXIT:{completed.returncode}")
        if isinstance(local_preflight, dict):
            if completed.returncode == 0 and local_preflight.get("passed") is not True:
                failures.append("PREFLIGHT_EXIT_REPORT_CONTRADICTION")
            if platform.machine().lower() not in {"aarch64", "arm64"} and (
                local_preflight.get("hardware_measured") is not False
                or completed.returncode != 2
            ):
                failures.append("NON_TARGET_PREFLIGHT_MUST_FAIL_WITHOUT_HARDWARE_EVIDENCE")
    install = (ROOT / "scripts" / "install_release.sh").read_text(encoding="utf-8")
    rollback = (ROOT / "scripts" / "rollback_release.sh").read_text(encoding="utf-8")
    recovery = (ROOT / "scripts" / "recover_pending_activation.sh").read_text(
        encoding="utf-8"
    )
    health_gate_script = (ROOT / "scripts" / "check_release_health.py").read_text(
        encoding="utf-8"
    )
    service = (ROOT / "systemd" / "family-health-edge.service").read_text(encoding="utf-8")
    if "wait_for_product_health" not in health_gate_script:
        failures.append("PRODUCT_HEALTH_STARTUP_WAIT_MISSING")
    required_install_controls = (
        "flock -n",
        "family-health-edge-tool",
        "verify-release-bundle",
        "verify-current-release",
        "mv -Tf",
        "systemctl restart family-health-edge.service",
        "check-release-health",
        "activation-marker",
        "pending-activation.json",
        "EDGE_UPDATE_STATE_ROOT",
        "required self-contained runtime tool",
        "EDGE_RUNTIME_TMPDIR",
        "export TMPDIR",
        "resume_existing",
        "cmp -s",
        "previous release restored",
    )
    for control in required_install_controls:
        if control not in install:
            failures.append(f"INSTALL_CONTROL_MISSING:{control}")
    for control in (
        "flock -n",
        "family-health-edge-tool",
        "verify-release-bundle",
        "verify-current-release",
        "check-rollback-transition",
        "check-release-health",
        "activation-marker",
        "pending-activation.json",
        "EDGE_UPDATE_STATE_ROOT",
        "required self-contained runtime tool",
        "EDGE_RUNTIME_TMPDIR",
        "export TMPDIR",
        "mv -Tf",
        "original release restored",
    ):
        if control not in rollback:
            failures.append(f"ROLLBACK_CONTROL_MISSING:{control}")
    for control in (
        "flock -n",
        "family-health-edge-tool",
        "verify-release-bundle",
        "activation-marker",
        "pending-activation.json",
        "EDGE_UPDATE_STATE_ROOT",
        "required self-contained runtime tool",
        "EDGE_RUNTIME_TMPDIR",
        "export TMPDIR",
        "mv -Tf",
        "recovered interrupted activation",
    ):
        if control not in recovery:
            failures.append(f"RECOVERY_CONTROL_MISSING:{control}")
    for control in (
        "ExecStartPre=/opt/family-health-edge/tools/family-health-edge-tool verify-current-release",
        "Requires=family-health-edge-recovery.service",
        "IPAddressDeny=any",
        "IPAddressAllow=localhost",
        "CapabilityBoundingSet=",
        "ProtectKernelModules=true",
        "RuntimeDirectory=family-health-edge-runtime",
        "Environment=TMPDIR=/run/family-health-edge-runtime",
        "--auth-grants /etc/family-health-edge/auth_grants.json",
        "--runtime-config /opt/family-health-edge/current/configs/runtime_adapters.json",
        "--backend-registry /opt/family-health-edge/current/configs/backend_registry.json",
        "--backend-selection /opt/family-health-edge/current/configs/runtime_backend_selection.json",
        "--release-manifest /opt/family-health-edge/current/manifest.json",
    ):
        if control not in service:
            failures.append(f"SYSTEMD_HARDENING_MISSING:{control}")
    runtime_entrypoints = {
        "install_release.sh": install,
        "rollback_release.sh": rollback,
        "recover_pending_activation.sh": recovery,
        "family-health-edge.service": service,
    }
    for name, content in runtime_entrypoints.items():
        folded = content.casefold()
        if "python3" in folded or "/usr/bin/python" in folded or ".py" in folded:
            failures.append(f"GLOBAL_PYTHON_RUNTIME_DEPENDENCY:{name}")
    recovery_service = (
        ROOT / "systemd" / "family-health-edge-recovery.service"
    ).read_text(encoding="utf-8")
    for control in (
        "Before=family-health-edge.service",
        "ExecStart=/opt/family-health-edge/tools/recover_pending_activation.sh",
        "User=root",
        "ProtectSystem=strict",
        "IPAddressDeny=any",
        "ReadWritePaths=/opt/family-health-edge /var/lib/family-health-edge-update",
        "RuntimeDirectory=family-health-edge-recovery-runtime",
        "Environment=EDGE_RUNTIME_TMPDIR=/run/family-health-edge-recovery-runtime",
    ):
        if control not in recovery_service:
            failures.append(f"RECOVERY_SERVICE_HARDENING_MISSING:{control}")
    sherpa = (ROOT / "scripts" / "build_sherpa_arm64.sh").read_text(encoding="utf-8")
    for control in (
        "SHERPA_ONNX_COMMIT",
        "AARCH64_TOOLCHAIN_SHA256",
        "status --porcelain --untracked-files=all",
        "FETCHCONTENT_FULLY_DISCONNECTED=ON",
        "SOURCE_DATE_EPOCH",
        "Non-aarch64 ELF artifact detected",
        "manifest.json",
    ):
        if control not in sherpa:
            failures.append(f"SHERPA_BUILD_CONTROL_MISSING:{control}")
    product_blockers = [
        "SIGNED_PRODUCT_BUNDLE_NOT_AVAILABLE",
        "TRUSTED_DEVICE_PUBLIC_KEY_NOT_PROVISIONED",
        "REAL_RK3566_INSTALL_UPGRADE_ROLLBACK_NOT_RUN",
    ]
    if not runtime_tool_built:
        product_blockers.append("SELF_CONTAINED_ARM64_RUNTIME_TOOLS_NOT_BUILT")
    else:
        product_blockers.extend(runtime_tool.get("blockers", []))
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not failures else "FAIL",
        "bash_executable": bash,
        "real_rk3566_install_executed": False,
        "power_loss_acceptance_executed": False,
        "global_python_runtime_dependency_detected": any(
            "python3" in content.casefold()
            or "/usr/bin/python" in content.casefold()
            or ".py" in content.casefold()
            for content in runtime_entrypoints.values()
        ),
        "runtime_tool_invocation_contract": "SELF_CONTAINED_EXECUTABLES_REQUIRED",
        "self_contained_arm64_runtime_tools_built": runtime_tool_built,
        "runtime_tool_verification": runtime_tool,
        "local_preflight_self_test": local_preflight,
        "failures": failures,
        "product_blockers": list(dict.fromkeys(product_blockers)),
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
