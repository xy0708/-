from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from research_assets import ResearchAssetPathError, resolve_locked_artifact


LOCK = ROOT / "vendor" / "rockchip" / "model_zoo.lock.json"
REPORT = ROOT / "reports" / "official_model_lock_verification.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_file(relative: str) -> Path:
    try:
        return resolve_locked_artifact(ROOT, relative)
    except ResearchAssetPathError as exc:
        raise ValueError(str(exc)) from exc


def verify_lock(lock_path: Path = LOCK) -> dict[str, Any]:
    errors: list[str] = []
    try:
        contract = json.loads(lock_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"status": "FAIL", "errors": [f"LOCK_READ_FAILED:{type(exc).__name__}"]}

    if contract.get("target_platform") != "rk3566":
        errors.append("TARGET_PLATFORM_NOT_RK3566")
    if contract.get("product_selected") is not False:
        errors.append("UNVERIFIED_PRODUCT_SELECTION")
    if contract.get("formal_release_allowed") is not False:
        errors.append("UNVERIFIED_RELEASE_ALLOWED")
    if contract.get("legal_review") != "BLOCKED_EXTERNAL":
        errors.append("LEGAL_REVIEW_MUST_REMAIN_BLOCKED")

    verified_files = 0
    sections = ("licenses", "source_files", "model_artifacts", "auxiliary_artifacts")
    for section in sections:
        records = contract.get(section)
        if not isinstance(records, list) or not records:
            errors.append(f"EMPTY_SECTION:{section}")
            continue
        for record in records:
            relative = record.get("path") if isinstance(record, dict) else None
            expected_bytes = record.get("bytes") if isinstance(record, dict) else None
            expected_sha = record.get("sha256") if isinstance(record, dict) else None
            if not isinstance(relative, str) or not isinstance(expected_bytes, int) or not isinstance(expected_sha, str):
                errors.append(f"INVALID_FILE_RECORD:{section}")
                continue
            try:
                target = _safe_file(relative)
            except (ValueError, OSError):
                errors.append(f"UNSAFE_FILE_PATH:{relative}")
                continue
            if not target.is_file():
                errors.append(f"MISSING_FILE:{relative}")
                continue
            if target.stat().st_size != expected_bytes:
                errors.append(f"SIZE_MISMATCH:{relative}")
                continue
            if sha256(target) != expected_sha:
                errors.append(f"SHA256_MISMATCH:{relative}")
                continue
            verified_files += 1

    repositories = contract.get("repositories")
    verified_repositories = 0
    if not isinstance(repositories, list) or not repositories:
        errors.append("REPOSITORIES_MISSING")
    else:
        for repository in repositories:
            relative = repository.get("local_checkout") if isinstance(repository, dict) else None
            expected_commit = repository.get("commit") if isinstance(repository, dict) else None
            if not isinstance(relative, str) or not isinstance(expected_commit, str):
                errors.append("INVALID_REPOSITORY_RECORD")
                continue
            checkout = (ROOT / relative).resolve()
            try:
                checkout.relative_to(ROOT.resolve())
            except ValueError:
                errors.append(f"UNSAFE_REPOSITORY_PATH:{relative}")
                continue
            completed = subprocess.run(
                ["git", "-C", str(checkout), "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
            )
            actual = completed.stdout.strip().lower()
            if completed.returncode != 0 or actual != expected_commit.lower():
                errors.append(f"REPOSITORY_COMMIT_MISMATCH:{relative}")
                continue
            verified_repositories += 1

    model_ids = {
        item.get("id")
        for item in contract.get("model_artifacts", [])
        if isinstance(item, dict)
    }
    for candidate in contract.get("candidate_groups", []):
        if not isinstance(candidate, dict):
            errors.append("INVALID_CANDIDATE_RECORD")
            continue
        if candidate.get("official_rk3566_support") is not True:
            errors.append(f"RK3566_SUPPORT_NOT_RECORDED:{candidate.get('id')}")
        if candidate.get("product_status") not in {"CANDIDATE_ONLY", "FALLBACK_CANDIDATE_ONLY"}:
            errors.append(f"INVALID_PRODUCT_STATUS:{candidate.get('id')}")
        for artifact_id in candidate.get("artifact_ids", []):
            if artifact_id not in model_ids:
                errors.append(f"UNKNOWN_ARTIFACT_ID:{artifact_id}")

    return {
        "status": "PASS_ENGINEERING" if not errors else "FAIL",
        "product_selected": False,
        "formal_release_allowed": False,
        "legal_review": "BLOCKED_EXTERNAL",
        "verified_files": verified_files,
        "verified_repositories": verified_repositories,
        "errors": errors,
    }


def main() -> int:
    result = verify_lock()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS_ENGINEERING" else 2


if __name__ == "__main__":
    raise SystemExit(main())
