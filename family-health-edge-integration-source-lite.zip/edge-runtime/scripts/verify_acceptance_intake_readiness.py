from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from acceptance.approvals import (  # noqa: E402
    REQUIRED_EXTERNAL_GATES,
    approval_gate_errors,
    gate_registry_errors,
)


REPORT = ROOT / "reports" / "acceptance_intake_readiness.json"
GATE_FIELDS = {
    "approved",
    "evidence_file",
    "evidence_sha256",
    "approved_by",
    "approved_at",
}
TEMPLATES = {
    "ocr": (
        ROOT / "configs" / "ocr_acceptance_manifest.template.json",
        {"privacy_legal_review", "ocr_acceptance_data_rights_approval"},
    ),
    "asr": (
        ROOT / "configs" / "asr_acceptance_manifest.template.json",
        {"privacy_legal_review", "asr_acceptance_data_rights_approval"},
    ),
}


def _load_object(path: Path, errors: list[str]) -> dict[str, Any]:
    label = path.as_posix()
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        errors.append(f"INVALID_JSON:{label}")
        return {}
    if not isinstance(value, dict):
        errors.append(f"JSON_NOT_OBJECT:{label}")
        return {}
    return value


def evaluate(root: Path = ROOT) -> dict[str, Any]:
    structural_errors: list[str] = []
    registry = _load_object(
        root / "configs" / "product_gate_evidence.json", structural_errors
    )
    structural_errors.extend(gate_registry_errors(registry))
    gates = registry.get("gates") if isinstance(registry.get("gates"), dict) else {}
    for gate_name in sorted(REQUIRED_EXTERNAL_GATES):
        record = gates.get(gate_name)
        if not isinstance(record, dict) or set(record) != GATE_FIELDS:
            structural_errors.append(f"GATE_RECORD_SCHEMA_INVALID:{gate_name}")
        elif not isinstance(record.get("approved"), bool):
            structural_errors.append(f"GATE_APPROVED_FLAG_INVALID:{gate_name}")

    for component, (path, required_bindings) in TEMPLATES.items():
        template_path = root / path.relative_to(ROOT)
        template = _load_object(template_path, structural_errors)
        if (
            template.get("schema_version") != "1.0.0"
            or template.get("template_status") != "NOT_EVIDENCE_FILL_AND_RENAME"
            or template.get("component") != component
        ):
            structural_errors.append(f"TEMPLATE_IDENTITY_INVALID:{component}")
        if any(
            template.get(field) is not expected
            for field, expected in {
                "rights_cleared": False,
                "synthetic": False,
                "independent_split": False,
                "direct_identifiers_removed": False,
            }.items()
        ):
            structural_errors.append(f"TEMPLATE_NOT_FAIL_CLOSED:{component}")
        bindings = template.get("approval_bindings")
        if not isinstance(bindings, dict) or set(bindings) != required_bindings:
            structural_errors.append(f"TEMPLATE_APPROVAL_BINDINGS_INVALID:{component}")
        if not isinstance(template.get("cases"), list) or not template["cases"]:
            structural_errors.append(f"TEMPLATE_CASES_MISSING:{component}")

    example = _load_object(root / "configs" / "acceptance_evidence.example.json", structural_errors)
    expected_bindings = {
        "privacy_legal_review",
        "ocr_acceptance_data_rights_approval",
        "asr_acceptance_data_rights_approval",
    }
    if (
        example.get("template_status") != "NOT_EVIDENCE_FILL_AND_RENAME"
        or not isinstance(example.get("approval_bindings"), dict)
        or set(example["approval_bindings"]) != expected_bindings
    ):
        structural_errors.append("AGGREGATE_TEMPLATE_APPROVAL_BINDINGS_INVALID")
    files = example.get("files")
    if not isinstance(files, list) or len(files) != 5:
        structural_errors.append("AGGREGATE_TEMPLATE_FILES_INVALID")
    elif any(
        not isinstance(item, dict)
        or item.get("rights_cleared") is not False
        or item.get("independent_split") is not False
        or item.get("direct_identifiers_removed") is not False
        for item in files
    ):
        structural_errors.append("AGGREGATE_TEMPLATE_NOT_FAIL_CLOSED")

    documentation = (root / "docs" / "operations" / "acceptance_evidence_format.md")
    try:
        documentation_text = documentation.read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        documentation_text = ""
    for marker in ("CHARLS 永久禁用", "approval_bindings", "direct_identifiers_removed"):
        if marker not in documentation_text:
            structural_errors.append(f"ACCEPTANCE_DOCUMENTATION_MISSING:{marker}")
    try:
        gitignore = (root / ".gitignore").read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError):
        gitignore = []
    for ignored_path in ("evidence/acceptance/", "evidence/approvals/"):
        if ignored_path not in gitignore:
            structural_errors.append(f"SENSITIVE_EVIDENCE_NOT_GITIGNORED:{ignored_path}")

    external_blockers: list[str] = []
    if not structural_errors:
        for gate_name in sorted(REQUIRED_EXTERNAL_GATES):
            for error in approval_gate_errors(root, registry, gate_name):
                external_blockers.append(f"{gate_name}:{error}")
    return {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not structural_errors else "FAIL_ENGINEERING",
        "formal_acceptance_ready": not structural_errors and not external_blockers,
        "product_release_allowed": False,
        "structural_errors": sorted(set(structural_errors)),
        "external_blockers": sorted(set(external_blockers)),
    }


def main() -> int:
    result = evaluate()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if result["status"] == "PASS_ENGINEERING" else 2


if __name__ == "__main__":
    raise SystemExit(main())
