from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "loop_requirements_audit.json"


def is_sha256(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


def load(relative: str) -> dict:
    path = ROOT / relative
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}


def arm64_asr_engineering_pass(
    asr: dict, model_simulation: dict, integration_simulation: dict
) -> bool:
    return (
        asr.get("status") == "PASS_ENGINEERING"
        and model_simulation.get("status") == "PASS_ENGINEERING"
        and model_simulation.get("hardware_measured") is False
        and model_simulation.get("product_complete") is False
        and model_simulation.get("three_model_inference_verified") is False
        and not model_simulation.get("errors")
        and integration_simulation.get("status") == "PASS_ENGINEERING"
        and integration_simulation.get("hardware_measured") is False
        and integration_simulation.get("product_complete") is False
        and integration_simulation.get("three_model_inference_verified") is False
        and not integration_simulation.get("errors")
    )


def component_integration_engineering_pass(
    component: dict, integration_simulation: dict
) -> bool:
    return (
        component.get("status") == "PASS_ENGINEERING"
        and component.get("process_supervisor_engineering_implemented") is True
        and component.get("engineering_asr_worker_registered") is True
        and component.get("engineering_ocr_worker_registered") is True
        and is_sha256(component.get("engineering_runtime_bootstrap_sha256"))
        and is_sha256(component.get("backend_registry_sha256"))
        and is_sha256(component.get("backend_selection_sha256"))
        and component.get("device_service_backend_registry_integrated") is True
        and isinstance(component.get("product_native_workers_registered"), bool)
        and isinstance(component.get("hardware_measured"), bool)
        and integration_simulation.get("status") == "PASS_ENGINEERING"
        and integration_simulation.get("hardware_measured") is False
        and integration_simulation.get("product_complete") is False
    )


def audit_exit_code(result: dict) -> int:
    if result.get("status") == "BLOCKED_EXTERNAL":
        return 2
    if result.get("status") == "PASS_PRODUCT_GATE":
        return 0
    return 1


def progressive_gate_status(*, engineering_pass: bool, product_pass: bool) -> str:
    if not engineering_pass:
        return "FAIL"
    return "PASS_PRODUCT_GATE" if product_pass else "PASS_ENGINEERING"


def pending_until_product(product_pass: bool, *items: str) -> list[str]:
    return [] if product_pass else list(items)


def main() -> int:
    device = load("configs/device_profile.json")
    acceptance = load("reports/device_acceptance.json")
    release = load("reports/final_release_verification.json")
    privacy = load("reports/privacy_verification.json")
    data = load("reports/data_policy_verification.json")
    health = load("reports/health_rules_verification.json")
    asr = load("reports/asr_arm64_verification.json")
    model_simulation = load("reports/arm64_model_simulation_verification.json")
    integration_simulation = load("reports/arm64_integration_simulation_verification.json")
    ocr = load("reports/ocr_rknn_verification.json")
    component = load("reports/component_contract_verification.json")
    upstream = load("reports/upstream_regression_verification.json")
    deployment = load("reports/deployment_script_verification.json")
    runtime_tool = load("reports/arm64_runtime_tool_verification.json")
    acceptance_passed = acceptance.get("status") == "PASS_PRODUCT_GATE"
    release_passed = (
        release.get("status") == "PASS_PRODUCT_GATE"
        and release.get("release_allowed") is True
        and release.get("formal_release_verified") is True
    )
    asr_engineering_passed = arm64_asr_engineering_pass(
        asr, model_simulation, integration_simulation
    )
    ocr_engineering_passed = ocr.get("status") == "PASS_ENGINEERING"
    component_engineering_passed = component_integration_engineering_pass(
        component, integration_simulation
    )
    privacy_engineering_passed = privacy.get("status") == "PASS_ENGINEERING"
    runtime_tool_engineering_passed = (
        runtime_tool.get("status") == "PASS_ENGINEERING_ARM64_TOOL_PRODUCT_BLOCKED"
        and runtime_tool.get("hardware_measured") is False
        and runtime_tool.get("product_accepted") is False
        and runtime_tool.get("errors") == []
    )
    deployment_engineering_passed = (
        deployment.get("status") == "PASS_ENGINEERING"
        and deployment.get("self_contained_arm64_runtime_tools_built") is True
        and runtime_tool_engineering_passed
    )
    gates = [
        {"gate": "E00", "status": "PASS_ENGINEERING", "evidence": ["EDGE_PRODUCTION_LOOP.md", "configs/product_scope.yaml"], "unmet": []},
        {"gate": "E01", "status": "PASS_ENGINEERING" if upstream.get("status") == "PASS_ENGINEERING" else "FAIL", "evidence": ["reports/workspace_verification.json", "reports/upstream_regression_verification.json", ".venv-edge"], "unmet": [] if upstream.get("status") == "PASS_ENGINEERING" else ["all three upstream regressions must pass"]},
        {"gate": "E02", "status": progressive_gate_status(engineering_pass=True, product_pass=release_passed), "evidence": ["configs/openapi.yaml", "configs/api_contract.json"], "unmet": pending_until_product(release_passed, "named product scope and interface approval")},
        {"gate": "E03", "status": "PASS_PRODUCT_GATE" if release.get("data_and_license_status") == "PASS" and release.get("privacy_and_security_status") == "PASS" and release.get("classification_and_legal_status") == "PASS" else "BLOCKED_EXTERNAL", "evidence": ["docs/compliance/model_license_audit.md", "configs/product_gate_evidence.json"], "unmet": [] if release.get("data_and_license_status") == "PASS" and release.get("privacy_and_security_status") == "PASS" and release.get("classification_and_legal_status") == "PASS" else ["license, privacy, and classification opinions"]},
        {"gate": "E04", "status": "PASS_PRODUCT_GATE" if device.get("hardware_measured") is True and acceptance.get("status") == "PASS_PRODUCT_GATE" else "BLOCKED_EXTERNAL", "evidence": ["scripts/preflight_rk3566.sh", "configs/device_profile.json"], "unmet": [] if device.get("hardware_measured") is True and acceptance.get("status") == "PASS_PRODUCT_GATE" else ["real RK3566 and image access"]},
        {"gate": "E05", "status": progressive_gate_status(engineering_pass=health.get("status") == "PASS_ENGINEERING", product_pass=release_passed), "evidence": ["reports/health_rules_verification.json"], "unmet": pending_until_product(release_passed, "named rule approval")},
        {"gate": "E06", "status": progressive_gate_status(engineering_pass=asr_engineering_passed, product_pass=release_passed and asr.get("product_gate") == "PASS_PRODUCT_GATE"), "evidence": ["reports/asr_arm64_verification.json", "reports/arm64_model_simulation_verification.json", "reports/arm64_model_simulation_latest.json", "reports/arm64_integration_simulation_verification.json", "reports/arm64_integration_simulation_latest.json", "asr_runtime/session.py", "asr_runtime/worker.py"], "unmet": pending_until_product(release_passed and asr.get("product_gate") == "PASS_PRODUCT_GATE", "real RK3566 runtime freeze and real target-mic acceptance") if asr_engineering_passed else ["verified ARM64 ASR worker and device-service integration evidence"]},
        {"gate": "E07", "status": progressive_gate_status(engineering_pass=ocr_engineering_passed, product_pass=release_passed and ocr.get("product_gate") == "PASS_PRODUCT_GATE"), "evidence": ["reports/ocr_rknn_verification.json", "ocr_runtime/input_validation.py"], "unmet": pending_until_product(release_passed and ocr.get("product_gate") == "PASS_PRODUCT_GATE", "licensed product RKNN and real report acceptance") if ocr_engineering_passed else ["verified OCR engineering evidence"]},
        {"gate": "E08", "status": progressive_gate_status(engineering_pass=component_engineering_passed, product_pass=release_passed and acceptance_passed), "evidence": ["reports/device_service_smoke.json", "reports/component_contract_verification.json", "reports/arm64_integration_simulation_verification.json", "storage/recovery.py", "integration_adapter/contracts.py", "integration_adapter/supervisor.py", "device_service/runtime_bootstrap.py", "asr_runtime/worker.py", "ocr_runtime/rknn_worker.py", "model_registry/backend_registry.json"], "unmet": pending_until_product(release_passed and acceptance_passed, "approved product encryption and device key lifecycle", "licensed product OCR/ASR product workers", "real RK3566 integration acceptance") if component_engineering_passed else ["verified component integration evidence"]},
        {"gate": "E09", "status": progressive_gate_status(engineering_pass=privacy_engineering_passed, product_pass=release_passed and privacy.get("product_privacy_gate") is True), "evidence": ["reports/privacy_verification.json", "docs/security/security_best_practices_report.md"], "unmet": pending_until_product(release_passed and privacy.get("product_privacy_gate") is True, "final threat model, current target vulnerability scan, RK3566 hardening") if privacy_engineering_passed else ["privacy engineering verification"]},
        {"gate": "E10", "status": acceptance.get("status", "BLOCKED_EXTERNAL"), "evidence": ["configs/acceptance_contract.json", "reports/device_acceptance.json"], "unmet": acceptance.get("blockers", ["real independent acceptance"])},
        {"gate": "E11", "status": progressive_gate_status(engineering_pass=deployment_engineering_passed, product_pass=release_passed), "evidence": ["release_tools/bundle.py", "reports/deployment_script_verification.json", "reports/arm64_runtime_tool_verification.json", "reports/arm64_simulation_latest.json"], "unmet": pending_until_product(release_passed, "named runtime distribution legal approval", "signed bundle and real RK3566 install/upgrade/rollback acceptance") if deployment_engineering_passed else ["self-contained ARM64 deployment engineering verification"]},
        {"gate": "E12", "status": release.get("status", "BLOCKED_EXTERNAL"), "evidence": ["reports/final_release_verification.json"], "unmet": release.get("blockers", ["all upstream product gates"])},
    ]
    contradictions = []
    if device.get("hardware_measured") is True and not acceptance_passed:
        contradictions.append("DEVICE_MEASUREMENT_NOT_ACCEPTED")
    if acceptance_passed and device.get("hardware_measured") is not True:
        contradictions.append("ACCEPTANCE_PASS_WITHOUT_MEASURED_DEVICE")
    if acceptance.get("synthetic_evidence_used") is not False:
        contradictions.append("SYNTHETIC_ACCEPTANCE_EVIDENCE_USED")
    if data.get("charls_used") is not False:
        contradictions.append("CHARLS_EXCLUSION_VIOLATED")
    if privacy.get("product_privacy_gate") is True and release.get("privacy_and_security_status") != "PASS":
        contradictions.append("PRIVACY_GATE_INCONSISTENT_WITH_RELEASE")
    if (
        asr.get("hardware_measured") is True or ocr.get("hardware_measured") is True
    ) and not acceptance_passed:
        contradictions.append("MODEL_HARDWARE_EVIDENCE_FABRICATED")
    if model_simulation and (
            model_simulation.get("hardware_measured") is not False
            or model_simulation.get("product_complete") is not False
            or model_simulation.get("three_model_inference_verified") is not False):
        contradictions.append("MODEL_SIMULATION_SCOPE_INFLATED")
    if integration_simulation and (
            integration_simulation.get("hardware_measured") is not False
            or integration_simulation.get("product_complete") is not False
            or integration_simulation.get("three_model_inference_verified") is not False):
        contradictions.append("INTEGRATION_SIMULATION_SCOPE_INFLATED")
    if release.get("release_allowed") is True and not release_passed:
        contradictions.append("RELEASE_PASS_STATE_INCONSISTENT")
    if deployment.get("self_contained_arm64_runtime_tools_built") is True and not runtime_tool_engineering_passed:
        contradictions.append("RUNTIME_TOOL_BUILD_CLAIM_WITHOUT_VERIFIED_ARTIFACT")
    product_gate_failures = [
        item["gate"]
        for item in gates
        if item["gate"] not in {"E00", "E01"}
        and item["status"] != "PASS_PRODUCT_GATE"
    ]
    if release_passed and product_gate_failures:
        contradictions.append("RELEASE_PASS_WITH_INCOMPLETE_PRODUCT_GATES")
    engineering_failures = [item["gate"] for item in gates if item["status"] == "FAIL"]
    goal_complete = not contradictions and not engineering_failures and release_passed and acceptance_passed
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": (
            "FAIL_CONTRADICTION"
            if contradictions
            else "FAIL_ENGINEERING"
            if engineering_failures
            else "PASS_PRODUCT_GATE"
            if goal_complete
            else "BLOCKED_EXTERNAL"
        ),
        "goal_complete": goal_complete,
        "product_release_allowed": release_passed,
        "engineering_gates_passed": [item["gate"] for item in gates if item["status"] in {"PASS_ENGINEERING", "PASS_PRODUCT_GATE"}],
        "product_gates_blocked": [item["gate"] for item in gates if item["status"] == "BLOCKED_EXTERNAL"],
        "gates": gates,
        "contradictions": contradictions,
        "engineering_failures": engineering_failures,
        "next_external_inputs": [] if goal_complete else [
            "real RK3566 access",
            "rights-cleared real OCR and target-microphone ASR acceptance inputs",
            "named license/privacy/classification/rule/threshold approvals",
            "approved encryption and signing-key provisioning",
        ],
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return audit_exit_code(result)


if __name__ == "__main__":
    raise SystemExit(main())
