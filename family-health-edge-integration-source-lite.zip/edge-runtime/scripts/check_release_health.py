from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from update_agent import wait_for_product_health


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default="http://127.0.0.1:18100/v1/health")
    parser.add_argument(
        "--timeout",
        type=float,
        default=10.0,
        help="Total startup-health deadline in seconds",
    )
    parser.add_argument("--request-timeout", type=float, default=2.0)
    parser.add_argument("--poll-interval", type=float, default=0.25)
    arguments = parser.parse_args()
    result = wait_for_product_health(
        arguments.url,
        startup_timeout_seconds=arguments.timeout,
        request_timeout_seconds=arguments.request_timeout,
        poll_interval_seconds=arguments.poll_interval,
    )
    print(json.dumps(result.as_dict(), ensure_ascii=True))
    return 0 if result.passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
