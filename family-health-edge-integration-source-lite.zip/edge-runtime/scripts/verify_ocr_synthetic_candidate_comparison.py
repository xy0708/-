from __future__ import annotations

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.ocr_synthetic_batch import sha256, validate_report


OCR_ROOT = ROOT.parent / "OCR"
REPORT = ROOT / "reports/ocr_synthetic_candidate_comparison.json"
VERIFICATION = ROOT / "reports/ocr_synthetic_candidate_comparison_verification.json"
GROUND_TRUTH = OCR_ROOT / "data/synthetic/synthetic_ground_truth.json"
CPU_MANIFEST = OCR_ROOT / "models/official_pretrained/manifest.json"
HEALTH_DICTIONARY = OCR_ROOT / "configs/health_indicator_dictionary.json"
RKNN_BATCH = ROOT / "reports/rknn_simulation_ppocrv4_synthetic_batch.json"


def verify() -> dict[str, object]:
    expected_hashes = {
        "synthetic_ground_truth_sha256": sha256(GROUND_TRUTH),
        "cpu_manifest_sha256": sha256(CPU_MANIFEST),
        "health_dictionary_sha256": sha256(HEALTH_DICTIONARY),
        "rknn_batch_report_sha256": sha256(RKNN_BATCH),
    }
    try:
        report = json.loads(REPORT.read_text(encoding="utf-8"))
        errors = validate_report(report, expected_hashes)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        errors = [f"COMPARISON_EVIDENCE_UNREADABLE:{type(exc).__name__}"]
    return {
        "status": "PASS_ENGINEERING_SYNTHETIC_PRODUCT_BLOCKED"
        if not errors
        else "FAIL",
        "phase": "R03_SYNTHETIC_ENGINEERING_COMPARISON_COMPLETE",
        "synthetic_only": True,
        "product_selection_allowed": False,
        "hardware_measured": False,
        "errors": errors,
    }


def main() -> int:
    result = verify()
    VERIFICATION.parent.mkdir(parents=True, exist_ok=True)
    VERIFICATION.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not result["errors"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
