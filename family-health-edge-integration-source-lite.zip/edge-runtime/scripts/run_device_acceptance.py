from __future__ import annotations

import json
import hashlib
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from acceptance.contract import acceptance_contract_scenario_errors


REPORT = ROOT / "reports" / "device_acceptance.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json_object(path: Path, blockers: list[str], code: str) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        blockers.append(code)
        return {}
    if not isinstance(value, dict):
        blockers.append(code)
        return {}
    return value


def safe_project_file(root: Path, relative: object) -> Path | None:
    if not isinstance(relative, str) or not relative:
        return None
    relative_path = Path(relative)
    if relative_path.is_absolute() or ".." in relative_path.parts:
        return None
    candidate = root / relative_path
    try:
        resolved = candidate.resolve(strict=True)
    except OSError:
        return None
    if candidate.is_symlink() or not resolved.is_file() or not resolved.is_relative_to(root.resolve()):
        return None
    return resolved


def evaluate(root: Path = ROOT) -> dict:
    blockers: list[str] = []
    contract = load_json_object(
        root / "configs" / "acceptance_contract.json",
        blockers,
        "ACCEPTANCE_CONTRACT_INVALID_OR_MISSING",
    )
    device = load_json_object(
        root / "configs" / "device_profile.json",
        blockers,
        "DEVICE_PROFILE_INVALID_OR_MISSING",
    )
    if contract.get("frozen_before_testing") is not True:
        blockers.append("ACCEPTANCE_CONTRACT_NOT_FROZEN_BEFORE_TESTING")
    if contract.get("approval_status") != "APPROVED":
        blockers.append("ACCEPTANCE_THRESHOLDS_NOT_NAMED_APPROVED")
    blockers.extend(acceptance_contract_scenario_errors(contract))
    thresholds = contract.get("thresholds")
    if not isinstance(thresholds, dict) or not thresholds or any(
        value is None for value in thresholds.values()
    ):
        blockers.append("ACCEPTANCE_THRESHOLDS_INCOMPLETE")
    preflight_relative = device.get("preflight_report")
    preflight: dict = {}
    preflight_path = safe_project_file(root, preflight_relative)
    if preflight_path is None:
        blockers.append("PINNED_REMOTE_PREFLIGHT_REPORT_MISSING")
    else:
        if sha256(preflight_path) != device.get("preflight_report_sha256"):
            blockers.append("PINNED_REMOTE_PREFLIGHT_REPORT_HASH_MISMATCH")
        else:
            preflight = load_json_object(
                preflight_path,
                blockers,
                "PINNED_REMOTE_PREFLIGHT_REPORT_INVALID",
            )
    preflight_script = root / "scripts" / "preflight_rk3566.sh"
    current_script_hash = sha256(preflight_script) if preflight_script.is_file() else None
    if current_script_hash is None or device.get("preflight_script_sha256") != current_script_hash:
        blockers.append("PREFLIGHT_SCRIPT_HASH_NOT_PINNED_TO_CURRENT_VERSION")
    evidence = preflight.get("hardware_evidence", {}) if isinstance(preflight, dict) else {}
    if (
        preflight.get("status") != "PASS_REAL_DEVICE_PREFLIGHT"
        or evidence.get("hardware_measured") is not True
        or evidence.get("rk3566_detected") is not True
        or evidence.get("simulation_detected") is not False
        or evidence.get("passed") is not True
        or not preflight.get("known_hosts_sha256")
        or not preflight.get("remote_stdout_sha256")
    ):
        blockers.append("REAL_RK3566_REMOTE_PREFLIGHT_NOT_VERIFIED")
    if device.get("device_connected") is not True or device.get("hardware_measured") is not True:
        blockers.append("DEVICE_PROFILE_NOT_IMPORTED_FROM_REAL_PREFLIGHT")
    if not contract.get("real_ocr_inputs_available", False):
        blockers.append("RIGHTS_CLEARED_REAL_OCR_ACCEPTANCE_INPUTS_MISSING")
    if not contract.get("real_human_asr_inputs_available", False):
        blockers.append("REAL_HUMAN_TARGET_MIC_ASR_INPUTS_MISSING")
    results_path = safe_project_file(root, contract.get("results_source"))
    acceptance_manifest_path = root / "configs" / "acceptance_evidence.json"
    computed: dict = {}
    if results_path is None:
        blockers.append("COMPUTED_INDEPENDENT_ACCEPTANCE_REPORT_MISSING")
    else:
        computed = load_json_object(
            results_path,
            blockers,
            "COMPUTED_INDEPENDENT_ACCEPTANCE_REPORT_INVALID",
        )
        if computed.get("status") != "PASS_COMPUTED_REAL_EVIDENCE" or computed.get("synthetic_evidence_used") is not False:
            blockers.append("COMPUTED_INDEPENDENT_ACCEPTANCE_REPORT_NOT_ELIGIBLE")
        if computed.get("device_alias") != preflight.get("device_alias"):
            blockers.append("ACCEPTANCE_DEVICE_ALIAS_MISMATCH")
        if computed.get("acceptance_contract_sha256") != sha256(root / "configs" / "acceptance_contract.json"):
            blockers.append("ACCEPTANCE_CONTRACT_CHANGED_AFTER_EVIDENCE_COMPUTATION")
        if computed.get("device_preflight_sha256") != device.get("preflight_report_sha256"):
            blockers.append("ACCEPTANCE_EVIDENCE_DEVICE_PREFLIGHT_MISMATCH")
        if (
            not acceptance_manifest_path.is_file()
            or acceptance_manifest_path.is_symlink()
            or computed.get("evidence_manifest_sha256")
            != sha256(acceptance_manifest_path)
        ):
            blockers.append("ACCEPTANCE_EVIDENCE_MANIFEST_HASH_MISMATCH")
    results = computed.get("metrics")
    thresholds = thresholds if isinstance(thresholds, dict) else {}
    comparisons = {
        "ocr_field_exact_match": ("ocr_field_exact_match_min", ">="),
        "ocr_required_field_recall": ("ocr_required_field_recall_min", ">="),
        "ocr_unsupported_input_rejection": ("ocr_unsupported_input_rejection_min", ">="),
        "asr_cer": ("asr_cer_max", "<="),
        "asr_health_slot_exact_match": ("asr_health_slot_exact_match_min", ">="),
        "p95_latency_ms": ("p95_latency_ms_max", "<="),
        "peak_memory_mib": ("peak_memory_mib_max", "<="),
        "max_temperature_c": ("max_temperature_c", "<="),
        "soak_duration_hours": ("soak_duration_hours_min", ">="),
        "unrecovered_crashes": ("unrecovered_crashes_max", "<="),
        "memory_growth_mib": ("memory_growth_mib_max", "<="),
    }
    if isinstance(results, dict) and not blockers:
        for result_name, (threshold_name, operator) in comparisons.items():
            actual = results.get(result_name)
            threshold = thresholds.get(threshold_name)
            if (
                isinstance(actual, bool)
                or isinstance(threshold, bool)
                or not isinstance(actual, (int, float))
                or not isinstance(threshold, (int, float))
                or not math.isfinite(float(actual))
                or not math.isfinite(float(threshold))
            ):
                blockers.append(f"ACCEPTANCE_RESULT_MISSING:{result_name}")
                continue
            passed = actual >= threshold if operator == ">=" else actual <= threshold
            if not passed:
                blockers.append(f"ACCEPTANCE_THRESHOLD_FAILED:{result_name}")
        scenarios = results.get("scenarios")
        required_scenarios = contract.get("required_scenarios")
        if not isinstance(required_scenarios, list) or not required_scenarios:
            blockers.append("ACCEPTANCE_REQUIRED_SCENARIOS_INVALID")
            required_scenarios = []
        for scenario in required_scenarios:
            if not isinstance(scenario, str) or not scenario:
                blockers.append("ACCEPTANCE_REQUIRED_SCENARIOS_INVALID")
                continue
            if not isinstance(scenarios, dict) or scenarios.get(scenario) != "PASS":
                blockers.append(f"ACCEPTANCE_SCENARIO_NOT_PASS:{scenario}")

    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "BLOCKED_EXTERNAL" if blockers else "PASS_PRODUCT_GATE",
        "hardware_measured": (
            device.get("hardware_measured") is True
            and evidence.get("hardware_measured") is True
            and preflight.get("status") == "PASS_REAL_DEVICE_PREFLIGHT"
        ),
        "synthetic_evidence_used": False,
        "acceptance_executed": isinstance(results, dict),
        "computed_metrics_report_sha256": sha256(results_path) if results_path is not None else None,
        "blockers": blockers,
    }
    return result


def main() -> int:
    result = evaluate()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not result["blockers"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
