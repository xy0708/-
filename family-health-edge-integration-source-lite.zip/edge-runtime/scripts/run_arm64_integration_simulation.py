from __future__ import annotations

import json
import os
import re
import shutil
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
sys.path.insert(0, str(ROOT))

from asr_runtime.worker import REQUIRED_MODEL_FILES, model_bundle_sha256
from scripts.run_arm64_simulation_loop import (
    ARM64_PLATFORM,
    BASE_TAG,
    image_inspect_arguments,
    local_endpoint,
    pinned_repository_digest,
    public_reason,
    run_command,
    sha256,
)
from scripts.verify_model_simulation_evidence import evaluate as evaluate_s2


CONFIG = ROOT / "configs" / "arm64_integration_simulation.json"
REPORT = ROOT / "reports" / "arm64_integration_simulation_latest.json"
PACKAGES = (
    "health_rules",
    "device_service",
    "integration_adapter",
    "storage",
    "ocr_runtime",
    "asr_runtime",
    "operations",
    "runtime_backends",
)


def workspace_path(relative: str, *, directory: bool = False) -> Path:
    path = (WORKSPACE / relative).resolve()
    if not path.is_relative_to(WORKSPACE.resolve()):
        raise ValueError("SOURCE_OUTSIDE_WORKSPACE")
    if directory and not path.is_dir():
        raise ValueError("SOURCE_DIRECTORY_MISSING")
    if not directory and not path.is_file():
        raise ValueError("SOURCE_FILE_MISSING")
    return path


def project_path(relative: str, *, directory: bool = False) -> Path:
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT.resolve()):
        raise ValueError("PROJECT_SOURCE_OUTSIDE_ROOT")
    if directory and not path.is_dir():
        raise ValueError("PROJECT_DIRECTORY_MISSING")
    if not directory and not path.is_file():
        raise ValueError("PROJECT_FILE_MISSING")
    return path


def source_key(path: Path) -> str:
    return path.resolve().relative_to(WORKSPACE.resolve()).as_posix()


def copy_application(context: Path) -> dict[str, str]:
    app = context / "app"
    copied: dict[str, str] = {}
    for package in PACKAGES:
        for source in sorted((ROOT / package).glob("*.py")):
            relative = source.relative_to(ROOT)
            target = app / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            copied[relative.as_posix()] = sha256(target)
    extra = {
        ROOT / "configs" / "health_rules.json": app / "configs" / "health_rules.json",
        ROOT / "model_registry" / "backend_registry.json": app / "model_registry" / "backend_registry.json",
        ROOT / "configs" / "runtime_backend_selection.json": app / "configs" / "runtime_backend_selection.json",
        ROOT / "simulation" / "integration_probe.py": app / "simulation" / "integration_probe.py",
    }
    for source, target in extra.items():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        copied[source.relative_to(ROOT).as_posix()] = sha256(target)
    return copied


def validate_guest(value: dict[str, object], requirements: dict[str, str]) -> bool:
    health = value.get("health") if isinstance(value.get("health"), dict) else {}
    asr = value.get("asr") if isinstance(value.get("asr"), dict) else {}
    ocr = value.get("ocr") if isinstance(value.get("ocr"), dict) else {}
    return (
        value.get("status") == "PASS_ASR_DEVICE_SERVICE_INTEGRATION"
        and value.get("stage") == "S3_ASR_DEVICE_SERVICE_PARTIAL"
        and value.get("system") == "Linux"
        and str(value.get("machine", "")).lower() in {"aarch64", "arm64"}
        and value.get("bits") == 64
        and value.get("simulated") is True
        and value.get("hardware_measured") is False
        and value.get("product_complete") is False
        and value.get("three_model_inference_verified") is False
        and value.get("loopback_server_cleaned") is True
        and value.get("requirements") == requirements
        and health.get("status") == "PASS_REAL_NON_DIAGNOSTIC_RULE_ENGINE"
        and health.get("loopback_http_verified") is True
        and health.get("diagnosis_exposed") is False
        and health.get("disease_probability_exposed") is False
        and asr.get("status") == "PASS_REAL_ISOLATED_WORKER_INTEGRATION"
        and asr.get("matches_s2_reference") is True
        and asr.get("runtime_config_bootstrap_verified") is True
        and asr.get("backend_registry_selection_verified") is True
        and asr.get("loopback_websocket_verified") is True
        and asr.get("raw_audio_persisted") is False
        and asr.get("confirmed_record_count") == 0
        and asr.get("pending_task_cancelled") is True
        and asr.get("product_accepted") is False
        and ocr.get("status") == "BLOCKED_EXTERNAL"
        and ocr.get("real_worker_invoked") is False
        and ocr.get("test_double_used") is False
    )


def main() -> int:
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    folder = ROOT / "reports" / "arm64_integration_simulation_runs" / run_id
    folder.mkdir(parents=True, exist_ok=False)
    report: dict[str, object] = {
        "schema_version": "1.0.0",
        "run_id": run_id,
        "status": "FAIL",
        "stage": "S3_ASR_DEVICE_SERVICE_PARTIAL",
        "simulated": True,
        "hardware_measured": False,
        "product_complete": False,
        "three_model_inference_verified": False,
        "simulation_complete": False,
        "commands": [],
        "blockers": [],
        "resume_command": ".venv-edge/Scripts/python.exe scripts/run_arm64_integration_simulation.py",
    }
    records = report["commands"]
    assert isinstance(records, list)
    environment = dict(os.environ)
    environment.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    docker = shutil.which("docker")
    if not docker and os.name == "nt":
        candidate = Path("C:/Program Files/Docker/Docker/resources/bin/docker.exe")
        if candidate.is_file():
            docker = str(candidate)
    container_name = "edge-arm64-integration-" + run_id.lower()
    created_container = False
    return_code = 2
    try:
        config = json.loads(CONFIG.read_text(encoding="utf-8"))
        if (
            config.get("platform") != ARM64_PLATFORM
            or config.get("base_image") != BASE_TAG
            or config.get("ocr", {}).get("engineering_worker_implemented") is not True
            or config.get("ocr", {}).get("runtime_bootstrap_selected") is not False
            or config.get("ocr", {}).get("product_worker_registered") is not False
            or config.get("ocr", {}).get("test_double_allowed") is not False
            or config.get("asr", {}).get("product_accepted") is not False
        ):
            raise ValueError("INTEGRATION_CONFIG_BOUNDARY_INVALID")
        requirements = {str(key): str(value) for key, value in config["requirements"].items()}
        if requirements != {
            "sherpa-onnx": "1.13.7",
            "sherpa-onnx-core": "1.13.7",
            "numpy": "2.5.1",
        }:
            raise ValueError("INTEGRATION_RUNTIME_PINS_INVALID")

        s2_path = project_path(config["s2_report"])
        s2_payload = json.loads(s2_path.read_text(encoding="utf-8"))
        s2_errors = evaluate_s2(s2_payload)
        if s2_errors:
            raise ValueError("S2_EVIDENCE_INVALID")
        s2_snapshot = folder / "s2_evidence.json"
        shutil.copyfile(s2_path, s2_snapshot)
        report["s2_evidence"] = {
            "snapshot": s2_snapshot.relative_to(ROOT).as_posix(),
            "sha256": sha256(s2_snapshot),
        }

        wheelhouse = project_path(config["wheelhouse"], directory=True)
        wheel_manifest_path = wheelhouse / "manifest.json"
        wheel_manifest = json.loads(wheel_manifest_path.read_text(encoding="utf-8"))
        installed_wheels = {
            item["name"]: item["version"] for item in wheel_manifest.get("files", [])
        }
        if (
            wheel_manifest.get("status") != "PASS_ENGINEERING"
            or any(installed_wheels.get(name) != version for name, version in requirements.items())
        ):
            raise ValueError("ARM64_WHEELHOUSE_INVALID")
        for item in wheel_manifest["files"]:
            wheel = wheelhouse / item["file"]
            if not wheel.is_file() or sha256(wheel) != item["sha256"]:
                raise ValueError("ARM64_WHEEL_HASH_MISMATCH")

        model_dir = workspace_path(config["asr"]["model_dir"], directory=True)
        model_manifest_path = workspace_path(config["asr"]["model_manifest"])
        model_manifest = json.loads(model_manifest_path.read_text(encoding="utf-8"))
        entries = {item["name"]: item for item in model_manifest.get("files", [])}
        if model_manifest.get("passed") is not True or not set(REQUIRED_MODEL_FILES).issubset(entries):
            raise ValueError("ASR_MODEL_MANIFEST_INVALID")
        runtime_files: dict[str, dict[str, object]] = {}
        for name in REQUIRED_MODEL_FILES:
            source = model_dir / name
            item = entries[name]
            if (
                not source.is_file()
                or source.stat().st_size != int(item["bytes"])
                or sha256(source) != str(item["sha256"]).lower()
            ):
                raise ValueError("ASR_MODEL_INTEGRITY_FAILED")
            runtime_files[name] = {
                "bytes": int(item["bytes"]),
                "sha256": str(item["sha256"]).lower(),
            }
        bundle_hash = model_bundle_sha256(runtime_files)
        sample = model_dir / config["asr"]["sample_wav"]
        if not sample.is_file():
            raise ValueError("ASR_SAMPLE_MISSING")
        reference_hash = s2_payload["components"]["asr"]["final_text_sha256"]
        if reference_hash != s2_payload["host_references"]["asr"]["final_text_sha256"]:
            raise ValueError("S2_REFERENCE_MISMATCH")

        context = folder / "context"
        context.mkdir()
        shutil.copyfile(ROOT / "simulation" / "IntegrationDockerfile", context / "Dockerfile")
        context_hashes = copy_application(context)
        runtime_manifest = {
            "schema_version": "1.0.0",
            "status": "ENGINEERING_MODEL_AVAILABLE_PRODUCT_LICENSE_PENDING",
            "runtime_version": requirements["sherpa-onnx"],
            "model_files": runtime_files,
            "model_bundle_sha256": bundle_hash,
            "product_accepted": False,
            "hardware_measured": False,
        }
        runtime_manifest_path = context / "app" / "asr_runtime_manifest.json"
        runtime_manifest_path.write_text(
            json.dumps(runtime_manifest, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        runtime_config = {
            "schema_version": "1.0.0",
            "mode": "ENGINEERING_SELECTED_BACKENDS",
            "product_accepted": False,
            "asr": {
                "enabled": True,
                "backend_id": "asr_sherpa_cpu_xasr",
                "python_module": "asr_runtime.worker",
                "model_id": "xasr_streaming_int8",
                "model_dir": "models/asr",
                "manifest": "asr_runtime_manifest.json",
                "runtime_name": "sherpa_onnx",
                "runtime_version": requirements["sherpa-onnx"],
                "contract_version": "1.0.0",
                "component_version": "1.0.0",
                "model_bundle_sha256": bundle_hash,
                "operation_timeout_seconds": int(config["asr"]["operation_timeout_seconds"]),
                "max_inflight_requests": 1,
                "circuit_failure_threshold": 3,
                "circuit_recovery_seconds": 30,
            },
            "ocr": {"enabled": False},
        }
        runtime_config_path = context / "app" / "configs" / "runtime_adapters.json"
        runtime_config_path.write_text(
            json.dumps(runtime_config, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        evidence = {
            "schema_version": "1.0.0",
            "scope": config["scope"],
            "requirements": requirements,
            "model_bundle_sha256": bundle_hash,
            "sample_sha256": sha256(sample),
            "reference_text_sha256": reference_hash,
            "operation_timeout_seconds": int(config["asr"]["operation_timeout_seconds"]),
            "product_accepted": False,
            "hardware_measured": False,
        }
        evidence_path = context / "app" / "evidence.json"
        evidence_path.write_text(
            json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        context_hashes["asr_runtime_manifest.json"] = sha256(runtime_manifest_path)
        context_hashes["configs/runtime_adapters.json"] = sha256(runtime_config_path)
        context_hashes["evidence.json"] = sha256(evidence_path)
        context_hashes["simulation/IntegrationDockerfile"] = sha256(context / "Dockerfile")
        report["context_sha256"] = context_hashes

        source_files = [
            CONFIG,
            ROOT / "simulation" / "IntegrationDockerfile",
            ROOT / "simulation" / "integration_probe.py",
            ROOT / "asr_runtime" / "worker.py",
            ROOT / "asr_runtime" / "field_extraction.py",
            ROOT / "asr_runtime" / "session.py",
            ROOT / "runtime_backends" / "__init__.py",
            ROOT / "runtime_backends" / "registry.py",
            ROOT / "model_registry" / "backend_registry.json",
            ROOT / "configs" / "runtime_backend_selection.json",
            ROOT / "integration_adapter" / "supervisor.py",
            ROOT / "device_service" / "application.py",
            ROOT / "device_service" / "runtime_bootstrap.py",
            ROOT / "device_service" / "server.py",
            ROOT / "device_service" / "websocket.py",
            ROOT / "operations" / "event_log.py",
            ROOT / "scripts" / "run_arm64_integration_simulation.py",
            ROOT / "scripts" / "verify_arm64_integration_evidence.py",
            wheel_manifest_path,
            model_manifest_path,
            sample,
            *[model_dir / name for name in REQUIRED_MODEL_FILES],
        ]
        report["source_sha256"] = {source_key(path): sha256(path) for path in source_files}
        report["wheel_sha256"] = {
            item["file"]: item["sha256"] for item in wheel_manifest["files"]
        }
        report["asr_model_bundle_sha256"] = bundle_hash

        if not docker:
            report["status"] = "BLOCKED_ENVIRONMENT"
            report["blockers"] = ["DOCKER_CLI_MISSING"]
            return 3
        endpoint = environment.get("DOCKER_HOST")
        if environment.get("DOCKER_CONTEXT") or not endpoint:
            command = [docker, "context", "inspect"]
            if environment.get("DOCKER_CONTEXT"):
                command.append(environment["DOCKER_CONTEXT"])
            command += ["--format", "{{json .Endpoints.docker.Host}}"]
            rc, raw = run_command(command, ROOT, folder, records, "docker_context", env=environment)
            if rc:
                report["status"] = "BLOCKED_ENVIRONMENT"
                report["blockers"] = ["DOCKER_CONTEXT_UNAVAILABLE"]
                return 3
            endpoint = json.loads(raw)
        if not isinstance(endpoint, str) or not local_endpoint(endpoint):
            raise ValueError("REMOTE_DOCKER_REFUSED")
        environment.pop("DOCKER_CONTEXT", None)
        environment["DOCKER_HOST"] = endpoint

        def docker_run(arguments: list[str], name: str, timeout: int = 30):
            return run_command([docker, *arguments], ROOT, folder, records, name, timeout, environment)

        rc, raw = docker_run(["info", "--format", "{{json .OSType}}"], "docker_info")
        if rc or json.loads(raw) != "linux":
            report["status"] = "BLOCKED_ENVIRONMENT"
            report["blockers"] = ["LOCAL_LINUX_DOCKER_NOT_READY"]
            return 3
        rc, _ = docker_run(["pull", "--platform", ARM64_PLATFORM, BASE_TAG], "pull_base", 600)
        if rc:
            raise ValueError("ARM64_BASE_PULL_FAILED")
        rc, raw = docker_run(image_inspect_arguments(BASE_TAG), "inspect_base")
        if rc:
            raise ValueError("BASE_IMAGE_INSPECTION_FAILED")
        base = json.loads(raw)[0]
        if base.get("Architecture") != "arm64" or base.get("Os") != "linux":
            raise ValueError("BASE_IMAGE_NOT_ARM64_LINUX")
        pinned = next(
            (
                item
                for item in base.get("RepoDigests", [])
                if re.fullmatch(r"(?:docker.io/library/)?python@sha256:[a-f0-9]{64}", item)
            ),
            None,
        )
        if pinned is None:
            raise ValueError("BASE_DIGEST_MISSING")
        report["base_image"] = {"tag": BASE_TAG, "digest": pinned, "id": base["Id"]}
        tag = "family-health-arm64-integration:" + run_id.lower()
        rc, _ = docker_run(
            [
                "build",
                "--platform",
                ARM64_PLATFORM,
                "--network=none",
                "--build-arg",
                "BASE_IMAGE=" + pinned,
                "--build-context",
                "wheelhouse=" + str(wheelhouse),
                "--build-context",
                "asr=" + str(model_dir),
                "-t",
                tag,
                str(context),
            ],
            "build_integration_image",
            900,
        )
        if rc:
            raise ValueError("ARM64_INTEGRATION_BUILD_FAILED")
        rc, raw = docker_run(image_inspect_arguments(tag), "inspect_candidate")
        if rc:
            raise ValueError("CANDIDATE_INSPECTION_FAILED")
        candidate = json.loads(raw)[0]
        if candidate.get("Architecture") != "arm64" or candidate.get("Os") != "linux":
            raise ValueError("CANDIDATE_NOT_ARM64_LINUX")
        reference = pinned_repository_digest(candidate.get("RepoDigests"))
        if reference is None:
            raise ValueError("CANDIDATE_REPOSITORY_DIGEST_MISSING")
        report["candidate_image"] = {"id": candidate["Id"], "reference": reference}
        rc, _ = docker_run(
            [
                "create",
                "--name",
                container_name,
                "--platform",
                ARM64_PLATFORM,
                "--network=none",
                "--read-only",
                "--cap-drop=ALL",
                "--security-opt=no-new-privileges",
                "--memory=4g",
                "--memory-swap=4g",
                "--cpus=4",
                "--pids-limit=128",
                "--tmpfs",
                "/tmp:rw,nosuid,nodev,size=256m,mode=1777",
                reference,
            ],
            "create_integration_container",
        )
        if rc:
            raise ValueError("INTEGRATION_CONTAINER_CREATE_FAILED")
        created_container = True
        rc, raw = docker_run(["start", "--attach", container_name], "run_integration_probe", 900)
        if rc:
            raise ValueError("INTEGRATION_GUEST_FAILED")
        rc, state_raw = docker_run(
            ["inspect", "--format", "{{json .State}}", container_name],
            "inspect_integration_guest",
        )
        state = json.loads(state_raw) if rc == 0 else {}
        if (
            state.get("ExitCode") != 0
            or state.get("Running") is not False
            or state.get("OOMKilled") is not False
        ):
            raise ValueError("INTEGRATION_GUEST_EXIT_INVALID")
        guest = json.loads(raw)
        if not validate_guest(guest, requirements):
            raise ValueError("INTEGRATION_GUEST_EVIDENCE_REJECTED")
        report["guest"] = guest
        report["components"] = {
            "health": guest["health"],
            "asr": guest["asr"],
            "ocr": guest["ocr"],
        }
        report["status"] = "PARTIAL_PASS_PRODUCT_BLOCKED"
        report["blockers"] = [
            "OCR_PRODUCT_WORKER_AND_LICENSE_REQUIRED",
            "ASR_PRODUCT_LICENSE_AND_TARGET_MIC_ACCEPTANCE_REQUIRED",
            "RK3566_NOT_TESTED",
        ]
        return_code = 0
        return return_code
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, IndexError) as exc:
        report["status"] = "FAIL"
        report["blockers"] = [public_reason(exc)]
        return_code = 2
        return return_code
    finally:
        if created_container and docker:
            cleanup_code, _ = run_command(
                [docker, "rm", "--force", container_name],
                ROOT,
                folder,
                records,
                "cleanup_own_integration_container",
                env=environment,
            )
            report["container_cleaned"] = cleanup_code == 0
        report["finished_at"] = datetime.now(timezone.utc).isoformat()
        encoded = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
        (folder / "audit.json").write_text(encoded, encoding="utf-8")
        REPORT.write_text(encoded, encoding="utf-8")
        print(
            json.dumps(
                {
                    key: report.get(key)
                    for key in (
                        "run_id",
                        "status",
                        "stage",
                        "blockers",
                        "three_model_inference_verified",
                    )
                },
                ensure_ascii=True,
            )
        )


if __name__ == "__main__":
    raise SystemExit(main())
