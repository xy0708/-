from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "data_policy_verification.json"


def main() -> int:
    failures: list[str] = []
    policy = json.loads((ROOT / "configs" / "data_policy.json").read_text(encoding="utf-8"))
    charls = policy.get("charls", {})
    if charls != {
        "status": "PERMANENTLY_EXCLUDED",
        "apply_for_access": False,
        "download": False,
        "train": False,
        "release_inclusion": False,
    }:
        failures.append("CHARLS_PERMANENT_EXCLUSION_CHANGED")
    nhanes = policy.get("nhanes", {})
    if nhanes.get("china_product_model_evidence_allowed") is not False:
        failures.append("NHANES_MUST_NOT_BE_CHINA_PRODUCT_MODEL_EVIDENCE")
    synthetic = policy.get("synthetic_data", {})
    if (
        synthetic.get("formal_training_evidence_allowed") is not False
        or synthetic.get("independent_acceptance_evidence_allowed") is not False
    ):
        failures.append("SYNTHETIC_DATA_PRODUCT_EVIDENCE_FORBIDDEN")
    release_inputs = json.loads(
        (ROOT / "configs" / "release_inputs.json").read_text(encoding="utf-8")
    )
    for item in release_inputs.get("files", []):
        combined = f"{item.get('source', '')} {item.get('destination', '')}".lower()
        if "charls" in combined:
            failures.append("CHARLS_PATH_IN_RELEASE_INPUTS")
        if "nhanes" in combined and any(
            word in combined for word in ("model", "checkpoint", "training", "weights")
        ):
            failures.append("NHANES_PRODUCT_MODEL_EVIDENCE_IN_RELEASE_INPUTS")
        if "synthetic" in combined and any(
            word in combined for word in ("acceptance", "validation", "calibration")
        ):
            failures.append("SYNTHETIC_FORMAL_EVIDENCE_IN_RELEASE_INPUTS")
    target = policy.get("china_target_population_commercial_data", {})
    blockers = []
    if target.get("available") is not True:
        blockers.append("COMMERCIAL_CHINA_TARGET_DATA_NOT_AVAILABLE")
    if target.get("license_audit_complete") is not True:
        blockers.append("COMMERCIAL_CHINA_TARGET_DATA_LICENSE_NOT_COMPLETE")
    if target.get("independent_validation_available") is not True:
        blockers.append("COMMERCIAL_CHINA_INDEPENDENT_VALIDATION_NOT_AVAILABLE")
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not failures else "FAIL",
        "charls_used": False,
        "nhanes_claimed_as_china_product_model": False,
        "synthetic_data_used_as_product_evidence": False,
        "china_target_population_product_data_ready": not blockers,
        "failures": failures,
        "product_blockers": blockers,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
