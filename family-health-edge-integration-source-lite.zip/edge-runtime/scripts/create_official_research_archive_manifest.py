from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_ROOT = ROOT.parent / "官方模型对比实验"
MODEL_ROOT = ARCHIVE_ROOT / "artifacts" / "official_models"
OUTPUT = ARCHIVE_ROOT / "OFFICIAL_RESEARCH_ARCHIVE_MANIFEST.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    archive = ARCHIVE_ROOT.resolve(strict=True)
    model_root = MODEL_ROOT.resolve(strict=True)
    model_root.relative_to(archive)
    records = []
    for path in sorted(model_root.rglob("*")):
        if path.is_symlink():
            raise RuntimeError(f"ARCHIVE_SYMLINK_FORBIDDEN:{path}")
        if path.is_file():
            records.append(
                {
                    "path": path.relative_to(archive).as_posix(),
                    "bytes": path.stat().st_size,
                    "sha256": sha256(path),
                }
            )
    if not records:
        raise RuntimeError("OFFICIAL_RESEARCH_ARCHIVE_EMPTY")
    payload = {
        "schema_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": "OFFICIAL_MODELS_ARCHIVED_RESEARCH_ONLY_PRODUCT_BLOCKED",
        "source_product_tree": ROOT.name,
        "model_root": "artifacts/official_models",
        "file_count": len(records),
        "total_bytes": sum(record["bytes"] for record in records),
        "product_selected": False,
        "formal_release_allowed": False,
        "hardware_measured": False,
        "records": records,
    }
    OUTPUT.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "status": payload["status"],
                "file_count": payload["file_count"],
                "total_bytes": payload["total_bytes"],
                "manifest": str(OUTPUT),
                "manifest_sha256": sha256(OUTPUT),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
