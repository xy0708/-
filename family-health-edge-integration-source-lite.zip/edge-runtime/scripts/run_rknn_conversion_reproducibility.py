from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from research_assets import official_research_root, resolve_locked_artifact


REPORT = ROOT / "reports" / "rknn_conversion_reproducibility.json"
DEFAULT_IMAGE = "family-health-rknn-converter:2.3.2-cp38"
EXPECTED_IMAGE_ID = (
    "sha256:7f9aada37e75721b62de280c087d4457c2d9356afc47d7518aa5efdbf627f18e"
)


@dataclass(frozen=True)
class ReplayCase:
    name: str
    profile: str
    source: str
    canonical_output: str


CASES = (
    ReplayCase(
        "ppocrv4_det",
        "ppocrv4_det",
        "artifacts/official_models/source_onnx/ppocrv4_det.onnx",
        "artifacts/official_models/rknn_engineering/ppocrv4_det_fp16.rknn",
    ),
    ReplayCase(
        "ppocrv4_rec",
        "ppocrv4_rec",
        "artifacts/official_models/source_onnx/ppocrv4_rec.onnx",
        "artifacts/official_models/rknn_engineering/ppocrv4_rec_fp16.rknn",
    ),
    ReplayCase(
        "zipformer_encoder",
        "zipformer",
        "artifacts/official_models/source_onnx/zipformer_encoder_epoch_99_avg_1.onnx",
        "artifacts/official_models/rknn_engineering/zipformer_encoder_fp16.rknn",
    ),
    ReplayCase(
        "zipformer_decoder",
        "zipformer",
        "artifacts/official_models/source_onnx/zipformer_decoder_epoch_99_avg_1.onnx",
        "artifacts/official_models/rknn_engineering/zipformer_decoder_fp16.rknn",
    ),
    ReplayCase(
        "zipformer_joiner",
        "zipformer",
        "artifacts/official_models/source_onnx/zipformer_joiner_epoch_99_avg_1.onnx",
        "artifacts/official_models/rknn_engineering/zipformer_joiner_fp16.rknn",
    ),
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Replay all frozen RKNN conversions and archive their raw logs."
    )
    parser.add_argument("--image", default=DEFAULT_IMAGE)
    parser.add_argument("--expected-image-id", default=EXPECTED_IMAGE_ID)
    parser.add_argument("--timeout-seconds", type=int, default=600)
    return parser.parse_args()


def inspect_image(image: str) -> str | None:
    completed = subprocess.run(
        ["docker", "image", "inspect", image, "--format", "{{.Id}}"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    return completed.stdout.strip() if completed.returncode == 0 else None


def docker_command(image: str, case: ReplayCase, temporary_root: Path) -> list[str]:
    research_root = official_research_root(ROOT)
    return [
        "docker",
        "run",
        "--rm",
        "--network",
        "none",
        "--volume",
        f"{ROOT}:/workspace:ro",
        "--volume",
        f"{research_root}:/research:ro",
        "--volume",
        f"{temporary_root}:/evidence",
        "--workdir",
        "/tmp/rknn-run",
        image,
        "python",
        "/workspace/conversion/toolchain/smoke_convert.py",
        "--input",
        f"/research/{case.source}",
        "--output",
        f"/evidence/{case.name}.rknn",
        "--report",
        f"/evidence/{case.name}.json",
        "--profile",
        case.profile,
    ]


def sanitized_command(command: list[str], temporary_root: Path) -> list[str]:
    root = str(ROOT)
    research = str(official_research_root(ROOT))
    temporary = str(temporary_root)
    return [
        argument.replace(temporary, "{TEMP}")
        .replace(research, "{RESEARCH}")
        .replace(root, "{WORKSPACE}")
        for argument in command
    ]


def notable_sdk_lines(output: str) -> list[str]:
    markers = ("unknown op target", "unkown op target", "transpose", "warning")
    notable: list[str] = []
    for line in output.replace("\r", "\n").splitlines():
        stripped = line.strip()
        if stripped and any(marker in stripped.lower() for marker in markers):
            if stripped not in notable:
                notable.append(stripped)
    return notable[:50]


def load_report(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return {}


def common_prefix_bytes(first: Path, second: Path, chunk_size: int = 1024 * 1024) -> int:
    matched = 0
    with first.open("rb") as first_stream, second.open("rb") as second_stream:
        while True:
            first_chunk = first_stream.read(chunk_size)
            second_chunk = second_stream.read(chunk_size)
            if not first_chunk or not second_chunk:
                return matched
            if first_chunk == second_chunk:
                matched += len(first_chunk)
                continue
            for index, (first_byte, second_byte) in enumerate(
                zip(first_chunk, second_chunk)
            ):
                if first_byte != second_byte:
                    return matched + index
            return matched + min(len(first_chunk), len(second_chunk))


def common_suffix_bytes(
    first: Path,
    second: Path,
    prefix_bytes: int,
    chunk_size: int = 1024 * 1024,
) -> int:
    first_size = first.stat().st_size
    second_size = second.stat().st_size
    comparable = min(first_size, second_size) - prefix_bytes
    matched = 0
    with first.open("rb") as first_stream, second.open("rb") as second_stream:
        while matched < comparable:
            read_size = min(chunk_size, comparable - matched)
            first_stream.seek(first_size - matched - read_size)
            second_stream.seek(second_size - matched - read_size)
            first_chunk = first_stream.read(read_size)
            second_chunk = second_stream.read(read_size)
            if first_chunk == second_chunk:
                matched += read_size
                continue
            for index, (first_byte, second_byte) in enumerate(
                zip(reversed(first_chunk), reversed(second_chunk))
            ):
                if first_byte != second_byte:
                    return matched + index
            return matched + read_size
    return matched


def binary_diff_summary(canonical: Path, replay: Path) -> dict[str, int | bool]:
    canonical_bytes = canonical.stat().st_size
    replay_bytes = replay.stat().st_size
    prefix = common_prefix_bytes(canonical, replay)
    suffix = common_suffix_bytes(canonical, replay, prefix)
    return {
        "same_size": canonical_bytes == replay_bytes,
        "canonical_bytes": canonical_bytes,
        "replay_bytes": replay_bytes,
        "common_prefix_bytes": prefix,
        "common_suffix_bytes": suffix,
        "canonical_changed_span_bytes": max(canonical_bytes - prefix - suffix, 0),
        "replay_changed_span_bytes": max(replay_bytes - prefix - suffix, 0),
    }


def printable_strings(data: bytes) -> list[str]:
    return [
        match.group(0).decode("ascii", errors="replace")
        for match in re.finditer(rb"[ -~]{4,}", data)
    ][:20]


def changed_region_diagnostics(
    canonical: Path,
    replay: Path,
    diff: dict[str, int | bool],
) -> dict[str, Any]:
    prefix = int(diff["common_prefix_bytes"])
    canonical_span = int(diff["canonical_changed_span_bytes"])
    replay_span = int(diff["replay_changed_span_bytes"])
    with canonical.open("rb") as stream:
        stream.seek(prefix)
        canonical_region = stream.read(canonical_span)
    with replay.open("rb") as stream:
        stream.seek(prefix)
        replay_region = stream.read(replay_span)
    comparable = min(len(canonical_region), len(replay_region))
    return {
        "canonical_region_sha256": hashlib.sha256(canonical_region).hexdigest(),
        "replay_region_sha256": hashlib.sha256(replay_region).hexdigest(),
        "different_byte_count_in_common_span": sum(
            first != second
            for first, second in zip(
                canonical_region[:comparable], replay_region[:comparable]
            )
        ),
        "canonical_hex_preview": canonical_region[:128].hex(),
        "replay_hex_preview": replay_region[:128].hex(),
        "canonical_printable_strings": printable_strings(canonical_region),
        "replay_printable_strings": printable_strings(replay_region),
    }


def replay_case(
    image: str,
    case: ReplayCase,
    temporary_root: Path,
    log_dir: Path,
    timeout_seconds: int,
    previous_replay_hash: str | None,
) -> dict[str, Any]:
    source = resolve_locked_artifact(ROOT, case.source)
    canonical = resolve_locked_artifact(ROOT, case.canonical_output)
    command = docker_command(image, case, temporary_root)
    started_at = datetime.now(timezone.utc)
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            check=False,
        )
        output = completed.stdout + completed.stderr
        exit_code = completed.returncode
        error = None
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        output = f"{stdout}{stderr}"
        exit_code = -1
        error = f"TIMEOUT_{timeout_seconds}_SECONDS"

    log_path = log_dir / f"{case.name}.log"
    log_path.write_text(output, encoding="utf-8")
    replay_output = temporary_root / f"{case.name}.rknn"
    replay_report = load_report(temporary_root / f"{case.name}.json")
    source_exists = source.is_file()
    canonical_exists = canonical.is_file()
    replay_exists = replay_output.is_file()
    source_hash = sha256(source) if source_exists else None
    canonical_hash = sha256(canonical) if canonical_exists else None
    replay_hash = sha256(replay_output) if replay_exists else None
    conversion_succeeded = (
        exit_code == 0
        and replay_report.get("status") == "PASS_ENGINEERING_CONVERSION_ONLY"
        and replay_hash is not None
        and replay_report.get("input", {}).get("sha256") == source_hash
        and replay_report.get("output", {}).get("sha256") == replay_hash
    )
    byte_reproducible = conversion_succeeded and replay_hash == canonical_hash
    diff = (
        binary_diff_summary(canonical, replay_output)
        if canonical_exists and replay_exists and not byte_reproducible
        else None
    )
    diff_diagnostics = (
        changed_region_diagnostics(canonical, replay_output, diff)
        if diff is not None
        else None
    )
    notable = notable_sdk_lines(output)
    return {
        "name": case.name,
        "profile": case.profile,
        "source": case.source,
        "source_sha256": source_hash,
        "canonical_output": case.canonical_output,
        "canonical_output_sha256": canonical_hash,
        "replay_output_sha256": replay_hash,
        "previous_replay_output_sha256": previous_replay_hash,
        "matches_previous_replay": (
            replay_hash == previous_replay_hash
            if replay_hash is not None and previous_replay_hash is not None
            else None
        ),
        "conversion_succeeded": conversion_succeeded,
        "byte_reproducible": byte_reproducible,
        "binary_diff": diff,
        "binary_diff_diagnostics": diff_diagnostics,
        "status": (
            "PASS_ENGINEERING_BYTE_REPRODUCIBLE"
            if byte_reproducible
            else (
                "PARTIAL_PASS_ENGINEERING_HASH_DRIFT"
                if conversion_succeeded
                else "FAIL_REPLAY"
            )
        ),
        "command": sanitized_command(command, temporary_root),
        "network_disabled": True,
        "exit_code": exit_code,
        "started_at": started_at.isoformat(),
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "log": log_path.relative_to(ROOT).as_posix(),
        "log_sha256": sha256(log_path),
        "notable_sdk_lines": notable,
        "sdk_warning_present": bool(notable),
        "error": error,
    }


def main() -> int:
    args = parse_args()
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    log_dir = ROOT / "reports" / "rknn_conversion_runs" / run_id
    log_dir.mkdir(parents=True, exist_ok=False)
    artifact_work = ROOT / ".artifact-work"
    artifact_work.mkdir(parents=True, exist_ok=True)
    previous_report = load_report(REPORT)
    previous_hashes = {
        str(record.get("name")): record.get("replay_output_sha256")
        for record in previous_report.get("records", [])
        if isinstance(record, dict)
        and isinstance(record.get("replay_output_sha256"), str)
    }

    actual_image_id = inspect_image(args.image)
    image_matches = actual_image_id == args.expected_image_id
    records: list[dict[str, Any]] = []
    temporary_path: Path | None = None
    if image_matches:
        with tempfile.TemporaryDirectory(
            prefix="conversion-replay-", dir=artifact_work
        ) as temporary:
            temporary_path = Path(temporary).resolve()
            if not temporary_path.is_relative_to(artifact_work.resolve()):
                raise RuntimeError("Unsafe replay temporary directory")
            for case in CASES:
                records.append(
                    replay_case(
                        args.image,
                        case,
                        temporary_path,
                        log_dir,
                        args.timeout_seconds,
                        previous_hashes.get(case.name),
                    )
                )

    temporary_deleted = temporary_path is None or not temporary_path.exists()
    conversions_succeeded = (
        image_matches
        and len(records) == len(CASES)
        and all(record["conversion_succeeded"] for record in records)
        and temporary_deleted
    )
    all_byte_reproducible = conversions_succeeded and all(
        record["byte_reproducible"] for record in records
    )
    result = {
        "schema_version": "1.0.0",
        "run_id": run_id,
        "status": (
            "PASS_ENGINEERING_CONVERSION_REPRODUCIBILITY"
            if all_byte_reproducible
            else (
                "PARTIAL_PASS_ENGINEERING_OUTPUT_HASH_DRIFT"
                if conversions_succeeded
                else "FAIL_ENGINEERING_CONVERSION_REPRODUCIBILITY"
            )
        ),
        "scope": "OFFLINE_HOST_CONVERSION_REPLAY_ONLY",
        "image": args.image,
        "expected_image_id": args.expected_image_id,
        "actual_image_id": actual_image_id,
        "image_id_matches": image_matches,
        "network_disabled": True,
        "candidate_count": len(CASES),
        "conversion_success_count": sum(
            bool(record["conversion_succeeded"]) for record in records
        ),
        "byte_reproduced_count": sum(
            bool(record["byte_reproducible"]) for record in records
        ),
        "hash_drift_count": sum(
            bool(record["conversion_succeeded"]) and not bool(record["byte_reproducible"])
            for record in records
        ),
        "all_outputs_byte_reproducible": all_byte_reproducible,
        "temporary_artifacts_deleted": temporary_deleted,
        "hardware_measured": False,
        "product_selection_allowed": False,
        "records": records,
        "log_directory": log_dir.relative_to(ROOT).as_posix(),
    }
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if all_byte_reproducible else 2


if __name__ == "__main__":
    raise SystemExit(main())
