$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Windows administrator privileges are required. Run this script in an elevated PowerShell.'
}
$edgeRoot = Split-Path -Parent $PSScriptRoot
$reportDir = Join-Path $edgeRoot 'reports'
$logPath = Join-Path $reportDir 'simulation_wsl_install.log'
$statePath = Join-Path $reportDir 'simulation_wsl_install.json'
$wingetPath = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\winget.exe'
$state = [ordered]@{ started_at=(Get-Date).ToUniversalTime().ToString('o'); status='INSTALLING'; version='2.7.13'; reboot_performed=$false }
$state | ConvertTo-Json | Set-Content -LiteralPath $statePath -Encoding UTF8
try {
    & $wingetPath install --id Microsoft.WSL --version 2.7.13 --exact --source winget --silent --disable-interactivity *> $logPath
    $state['installer_exit_code'] = $LASTEXITCODE
    if ($LASTEXITCODE -ne 0) { throw 'WSL_INSTALLER_FAILED_SEE_LOG' }
    # Windows PowerShell treats native stderr warnings as errors under Stop.
    # Judge native setup by its exit code, not by presence of stderr text.
    $ErrorActionPreference = 'Continue'
    & 'C:\Windows\System32\wsl.exe' --install --no-distribution *>> $logPath
    $state['feature_exit_code'] = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    $state['status'] = if ($LASTEXITCODE -eq 0) { 'INSTALLED_RECHECK_REBOOT_REQUIREMENT' } else { 'FEATURE_SETUP_NEEDS_ATTENTION' }
} catch {
    $state['status'] = 'BLOCKED_INSTALLATION'
    $state['error'] = $_.Exception.Message
} finally {
    $state['finished_at'] = (Get-Date).ToUniversalTime().ToString('o')
    $state | ConvertTo-Json | Set-Content -LiteralPath $statePath -Encoding UTF8
}
