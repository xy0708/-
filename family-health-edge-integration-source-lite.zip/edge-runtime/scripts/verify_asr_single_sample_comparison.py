from __future__ import annotations

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.asr_single_sample import validate_report


ASR_ROOT = (
    ROOT.parent
    / "语音转文字"
    / "家庭健康语音转文字_Codex_Goal_Loop"
    / "health_asr_codex_loop"
)
REPORT = ROOT / "reports/asr_cpu_rknn_single_sample_comparison.json"
VERIFICATION = ROOT / "reports/asr_cpu_rknn_single_sample_comparison_verification.json"
AUDIO = ROOT / "vendor/rockchip/rknn_model_zoo/examples/zipformer/model/test.wav"
CPU_MANIFEST = ASR_ROOT / "models/sherpa/model_manifest.json"
RKNN_REPORT = ROOT / "reports/rknn_simulation_zipformer_audio.json"
REGISTRY = ROOT / "model_registry/backend_registry.json"
HOST_WHEELS = sorted((ROOT / "artifacts/host_wheelhouse/sherpa-1.13.7").glob("*.whl"))
CPU_VERIFIER = ASR_ROOT / "scripts/verify_sherpa.py"


def verify() -> dict[str, object]:
    try:
        report = json.loads(REPORT.read_text(encoding="utf-8"))
        errors = validate_report(
            report,
            audio_path=AUDIO,
            cpu_manifest_path=CPU_MANIFEST,
            rknn_report_path=RKNN_REPORT,
            registry_path=REGISTRY,
            host_wheels=HOST_WHEELS,
            verifier_path=CPU_VERIFIER,
        )
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        errors = [f"COMPARISON_EVIDENCE_UNREADABLE:{type(exc).__name__}"]
    return {
        "status": "PASS_ENGINEERING_SINGLE_SAMPLE_PRODUCT_BLOCKED"
        if not errors
        else "FAIL",
        "phase": "R04_ENGINEERING_COMPARISON_PARTIAL",
        "single_sample_only": True,
        "cer_or_wer_claim_allowed": False,
        "product_selection_allowed": False,
        "hardware_measured": False,
        "errors": errors,
    }


def main() -> int:
    result = verify()
    VERIFICATION.parent.mkdir(parents=True, exist_ok=True)
    VERIFICATION.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not result["errors"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
