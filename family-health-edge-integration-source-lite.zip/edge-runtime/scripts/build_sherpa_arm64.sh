#!/bin/sh
set -eu

: "${SHERPA_ONNX_SOURCE:?Set SHERPA_ONNX_SOURCE to an audited source checkout}"
: "${SHERPA_ONNX_COMMIT:?Set SHERPA_ONNX_COMMIT to the approved 40-character Git commit}"
: "${AARCH64_TOOLCHAIN_FILE:?Set AARCH64_TOOLCHAIN_FILE to the approved CMake toolchain file}"
: "${AARCH64_TOOLCHAIN_SHA256:?Set AARCH64_TOOLCHAIN_SHA256 to its lowercase SHA-256}"
EDGE_BUILD_JOBS="${EDGE_BUILD_JOBS:-2}"

case "$SHERPA_ONNX_COMMIT" in
  *[!0-9a-f]*|'') printf '%s\n' 'SHERPA_ONNX_COMMIT must be lowercase hexadecimal.' >&2; exit 2 ;;
esac
[ "${#SHERPA_ONNX_COMMIT}" -eq 40 ] || { printf '%s\n' 'SHERPA_ONNX_COMMIT must contain 40 characters.' >&2; exit 2; }
case "$AARCH64_TOOLCHAIN_SHA256" in
  *[!0-9a-f]*|'') printf '%s\n' 'AARCH64_TOOLCHAIN_SHA256 must be lowercase hexadecimal.' >&2; exit 2 ;;
esac
[ "${#AARCH64_TOOLCHAIN_SHA256}" -eq 64 ] || { printf '%s\n' 'AARCH64_TOOLCHAIN_SHA256 must contain 64 characters.' >&2; exit 2; }
case "$EDGE_BUILD_JOBS" in *[!0-9]*|'') printf '%s\n' 'EDGE_BUILD_JOBS must be a positive integer.' >&2; exit 2 ;; esac
[ "$EDGE_BUILD_JOBS" -ge 1 ] && [ "$EDGE_BUILD_JOBS" -le 16 ] || { printf '%s\n' 'EDGE_BUILD_JOBS must be in 1-16.' >&2; exit 2; }
[ "$(id -u)" -ne 0 ] || { printf '%s\n' 'Refusing to build as root.' >&2; exit 2; }

for EDGE_TOOL in cmake git sha256sum file python3; do
  command -v "$EDGE_TOOL" >/dev/null 2>&1 || { printf '%s\n' "$EDGE_TOOL is required." >&2; exit 2; }
done
[ -f "$AARCH64_TOOLCHAIN_FILE" ] || { printf '%s\n' 'Toolchain file does not exist.' >&2; exit 2; }
EDGE_ACTUAL_TOOLCHAIN_SHA256="$(sha256sum "$AARCH64_TOOLCHAIN_FILE" | awk '{print $1}')"
[ "$EDGE_ACTUAL_TOOLCHAIN_SHA256" = "$AARCH64_TOOLCHAIN_SHA256" ] || {
  printf '%s\n' 'Toolchain SHA-256 mismatch.' >&2
  exit 2
}
git -C "$SHERPA_ONNX_SOURCE" rev-parse --is-inside-work-tree >/dev/null 2>&1 || {
  printf '%s\n' 'Sherpa source is not a Git worktree.' >&2
  exit 2
}
EDGE_ACTUAL_COMMIT="$(git -C "$SHERPA_ONNX_SOURCE" rev-parse HEAD)"
[ "$EDGE_ACTUAL_COMMIT" = "$SHERPA_ONNX_COMMIT" ] || {
  printf '%s\n' 'Sherpa source commit mismatch.' >&2
  exit 2
}
[ -z "$(git -C "$SHERPA_ONNX_SOURCE" status --porcelain --untracked-files=all)" ] || {
  printf '%s\n' 'Sherpa source worktree is dirty.' >&2
  exit 2
}

EDGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
EDGE_BUILD_ID="$(printf 'sherpa-%s-%s' "$(printf '%s' "$SHERPA_ONNX_COMMIT" | cut -c1-12)" "$(printf '%s' "$AARCH64_TOOLCHAIN_SHA256" | cut -c1-12)")"
EDGE_ARTIFACT_ROOT="$EDGE_ROOT/artifacts/arm64"
EDGE_DESTINATION="$EDGE_ARTIFACT_ROOT/$EDGE_BUILD_ID"
[ ! -e "$EDGE_DESTINATION" ] || { printf '%s\n' 'Immutable ARM64 artifact already exists.' >&2; exit 2; }
mkdir -p "$EDGE_ARTIFACT_ROOT"
EDGE_STAGING="$(mktemp -d "$EDGE_ARTIFACT_ROOT/.build.XXXXXX")"
EDGE_BUILD="$EDGE_STAGING/build"
EDGE_INSTALL="$EDGE_STAGING/install"
EDGE_CLEANUP=true
cleanup() {
  if [ "$EDGE_CLEANUP" = true ] && [ -d "$EDGE_STAGING" ]; then
    find "$EDGE_STAGING" -depth -mindepth 1 -delete
    rmdir "$EDGE_STAGING"
  fi
}
trap cleanup EXIT

EDGE_SOURCE_DATE_EPOCH="$(git -C "$SHERPA_ONNX_SOURCE" show -s --format=%ct "$SHERPA_ONNX_COMMIT")"
export SOURCE_DATE_EPOCH="$EDGE_SOURCE_DATE_EPOCH"
cmake -S "$SHERPA_ONNX_SOURCE" -B "$EDGE_BUILD" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_TOOLCHAIN_FILE="$AARCH64_TOOLCHAIN_FILE" \
  -DCMAKE_INSTALL_PREFIX="$EDGE_INSTALL" \
  -DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF \
  -DCMAKE_FIND_PACKAGE_NO_PACKAGE_REGISTRY=ON \
  -DFETCHCONTENT_FULLY_DISCONNECTED=ON \
  -DBUILD_SHARED_LIBS=ON
cmake --build "$EDGE_BUILD" --config Release --parallel "$EDGE_BUILD_JOBS"
cmake --install "$EDGE_BUILD"

EDGE_ELF_COUNT=0
EDGE_BAD_ELF_COUNT=0
while IFS= read -r EDGE_FILE; do
  EDGE_DESCRIPTION="$(file -b "$EDGE_FILE")"
  case "$EDGE_DESCRIPTION" in
    *ELF*)
      EDGE_ELF_COUNT=$((EDGE_ELF_COUNT + 1))
      case "$EDGE_DESCRIPTION" in *ARM\ aarch64*|*aarch64*) : ;; *) EDGE_BAD_ELF_COUNT=$((EDGE_BAD_ELF_COUNT + 1)) ;; esac
      ;;
  esac
done <<EOF
$(find "$EDGE_INSTALL" -type f -print | LC_ALL=C sort)
EOF
[ "$EDGE_ELF_COUNT" -gt 0 ] || { printf '%s\n' 'No installed ELF artifacts were found.' >&2; exit 2; }
[ "$EDGE_BAD_ELF_COUNT" -eq 0 ] || { printf '%s\n' 'Non-aarch64 ELF artifact detected.' >&2; exit 2; }

export EDGE_INSTALL EDGE_BUILD_ID EDGE_ACTUAL_COMMIT EDGE_ACTUAL_TOOLCHAIN_SHA256 EDGE_SOURCE_DATE_EPOCH EDGE_ELF_COUNT
python3 - <<'PY' > "$EDGE_STAGING/manifest.json"
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path

root = Path(os.environ["EDGE_INSTALL"])
files = []
for path in sorted(value for value in root.rglob("*") if value.is_file()):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    files.append({"path": path.relative_to(root).as_posix(), "size": path.stat().st_size, "sha256": digest})
print(json.dumps({
    "schema_version": "1.0.0",
    "created_at": datetime.now(timezone.utc).isoformat(),
    "status": "ENGINEERING_ARM64_ARTIFACT_DEVICE_ACCEPTANCE_REQUIRED",
    "build_id": os.environ["EDGE_BUILD_ID"],
    "source_commit": os.environ["EDGE_ACTUAL_COMMIT"],
    "toolchain_sha256": os.environ["EDGE_ACTUAL_TOOLCHAIN_SHA256"],
    "source_date_epoch": int(os.environ["EDGE_SOURCE_DATE_EPOCH"]),
    "aarch64_elf_count": int(os.environ["EDGE_ELF_COUNT"]),
    "files": files,
}, ensure_ascii=False, indent=2))
PY
mv "$EDGE_STAGING" "$EDGE_DESTINATION"
EDGE_CLEANUP=false
trap - EXIT
printf '%s\n' "ARM64 engineering artifact created at $EDGE_DESTINATION; real-device acceptance is still required."
