from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.asr_single_sample import (
    REPORT_SCHEMA_VERSION,
    REPORT_SCOPE,
    REPORT_STATUS,
    disagreement,
    load_registry_hash,
    load_rknn_transcript,
    sha256,
    transcript_digest,
    validate_report,
    verify_cpu_model_manifest,
)


ASR_ROOT = (
    ROOT.parent
    / "语音转文字"
    / "家庭健康语音转文字_Codex_Goal_Loop"
    / "health_asr_codex_loop"
)
MODEL_NAME = (
    "sherpa-onnx-x-asr-960ms-streaming-zipformer-transducer-"
    "zh-en-punct-int8-2026-06-05"
)
CPU_MODEL_DIR = ASR_ROOT / "models/sherpa" / MODEL_NAME
CPU_MANIFEST = ASR_ROOT / "models/sherpa/model_manifest.json"
CPU_VERIFIER = ASR_ROOT / "scripts/verify_sherpa.py"
ASR_PYTHON = ASR_ROOT / ".venv-sherpa/Scripts/python.exe"
AUDIO = ROOT / "vendor/rockchip/rknn_model_zoo/examples/zipformer/model/test.wav"
RKNN_REPORT = ROOT / "reports/rknn_simulation_zipformer_audio.json"
REGISTRY = ROOT / "model_registry/backend_registry.json"
HOST_WHEEL_DIR = ROOT / "artifacts/host_wheelhouse/sherpa-1.13.7"
HOST_WHEELS = sorted(HOST_WHEEL_DIR.glob("*.whl"))
WORK_ROOT = ROOT / ".artifact-work"
OUTPUT = ROOT / "reports/asr_cpu_rknn_single_sample_comparison.json"


def run_checked(command: list[str], *, environment: dict[str, str] | None = None) -> None:
    completed = subprocess.run(
        command,
        cwd=ROOT,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=300,
        check=False,
    )
    if completed.returncode:
        raise RuntimeError(
            f"ASR comparison subprocess failed with exit code {completed.returncode}"
        )


def run_cpu_candidate() -> dict[str, object]:
    if not ASR_PYTHON.is_file() or len(HOST_WHEELS) != 2:
        raise RuntimeError("locked ASR host runtime is incomplete")
    WORK_ROOT.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="asr-compare-", dir=WORK_ROOT) as directory:
        temporary = Path(directory)
        runtime = temporary / "runtime"
        result_path = temporary / "cpu_result.json"
        run_checked(
            [
                str(ASR_PYTHON),
                "-m",
                "pip",
                "install",
                "--disable-pip-version-check",
                "--no-index",
                "--no-deps",
                "--target",
                str(runtime),
                *(str(wheel) for wheel in HOST_WHEELS),
            ]
        )
        environment = dict(os.environ)
        environment["PYTHONPATH"] = str(runtime)
        environment["PYTHONUTF8"] = "1"
        run_checked(
            [
                str(ASR_PYTHON),
                str(CPU_VERIFIER),
                "--model-dir",
                str(CPU_MODEL_DIR),
                "--wav",
                str(AUDIO),
                "--num-threads",
                "1",
                "--chunk-ms",
                "100",
                "--output",
                str(result_path),
            ],
            environment=environment,
        )
        result = json.loads(result_path.read_text(encoding="utf-8"))
    if (
        result.get("passed") is not True
        or result.get("sherpa_onnx_version") != "1.13.7"
        or result.get("sample_rate") != 16_000
        or not isinstance(result.get("final_text"), str)
        or not result["final_text"].strip()
    ):
        raise RuntimeError("CPU ASR result boundary is invalid")
    return result


def build_report() -> dict[str, object]:
    audio_hash = sha256(AUDIO)
    cpu_bundle_hash = verify_cpu_model_manifest(CPU_MODEL_DIR, CPU_MANIFEST)
    registered_cpu_hash = load_registry_hash(REGISTRY, "asr_sherpa_cpu_xasr")
    if cpu_bundle_hash != registered_cpu_hash:
        raise RuntimeError("CPU ASR bundle and backend registry do not match")
    registered_rknn_hash = load_registry_hash(REGISTRY, "asr_rknn_zipformer")
    rknn_text, rknn_host_seconds = load_rknn_transcript(RKNN_REPORT, audio_hash)
    cpu_result = run_cpu_candidate()
    cpu_text = str(cpu_result["final_text"]).strip()
    report = {
        "schema_version": REPORT_SCHEMA_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": REPORT_STATUS,
        "scope": REPORT_SCOPE,
        "reference_transcript_available": False,
        "cer_or_wer_claim_allowed": False,
        "accuracy_claim_allowed": False,
        "product_selection_allowed": False,
        "hardware_measured": False,
        "host_timing_comparable_for_ranking": False,
        "target_microphone_data_used": False,
        "input": {
            "kind": "Rockchip bundled non-health ASR sample",
            "bytes": AUDIO.stat().st_size,
            "duration_seconds": cpu_result["audio_seconds"],
            "sample_rate_hz": cpu_result["sample_rate"],
            "channels": 1,
            "same_audio_bytes_for_both_candidates": True,
            "same_segmentation_for_both_candidates": False,
            "segmentation_note": (
                "CPU uses 100 ms streaming feeds; RKNN simulator uses its frozen "
                "103-frame segment and 96-frame offset. This blocks R06 ranking."
            ),
        },
        "source_hashes": {
            "audio_sha256": audio_hash,
            "cpu_manifest_sha256": sha256(CPU_MANIFEST),
            "rknn_simulator_report_sha256": sha256(RKNN_REPORT),
            "backend_registry_sha256": sha256(REGISTRY),
            "cpu_verifier_sha256": sha256(CPU_VERIFIER),
            "host_wheel_sha256": {
                wheel.name: sha256(wheel) for wheel in HOST_WHEELS
            },
        },
        "candidates": {
            "asr_sherpa_cpu_xasr": {
                "execution": "WINDOWS_X86_64_CPU_REAL_INFERENCE",
                "runtime_version": cpu_result["sherpa_onnx_version"],
                "model_bundle_sha256": cpu_bundle_hash,
                "normalized_transcript_sha256": transcript_digest(cpu_text),
                "load_seconds_single_host_run_not_ranking": cpu_result["load_seconds"],
                "decode_seconds_single_host_run_not_ranking": cpu_result[
                    "decode_seconds"
                ],
                "rtf_single_host_run_not_ranking": cpu_result["rtf"],
                "rss_after_decode_mb_single_host_run_not_ranking": cpu_result[
                    "rss_after_decode_mb"
                ],
            },
            "asr_rknn_zipformer": {
                "execution": "X86_64_PC_SIMULATOR_FROM_FROZEN_ONNX",
                "exported_target_rknn_loaded": False,
                "model_bundle_sha256": registered_rknn_hash,
                "normalized_transcript_sha256": transcript_digest(rknn_text),
                "host_seconds_single_run_not_ranking": rknn_host_seconds,
            },
        },
        "comparison": disagreement(cpu_text, rknn_text),
        "conclusion": {
            "result": "NO_PRODUCT_WINNER",
            "winner": None,
            "reasons": [
                "the bundled audio has no frozen reference transcript",
                "candidate segmentation differs and R06 requires identical segmentation",
                "RKNN evidence is a PC simulator rebuild and not target RKNN execution",
                "host timing cannot rank RK3566 CPU versus NPU performance",
                "target-microphone validation and named license approval are absent",
            ],
        },
    }
    errors = validate_report(
        report,
        audio_path=AUDIO,
        cpu_manifest_path=CPU_MANIFEST,
        rknn_report_path=RKNN_REPORT,
        registry_path=REGISTRY,
        host_wheels=HOST_WHEELS,
        verifier_path=CPU_VERIFIER,
    )
    if errors:
        raise RuntimeError(",".join(errors))
    return report


def main() -> int:
    report = build_report()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    safe_summary = {
        "status": report["status"],
        "report": OUTPUT.relative_to(ROOT).as_posix(),
        "report_sha256": sha256(OUTPUT),
        "comparison": report["comparison"],
        "conclusion": report["conclusion"],
    }
    print(json.dumps(safe_summary, ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
