from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent.resolve()
ALLOWED_PROJECT = (WORKSPACE / "健康模型" / "health-risk-model").resolve()
CONFIG = ROOT / "configs" / "health_ml_candidate.json"
PUBLIC_DATASETS = ROOT / "configs" / "public_dataset_candidates.json"
REPORT = ROOT / "reports" / "health_ml_candidate_verification.json"

EXPECTED_LINEAGE = {
    "dm": {
        "candidate_id": "rich_healthcare_diabetes_dryad",
        "raw_input_key": "rich_diabetes",
        "intended_engineering_task": "incident_diabetes_warning",
    },
    "ht": {
        "candidate_id": "sua_cvd_risk_factors_dryad",
        "raw_input_key": "hangzhou_cvd_risk",
        "intended_engineering_task": "next_visit_incident_hypertension_warning",
    },
}
HEX_64 = re.compile(r"^[0-9a-f]{64}$")


def _digest(path: Path, algorithm: str = "sha256") -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _bound_file(
    relative: Any, expected: Any, errors: list[str], label: str
) -> Path | None:
    if not isinstance(relative, str) or not isinstance(expected, str):
        errors.append(f"{label}:path_or_hash_missing")
        return None
    path = (ROOT / relative).resolve()
    if ALLOWED_PROJECT not in path.parents or not path.is_file():
        errors.append(f"{label}:missing_or_outside_health_project")
        return None
    if _digest(path) != expected:
        errors.append(f"{label}:sha256_mismatch")
    return path


def _load_json(path: Path, errors: list[str], label: str) -> dict:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        errors.append(f"{label}:unreadable_json")
        return {}
    if not isinstance(payload, dict):
        errors.append(f"{label}:root_not_object")
        return {}
    return payload


def _index_dicts(items: Any, key: str, errors: list[str], label: str) -> dict[str, dict]:
    if not isinstance(items, list):
        errors.append(f"{label}:not_list")
        return {}
    indexed: dict[str, dict] = {}
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get(key), str):
            errors.append(f"{label}:invalid_item")
            continue
        item_key = item[key]
        if item_key in indexed:
            errors.append(f"{label}:duplicate:{item_key}")
        indexed[item_key] = item
    return indexed


def _validate_split_evidence(task: str, task_report: Any, errors: list[str]) -> None:
    if not isinstance(task_report, dict):
        errors.append(f"{task}:training_task_missing")
        return
    splits = task_report.get("splits")
    if not isinstance(splits, dict) or set(splits) != {"train", "validation", "test"}:
        errors.append(f"{task}:split_set_invalid")
        return
    fingerprints: list[str] = []
    for split_name, split in splits.items():
        if not isinstance(split, dict):
            errors.append(f"{task}:{split_name}:split_evidence_invalid")
            continue
        count = split.get("n")
        positive = split.get("positive")
        fingerprint = split.get("person_id_sha256")
        if (
            not isinstance(count, int)
            or isinstance(count, bool)
            or count <= 0
            or not isinstance(positive, int)
            or isinstance(positive, bool)
            or not 0 < positive < count
        ):
            errors.append(f"{task}:{split_name}:class_count_invalid")
        if not isinstance(fingerprint, str) or not HEX_64.fullmatch(fingerprint):
            errors.append(f"{task}:{split_name}:person_fingerprint_invalid")
        else:
            fingerprints.append(fingerprint)
    if len(fingerprints) == 3 and len(set(fingerprints)) != 3:
        errors.append(f"{task}:split_fingerprint_reused")

    external = task_report.get("external_validation")
    if task == "dm":
        if not isinstance(external, dict) or external.get("status") == "NOT_AVAILABLE":
            errors.append("dm:geographic_holdout_missing")
        elif not HEX_64.fullmatch(str(external.get("person_id_sha256", ""))):
            errors.append("dm:external_person_fingerprint_invalid")
        elif external["person_id_sha256"] in fingerprints:
            errors.append("dm:external_fingerprint_reuses_development_split")
    elif task == "ht" and (
        not isinstance(external, dict) or external.get("status") != "NOT_AVAILABLE"
    ):
        errors.append("ht:external_validation_boundary_invalid")


def validate_training_lineage(
    config: dict,
    model_manifest: dict,
    training_report: dict,
    data_manifest: dict,
    public_registry: dict,
) -> list[str]:
    errors: list[str] = []
    lineage = config.get("training_lineage")
    if lineage != EXPECTED_LINEAGE:
        errors.append("training_lineage_contract_invalid")
        lineage = lineage if isinstance(lineage, dict) else {}

    boundary = {
        "status": "PASS",
        "product_model": False,
        "formal_product_training": False,
        "clinical_diagnosis": False,
        "legal_product_approval": "PENDING_NAMED_REVIEW",
        "china_target_population_independent_validation_complete": False,
    }
    for field, expected in boundary.items():
        if training_report.get(field) != expected:
            errors.append(f"training_report_boundary_invalid:{field}")
    for field, expected in {
        "product_model": False,
        "formal_product_training": False,
        "legal_product_approval": "PENDING_NAMED_REVIEW",
    }.items():
        if data_manifest.get(field) != expected:
            errors.append(f"data_manifest_boundary_invalid:{field}")
    if "CHARLS" not in data_manifest.get("permanent_exclusions", []):
        errors.append("data_manifest_charls_exclusion_missing")

    candidates = _index_dicts(
        public_registry.get("candidates"), "id", errors, "public_candidates"
    )
    datasets = _index_dicts(
        data_manifest.get("datasets"),
        "intended_engineering_task",
        errors,
        "health_data_manifest",
    )
    raw_inputs = training_report.get("raw_inputs")
    training_tasks = training_report.get("tasks")
    if not isinstance(raw_inputs, dict):
        errors.append("training_raw_inputs_invalid")
        raw_inputs = {}
    if not isinstance(training_tasks, dict) or set(training_tasks) != set(EXPECTED_LINEAGE):
        errors.append("training_tasks_invalid")
        training_tasks = training_tasks if isinstance(training_tasks, dict) else {}
    if set(raw_inputs) != {
        item["raw_input_key"] for item in EXPECTED_LINEAGE.values()
    }:
        errors.append("training_raw_input_set_invalid")
    if set(datasets) != {
        item["intended_engineering_task"] for item in EXPECTED_LINEAGE.values()
    }:
        errors.append("data_manifest_task_set_invalid")

    candidate_ids: list[str] = []
    for task, expected in EXPECTED_LINEAGE.items():
        task_lineage = lineage.get(task, {}) if isinstance(lineage, dict) else {}
        candidate_id = task_lineage.get("candidate_id")
        candidate_ids.append(str(candidate_id))
        candidate = candidates.get(str(candidate_id), {})
        dataset = datasets.get(expected["intended_engineering_task"], {})
        raw_input = raw_inputs.get(expected["raw_input_key"], {})

        if not candidate:
            errors.append(f"{task}:public_candidate_missing")
        else:
            if candidate.get("downloaded") is not True:
                errors.append(f"{task}:public_candidate_not_downloaded")
            if candidate.get("engineering_use_allowed") is not True:
                errors.append(f"{task}:engineering_use_not_allowed")
            if candidate.get("commercial_product_use_approved") is not False:
                errors.append(f"{task}:commercial_approval_must_remain_false")
            if candidate.get("product_acceptance_evidence_allowed") is not False:
                errors.append(f"{task}:product_acceptance_use_must_remain_false")

        if not dataset or not isinstance(raw_input, dict):
            errors.append(f"{task}:source_evidence_missing")
            _validate_split_evidence(task, training_tasks.get(task), errors)
            continue

        digest_type = str(candidate.get("artifact_digest_type", "")).lower()
        digest = str(candidate.get("artifact_digest", "")).lower()
        if dataset.get("digest_type") != digest_type or dataset.get("digest") != digest:
            errors.append(f"{task}:data_manifest_digest_mismatch")
        if raw_input.get("digest_type") != digest_type or raw_input.get("digest") != digest:
            errors.append(f"{task}:training_report_digest_mismatch")
        if raw_input.get("bytes") != dataset.get("bytes"):
            errors.append(f"{task}:training_report_size_mismatch")
        if dataset.get("landing_page") != candidate.get("source_url"):
            errors.append(f"{task}:source_url_mismatch")

        candidate_path = (WORKSPACE / str(candidate.get("local_artifact_path", ""))).resolve()
        dataset_path = (ALLOWED_PROJECT / str(dataset.get("file", ""))).resolve()
        raw_value = raw_input.get("path")
        raw_path = Path(raw_value).resolve() if isinstance(raw_value, str) else None
        if (
            candidate_path != dataset_path
            or raw_path != dataset_path
            or ALLOWED_PROJECT not in dataset_path.parents
            or not dataset_path.is_file()
        ):
            errors.append(f"{task}:source_path_binding_invalid")
        elif (
            digest_type not in hashlib.algorithms_available
            or _digest(dataset_path, digest_type) != digest
            or dataset_path.stat().st_size != dataset.get("bytes")
        ):
            errors.append(f"{task}:source_artifact_integrity_invalid")

        _validate_split_evidence(task, training_tasks.get(task), errors)

    if len(candidate_ids) == len(EXPECTED_LINEAGE) and len(set(candidate_ids)) != len(candidate_ids):
        errors.append("training_tasks_reuse_same_source_candidate")

    source_report = model_manifest.get("source_report")
    if not isinstance(source_report, str):
        errors.append("model_manifest_source_report_missing")
    else:
        source_path = (ALLOWED_PROJECT / source_report).resolve()
        configured_path = (ROOT / str(config.get("training_report", ""))).resolve()
        if source_path != configured_path:
            errors.append("model_manifest_source_report_path_mismatch")
        if model_manifest.get("source_report_sha256") != config.get(
            "training_report_sha256"
        ):
            errors.append("model_manifest_source_report_hash_mismatch")
    return sorted(set(errors))


def main() -> int:
    errors: list[str] = []
    config = _load_json(CONFIG, errors, "config")
    public_registry = _load_json(PUBLIC_DATASETS, errors, "public_registry")
    expected = {
        "status": "ENGINEERING_SHADOW_ONLY",
        "enabled_for_product": False,
        "expose_disease_probability": False,
        "backend": "onnxruntime_cpu",
        "target_device_validated": False,
        "rknn_conversion_applicable": False,
        "tasks": ["dm", "ht"],
    }
    for field, value in expected.items():
        if config.get(field) != value:
            errors.append(f"config_boundary_mismatch:{field}")

    runtime = _bound_file(
        config.get("runtime"), config.get("runtime_sha256"), errors, "runtime"
    )
    manifest_path = _bound_file(
        config.get("manifest"), config.get("manifest_sha256"), errors, "manifest"
    )
    training_report_path = _bound_file(
        config.get("training_report"),
        config.get("training_report_sha256"),
        errors,
        "training_report",
    )
    data_manifest_path = _bound_file(
        config.get("data_manifest"),
        config.get("data_manifest_sha256"),
        errors,
        "data_manifest",
    )
    benchmark_path = _bound_file(
        config.get("benchmark_report"),
        config.get("benchmark_report_sha256"),
        errors,
        "benchmark",
    )
    if runtime and "charls" in runtime.read_text(encoding="utf-8").casefold():
        errors.append("forbidden_dataset_marker_in_runtime")

    manifest = _load_json(manifest_path, errors, "manifest") if manifest_path else {}
    if manifest:
        if any(
            manifest.get(field) != value
            for field, value in {
                "status": "PASS",
                "product_model": False,
                "formal_product_training": False,
                "clinical_diagnosis": False,
            }.items()
        ):
            errors.append("manifest_product_boundary_invalid")
        models = manifest.get("models", {})
        if not isinstance(models, dict) or set(models) != {"dm", "ht"}:
            errors.append("manifest_tasks_invalid")
        else:
            for task in ["dm", "ht"]:
                item = models[task]
                model_path = (ALLOWED_PROJECT / str(item.get("onnx_file", ""))).resolve()
                expected_hash = config.get("models", {}).get(task)
                if (
                    ALLOWED_PROJECT not in model_path.parents
                    or not model_path.is_file()
                    or _digest(model_path) != expected_hash
                    or item.get("onnx_sha256") != expected_hash
                ):
                    errors.append(f"{task}:model_binding_invalid")

    training_report = (
        _load_json(training_report_path, errors, "training_report")
        if training_report_path
        else {}
    )
    data_manifest = (
        _load_json(data_manifest_path, errors, "data_manifest")
        if data_manifest_path
        else {}
    )
    if manifest and training_report and data_manifest and public_registry:
        errors.extend(
            validate_training_lineage(
                config,
                manifest,
                training_report,
                data_manifest,
                public_registry,
            )
        )

    if benchmark_path:
        benchmark = _load_json(benchmark_path, errors, "benchmark")
        if any(
            benchmark.get(field) != value
            for field, value in {
                "status": "PASS_ENGINEERING",
                "measurement_host": "development_host",
                "target_hardware_measured": False,
                "target_device_validation": "BLOCKED_EXTERNAL",
                "product_model": False,
                "clinical_diagnosis": False,
            }.items()
        ):
            errors.append("benchmark_truth_boundary_invalid")

    errors = sorted(set(errors))
    payload = {
        "schema_version": "1.1.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not errors else "FAIL",
        "engineering_shadow_available": not errors,
        "training_source_lineage_verified": not errors,
        "training_sources_fused": False if not errors else None,
        "source_candidate_by_task": {
            task: item["candidate_id"] for task, item in EXPECTED_LINEAGE.items()
        },
        "enabled_for_product": False,
        "target_device_validated": False,
        "formal_release_allowed": False,
        "errors": errors,
    }
    REPORT.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
