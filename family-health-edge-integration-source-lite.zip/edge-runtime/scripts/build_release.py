from __future__ import annotations

import json
import hashlib
import os
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from release_tools import (
    ReleaseInputError,
    controlled_release_path,
    copy_verified_release_input,
    validate_product_release_contents,
    validate_product_runtime_bundle,
    validate_release_inputs,
)


REPORT = ROOT / "reports" / "release_build.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def blocked_build_result(
    blocker: str, *, release_directory: Path | None = None
) -> dict:
    return {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "BLOCKED_FAIL_CLOSED",
        "formal_release_created": False,
        "release_directory": (
            str(release_directory) if release_directory is not None else None
        ),
        "blockers": [blocker],
    }


def build_failure_code(error: Exception) -> str:
    if isinstance(error, ReleaseInputError):
        return f"PRODUCT_RELEASE_BUILD_INVALID:{error}"
    return f"RELEASE_BUILD_IO_ERROR:{type(error).__name__}"


def write_result(result: dict) -> None:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


def main() -> int:
    from scripts.verify_release import evaluate

    formal = evaluate(require_formal_release=True)
    if formal.get("release_allowed") is True and formal.get("formal_release_verified") is True:
        result = {
            "schema_version": "1.0.0",
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "status": "FORMAL_RELEASE_ALREADY_VERIFIED",
            "formal_release_created": True,
            "release_directory": str(formal.get("formal_release_id")) if formal.get("formal_release_id") else None,
            "blockers": [],
        }
        write_result(result)
        return 0

    final = evaluate(require_formal_release=False)
    blockers = list(final["blockers"])

    if blockers:
        result = {
            "schema_version": "1.0.0",
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "status": "BLOCKED_FAIL_CLOSED",
            "formal_release_created": False,
            "release_directory": None,
            "blockers": blockers,
        }
        write_result(result)
        return 2

    try:
        inputs = json.loads(
            (ROOT / "configs" / "release_inputs.json").read_text(encoding="utf-8")
        )
        validated_inputs = validate_release_inputs(inputs, ROOT)
        validate_product_release_contents(validated_inputs)
        release_id = inputs["release_id"]
        destination = controlled_release_path(
            ROOT, "release_candidates", release_id
        )
    except (OSError, UnicodeError, json.JSONDecodeError, ReleaseInputError) as exc:
        result = blocked_build_result(
            str(exc) if isinstance(exc, ReleaseInputError) else "RELEASE_INPUT_INVALID_JSON"
        )
        write_result(result)
        return 2
    release_root = destination.parent
    if destination.exists() or destination.is_symlink():
        result = blocked_build_result(
            "RELEASE_CANDIDATE_ALREADY_EXISTS_IMMUTABLE",
            release_directory=destination,
        )
        write_result(result)
        return 2
    staging: Path | None = None
    manifest_files = []
    try:
        release_root.mkdir(parents=True, exist_ok=True)
        destination = controlled_release_path(ROOT, "release_candidates", release_id)
        staging = Path(tempfile.mkdtemp(prefix=f".{release_id}-", dir=release_root))
        for required in (
            "bin", "models", "configs", "lib", "systemd", "migrations",
            "licenses", "sbom", "reports", "signatures"
        ):
            (staging / required).mkdir(parents=True, exist_ok=True)
        for item in validated_inputs:
            target = copy_verified_release_input(item, staging)
            manifest_files.append(
                {
                    "path": item.destination.as_posix(),
                    "size": target.stat().st_size,
                    "sha256": item.sha256,
                }
            )
        validate_product_runtime_bundle(staging)
        rollback = {
            "schema_version": "1.0.0",
            "previous_release_id": inputs["previous_release_id"],
            "database_rollback_compatible": inputs["database_rollback_compatible"],
        }
        rollback_path = staging / "rollback.json"
        rollback_path.write_text(json.dumps(rollback, indent=2) + "\n", encoding="utf-8")
        manifest_files.append(
            {
                "path": "rollback.json",
                "size": rollback_path.stat().st_size,
                "sha256": sha256(rollback_path),
            }
        )
        manifest = {
            "schema_version": "1.0.0",
            "release_id": release_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "files": sorted(manifest_files, key=lambda value: value["path"]),
        }
        (staging / "manifest.json").write_text(
            json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
        )
        os.replace(staging, destination)
    except (OSError, UnicodeError, ReleaseInputError) as exc:
        if staging is not None:
            shutil.rmtree(staging, ignore_errors=True)
        result = blocked_build_result(
            build_failure_code(exc), release_directory=destination
        )
        write_result(result)
        return 2
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "CANDIDATE_BUILT_AWAITING_EXTERNAL_SIGNATURE",
        "formal_release_created": False,
        "release_directory": str(destination),
        "blockers": [],
    }
    write_result(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
