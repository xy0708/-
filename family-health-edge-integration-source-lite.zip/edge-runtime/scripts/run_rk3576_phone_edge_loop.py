from __future__ import annotations

import json
import os
import signal
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PHONE_ROOT = ROOT.parent / "FamilyHealthPhone-main" / "FamilyHealthPhone-main"
REPORT = ROOT / "reports" / "rk3576_phone_edge_loop_latest.json"
TEST_TEMP = ROOT / "reports" / "test_tmp"
FLUTTER_ENVIRONMENT_ERRORS = (
    "Failed to canonicalize path",
    "fatal: cannot change to 'C:\\flutter': Permission denied",
    "flutter_not_found",
)


def run(name: str, command: list[str], cwd: Path, timeout: int = 300) -> dict:
    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    TEST_TEMP.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment.update({key: str(TEST_TEMP) for key in ("TMP", "TEMP", "TMPDIR")})
    try:
        process = subprocess.Popen(
            command,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags,
            start_new_session=os.name != "nt",
            env=environment,
        )
        stdout, stderr = process.communicate(timeout=timeout)
        return {
            "name": name,
            "command": command,
            "exit_code": process.returncode,
            "stdout_tail": stdout[-4000:],
            "stderr_tail": stderr[-4000:],
        }
    except subprocess.TimeoutExpired as error:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                capture_output=True,
                check=False,
            )
        else:
            os.killpg(os.getpgid(process.pid), signal.SIGTERM)
        stdout, stderr = process.communicate()
        return {
            "name": name,
            "command": command,
            "exit_code": 124,
            "stdout_tail": (stdout or error.stdout or "")[-4000:],
            "stderr_tail": (stderr or error.stderr or "")[-3500:]
            + f"\ntimeout_after_{timeout}_seconds",
        }


def classify_checks(checks: list[dict]) -> str:
    if all(check["exit_code"] == 0 for check in checks):
        return "PASS_ENGINEERING_PRODUCT_BLOCKED"
    flutter_errors = [check for check in checks if check["exit_code"] != 0]
    if flutter_errors and all(
        check["name"].startswith("phone_flutter_")
        and any(
            marker in check.get("stderr_tail", "")
            for marker in FLUTTER_ENVIRONMENT_ERRORS
        )
        for check in flutter_errors
    ):
        return "PARTIAL_ENGINEERING_ENV_BLOCKED"
    return "FAIL_ENGINEERING"


def main() -> int:
    flutter = shutil.which("flutter") or shutil.which("flutter.bat")
    checks = [
        run(
            "rk3576_phone_edge_contract",
            [sys.executable, str(ROOT / "scripts" / "verify_rk3576_phone_edge_integration.py")],
            ROOT,
        ),
        run(
            "android_migration_contract_tests",
            [
                sys.executable,
                "-m",
                "unittest",
                "discover",
                "-s",
                "tests",
                "-p",
                "test_android*.py",
                "-v",
            ],
            ROOT,
        ),
        run(
            "member_scoped_device_application_tests",
            [
                sys.executable, "-m", "unittest", "discover", "-s", "tests",
                "-p", "test_device_application.py", "-v",
            ],
            ROOT,
        ),
        run(
            "component_fault_isolation_tests",
            [
                sys.executable, "-m", "unittest", "discover", "-s", "tests",
                "-p", "test_fault_isolation.py", "-v",
            ],
            ROOT,
        ),
        run(
            "loopback_device_service_smoke",
            [sys.executable, str(ROOT / "scripts" / "smoke_device_service.py")],
            ROOT,
        ),
    ]
    if flutter:
        checks.extend(
            [
                run("phone_flutter_analyze", [flutter, "analyze"], PHONE_ROOT, 600),
                run("phone_flutter_test", [flutter, "test"], PHONE_ROOT, 600),
            ]
        )
    else:
        checks.append(
            {
                "name": "phone_flutter_toolchain",
                "command": ["flutter"],
                "exit_code": 127,
                "stdout_tail": "",
                "stderr_tail": "flutter_not_found",
            }
        )

    status = classify_checks(checks)
    payload = {
        "schema_version": "1.0.0",
        "run_id": datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"),
        "status": status,
        "product_complete": False,
        "formal_release_allowed": False,
        "hardware_acceptance_complete": False,
        "checks": checks,
        "external_blockers": [
            "real_watch_not_available",
            "rk3576_board_not_available",
            "vendor_binary_redistribution_not_approved",
            "real_vendor_watch_adapter_not_integrated",
            "rk3576_authenticated_https_listener_not_implemented",
            "rk3576_rknpu_and_rknn_runtime_not_frozen",
            "product_auth_and_pairing_not_implemented",
            "release_application_id_and_signing_not_frozen",
        ],
    }
    if status == "PARTIAL_ENGINEERING_ENV_BLOCKED":
        payload["environment_blockers"] = ["flutter_snapshot_access_denied_in_sandbox"]
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        previous = json.loads(REPORT.read_text(encoding="utf-8"))
        previous_id = previous.get("run_id")
        if previous_id:
            previous_archive = REPORT.with_name(f"rk3576_phone_edge_loop_{previous_id}.json")
            if not previous_archive.exists():
                shutil.copy2(REPORT, previous_archive)
    report_text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    REPORT.with_name(f"rk3576_phone_edge_loop_{payload['run_id']}.json").write_text(
        report_text, encoding="utf-8"
    )
    REPORT.write_text(report_text, encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=True, indent=2))
    return 0 if status == "PASS_ENGINEERING_PRODUCT_BLOCKED" else 3 if status == "PARTIAL_ENGINEERING_ENV_BLOCKED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
