from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Collection


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.asr_med_ch import (
    COMPARISON_STATUS,
    candidate_report_is_current,
    load_dataset,
    sha256,
    validate_candidate_report,
)
from benchmarks.comparison.asr_single_sample import (
    load_registry_hash,
    verify_cpu_model_manifest,
)
from research_assets import resolve_locked_artifact


ASR_ROOT = (
    ROOT.parent
    / "语音转文字"
    / "家庭健康语音转文字_Codex_Goal_Loop"
    / "health_asr_codex_loop"
)
DATASET_ROOT = ASR_ROOT / "data/eval/gigaspeechbench_med_ch"
MANIFEST = DATASET_ROOT / "subset_manifest.jsonl"
METADATA = DATASET_ROOT / "metadata.json"
SUBSET_REPORT = DATASET_ROOT / "subset_report.json"
MODEL_NAME = (
    "sherpa-onnx-x-asr-960ms-streaming-zipformer-transducer-"
    "zh-en-punct-int8-2026-06-05"
)
CPU_MODEL_DIR = ASR_ROOT / "models/sherpa" / MODEL_NAME
CPU_MANIFEST = ASR_ROOT / "models/sherpa/model_manifest.json"
ASR_PYTHON = ASR_ROOT / ".venv-sherpa/Scripts/python.exe"
HOST_WHEELS = sorted((ROOT / "artifacts/host_wheelhouse/sherpa-1.13.7").glob("*.whl"))
REGISTRY = ROOT / "model_registry/backend_registry.json"
CPU_EVALUATOR = ROOT / "conversion/asr/evaluate_xasr_med_ch.py"
RKNN_EVALUATOR = ROOT / "conversion/asr/evaluate_zipformer_med_ch.py"
SIMULATOR_SOURCE = ROOT / "conversion/asr/simulate_zipformer_audio.py"
ENCODER = resolve_locked_artifact(
    ROOT, "artifacts/official_models/source_onnx/zipformer_encoder_epoch_99_avg_1.onnx"
)
DECODER = resolve_locked_artifact(
    ROOT, "artifacts/official_models/source_onnx/zipformer_decoder_epoch_99_avg_1.onnx"
)
JOINER = resolve_locked_artifact(
    ROOT, "artifacts/official_models/source_onnx/zipformer_joiner_epoch_99_avg_1.onnx"
)
VOCAB = ROOT / "vendor/rockchip/rknn_model_zoo/examples/zipformer/model/vocab.txt"
IMAGE = "family-health-zipformer-simulator:1.25.4-dev20240223"
IMAGE_ID = "sha256:5d0416702a2964e458264757e02641ec03de6fa009d10d484cd988a8d810c6aa"
CPU_OUTPUT = ROOT / "reports/asr_med_ch_cpu_candidate.json"
RKNN_OUTPUT = ROOT / "reports/asr_med_ch_rknn_pc_candidate.json"
OUTPUT = ROOT / "reports/asr_med_ch_candidate_comparison.json"
WORK_ROOT = ROOT / ".artifact-work"
CHECKPOINT_ROOT = WORK_ROOT / "asr-med-ch-checkpoint"


def run_command(
    command: list[str],
    *,
    expected_codes: Collection[int] = (0,),
    environment: dict[str, str] | None = None,
    timeout_seconds: int = 1800,
) -> str:
    completed = subprocess.run(
        command,
        cwd=ROOT,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout_seconds,
        check=False,
    )
    output = completed.stdout.decode("utf-8", errors="replace")
    if completed.returncode not in expected_codes:
        raise RuntimeError(f"comparison command failed:{completed.returncode}")
    return output


def docker_executable() -> str:
    candidate = shutil.which("docker")
    if not candidate and os.name == "nt":
        fallback = Path("C:/Program Files/Docker/Docker/resources/bin/docker.exe")
        candidate = str(fallback) if fallback.is_file() else None
    if not candidate:
        raise RuntimeError("Docker CLI is unavailable")
    return candidate


def assert_simulator_image(docker: str) -> None:
    actual = run_command([docker, "image", "inspect", IMAGE, "--format", "{{.Id}}"])
    if actual.strip() != IMAGE_ID:
        raise RuntimeError("Zipformer simulator image identity mismatch")


def container_path(host_path: Path) -> str:
    workspace = ROOT.parent.resolve(strict=True)
    return "/workspace/" + host_path.resolve(strict=True).relative_to(workspace).as_posix()


def run_cpu(temp: Path) -> Path:
    runtime = temp / "cpu_runtime"
    candidate_output = temp / "cpu.json"
    if runtime.exists():
        shutil.rmtree(runtime)
    candidate_output.unlink(missing_ok=True)
    run_command(
        [
            str(ASR_PYTHON),
            "-m",
            "pip",
            "install",
            "--disable-pip-version-check",
            "--no-index",
            "--no-deps",
            "--target",
            str(runtime),
            *(str(wheel) for wheel in HOST_WHEELS),
        ],
        timeout_seconds=300,
    )
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(runtime)
    environment["PYTHONUTF8"] = "1"
    run_command(
        [
            str(ASR_PYTHON),
            str(CPU_EVALUATOR),
            "--project-root",
            str(ASR_ROOT),
            "--manifest",
            str(MANIFEST),
            "--metadata",
            str(METADATA),
            "--subset-report",
            str(SUBSET_REPORT),
            "--model-dir",
            str(CPU_MODEL_DIR),
            "--model-manifest",
            str(CPU_MANIFEST),
            "--output",
            str(candidate_output),
        ],
        expected_codes=(0, 2),
        environment=environment,
        timeout_seconds=600,
    )
    return candidate_output


def run_rknn_simulator(docker: str, temp: Path) -> Path:
    candidate_output = temp / "rknn.json"
    candidate_output.unlink(missing_ok=True)
    workspace = ROOT.parent.resolve(strict=True)
    container_name = f"family-health-asr-med-ch-{os.getpid()}"
    command = [
        docker,
        "run",
        "--rm",
        "--name",
        container_name,
        "--network",
        "none",
        "--read-only",
        "--cpus",
        "4",
        "--memory",
        "6g",
        "--tmpfs",
        "/tmp:rw,noexec,nosuid,size=3g",
        "--workdir",
        "/tmp",
        "--mount",
        f"type=bind,source={workspace},target=/workspace,readonly",
        "--mount",
        f"type=bind,source={temp.resolve()},target=/output",
        IMAGE,
        "python",
        container_path(RKNN_EVALUATOR),
        "--project-root",
        container_path(ASR_ROOT),
        "--manifest",
        container_path(MANIFEST),
        "--metadata",
        container_path(METADATA),
        "--subset-report",
        container_path(SUBSET_REPORT),
        "--encoder-onnx",
        container_path(ENCODER),
        "--decoder-onnx",
        container_path(DECODER),
        "--joiner-onnx",
        container_path(JOINER),
        "--vocab",
        container_path(VOCAB),
        "--output",
        "/output/rknn.json",
    ]
    try:
        run_command(command, expected_codes=(0, 2), timeout_seconds=7200)
    finally:
        remove_container(docker, container_name)
    return candidate_output


def remove_container(docker: str, container_name: str) -> None:
    try:
        subprocess.run(
            [docker, "rm", "--force", container_name],
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=30,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        # Cleanup must not hide the inference failure that triggered it.
        pass


def atomic_copy(source: Path, destination: Path) -> None:
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    shutil.copyfile(source, temporary)
    temporary.replace(destination)


def read_reusable_candidate(
    path: Path,
    *,
    candidate_id: str,
    expected_dataset: dict[str, object],
    expected_identity: dict[str, object],
) -> dict[str, object] | None:
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not candidate_report_is_current(
        report,
        candidate_id=candidate_id,
        expected_dataset=expected_dataset,
        expected_identity=expected_identity,
    ):
        return None
    return report


def build_comparison(cpu: dict, rknn: dict) -> dict[str, object]:
    cpu_errors = validate_candidate_report(cpu, "asr_sherpa_cpu_xasr")
    rknn_errors = validate_candidate_report(rknn, "asr_rknn_zipformer")
    if cpu_errors or rknn_errors:
        raise RuntimeError("candidate evidence invalid")
    if cpu["dataset"] != rknn["dataset"]:
        raise RuntimeError("candidate dataset fingerprints differ")
    cpu_metrics = cpu["metrics"]
    rknn_metrics = rknn["metrics"]
    observed_lower = None
    if cpu_metrics["cer"] < rknn_metrics["cer"]:
        observed_lower = "asr_sherpa_cpu_xasr"
    elif rknn_metrics["cer"] < cpu_metrics["cer"]:
        observed_lower = "asr_rknn_zipformer"
    return {
        "schema_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": COMPARISON_STATUS,
        "scope": "MED_CH_60_RESEARCH_ENGINEERING_ONLY",
        "dataset": cpu["dataset"],
        "same_audio_bytes": True,
        "same_reference_transcripts": True,
        "same_utterance_boundaries": True,
        "same_internal_feature_chunking": False,
        "same_metric_normalization": True,
        "failures_included_in_denominator": True,
        "candidate_reports": {
            "asr_sherpa_cpu_xasr": {
                "path": CPU_OUTPUT.relative_to(ROOT).as_posix(),
                "sha256": sha256(CPU_OUTPUT),
                "metrics": cpu_metrics,
            },
            "asr_rknn_zipformer": {
                "path": RKNN_OUTPUT.relative_to(ROOT).as_posix(),
                "sha256": sha256(RKNN_OUTPUT),
                "metrics": rknn_metrics,
            },
        },
        "observations": {
            "lower_cer_on_this_research_set": observed_lower,
            "observation_is_product_winner": False,
            "host_latency_comparison_valid": False,
        },
        "product_selection_allowed": False,
        "winner": None,
        "hardware_measured": False,
        "target_microphone_evidence": False,
        "commercial_rights_cleared": False,
        "thresholds_approved": False,
        "real_rk3566_profile_available": False,
        "conclusion": "NO_PRODUCT_WINNER",
        "blockers": [
            "MED-CH commercial rights are not cleared",
            "internal feature chunking differs between candidate-native pipelines",
            "RKNN was rebuilt from ONNX in an x86_64 PC simulator",
            "target-microphone independent data and real RK3566 evidence are absent",
            "metric thresholds, priority, and tie-breaker lack named approval",
        ],
    }


def main() -> int:
    if not ASR_PYTHON.is_file() or len(HOST_WHEELS) != 2:
        raise RuntimeError("locked CPU comparison environment is incomplete")
    cpu_bundle = verify_cpu_model_manifest(CPU_MODEL_DIR, CPU_MANIFEST)
    if cpu_bundle != load_registry_hash(REGISTRY, "asr_sherpa_cpu_xasr"):
        raise RuntimeError("CPU model bundle does not match registry")
    docker = docker_executable()
    assert_simulator_image(docker)
    WORK_ROOT.mkdir(parents=True, exist_ok=True)
    CHECKPOINT_ROOT.mkdir(parents=True, exist_ok=True)
    _, expected_dataset = load_dataset(
        project_root=ASR_ROOT,
        manifest_path=MANIFEST,
        metadata_path=METADATA,
        subset_report_path=SUBSET_REPORT,
    )
    CPU_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    cpu = read_reusable_candidate(
        CPU_OUTPUT,
        candidate_id="asr_sherpa_cpu_xasr",
        expected_dataset=expected_dataset,
        expected_identity={
            "execution": "WINDOWS_X86_64_CPU_REAL_INFERENCE",
            "runtime": {"name": "sherpa_onnx", "version": "1.13.7"},
            "model_bundle_sha256": cpu_bundle,
            "model_manifest_sha256": sha256(CPU_MANIFEST),
        },
    )
    if cpu is None:
        cpu_temp = run_cpu(CHECKPOINT_ROOT)
        atomic_copy(cpu_temp, CPU_OUTPUT)
        cpu = json.loads(CPU_OUTPUT.read_text(encoding="utf-8"))
        print("ASR_MED_CH_STAGE_COMPLETE:CPU", flush=True)
    else:
        print("ASR_MED_CH_STAGE_REUSED:CPU", flush=True)

    rknn_identity = {
        "execution": "X86_64_PC_SIMULATOR_FROM_FROZEN_ONNX",
        "runtime": {"name": "rknn_toolkit2_pc_simulator", "version": "2.3.2"},
        "exported_target_rknn_loaded": False,
        "source_model_sha256": {
            "encoder_onnx": sha256(ENCODER),
            "decoder_onnx": sha256(DECODER),
            "joiner_onnx": sha256(JOINER),
            "vocab": sha256(VOCAB),
        },
    }
    rknn = read_reusable_candidate(
        RKNN_OUTPUT,
        candidate_id="asr_rknn_zipformer",
        expected_dataset=expected_dataset,
        expected_identity=rknn_identity,
    )
    if rknn is None:
        rknn_temp = run_rknn_simulator(docker, CHECKPOINT_ROOT)
        atomic_copy(rknn_temp, RKNN_OUTPUT)
        rknn = json.loads(RKNN_OUTPUT.read_text(encoding="utf-8"))
        print("ASR_MED_CH_STAGE_COMPLETE:RKNN_PC_SIMULATOR", flush=True)
    else:
        print("ASR_MED_CH_STAGE_REUSED:RKNN_PC_SIMULATOR", flush=True)

    comparison = build_comparison(cpu, rknn)
    OUTPUT.write_text(
        json.dumps(comparison, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "status": comparison["status"],
                "dataset": comparison["dataset"],
                "candidate_reports": comparison["candidate_reports"],
                "observations": comparison["observations"],
                "conclusion": comparison["conclusion"],
            },
            ensure_ascii=True,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
