from __future__ import annotations

import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PHONE_ROOT = ROOT.parent / "FamilyHealthPhone-main" / "FamilyHealthPhone-main"
REPORT = ROOT / "reports" / "rk3576_phone_edge_verification.json"
ANDROID_NAMESPACE = "{http://schemas.android.com/apk/res/android}"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate() -> tuple[list[str], dict]:
    errors: list[str] = []
    edge_files = [
        ROOT / "RK3576_PHONE_WATCH_INTEGRATION_LOOP.md",
        ROOT / "configs" / "phone_edge_contract.json",
        ROOT / "configs" / "yucheng_android_sdk_source.json",
        ROOT / "configs" / "device_profile.json",
        ROOT / "configs" / "wearable_measurement_contract.json",
        ROOT / "configs" / "phone_debug_apk.json",
    ]
    phone_files = [
        PHONE_ROOT / "pubspec.yaml",
        PHONE_ROOT / "lib" / "core" / "watch" / "watch_gateway.dart",
        PHONE_ROOT / "lib" / "core" / "watch" / "simulated_watch_gateway.dart",
        PHONE_ROOT / "lib" / "core" / "watch" / "unavailable_watch_gateway.dart",
        PHONE_ROOT / "lib" / "providers" / "device_provider.dart",
        PHONE_ROOT / "lib" / "core" / "watch" / "wearable_measurement.dart",
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_client.dart",
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_asr_client.dart",
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_asr_microphone.dart",
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_asr_result.dart",
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_ocr_review.dart",
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_health_result.dart",
        PHONE_ROOT / "lib" / "providers" / "edge_connection_provider.dart",
        PHONE_ROOT / "lib" / "core" / "config" / "app_config.dart",
        PHONE_ROOT / "lib" / "providers" / "health_provider.dart",
        PHONE_ROOT / "lib" / "providers" / "auth_provider.dart",
        PHONE_ROOT / "lib" / "providers" / "alert_provider.dart",
        PHONE_ROOT / "lib" / "pages" / "assessment" / "ocr_preview_page.dart",
        PHONE_ROOT / "lib" / "pages" / "assessment" / "assessment_page.dart",
        PHONE_ROOT / "lib" / "pages" / "assessment" / "asr_capture_page.dart",
        PHONE_ROOT / "test" / "watch_gateway_test.dart",
        PHONE_ROOT / "test" / "wearable_measurement_test.dart",
        PHONE_ROOT / "test" / "edge_client_test.dart",
        PHONE_ROOT / "test" / "edge_asr_client_test.dart",
        PHONE_ROOT / "test" / "edge_asr_microphone_test.dart",
        PHONE_ROOT / "test" / "edge_asr_result_test.dart",
        PHONE_ROOT / "test" / "edge_connection_provider_test.dart",
        PHONE_ROOT / "test" / "edge_ocr_review_test.dart",
        PHONE_ROOT / "test" / "edge_health_result_test.dart",
        PHONE_ROOT / "android" / "app" / "src" / "main" / "AndroidManifest.xml",
        PHONE_ROOT / "android" / "app" / "build.gradle.kts",
    ]
    for path in [*edge_files, *phone_files]:
        if not path.is_file():
            errors.append(f"missing:{path}")
    if errors:
        return errors, {"phone_project": str(PHONE_ROOT)}

    contract = load_json(ROOT / "configs" / "phone_edge_contract.json")
    device = load_json(ROOT / "configs" / "device_profile.json")
    sdk = load_json(ROOT / "configs" / "yucheng_android_sdk_source.json")
    measurement_contract = load_json(
        ROOT / "configs" / "wearable_measurement_contract.json"
    )
    phone_apk = load_json(ROOT / "configs" / "phone_debug_apk.json")

    expected_target = {
        "soc": "RK3576",
        "abi": "arm64-v8a",
        "os_family": "Android",
        "android_release": "14",
    }
    actual_target = device.get("target", {})
    for name, expected in expected_target.items():
        if actual_target.get(name) != expected:
            errors.append(f"target_{name}_invalid")
    if device.get("hardware_measured") is not False:
        errors.append("hardware_evidence_must_remain_false_without_board")
    if device.get("device_connected") is not False:
        errors.append("device_connection_must_remain_false_without_board")
    if contract.get("phone", {}).get("watch_scan_owner") != "PHONE_LOCAL_WATCH_GATEWAY":
        errors.append("watch_scan_owner_invalid")
    if contract.get("phone", {}).get("backend_device_scan_allowed") is not False:
        errors.append("backend_watch_scan_must_be_disabled")
    if contract.get("phone", {}).get("watch_gateway_default") != "UNAVAILABLE_UNTIL_REAL_SDK_ADAPTER":
        errors.append("phone_watch_default_truth_invalid")
    if contract.get("phone", {}).get("simulated_adapter_explicit_only") is not True:
        errors.append("phone_simulation_must_be_explicit")
    if contract.get("phone", {}).get("real_sdk_adapter_implemented") is not False:
        errors.append("phone_real_sdk_adapter_false_claim")
    if contract.get("simulation", {}).get("counts_as_product_acceptance") is not False:
        errors.append("simulation_acceptance_boundary_invalid")
    runtime_implementation = contract.get("edge", {}).get("runtime_implementation", {})
    if runtime_implementation.get("legacy_python_device_service_binding") != "127.0.0.1":
        errors.append("legacy_device_service_binding_truth_invalid")
    if runtime_implementation.get("phone_lan_https_gateway_implemented") is not False:
        errors.append("unimplemented_lan_gateway_must_remain_false")
    if runtime_implementation.get("phone_https_client_implemented") is not True:
        errors.append("phone_https_client_not_recorded")
    if runtime_implementation.get("phone_health_client_implemented") is not True:
        errors.append("phone_health_client_not_recorded")
    if runtime_implementation.get("phone_ocr_task_client_implemented") is not True:
        errors.append("phone_ocr_task_client_not_recorded")
    if runtime_implementation.get("phone_asr_stream_client_implemented") is not True:
        errors.append("phone_asr_stream_client_not_recorded")
    if runtime_implementation.get("phone_connection_ui_implemented") is not True:
        errors.append("phone_connection_ui_not_recorded")
    if runtime_implementation.get("phone_ocr_ui_implemented") is not True:
        errors.append("phone_ocr_ui_not_recorded")
    if runtime_implementation.get("phone_health_ui_implemented") is not True:
        errors.append("phone_health_ui_not_recorded")
    if runtime_implementation.get("phone_health_manual_confirmed_input_implemented") is not True:
        errors.append("phone_health_manual_input_not_recorded")
    if runtime_implementation.get("phone_health_watch_automatic_input_implemented") is not False:
        errors.append("phone_health_watch_input_false_claim")
    if runtime_implementation.get("phone_asr_ui_implemented") is not True:
        errors.append("phone_asr_ui_not_recorded")
    if runtime_implementation.get("phone_asr_microphone_pcm16_stream_implemented") is not True:
        errors.append("phone_asr_microphone_not_recorded")
    if runtime_implementation.get("phone_asr_confirmation_ui_implemented") is not True:
        errors.append("phone_asr_confirmation_ui_not_recorded")
    if runtime_implementation.get("phone_client_wired_to_product_ui") is not True:
        errors.append("phone_product_ui_wiring_not_recorded")
    if runtime_implementation.get("production_mock_fallback_allowed") is not False:
        errors.append("production_mock_fallback_policy_invalid")
    if runtime_implementation.get("engineering_demo_data_requires_explicit_flag") is not True:
        errors.append("engineering_demo_flag_policy_invalid")
    if contract.get("api", {}).get("health_evaluation_member_scope_enforced") is not True:
        errors.append("health_member_scope_contract_missing")
    application_source = (ROOT / "device_service" / "application.py").read_text(
        encoding="utf-8"
    )
    health_route = application_source.split(
        'if method == "POST" and path == "/v1/health/evaluate":', 1
    )[-1].split('if method == "POST" and path == "/v1/ocr/tasks":', 1)[0]
    if "_request_member_id(payload, normalized_headers)" not in health_route or "_require_member_access(principal, member_id)" not in health_route:
        errors.append("health_member_scope_not_enforced")
    sdk_source = sdk.get("source", {})
    sdk_archive = ROOT / sdk_source.get("archive_path", "")
    sdk_aar = ROOT / sdk.get("sdk", {}).get("core_aar", "")
    if sdk_source.get("immutable_reference") is not True:
        errors.append("vendor_sdk_snapshot_not_hash_frozen")
    if not sdk_archive.is_file() or sha256(sdk_archive) != sdk_source.get("archive_sha256"):
        errors.append("vendor_sdk_archive_hash_invalid")
    if not sdk_aar.is_file() or sha256(sdk_aar) != sdk.get("sdk", {}).get("core_aar_sha256"):
        errors.append("vendor_sdk_core_aar_hash_invalid")
    if sdk.get("product_use_allowed") is not False:
        errors.append("unreviewed_vendor_sdk_must_not_be_product_enabled")
    if measurement_contract.get("hardware_verified") is not False:
        errors.append("wearable_fields_must_remain_hardware_unverified")
    if measurement_contract.get("product_ready") is not False:
        errors.append("wearable_fields_must_remain_product_blocked")
    heart_rate = measurement_contract.get("metrics", {}).get("heartRate", {})
    if heart_rate.get("vendor_value_key") != "heartValue":
        errors.append("wearable_heart_rate_mapping_invalid")
    if heart_rate.get("real_watch_confirmed") is not False:
        errors.append("heart_rate_mapping_must_not_claim_watch_confirmation")

    apk_path = (ROOT / phone_apk.get("artifact_path", "")).resolve()
    if phone_apk.get("status") != "ENGINEERING_DEBUG_NOT_PRODUCT":
        errors.append("phone_apk_status_invalid")
    if not apk_path.is_file():
        errors.append("phone_debug_apk_missing")
    else:
        if apk_path.stat().st_size != phone_apk.get("bytes"):
            errors.append("phone_debug_apk_size_mismatch")
        if sha256(apk_path) != phone_apk.get("sha256"):
            errors.append("phone_debug_apk_hash_mismatch")
        try:
            with zipfile.ZipFile(apk_path) as archive:
                packaged_abis = sorted(
                    {
                        name.split("/", 2)[1]
                        for name in archive.namelist()
                        if name.startswith("lib/") and name.count("/") >= 2
                    }
                )
        except zipfile.BadZipFile:
            errors.append("phone_debug_apk_invalid_zip")
            packaged_abis = []
        if packaged_abis != ["arm64-v8a"] or packaged_abis != phone_apk.get("abis"):
            errors.append("phone_debug_apk_abi_invalid")
    signature = phone_apk.get("signature", {})
    if signature.get("formal_company_signature") is not False:
        errors.append("phone_debug_apk_signature_false_claim")
    if phone_apk.get("installed_on_android") is not False:
        errors.append("phone_debug_apk_install_false_claim")
    if phone_apk.get("product_complete") is not False:
        errors.append("phone_debug_apk_product_false_claim")
    if phone_apk.get("demo_data_enabled") is not False:
        errors.append("phone_debug_apk_demo_data_must_be_disabled")
    if phone_apk.get("missing_service_behavior") != "FAIL_CLOSED":
        errors.append("phone_debug_apk_missing_service_policy_invalid")

    app_config = (
        PHONE_ROOT / "lib" / "core" / "config" / "app_config.dart"
    ).read_text(encoding="utf-8")
    if "'ALLOW_DEMO_DATA'" not in app_config or "defaultValue: false" not in app_config:
        errors.append("phone_demo_data_flag_must_default_false")
    for provider_name in ["health_provider.dart", "auth_provider.dart", "alert_provider.dart"]:
        provider_source = (
            PHONE_ROOT / "lib" / "providers" / provider_name
        ).read_text(encoding="utf-8")
        if "AppConfig.allowDemoData" not in provider_source:
            errors.append(f"phone_provider_demo_policy_missing:{provider_name}")
    auth_source = (PHONE_ROOT / "lib" / "providers" / "auth_provider.dart").read_text(
        encoding="utf-8"
    )
    if "_token?.startsWith('mock_token_')" not in auth_source:
        errors.append("phone_stale_mock_token_cleanup_missing")

    provider = (PHONE_ROOT / "lib" / "providers" / "device_provider.dart").read_text(
        encoding="utf-8"
    )
    for forbidden in ["ApiEndpoints.scanDevices", "ApiClient()", "_mockDevices", "?? SimulatedWatchGateway()"]:
        if forbidden in provider:
            errors.append(f"phone_device_provider_forbidden_marker:{forbidden}")
    for required in ["WatchGateway", "setConnection", "_watchGateway.scan", "?? const UnavailableWatchGateway()"]:
        if required not in provider:
            errors.append(f"phone_device_provider_marker_missing:{required}")
    edge_client = (PHONE_ROOT / "lib" / "core" / "edge" / "edge_client.dart").read_text(
        encoding="utf-8"
    )
    for required in [
        "createOcrTask",
        "getTask",
        "cancelTask",
        "confirmTask",
        "maxOcrImageBytes = 8 * 1024 * 1024",
        "sha256.convert(imageBytes)",
        "'/v1/ocr/tasks'",
        "'/v1/records/confirm'",
    ]:
        if required not in edge_client:
            errors.append(f"phone_edge_client_marker_missing:{required}")
    edge_asr_client = (
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_asr_client.dart"
    ).read_text(encoding="utf-8")
    for required in [
        "IOWebSocketChannel.connect",
        "v1/asr/stream",
        "'sample_rate_hz': 16000",
        "'channels': 1",
        "'sample_format': 's16le'",
        "final_pending_confirmation",
        "raw_audio_persisted",
        "maxTotalBytes = 16000 * 1 * 2 * 120",
    ]:
        if required not in edge_asr_client:
            errors.append(f"phone_edge_asr_client_marker_missing:{required}")
    asr_microphone = (
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_asr_microphone.dart"
    ).read_text(encoding="utf-8")
    for required in [
        "AudioEncoder.pcm16bits",
        "sampleRate: 16000",
        "numChannels: 1",
        "waitUntilStreaming",
        "stopAndWait",
    ]:
        if required not in asr_microphone:
            errors.append(f"phone_asr_microphone_marker_missing:{required}")
    asr_result = (
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_asr_result.dart"
    ).read_text(encoding="utf-8")
    for required in [
        "final_pending_confirmation",
        "raw_audio_persisted",
        "RegExp(r'^[0-9a-f]{32}$')",
    ]:
        if required not in asr_result:
            errors.append(f"phone_asr_result_marker_missing:{required}")
    asr_page = (
        PHONE_ROOT / "lib" / "pages" / "assessment" / "asr_capture_page.dart"
    ).read_text(encoding="utf-8")
    for required in [
        "EdgeAsrPendingResult.fromEvent",
        "确认文字并保存",
        "cancelTask",
        "confirmedFields: {'transcript': text}",
    ]:
        if required not in asr_page:
            errors.append(f"phone_asr_ui_marker_missing:{required}")
    ocr_page = (
        PHONE_ROOT / "lib" / "pages" / "assessment" / "ocr_preview_page.dart"
    ).read_text(encoding="utf-8")
    for forbidden in [
        "_mockOcrResult",
        "ApiEndpoints.aiOcrUpload",
        "ApiClient().uploadFile",
        "回退本地演示数据",
    ]:
        if forbidden in ocr_page:
            errors.append(f"phone_ocr_ui_forbidden_marker:{forbidden}")
    for required in [
        "EdgeConnectionProvider",
        "createOcrTask",
        "getTask",
        "confirmTask",
        "cancelTask",
        "待人工确认",
        "置信度不是医学准确率",
    ]:
        if required not in ocr_page:
            errors.append(f"phone_ocr_ui_marker_missing:{required}")
    health_page = (
        PHONE_ROOT / "lib" / "pages" / "assessment" / "assessment_page.dart"
    ).read_text(encoding="utf-8")
    for required in [
        "端侧健康提示（非诊断）",
        "evaluateConfirmedMeasurement",
        "EdgeHealthResult.fromResponse",
        "user_confirmed_manual",
        "尚未获产品发布批准",
    ]:
        if required not in health_page:
            errors.append(f"phone_health_ui_marker_missing:{required}")
    health_result = (
        PHONE_ROOT / "lib" / "core" / "edge" / "edge_health_result.dart"
    ).read_text(encoding="utf-8")
    for required in [
        "NON_DIAGNOSTIC_HEALTH_MANAGEMENT",
        "diagnostic output is forbidden",
        "disease_probability",
        "product_release_allowed",
    ]:
        if required not in health_result:
            errors.append(f"phone_health_result_marker_missing:{required}")
    profile_page = (PHONE_ROOT / "lib" / "pages" / "profile" / "profile_page.dart").read_text(
        encoding="utf-8"
    )
    if "devices.lastError" not in profile_page:
        errors.append("phone_watch_error_not_visible")
    android_build = (PHONE_ROOT / "android" / "app" / "build.gradle.kts").read_text(
        encoding="utf-8"
    )
    if 'signingConfigs.getByName("debug")' in android_build:
        errors.append("phone_release_debug_signing_fallback_forbidden")
    if "Release signing is incomplete" not in android_build:
        errors.append("phone_release_signing_fail_closed_missing")

    manifest_path = (
        PHONE_ROOT / "android" / "app" / "src" / "main" / "AndroidManifest.xml"
    )
    manifest = ET.parse(manifest_path).getroot()
    permissions = {
        node.attrib.get(f"{ANDROID_NAMESPACE}name")
        for node in manifest.findall("uses-permission")
    }
    expected_ble = {
        "android.permission.BLUETOOTH",
        "android.permission.BLUETOOTH_ADMIN",
        "android.permission.BLUETOOTH_SCAN",
        "android.permission.BLUETOOTH_CONNECT",
    }
    if not expected_ble.issubset(permissions):
        errors.append("phone_ble_permissions_incomplete")
    if "android.permission.INTERNET" not in permissions:
        errors.append("phone_lan_permission_missing")
    if "android.permission.RECORD_AUDIO" not in permissions:
        errors.append("phone_microphone_permission_missing")
    application = manifest.find("application")
    if application is None:
        errors.append("phone_android_application_missing")
    else:
        if application.attrib.get(f"{ANDROID_NAMESPACE}allowBackup") != "false":
            errors.append("phone_android_backup_must_be_disabled")
        if application.attrib.get(f"{ANDROID_NAMESPACE}usesCleartextTraffic") != "false":
            errors.append("phone_cleartext_traffic_must_be_disabled")

    facts = {
        "phone_project": str(PHONE_ROOT),
        "target": {name: actual_target.get(name) for name in expected_target},
        "watch_gateway": "PHONE_LOCAL_FAIL_CLOSED_WITH_EXPLICIT_SIMULATED_ADAPTER",
        "health_evaluation_member_scope_enforced": contract.get("api", {}).get(
            "health_evaluation_member_scope_enforced"
        ),
        "vendor_sdk_repository": sdk.get("source", {}).get("repository"),
        "vendor_sdk_frozen": sdk_source.get("immutable_reference"),
        "vendor_sdk_archive_sha256": sdk_source.get("archive_sha256"),
        "vendor_sdk_core_aar_version": sdk.get("sdk", {}).get("core_aar_version"),
        "vendor_sdk_core_aar_sha256": sdk.get("sdk", {}).get("core_aar_sha256"),
        "vendor_sdk_product_use_allowed": sdk.get("product_use_allowed"),
        "hardware_measured": device.get("hardware_measured"),
        "phone_lan_https_gateway_implemented": runtime_implementation.get(
            "phone_lan_https_gateway_implemented"
        ),
        "phone_health_client_implemented": runtime_implementation.get(
            "phone_health_client_implemented"
        ),
        "phone_ocr_task_client_implemented": runtime_implementation.get(
            "phone_ocr_task_client_implemented"
        ),
        "phone_asr_stream_client_implemented": runtime_implementation.get(
            "phone_asr_stream_client_implemented"
        ),
        "phone_client_wired_to_product_ui": runtime_implementation.get(
            "phone_client_wired_to_product_ui"
        ),
        "phone_connection_ui_implemented": runtime_implementation.get(
            "phone_connection_ui_implemented"
        ),
        "phone_ocr_ui_implemented": runtime_implementation.get(
            "phone_ocr_ui_implemented"
        ),
        "phone_health_ui_implemented": runtime_implementation.get(
            "phone_health_ui_implemented"
        ),
        "phone_asr_ui_implemented": runtime_implementation.get(
            "phone_asr_ui_implemented"
        ),
        "phone_debug_apk_sha256": phone_apk.get("sha256"),
        "phone_debug_apk_bytes": phone_apk.get("bytes"),
        "phone_debug_apk_abis": phone_apk.get("abis"),
        "phone_debug_apk_installed_on_android": phone_apk.get(
            "installed_on_android"
        ),
        "wearable_measurement_contract_status": measurement_contract.get("status"),
        "manifest_ble_permissions": sorted(permission for permission in permissions if permission),
    }
    return errors, facts


def main() -> int:
    errors, facts = validate()
    payload = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING_PRODUCT_BLOCKED" if not errors else "FAIL_ENGINEERING",
        "product_complete": False,
        "formal_release_allowed": False,
        "hardware_acceptance_complete": False,
        "errors": errors,
        "facts": facts,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(payload, ensure_ascii=True, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
