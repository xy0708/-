from __future__ import annotations

import json
import platform
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "sbom" / "engineering.cdx.json"


def main() -> int:
    components = [
        {
            "type": "application",
            "name": "family-health-edge-product",
            "version": "0.1.0",
            "properties": [{"name": "release.status", "value": "engineering-only"}],
        },
        {
            "type": "framework",
            "name": "CPython",
            "version": platform.python_version(),
            "properties": [{"name": "target-device-version", "value": "pending-rk3566-preflight"}],
        },
    ]
    report_specs = [
        ("reports/asr_arm64_verification.json", "source_model_integrity", "ASR source asset"),
        ("reports/ocr_rknn_verification.json", "pretrained_asset_integrity", "OCR pretrained asset"),
    ]
    for relative, field, kind in report_specs:
        report = json.loads((ROOT / relative).read_text(encoding="utf-8"))
        for asset in report.get(field, []):
            if not asset.get("passed"):
                continue
            components.append(
                {
                    "type": "file",
                    "name": Path(asset["path"]).name,
                    "hashes": [{"alg": "SHA-256", "content": asset["actual_sha256"]}],
                    "properties": [
                        {"name": "asset.kind", "value": kind},
                        {"name": "commercial-distribution", "value": "pending-legal-opinion"},
                        {"name": "included-in-formal-release", "value": "false"},
                    ],
                }
            )
    sbom = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.6",
        "serialNumber": "urn:uuid:engineering-sbom-not-a-release",
        "version": 1,
        "metadata": {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "properties": [
                {"name": "scope", "value": "engineering inventory; not a formal release SBOM"}
            ],
        },
        "components": components,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(sbom, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS_ENGINEERING", "output": str(OUTPUT), "components": len(components)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
