from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.run_arm64_simulation_loop import decode_output


def capture(command):
    try:
        result = subprocess.run(command, capture_output=True, timeout=30)
        return {'exit_code': result.returncode,
                'stdout': decode_output(result.stdout), 'stderr': decode_output(result.stderr)}
    except (OSError, subprocess.TimeoutExpired):
        return {'exit_code': -1, 'stdout': '', 'stderr': 'HOST_PROBE_UNAVAILABLE'}


def main():
    query = """
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
$computer = Get-CimInstance Win32_ComputerSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
[ordered]@{
 memory_bytes=$computer.TotalPhysicalMemory
 hypervisor_present=$computer.HypervisorPresent
 cpu=$cpu.Name
 firmware_virtualization=$cpu.VirtualizationFirmwareEnabled
 reboot_pending=(Test-Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Component Based Servicing\\RebootPending')
 docker_desktop_installed=(Test-Path 'C:\\Program Files\\Docker\\Docker\\Docker Desktop.exe')
} | ConvertTo-Json -Compress
"""
    report = dict(checked_at=datetime.now(timezone.utc).isoformat(),
                  hardware_measured=False, product_complete=False,
                  wsl_version=capture(['wsl.exe', '--version']),
                  wsl_status=capture(['wsl.exe', '--status']),
                  windows=capture(['powershell.exe', '-NoProfile', '-Command', query]))
    (ROOT / 'reports/simulation_host.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=True))


if __name__ == '__main__':
    main()
