from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from runtime_backends import BackendRegistryError, load_registry, select_backend


WORKER = ROOT / "ocr_runtime" / "rknn_worker.py"
WORKER_MANIFEST = ROOT / "model_registry" / "ocr_rknn_ppocrv4_worker_manifest.json"
BACKEND_REGISTRY = ROOT / "model_registry" / "backend_registry.json"
CANDIDATES = ROOT / "model_registry" / "official_candidate_artifacts.json"
SOURCE_LOCK = ROOT / "vendor" / "rockchip" / "model_zoo.lock.json"
REPORT = ROOT / "reports" / "ocr_rknn_worker_verification.json"


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _load_json(path: Path, error: str, errors: list[str]) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        errors.append(error)
        return {}
    if not isinstance(payload, dict):
        errors.append(error)
        return {}
    return payload


def _find_record(records: object, key: str, value: str) -> dict[str, Any]:
    if not isinstance(records, list):
        return {}
    for record in records:
        if isinstance(record, dict) and record.get(key) == value:
            return record
    return {}


def verify_worker() -> dict[str, Any]:
    errors: list[str] = []
    manifest = _load_json(
        WORKER_MANIFEST, "OCR_RKNN_WORKER_MANIFEST_INVALID", errors
    )
    files = manifest.get("files", {}) if manifest else {}
    model_records = [files.get("detector"), files.get("recognizer")]
    if (
        manifest.get("status") != "ENGINEERING_WORKER_ARCHIVED_PRODUCT_BLOCKED"
        or manifest.get("active_runtime_manifest") is not False
        or manifest.get("asset_location") != "OFFICIAL_RESEARCH_ARCHIVE_SIBLING"
        or manifest.get("product_accepted") is not False
        or manifest.get("hardware_validated") is not False
        or manifest.get("license_approved") is not False
        or any(
            not isinstance(record, dict)
            or not str(record.get("path", "")).startswith(
                "artifacts/official_models/"
            )
            for record in model_records
        )
    ):
        errors.append("OCR_RKNN_ARCHIVED_WORKER_MANIFEST_INVALID")
    active_model_root = ROOT / "artifacts" / "official_models"
    if active_model_root.exists():
        errors.append("OCR_RKNN_MODEL_ASSETS_STILL_ACTIVE")

    try:
        registry = load_registry(BACKEND_REGISTRY)
    except BackendRegistryError as exc:
        registry = None
        errors.append(f"BACKEND_REGISTRY_INVALID:{exc.code}")
    backend = registry.backends.get("ocr_rknn_ppocrv4") if registry else None
    if (
        backend is None
        or backend.status != "BLOCKED_ENGINEERING"
        or backend.implementation_module is not None
        or backend.model_bundle_sha256
        != "990970c4c8e34bdc9890bb56c10d1561b7a80dddddb83e69f674ad2f7aca3c7f"
        or "official_research_assets_archived_outside_product_tree"
        not in backend.unavailable_reasons
    ):
        errors.append("OCR_RKNN_BACKEND_REGISTRATION_INVALID")
    if registry is not None:
        try:
            select_backend(
                registry,
                component="ocr",
                backend_id="ocr_rknn_ppocrv4",
                product_mode=False,
            )
        except BackendRegistryError as exc:
            if exc.code != "BACKEND_NOT_ENGINEERING_READY":
                errors.append(f"OCR_RKNN_SELECTION_FAILURE_INVALID:{exc.code}")
        else:
            errors.append("OCR_RKNN_UNVERIFIED_BACKEND_SELECTABLE")

    candidates = _load_json(CANDIDATES, "CANDIDATE_MANIFEST_INVALID", errors)
    candidate = _find_record(candidates.get("candidates"), "candidate_id", "OCR-O2")
    gates = candidate.get("gates", {}) if candidate else {}
    if (
        gates.get("engineering_worker_implemented") is not True
        or gates.get("engineering_assets_archived_outside_product_tree") is not True
        or gates.get("product_worker_registered") is not False
        or gates.get("authorized_selection_validation_complete") is not False
        or gates.get("license_approved") is not False
        or gates.get("real_rk3566_verified") is not False
        or gates.get("product_ready") is not False
    ):
        errors.append("OCR_RKNN_WORKER_PRODUCT_BOUNDARY_INVALID")

    source_lock = _load_json(SOURCE_LOCK, "SOURCE_LOCK_INVALID", errors)
    source = _find_record(source_lock.get("repositories"), "id", "airockchip_rknn_model_zoo")
    if manifest.get("source_commit") != source.get("commit"):
        errors.append("OCR_RKNN_WORKER_SOURCE_COMMIT_MISMATCH")

    if not WORKER.is_file() or WORKER.is_symlink():
        errors.append("OCR_RKNN_WORKER_MODULE_MISSING")
    return {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": (
            "PASS_ENGINEERING_WORKER_ARCHIVED_PRODUCT_BLOCKED"
            if not errors
            else "FAIL"
        ),
        "backend_id": "ocr_rknn_ppocrv4",
        "implementation_module": None,
        "worker_sha256": sha256(WORKER) if WORKER.is_file() else None,
        "worker_manifest_sha256": (
            sha256(WORKER_MANIFEST) if WORKER_MANIFEST.is_file() else None
        ),
        "model_bundle_sha256": manifest.get("model_bundle_sha256"),
        "engineering_worker_implemented": not errors,
        "assets_archived_outside_product_tree": not active_model_root.exists(),
        "backend_selectable": False,
        "product_worker_registered": False,
        "hardware_measured": False,
        "real_rk3566_verified": False,
        "license_approved": False,
        "authorized_product_data_verified": False,
        "product_ready": False,
        "errors": errors,
    }


def main() -> int:
    result = verify_worker()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"].startswith("PASS_") else 2


if __name__ == "__main__":
    raise SystemExit(main())
