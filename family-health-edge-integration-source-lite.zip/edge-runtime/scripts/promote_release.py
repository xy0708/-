from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from release_tools import (
    ReleaseInputError,
    approved_public_key,
    controlled_release_path,
    verify_product_release_bundle,
)
from scripts.verify_release import evaluate


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release-id", required=True)
    parser.add_argument("--public-key", type=Path, required=True)
    args = parser.parse_args()
    try:
        candidate = controlled_release_path(
            ROOT, "release_candidates", args.release_id, require_collection=True
        )
        destination = controlled_release_path(ROOT, "release", args.release_id)
        public_key = approved_public_key(ROOT, args.public_key)
    except (OSError, ReleaseInputError) as exc:
        error = str(exc) if isinstance(exc, ReleaseInputError) else "SIGNING_POLICY_IO_ERROR"
        print(json.dumps({"status": "BLOCKED_FAIL_CLOSED", "error": error}))
        return 2
    preflight = evaluate(require_formal_release=False)
    if preflight["blockers"]:
        print(json.dumps({"status": "BLOCKED_FAIL_CLOSED", "blockers": preflight["blockers"]}))
        return 2
    verification = verify_product_release_bundle(candidate, public_key)
    if not verification.passed:
        print(json.dumps(verification.as_dict(), indent=2))
        return 2
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        destination = controlled_release_path(ROOT, "release", args.release_id)
    except ReleaseInputError as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}))
        return 2
    if destination.exists() or destination.is_symlink():
        print(json.dumps({"status": "FAIL", "error": "IMMUTABLE_RELEASE_EXISTS"}))
        return 2
    os.replace(candidate, destination)
    report = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PROMOTED_SIGNED_RELEASE",
        "release_id": args.release_id,
        "bundle": str(destination),
        "signature_verified": True,
    }
    output = ROOT / "reports" / "release_promotion.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
