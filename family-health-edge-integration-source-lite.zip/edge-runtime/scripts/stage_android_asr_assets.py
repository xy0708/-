from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
CONFIG = ROOT / "configs" / "android_asr_candidate.json"
REPORT = ROOT / "reports" / "android_asr_asset_staging.json"
ASR_ROOT = (
    WORKSPACE
    / "语音转文字"
    / "家庭健康语音转文字_Codex_Goal_Loop"
    / "health_asr_codex_loop"
)
MODEL_SOURCE = (
    ASR_ROOT
    / "models"
    / "sherpa"
    / "sherpa-onnx-x-asr-960ms-streaming-zipformer-transducer-zh-en-punct-int8-2026-06-05"
)
MODEL_DESTINATION = ROOT / "android_app" / "assets" / "asr" / "x_asr_streaming"
LICENSE_DESTINATION = ROOT / "android_app" / "assets" / "licenses"
CONFIG_DESTINATION = ROOT / "android_app" / "assets" / "asr_candidate.json"
LICENSE_SOURCES = {
    "SHERPA-ONNX-LICENSE": ASR_ROOT / "third_party" / "SHERPA-ONNX-LICENSE",
    "X-ASR-LICENSE": ASR_ROOT / "third_party" / "X-ASR-LICENSE",
    "ASR-THIRD-PARTY-NOTICES.md": ASR_ROOT / "THIRD_PARTY_NOTICES.md",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def copy_verified(source: Path, destination: Path, expected_size: int, expected_hash: str) -> dict:
    if not source.is_file():
        raise FileNotFoundError(f"source_missing:{source}")
    if source.stat().st_size != expected_size:
        raise ValueError(f"source_size_mismatch:{source.name}")
    if sha256(source) != expected_hash:
        raise ValueError(f"source_hash_mismatch:{source.name}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file() and destination.stat().st_size == expected_size:
        if sha256(destination) == expected_hash:
            return {"path": destination.relative_to(ROOT).as_posix(), "reused": True}
    handle, temporary_name = tempfile.mkstemp(prefix=f".{destination.name}.", dir=destination.parent)
    os.close(handle)
    temporary = Path(temporary_name)
    try:
        shutil.copyfile(source, temporary)
        if temporary.stat().st_size != expected_size or sha256(temporary) != expected_hash:
            raise ValueError(f"staged_hash_mismatch:{destination.name}")
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    return {"path": destination.relative_to(ROOT).as_posix(), "reused": False}


def main() -> int:
    config = json.loads(CONFIG.read_text(encoding="utf-8"))
    staged: dict[str, dict] = {}
    errors: list[str] = []
    try:
        for name, expected in config["model"]["files"].items():
            result = copy_verified(
                MODEL_SOURCE / name,
                MODEL_DESTINATION / name,
                expected["bytes"],
                expected["sha256"],
            )
            result.update({"bytes": expected["bytes"], "sha256": expected["sha256"]})
            staged[name] = result
        for destination_name, source in LICENSE_SOURCES.items():
            copy_verified(
                source,
                LICENSE_DESTINATION / destination_name,
                source.stat().st_size,
                sha256(source),
            )
        copy_verified(CONFIG, CONFIG_DESTINATION, CONFIG.stat().st_size, sha256(CONFIG))
    except (FileNotFoundError, OSError, ValueError, KeyError, TypeError) as exc:
        errors.append(str(exc))

    payload = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING_ASSETS_STAGED" if not errors else "FAIL_ENGINEERING",
        "product_release": False,
        "android_runtime_executed": False,
        "source_model_directory": str(MODEL_SOURCE),
        "source_manifest_sha256": sha256(ASR_ROOT / "models" / "sherpa" / "model_manifest.json"),
        "staged_files": staged,
        "errors": errors,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
