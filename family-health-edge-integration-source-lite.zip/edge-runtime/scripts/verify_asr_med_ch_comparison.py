from __future__ import annotations

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.asr_med_ch import (
    COMPARISON_STATUS,
    sha256,
    validate_candidate_report,
)


CPU = ROOT / "reports/asr_med_ch_cpu_candidate.json"
RKNN = ROOT / "reports/asr_med_ch_rknn_pc_candidate.json"
COMPARISON = ROOT / "reports/asr_med_ch_candidate_comparison.json"
OUTPUT = ROOT / "reports/asr_med_ch_candidate_comparison_verification.json"


def verify() -> dict[str, object]:
    errors: list[str] = []
    try:
        cpu = json.loads(CPU.read_text(encoding="utf-8"))
        rknn = json.loads(RKNN.read_text(encoding="utf-8"))
        comparison = json.loads(COMPARISON.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return {"status": "FAIL", "errors": ["ASR_MED_CH_REPORT_UNREADABLE"]}
    errors.extend(validate_candidate_report(cpu, "asr_sherpa_cpu_xasr"))
    errors.extend(validate_candidate_report(rknn, "asr_rknn_zipformer"))
    reports = comparison.get("candidate_reports", {})
    if (
        comparison.get("schema_version") != "1.0.0"
        or comparison.get("status") != COMPARISON_STATUS
        or comparison.get("scope") != "MED_CH_60_RESEARCH_ENGINEERING_ONLY"
        or comparison.get("dataset") != cpu.get("dataset")
        or comparison.get("dataset") != rknn.get("dataset")
        or comparison.get("same_audio_bytes") is not True
        or comparison.get("same_reference_transcripts") is not True
        or comparison.get("same_utterance_boundaries") is not True
        or comparison.get("same_internal_feature_chunking") is not False
        or comparison.get("same_metric_normalization") is not True
        or comparison.get("failures_included_in_denominator") is not True
    ):
        errors.append("COMPARISON_CONTRACT_INVALID")
    expected_reports = {
        "asr_sherpa_cpu_xasr": (CPU, cpu.get("metrics")),
        "asr_rknn_zipformer": (RKNN, rknn.get("metrics")),
    }
    if not isinstance(reports, dict) or set(reports) != set(expected_reports):
        errors.append("COMPARISON_REPORT_SET_INVALID")
    else:
        for candidate_id, (path, metrics) in expected_reports.items():
            record = reports.get(candidate_id, {})
            if (
                not isinstance(record, dict)
                or record.get("sha256") != sha256(path)
                or record.get("metrics") != metrics
            ):
                errors.append(f"COMPARISON_REPORT_HASH_INVALID:{candidate_id}")
    for field in (
        "product_selection_allowed",
        "hardware_measured",
        "target_microphone_evidence",
        "commercial_rights_cleared",
        "thresholds_approved",
        "real_rk3566_profile_available",
    ):
        if comparison.get(field) is not False:
            errors.append(f"UNSAFE_TRUE_FLAG:{field}")
    observations = comparison.get("observations", {})
    if (
        comparison.get("winner") is not None
        or comparison.get("conclusion") != "NO_PRODUCT_WINNER"
        or not isinstance(observations, dict)
        or observations.get("observation_is_product_winner") is not False
        or observations.get("host_latency_comparison_valid") is not False
    ):
        errors.append("PRODUCT_WINNER_OVERSTATED")
    return {
        "status": "PASS_ENGINEERING_PUBLIC_SET_PRODUCT_BLOCKED"
        if not errors
        else "FAIL",
        "phase": "R04_R06_ENGINEERING_COMPARISON_PARTIAL",
        "sample_count": cpu.get("metrics", {}).get("samples"),
        "cpu_cer": cpu.get("metrics", {}).get("cer"),
        "rknn_pc_simulator_cer": rknn.get("metrics", {}).get("cer"),
        "product_selection_allowed": False,
        "hardware_measured": False,
        "errors": errors,
    }


def main() -> int:
    result = verify()
    OUTPUT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not result["errors"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
