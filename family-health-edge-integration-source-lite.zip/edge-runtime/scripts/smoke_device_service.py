from __future__ import annotations

import json
import base64
import sys
import tempfile
import threading
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from device_service.application import DeviceApplication, TokenAuthorizer
from device_service.server import BoundedThreadingHTTPServer, DeviceRequestHandler
from storage import PlaintextEngineeringCodec, RecordStore


REPORT = ROOT / "reports" / "device_service_smoke.json"
TOKEN = "engineering-smoke-token-not-for-product-123456"
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + (1).to_bytes(4, "big") + (1).to_bytes(4, "big")


def request(
    url: str,
    method: str = "GET",
    body: dict | None = None,
    auth: bool = False,
    member_id: str | None = None,
):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers = {"Content-Type": "application/json"}
    if auth:
        headers["Authorization"] = f"Bearer {TOKEN}"
    if member_id is not None:
        headers["X-Edge-Member-Id"] = member_id
    call = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(call, timeout=5) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def main() -> int:
    failures: list[str] = []
    with tempfile.TemporaryDirectory() as temporary:
        store = RecordStore(
            Path(temporary) / "smoke.db",
            PlaintextEngineeringCodec(),
            allow_unencrypted_engineering=True,
        )
        app = DeviceApplication(
            store, TokenAuthorizer({TOKEN: {"smoke-member"}})
        )
        server = BoundedThreadingHTTPServer(("127.0.0.1", 0), DeviceRequestHandler)
        server.application = app  # type: ignore[attr-defined]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_address[1]}"
        try:
            status, health = request(f"{base}/v1/health")
            if status != 200 or health["result"]["network_scope"] != "loopback_only":
                failures.append("loopback_health_failed")
            status, unauthorized = request(f"{base}/v1/version")
            if status != 401 or unauthorized["error"]["code"] != "AUTH_REQUIRED":
                failures.append("auth_gate_failed")
            health_input = {
                "confirmed": True,
                "measurements": [
                    {
                        "metric": "heart_rate",
                        "value": 72,
                        "unit": "bpm",
                        "measured_at": datetime.now(timezone.utc).isoformat(),
                        "confirmed": True,
                    }
                ],
            }
            status, evaluated = request(
                f"{base}/v1/health/evaluate", "POST", health_input,
                auth=True, member_id="smoke-member",
            )
            if status != 200:
                failures.append("health_evaluate_http_failed")
            else:
                result = evaluated["result"]
                if result["diagnosis"] is not None or result["disease_probability"] is not None:
                    failures.append("medical_claim_leaked")
                if result["measurements"][0]["metric"] != "heart_rate":
                    failures.append("phone_heart_rate_wire_contract_failed")
            missing_status, missing = request(
                f"{base}/v1/health/evaluate", "POST", health_input,
                auth=True,
            )
            if missing_status != 422 or missing["error"]["code"] != "INPUT_INVALID":
                failures.append("health_member_header_not_required")
            foreign_status, foreign = request(
                f"{base}/v1/health/evaluate", "POST", health_input,
                auth=True, member_id="other-member",
            )
            if foreign_status != 403 or foreign["error"]["code"] != "AUTH_INVALID":
                failures.append("health_cross_member_not_rejected")
            status, ocr = request(
                f"{base}/v1/ocr/tasks",
                "POST",
                {
                    "member_id": "smoke-member",
                    "image": {
                        "media_type": "image/png",
                        "data_base64": base64.b64encode(PNG).decode("ascii"),
                    },
                },
                auth=True,
            )
            if status != 503 or ocr["error"]["code"] != "COMPONENT_NOT_READY":
                failures.append("unavailable_ocr_did_not_fail_closed")
        finally:
            server.shutdown()
            server.server_close()
            store.close()
            thread.join(timeout=5)

    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not failures else "FAIL",
        "network_scope": "loopback_only",
        "engineering_plaintext_storage": True,
        "product_storage_ready": False,
        "ocr_product_adapter_ready": False,
        "asr_product_adapter_ready": False,
        "failures": failures,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
