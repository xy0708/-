from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from research_assets import archived_model_root, official_research_root


CONFIG = ROOT / "configs" / "official_research_archive.json"
CANDIDATES = ROOT / "model_registry" / "official_candidate_artifacts.json"
MODEL_LOCK = ROOT / "vendor" / "rockchip" / "model_zoo.lock.json"
BACKEND_REGISTRY = ROOT / "model_registry" / "backend_registry.json"
REPORT = ROOT / "reports" / "official_research_archive_verification.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path, error: str, errors: list[str]) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        errors.append(error)
        return {}
    if not isinstance(payload, dict):
        errors.append(error)
        return {}
    return payload


def locked_official_records(
    candidates: dict[str, Any], model_lock: dict[str, Any], errors: list[str]
) -> dict[str, tuple[int, str]]:
    expected: dict[str, tuple[int, str]] = {}
    sources: list[object] = list(model_lock.get("model_artifacts", []))
    for candidate in candidates.get("candidates", []):
        if isinstance(candidate, dict):
            sources.extend(candidate.get("artifacts", []))
    for record in sources:
        if not isinstance(record, dict):
            continue
        path = record.get("path")
        size = record.get("bytes")
        digest = record.get("sha256")
        if not isinstance(path, str) or not path.startswith("artifacts/official_models/"):
            continue
        if not isinstance(size, int) or not isinstance(digest, str):
            errors.append(f"LOCKED_RECORD_INVALID:{path}")
            continue
        previous = expected.get(path)
        identity = (size, digest)
        if previous is not None and previous != identity:
            errors.append(f"LOCKED_RECORD_CONFLICT:{path}")
        expected[path] = identity
    if not expected:
        errors.append("LOCKED_OFFICIAL_RECORDS_EMPTY")
    return expected


def verify_archive() -> dict[str, Any]:
    errors: list[str] = []
    config = load_json(CONFIG, "ARCHIVE_CONFIG_INVALID", errors)
    candidates = load_json(CANDIDATES, "CANDIDATE_MANIFEST_INVALID", errors)
    model_lock = load_json(MODEL_LOCK, "MODEL_LOCK_INVALID", errors)
    registry = load_json(BACKEND_REGISTRY, "BACKEND_REGISTRY_INVALID", errors)

    active_root = ROOT / "artifacts" / "official_models"
    if active_root.exists():
        errors.append("OFFICIAL_MODELS_STILL_IN_ACTIVE_PRODUCT_TREE")
    archive_root = official_research_root(ROOT)
    model_root = archived_model_root(ROOT)
    manifest = archive_root / str(config.get("archive_manifest", ""))
    if archive_root.name != config.get("archive_sibling"):
        errors.append("ARCHIVE_SIBLING_CONFIG_MISMATCH")
    if not model_root.is_dir() or model_root.is_symlink():
        errors.append("ARCHIVED_MODEL_ROOT_INVALID")

    archive = load_json(manifest, "ARCHIVE_MANIFEST_INVALID", errors)
    expected_manifest_hash = config.get("archive_manifest_sha256")
    if (
        not manifest.is_file()
        or manifest.is_symlink()
        or not isinstance(expected_manifest_hash, str)
        or len(expected_manifest_hash) != 64
        or sha256(manifest) != expected_manifest_hash
    ):
        errors.append("ARCHIVE_MANIFEST_HASH_MISMATCH")
    if (
        config.get("status")
        != "OFFICIAL_MODELS_ARCHIVED_RESEARCH_ONLY_PRODUCT_BLOCKED"
        or archive.get("status")
        != "OFFICIAL_MODELS_ARCHIVED_RESEARCH_ONLY_PRODUCT_BLOCKED"
        or config.get("product_selected") is not False
        or config.get("formal_release_allowed") is not False
        or archive.get("product_selected") is not False
        or archive.get("formal_release_allowed") is not False
        or archive.get("hardware_measured") is not False
    ):
        errors.append("ARCHIVE_PRODUCT_BOUNDARY_INVALID")

    archived_records: dict[str, tuple[int, str]] = {}
    records = archive.get("records")
    if not isinstance(records, list):
        errors.append("ARCHIVE_RECORDS_INVALID")
        records = []
    resolved_archive = archive_root.resolve() if archive_root.exists() else archive_root
    for record in records:
        if not isinstance(record, dict):
            errors.append("ARCHIVE_RECORD_INVALID")
            continue
        relative = record.get("path")
        size = record.get("bytes")
        digest = record.get("sha256")
        if (
            not isinstance(relative, str)
            or not relative.startswith("artifacts/official_models/")
            or not isinstance(size, int)
            or not isinstance(digest, str)
        ):
            errors.append(f"ARCHIVE_RECORD_INVALID:{relative}")
            continue
        try:
            path = (archive_root / Path(*relative.split("/"))).resolve(strict=True)
            path.relative_to(resolved_archive)
        except (OSError, ValueError):
            errors.append(f"ARCHIVE_PATH_INVALID:{relative}")
            continue
        if path.is_symlink() or not path.is_file():
            errors.append(f"ARCHIVE_FILE_INVALID:{relative}")
            continue
        if path.stat().st_size != size or sha256(path) != digest:
            errors.append(f"ARCHIVE_FILE_MISMATCH:{relative}")
            continue
        archived_records[relative] = (size, digest)

    if archive.get("file_count") != len(archived_records):
        errors.append("ARCHIVE_FILE_COUNT_INVALID")
    if archive.get("total_bytes") != sum(size for size, _ in archived_records.values()):
        errors.append("ARCHIVE_TOTAL_BYTES_INVALID")
    expected = locked_official_records(candidates, model_lock, errors)
    for relative, identity in expected.items():
        if archived_records.get(relative) != identity:
            errors.append(f"LOCKED_MODEL_NOT_ARCHIVED:{relative}")

    active_candidates = {
        item.get("candidate_id"): item
        for item in candidates.get("candidates", [])
        if isinstance(item, dict)
    }
    for candidate_id in ("OCR-O2", "ASR-A2"):
        candidate = active_candidates.get(candidate_id, {})
        if (
            not str(candidate.get("status", "")).startswith("DEFERRED_AFTER_")
            or candidate.get("gates", {}).get(
                "engineering_assets_archived_outside_product_tree"
            )
            is not True
            or candidate.get("gates", {}).get("product_ready") is not False
        ):
            errors.append(f"ARCHIVED_CANDIDATE_BOUNDARY_INVALID:{candidate_id}")

    official_backends = {
        item.get("backend_id"): item
        for item in registry.get("backends", [])
        if isinstance(item, dict)
    }
    for backend_id in ("ocr_rknn_ppocrv4", "asr_rknn_zipformer"):
        backend = official_backends.get(backend_id, {})
        if (
            backend.get("status") != "BLOCKED_ENGINEERING"
            or "official_research_assets_archived_outside_product_tree"
            not in backend.get("unavailable_reasons", [])
            or backend.get("product_accepted") is not False
        ):
            errors.append(f"ARCHIVED_BACKEND_BOUNDARY_INVALID:{backend_id}")

    return {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING_ARCHIVED_PRODUCT_BLOCKED" if not errors else "FAIL",
        "archive_directory": archive_root.name,
        "active_product_tree_model_root_absent": not active_root.exists(),
        "archived_file_count": len(archived_records),
        "archived_total_bytes": sum(size for size, _ in archived_records.values()),
        "locked_model_record_count": len(expected),
        "product_selected": False,
        "formal_release_allowed": False,
        "hardware_measured": False,
        "errors": errors,
    }


def main() -> int:
    result = verify_archive()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS_ENGINEERING_ARCHIVED_PRODUCT_BLOCKED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
