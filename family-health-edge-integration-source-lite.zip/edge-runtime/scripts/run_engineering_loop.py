from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def loop_audit_is_expected(path: Path) -> bool:
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False
    clean = report.get("contradictions") == [] and report.get("engineering_failures") == []
    blocked = (
        report.get("status") == "BLOCKED_EXTERNAL"
        and report.get("goal_complete") is False
        and report.get("product_release_allowed") is False
    )
    passed = (
        report.get("status") == "PASS_PRODUCT_GATE"
        and report.get("goal_complete") is True
        and report.get("product_release_allowed") is True
    )
    return clean and (blocked or passed)


def all_loops_audit_is_expected(path: Path) -> bool:
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False
    clean = report.get("contradictions") == [] and report.get("engineering_failures") == []
    blocked = (
        report.get("status") == "BLOCKED_EXTERNAL"
        and report.get("all_engineering_work_reachable_without_external_inputs_complete") is True
        and report.get("all_product_loops_complete") is False
        and report.get("unfinished_without_external_inputs") == []
        and bool(report.get("unfinished_requiring_external_inputs"))
    )
    passed = (
        report.get("status") == "PASS_PRODUCT_GATE"
        and report.get("all_product_loops_complete") is True
    )
    return clean and (blocked or passed)


def acceptance_metrics_result_is_consistent(path: Path, exit_code: int) -> bool:
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False
    if not isinstance(report, dict):
        return False
    status = report.get("status")
    failures = report.get("failures")
    if exit_code == 0:
        return (
            status == "PASS_COMPUTED_REAL_EVIDENCE"
            and failures == []
            and isinstance(report.get("metrics"), dict)
        )
    if exit_code == 2:
        return (
            status == "FAIL_OR_BLOCKED"
            and isinstance(failures, list)
            and bool(failures)
            and report.get("metrics") is None
        )
    return False


def gate_report_is_consistent(path: Path, exit_code: int, kind: str) -> bool:
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False
    if not isinstance(report, dict) or not isinstance(report.get("blockers"), list):
        return False
    blockers = report["blockers"]
    if kind == "device":
        passed = (
            report.get("status") == "PASS_PRODUCT_GATE"
            and report.get("hardware_measured") is True
            and report.get("acceptance_executed") is True
            and blockers == []
        )
        blocked = report.get("status") == "BLOCKED_EXTERNAL" and bool(blockers)
    elif kind == "release":
        passed = (
            report.get("status") == "PASS_PRODUCT_GATE"
            and report.get("release_allowed") is True
            and report.get("formal_release_verified") is True
            and blockers == []
        )
        blocked = (
            report.get("status") == "BLOCKED_EXTERNAL"
            and report.get("release_allowed") is False
            and bool(blockers)
        )
    elif kind == "build":
        passed = report.get("status") in {
            "CANDIDATE_BUILT_AWAITING_EXTERNAL_SIGNATURE",
            "FORMAL_RELEASE_ALREADY_VERIFIED",
        } and blockers == []
        blocked = report.get("status") == "BLOCKED_FAIL_CLOSED" and bool(blockers)
    else:
        return False
    return (exit_code == 0 and passed) or (exit_code == 2 and blocked)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def snapshot_outputs(
    root: Path, log_dir: Path, output_paths: list[str]
) -> tuple[dict[str, str], dict[str, dict[str, str]], list[str]]:
    """Copy mutable verifier outputs into the immutable per-run evidence folder."""

    root = root.resolve()
    outputs: dict[str, str] = {}
    evidence: dict[str, dict[str, str]] = {}
    errors: list[str] = []
    for relative in output_paths:
        relative_path = Path(relative)
        if relative_path.is_absolute() or ".." in relative_path.parts:
            errors.append(f"unsafe_output_path:{relative}")
            continue
        source = root / relative_path
        if not source.is_file():
            errors.append(f"missing_output:{relative}")
            continue
        if source.is_symlink() or not source.resolve().is_relative_to(root):
            errors.append(f"unsafe_output_source:{relative}")
            continue
        source_hash = sha256(source)
        snapshot = log_dir / "outputs" / relative_path
        try:
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, snapshot)
        except OSError:
            errors.append(f"output_snapshot_copy_failed:{relative}")
            continue
        snapshot_hash = sha256(snapshot)
        outputs[relative] = source_hash
        evidence[relative] = {
            "source_sha256": source_hash,
            "snapshot": snapshot.relative_to(root).as_posix(),
            "snapshot_sha256": snapshot_hash,
        }
        if snapshot_hash != source_hash:
            errors.append(f"output_snapshot_hash_mismatch:{relative}")
    return outputs, evidence, errors


def main() -> int:
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    log_dir = ROOT / "reports" / "loop_runs" / run_id
    log_dir.mkdir(parents=True, exist_ok=False)
    python = sys.executable
    checks = [
        ("workspace", [python, "scripts/verify_workspace.py"], {0}),
        ("product_scope", [python, "scripts/verify_product_scope.py"], {0}),
        ("product_delivery_plan", [python, "scripts/verify_product_delivery_plan.py"], {0}),
        ("component_contracts", [python, "scripts/verify_component_contracts.py"], {0}),
        ("official_model_lock", [python, "scripts/verify_official_model_lock.py"], {0}),
        ("rknn_toolchain_lock", [python, "scripts/verify_rknn_toolchain_lock.py"], {0}),
        (
            "asr_med_ch_comparison",
            [python, "scripts/verify_asr_med_ch_comparison.py"],
            {0},
        ),
        (
            "official_candidate_artifacts",
            [python, "scripts/verify_official_candidate_artifacts.py"],
            {0},
        ),
        (
            "official_research_archive",
            [python, "scripts/verify_official_research_archive.py"],
            {0},
        ),
        (
            "rknn_conversion_reproducibility",
            [python, "scripts/verify_rknn_conversion_reproducibility.py"],
            {0},
        ),
        (
            "rknn_conversion_determinism_probe",
            [python, "scripts/verify_rknn_conversion_determinism_probe.py"],
            {0},
        ),
        (
            "rknn_exported_artifact_capability_probe",
            [python, "scripts/verify_rknn_exported_artifact_capability_probe.py"],
            {0},
        ),
        (
            "candidate_comparison_contract",
            [python, "scripts/verify_candidate_comparison_contract.py"],
            {0},
        ),
        (
            "ocr_single_sample_comparison",
            [python, "scripts/verify_ocr_single_sample_comparison.py"],
            {0},
        ),
        (
            "ocr_synthetic_candidate_comparison",
            [python, "scripts/verify_ocr_synthetic_candidate_comparison.py"],
            {0},
        ),
        (
            "asr_single_sample_comparison",
            [python, "scripts/verify_asr_single_sample_comparison.py"],
            {0},
        ),
        ("runtime_backend_registry", [python, "scripts/verify_runtime_backend_registry.py"], {0}),
        ("ocr_rknn_worker", [python, "scripts/verify_ocr_rknn_worker.py"], {0}),
        ("arm64_runtime_tool", [python, "scripts/verify_arm64_runtime_tool.py"], {0}),
        ("simulation_evidence", [python, "scripts/verify_simulation_evidence.py"], {0}),
        ("model_simulation_evidence", [python, "scripts/verify_model_simulation_evidence.py"], {0}),
        ("integration_simulation_evidence", [python, "scripts/verify_arm64_integration_evidence.py"], {0}),
        ("health_rules", [python, "scripts/verify_health_rules.py"], {0}),
        ("health_ml_candidate", [python, "scripts/verify_health_ml_candidate.py"], {0}),
        ("asr_assets", [python, "scripts/verify_asr_arm64.py"], {0}),
        ("ocr_assets", [python, "scripts/verify_ocr_rknn.py"], {0}),
        (
            "acceptance_intake_readiness",
            [python, "scripts/verify_acceptance_intake_readiness.py"],
            {0},
        ),
        ("engineering_sbom", [python, "scripts/generate_engineering_sbom.py"], {0}),
        ("dependency_security", [python, "scripts/verify_dependency_security.py"], {0}),
        ("data_policy", [python, "scripts/verify_data_policy.py"], {0}),
        (
            "public_dataset_candidates",
            [python, "scripts/verify_public_dataset_candidates.py"],
            {0},
        ),
        ("deployment_scripts", [python, "scripts/verify_deployment_scripts.py"], {0}),
        ("http_smoke", [python, "scripts/smoke_device_service.py"], {0}),
        ("unit_tests", [python, "-m", "unittest", "discover", "-s", "tests", "-v"], {0}),
        ("upstream_regressions", [python, "scripts/verify_upstream_regressions.py"], {0}),
        (
            "acceptance_metrics_computation",
            [
                python,
                "scripts/compute_acceptance_metrics.py",
                "--evidence",
                "configs/acceptance_evidence.json",
            ],
            {0, 2},
        ),
        ("device_acceptance", [python, "scripts/run_device_acceptance.py"], {0, 2}),
        ("privacy", [python, "scripts/verify_privacy.py"], {0}),
        ("release_verification", [python, "scripts/verify_release.py"], {0, 2}),
        ("release_build", [python, "scripts/build_release.py"], {0, 2}),
        ("loop_requirements_audit", [python, "scripts/audit_loop_requirements.py"], {0, 2}),
        ("all_loops_audit", [python, "scripts/audit_all_loops.py"], {0, 2}),
    ]
    input_paths = [
        "EDGE_PRODUCTION_LOOP.md",
        "OCR_ASR_BACKEND_SELECTION_LOOP.md",
        "RK3566_OFFICIAL_MODELS_PRODUCTION_LOOP.md",
        "PRODUCT_EDGE_DEPLOYMENT_PLAN.md",
        "vendor/rockchip/model_zoo.lock.json",
        "vendor/rockchip/toolkit_runtime_matrix.json",
        "artifacts/rknn_converter_dependencies/manifest.json",
        "conversion/toolchain/Dockerfile.offline-ubuntu20.04-cp38-rknn2.3.2",
        "conversion/toolchain/pip-requirements.lock.txt",
        "reports/rknn_offline_dependency_lock.json",
        "model_registry/official_candidate_artifacts.json",
        "configs/official_research_archive.json",
        "reports/rknn_conversion_reproducibility.json",
        "reports/rknn_conversion_determinism_probe.json",
        "reports/rknn_exported_artifact_capability_probe.json",
        "conversion/toolchain/probe_exported_rknn_load.py",
        "model_registry/backend_registry.json",
        "model_registry/ocr_rknn_ppocrv4_worker_manifest.json",
        "configs/candidate_comparison_contract.json",
        "reports/ocr_cpu_rknn_single_sample_comparison.json",
        "reports/rknn_simulation_ppocrv4_synthetic_batch.json",
        "reports/ocr_synthetic_candidate_comparison.json",
        "reports/asr_cpu_rknn_single_sample_comparison.json",
        "reports/asr_med_ch_cpu_candidate.json",
        "reports/asr_med_ch_rknn_pc_candidate.json",
        "reports/asr_med_ch_candidate_comparison.json",
        "configs/runtime_backend_selection.json",
        "vendor/rockchip/THIRD_PARTY_NOTICES.md",
        "configs/product_scope.yaml",
        "configs/device_profile.json",
        "configs/acceptance_contract.json",
        "configs/acceptance_evidence.example.json",
        "configs/acceptance_evidence.json",
        "configs/ocr_acceptance_manifest.template.json",
        "configs/asr_acceptance_manifest.template.json",
        "configs/product_gate_evidence.json",
        "configs/release_inputs.json",
        "configs/data_policy.json",
        "configs/public_dataset_candidates.json",
        "docs/compliance/public_dataset_audit_2026-09-23.md",
        "configs/health_ml_candidate.json",
        "configs/product_delivery_contract.json",
        "configs/arm64_runtime_tool_build.json",
        "reports/arm64_runtime_tool_build_latest.json",
        "configs/component_contracts.json",
        "configs/api_contract.json",
        "configs/openapi.yaml",
        "configs/error_codes.json",
        "device_service/application.py",
        "device_service/server.py",
        "device_service/runtime_bootstrap.py",
        "storage/database.py",
        "asr_runtime/session.py",
        "integration_adapter/contracts.py",
        "integration_adapter/supervisor.py",
        "scripts/verify_upstream_regressions.py",
        "ARM64_SIMULATION_LOOP.md",
        "simulation/Dockerfile",
        "simulation/guest_probe.py",
        "scripts/run_arm64_simulation_loop.py",
        "scripts/verify_simulation_evidence.py",
        "configs/arm64_model_simulation.json",
        "simulation/ModelDockerfile",
        "simulation/model_probe.py",
        "simulation/health_reference.py",
        "scripts/build_arm64_wheelhouse_manifest.py",
        "scripts/run_arm64_model_simulation.py",
        "scripts/verify_model_simulation_evidence.py",
        "configs/arm64_integration_simulation.json",
        "simulation/IntegrationDockerfile",
        "simulation/integration_probe.py",
        "asr_runtime/field_extraction.py",
        "asr_runtime/worker.py",
        "scripts/run_arm64_integration_simulation.py",
        "scripts/verify_arm64_integration_evidence.py",
        "tests/test_runtime_bootstrap.py",
        "scripts/audit_loop_requirements.py",
        "scripts/run_engineering_loop.py",
        "scripts/verify_loop_run_evidence.py",
        "docs/operations/acceptance_evidence_format.md",
        ".gitignore",
    ]
    # Bind the complete executable/test surface of the engineering loop, not only
    # selected entry points. Otherwise a verifier could pass while an update,
    # installer, adapter, or test file had drifted after the recorded run.
    source_sets = (
        ("acceptance", {".py"}),
        ("asr_runtime", {".py"}),
        ("benchmarks", {".py"}),
        ("device_service", {".py"}),
        ("health_rules", {".py"}),
        ("integration_adapter", {".py"}),
        ("ocr_runtime", {".py"}),
        ("operations", {".py"}),
        ("release_tools", {".py"}),
        ("storage", {".py"}),
        ("update_agent", {".py"}),
        ("scripts", {".py", ".sh"}),
        ("simulation", {".py"}),
        ("tests", {".py"}),
        ("systemd", {".service"}),
    )
    for directory, suffixes in source_sets:
        for path in (ROOT / directory).rglob("*"):
            if path.is_file() and not path.is_symlink() and path.suffix in suffixes:
                input_paths.append(path.relative_to(ROOT).as_posix())
    try:
        runtime_contract = json.loads(
            (ROOT / "configs/arm64_runtime_tool_build.json").read_text(encoding="utf-8")
        )
        runtime_latest = json.loads(
            (ROOT / "reports/arm64_runtime_tool_build_latest.json").read_text(encoding="utf-8")
        )
    except (OSError, UnicodeError, json.JSONDecodeError):
        runtime_contract = {}
        runtime_latest = {}
    wheelhouse = ROOT / str(runtime_contract.get("wheelhouse", ""))
    if wheelhouse.is_dir() and wheelhouse.resolve().is_relative_to(ROOT.resolve()):
        for path in wheelhouse.glob("*.whl"):
            if path.is_file() and not path.is_symlink():
                input_paths.append(path.relative_to(ROOT).as_posix())
    runtime_artifact_directory = ROOT / str(runtime_latest.get("artifact_directory", ""))
    runtime_artifact_root = (ROOT / "artifacts/arm64_runtime_tools").resolve()
    if (
        runtime_artifact_directory.is_dir()
        and not runtime_artifact_directory.is_symlink()
        and runtime_artifact_directory.resolve().is_relative_to(runtime_artifact_root)
    ):
        for path in runtime_artifact_directory.rglob("*"):
            if path.is_file() and not path.is_symlink():
                input_paths.append(path.relative_to(ROOT).as_posix())
    input_paths = sorted(set(input_paths))
    inputs = {relative: sha256(ROOT / relative) for relative in input_paths}
    records = []
    unexpected = []
    for name, command, expected_codes in checks:
        started = datetime.now(timezone.utc)
        timeout_seconds = 1200 if name == "upstream_regressions" else 120
        try:
            completed = subprocess.run(
                command,
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=timeout_seconds,
                check=False,
            )
            output = completed.stdout.decode("utf-8", errors="replace")
            exit_code = completed.returncode
            error = None
        except subprocess.TimeoutExpired as exc:
            raw = exc.stdout or b""
            output = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else str(raw)
            exit_code = -1
            error = f"TIMEOUT_{timeout_seconds}_SECONDS"
        log_path = log_dir / f"{name}.log"
        log_path.write_text(output, encoding="utf-8")
        expected = exit_code in expected_codes
        if not expected:
            unexpected.append(name)
        records.append(
            {
                "gate_check": name,
                "command": command,
                "pid": os.getpid(),
                "started_at": started.isoformat(),
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "exit_code": exit_code,
                "expected_exit_codes": sorted(expected_codes),
                "result_as_expected": expected,
                "log": str(log_path.relative_to(ROOT)),
                "log_sha256": sha256(log_path),
                "error": error,
            }
        )
        if name == "acceptance_metrics_computation" and not acceptance_metrics_result_is_consistent(
            ROOT / "reports" / "computed_acceptance_metrics.json", exit_code
        ):
            unexpected.append("acceptance_metrics_computation:invalid_report_state")
        terminal_reports = {
            "device_acceptance": ("reports/device_acceptance.json", "device"),
            "release_verification": ("reports/final_release_verification.json", "release"),
            "release_build": ("reports/release_build.json", "build"),
        }
        if name in terminal_reports:
            report_path, kind = terminal_reports[name]
            if not gate_report_is_consistent(ROOT / report_path, exit_code, kind):
                unexpected.append(f"{name}:invalid_report_state")
    if not loop_audit_is_expected(ROOT / "reports/loop_requirements_audit.json"):
        unexpected.append("loop_requirements_audit:invalid_report_state")
    if not all_loops_audit_is_expected(ROOT / "reports/all_loops_audit.json"):
        unexpected.append("all_loops_audit:invalid_report_state")
    output_paths = [
        "reports/workspace_verification.json",
        "reports/product_scope_verification.json",
        "reports/product_delivery_plan_verification.json",
        "reports/component_contract_verification.json",
        "reports/official_model_lock_verification.json",
        "reports/rknn_toolchain_lock_verification.json",
        "reports/official_candidate_artifacts_verification.json",
        "reports/official_research_archive_verification.json",
        "reports/rknn_conversion_reproducibility_verification.json",
        "reports/rknn_conversion_determinism_probe_verification.json",
        "reports/rknn_exported_artifact_capability_probe.json",
        "reports/rknn_exported_artifact_capability_verification.json",
        "reports/candidate_comparison_contract_verification.json",
        "reports/ocr_cpu_rknn_single_sample_comparison.json",
        "reports/ocr_cpu_rknn_single_sample_comparison_verification.json",
        "reports/rknn_simulation_ppocrv4_synthetic_batch.json",
        "reports/ocr_synthetic_candidate_comparison.json",
        "reports/ocr_synthetic_candidate_comparison_verification.json",
        "reports/asr_cpu_rknn_single_sample_comparison.json",
        "reports/asr_cpu_rknn_single_sample_comparison_verification.json",
        "reports/asr_med_ch_cpu_candidate.json",
        "reports/asr_med_ch_rknn_pc_candidate.json",
        "reports/asr_med_ch_candidate_comparison.json",
        "reports/asr_med_ch_candidate_comparison_verification.json",
        "reports/runtime_backend_registry_verification.json",
        "reports/ocr_rknn_worker_verification.json",
        "reports/arm64_runtime_tool_verification.json",
        "reports/simulation_evidence_verification.json",
        "reports/arm64_simulation_latest.json",
        "reports/arm64_model_simulation_latest.json",
        "reports/arm64_model_simulation_verification.json",
        "reports/arm64_integration_simulation_latest.json",
        "reports/arm64_integration_simulation_verification.json",
        "reports/health_rules_verification.json",
        "reports/health_ml_candidate_verification.json",
        "reports/asr_arm64_verification.json",
        "reports/ocr_rknn_verification.json",
        "reports/privacy_verification.json",
        "reports/acceptance_intake_readiness.json",
        "reports/computed_acceptance_metrics.json",
        "reports/dependency_security.json",
        "reports/data_policy_verification.json",
        "reports/public_dataset_candidates_verification.json",
        "reports/deployment_script_verification.json",
        "reports/device_service_smoke.json",
        "reports/upstream_regression_verification.json",
        "reports/device_acceptance.json",
        "reports/final_release_verification.json",
        "reports/release_build.json",
        "reports/loop_requirements_audit.json",
        "reports/all_loops_audit.json",
        "sbom/engineering.cdx.json",
    ]
    outputs, output_evidence, snapshot_errors = snapshot_outputs(
        ROOT, log_dir, output_paths
    )
    unexpected.extend(f"output_snapshot:{error}" for error in snapshot_errors)
    try:
        audit_report = json.loads(
            (ROOT / "reports" / "loop_requirements_audit.json").read_text(
                encoding="utf-8"
            )
        )
    except (OSError, UnicodeError, json.JSONDecodeError):
        audit_report = {}
    product_complete = audit_report.get("status") == "PASS_PRODUCT_GATE"
    result = {
        "schema_version": "1.0.0",
        "run_id": run_id,
        "status": (
            "PASS_PRODUCT_GATE"
            if not unexpected and product_complete
            else "PASS_ENGINEERING_PRODUCT_BLOCKED"
            if not unexpected
            else "FAIL_ENGINEERING"
        ),
        "formal_release_created": product_complete,
        "input_sha256": inputs,
        "output_sha256": outputs,
        "output_evidence": output_evidence,
        "snapshot_integrity_verified": not snapshot_errors,
        "checks": records,
        "unexpected_checks": unexpected,
        "resume_command": f'"{python}" scripts/run_engineering_loop.py',
        "next_step": "Provide the external evidence listed in BLOCKERS.md, then rerun",
    }
    report = log_dir / "audit.json"
    report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    latest = ROOT / "reports" / "loop_run_latest.json"
    latest.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not unexpected else 2


if __name__ == "__main__":
    raise SystemExit(main())
