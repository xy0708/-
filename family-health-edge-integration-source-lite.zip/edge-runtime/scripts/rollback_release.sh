#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "usage: rollback_release.sh RELEASE_ID" >&2
  exit 2
fi
if [ "$(id -u)" -ne 0 ]; then
  echo "rollback requires root" >&2
  exit 2
fi

release_id="$1"
if [[ ! "$release_id" =~ ^[A-Za-z0-9]([A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$ ]]; then
  echo "invalid release id" >&2
  exit 2
fi
install_root="${EDGE_INSTALL_ROOT:-/opt/family-health-edge}"
state_root="${EDGE_STATE_ROOT:-/var/lib/family-health-edge}"
update_state_root="${EDGE_UPDATE_STATE_ROOT:-/var/lib/family-health-edge-update}"
public_key="${EDGE_RELEASE_PUBLIC_KEY:-/etc/family-health-edge/release-public.pem}"
runtime_tool="${EDGE_RUNTIME_TOOL:-$install_root/tools/family-health-edge-tool}"
runtime_tmp="${EDGE_RUNTIME_TMPDIR:-/run/family-health-edge-maintenance}"
marker="$update_state_root/pending-activation.json"
target="$install_root/releases/$release_id"
install -d -m 0700 -o root -g root "$update_state_root"
install -d -m 0700 -o root -g root "$runtime_tmp"
export TMPDIR="$runtime_tmp"
exec 9>"$update_state_root/release-install.lock"
flock -n 9 || { echo "another install or rollback is active" >&2; exit 2; }
[ -x "$runtime_tool" ] || { echo "required self-contained runtime tool is missing or not executable: $runtime_tool" >&2; exit 2; }
if [ -e "$marker" ] || [ -L "$marker" ]; then
  echo "pending activation must be recovered before rollback" >&2
  exit 2
fi
if [ ! -L "$install_root/current" ]; then
  echo "current release link is missing" >&2
  exit 2
fi
"$runtime_tool" verify-current-release --current "$install_root/current" --install-root "$install_root" --public-key "$public_key"
"$runtime_tool" check-rollback-transition --current "$install_root/current" --target "$release_id"
"$runtime_tool" verify-release-bundle --bundle "$target" --public-key "$public_key"

current="$(readlink "$install_root/current")"
if [[ ! "$current" =~ ^releases/[A-Za-z0-9]([A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$ ]]; then
  echo "current release link is not canonical" >&2
  exit 2
fi
current_id="${current#releases/}"
switch_current() {
  local link_target="$1"
  local link_parent
  link_parent="$(mktemp -d "$install_root/.activation-link.XXXXXX")"
  ln -s "$link_target" "$link_parent/current"
  mv -Tf "$link_parent/current" "$install_root/current"
  rmdir "$link_parent"
}
"$runtime_tool" activation-marker prepare --marker "$marker" --candidate "$release_id" --previous "$current_id"
switch_current "releases/$release_id"
if ! systemctl restart family-health-edge.service || ! "$runtime_tool" check-release-health --url http://127.0.0.1:18100/v1/health --timeout 10; then
  if [ -n "$current" ]; then
    switch_current "$current"
    systemctl restart family-health-edge.service || true
  else
    unlink "$install_root/current"
    systemctl stop family-health-edge.service || true
  fi
  "$runtime_tool" activation-marker clear --marker "$marker" --candidate "$release_id"
  echo "rollback health check failed; original release restored" >&2
  exit 2
fi
"$runtime_tool" activation-marker clear --marker "$marker" --candidate "$release_id"
echo "rolled back to $release_id"
