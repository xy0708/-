from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / "configs" / "arm64_runtime_tool_build.json"
RUNS = ROOT / "reports" / "arm64_runtime_tool_build_runs"
LATEST = ROOT / "reports" / "arm64_runtime_tool_build_latest.json"
ARTIFACTS = ROOT / "artifacts" / "arm64_runtime_tools"
PACKAGES = (
    "acceptance",
    "asr_runtime",
    "device_service",
    "health_rules",
    "integration_adapter",
    "ocr_runtime",
    "operations",
    "release_tools",
    "runtime_backends",
    "storage",
    "update_agent",
)
SCRIPT_FILES = (
    "__init__.py",
    "activation_marker.py",
    "check_release_health.py",
    "check_rollback_transition.py",
    "runtime_tool.py",
    "verify_current_release.py",
    "verify_release_bundle.py",
)
EXPECTED_COMMANDS = {
    "activation-marker",
    "check-release-health",
    "check-rollback-transition",
    "verify-current-release",
    "verify-release-bundle",
}


class BuildError(ValueError):
    pass


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_contract() -> dict:
    try:
        value = json.loads(CONTRACT.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise BuildError("BUILD_CONTRACT_INVALID") from exc
    if (
        not isinstance(value, dict)
        or value.get("schema_version") != "1.0.0"
        or value.get("target_platform") != "linux/arm64"
        or value.get("target_elf_machine") != 183
        or value.get("python_version") != "3.12.10"
        or value.get("build_network_allowed") is not False
        or value.get("global_python_required_at_runtime") is not False
        or value.get("hardware_measured") is not False
        or value.get("product_accepted") is not False
        or set(value.get("commands", [])) != EXPECTED_COMMANDS
    ):
        raise BuildError("BUILD_CONTRACT_BOUNDARY_INVALID")
    builder = value.get("builder")
    if (
        not isinstance(builder, dict)
        or builder.get("name") != "PyInstaller"
        or builder.get("version") != "6.22.3"
        or builder.get("mode") != "onefile"
        or builder.get("named_legal_approval") is not False
    ):
        raise BuildError("BUILD_TOOL_LOCK_INVALID")
    base = value.get("base_image")
    if not isinstance(base, str) or re.fullmatch(
        r"python@sha256:[0-9a-f]{64}", base
    ) is None:
        raise BuildError("BASE_IMAGE_NOT_DIGEST_PINNED")
    return value


def validate_wheelhouse(contract: dict) -> list[dict]:
    wheelhouse = ROOT / str(contract.get("wheelhouse"))
    if not wheelhouse.is_dir() or wheelhouse.is_symlink():
        raise BuildError("WHEELHOUSE_INVALID")
    records = contract.get("wheels")
    if not isinstance(records, list) or not records:
        raise BuildError("WHEEL_LOCK_EMPTY")
    expected_names: set[str] = set()
    for record in records:
        if not isinstance(record, dict) or set(record) != {
            "file",
            "size",
            "sha256",
            "license",
        }:
            raise BuildError("WHEEL_LOCK_SCHEMA_INVALID")
        name = record.get("file")
        digest = record.get("sha256")
        size = record.get("size")
        license_name = record.get("license")
        if (
            not isinstance(name, str)
            or Path(name).name != name
            or not name.endswith(".whl")
            or name in expected_names
            or isinstance(size, bool)
            or not isinstance(size, int)
            or size <= 0
            or not isinstance(digest, str)
            or re.fullmatch(r"[0-9a-f]{64}", digest) is None
            or not isinstance(license_name, str)
            or not license_name.strip()
        ):
            raise BuildError("WHEEL_LOCK_RECORD_INVALID")
        expected_names.add(name)
        path = wheelhouse / name
        if (
            not path.is_file()
            or path.is_symlink()
            or path.stat().st_size != size
            or sha256(path) != digest
        ):
            raise BuildError(f"WHEEL_LOCK_MISMATCH:{name}")
    actual_names = {path.name for path in wheelhouse.glob("*.whl")}
    if actual_names != expected_names:
        raise BuildError("WHEELHOUSE_UNREGISTERED_OR_MISSING_FILE")
    return records


def source_files() -> list[Path]:
    files = [CONTRACT]
    for package in PACKAGES:
        files.extend(sorted((ROOT / package).glob("*.py")))
    files.extend(ROOT / "scripts" / name for name in SCRIPT_FILES)
    for path in files:
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(ROOT):
            raise BuildError("BUILD_SOURCE_INVALID")
    return sorted(set(files))


def aggregate_hash(records: dict[str, str]) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(records.items()):
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(value.encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def write_context(context: Path, contract: dict, wheel_records: list[dict]) -> dict[str, str]:
    app = context / "app"
    wheelhouse = context / "wheelhouse"
    app.mkdir(parents=True)
    wheelhouse.mkdir()
    hashes: dict[str, str] = {}
    for source in source_files():
        relative = source.relative_to(ROOT)
        target = app / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        hashes[relative.as_posix()] = sha256(target)
    source_wheelhouse = ROOT / contract["wheelhouse"]
    for record in wheel_records:
        source = source_wheelhouse / record["file"]
        shutil.copy2(source, wheelhouse / source.name)
    dockerfile = f"""ARG BASE_IMAGE={contract['base_image']}
FROM ${{BASE_IMAGE}}
WORKDIR /build
COPY wheelhouse /wheelhouse
RUN python -m pip install --no-index --no-cache-dir --find-links=/wheelhouse pyinstaller==6.22.3
COPY app /build/app
WORKDIR /build/app
RUN python -m PyInstaller --clean --noconfirm --onefile --name family-health-edge-tool scripts/runtime_tool.py
COPY smoke.sh /smoke.sh
RUN chmod 0555 /build/app/dist/family-health-edge-tool /smoke.sh
ENTRYPOINT ["/build/app/dist/family-health-edge-tool"]
"""
    (context / "Dockerfile").write_text(dockerfile, encoding="utf-8", newline="\n")
    smoke = """#!/bin/sh
set -eu
tool=/build/app/dist/family-health-edge-tool
for command in activation-marker check-release-health check-rollback-transition verify-current-release verify-release-bundle; do
  printf 'checking command: %s\n' "$command"
  "$tool" "$command" --help
done
marker=/state/pending-activation.json
"$tool" activation-marker prepare --marker "$marker" --candidate v2 --previous v1 >/dev/null
[ "$("$tool" activation-marker read --marker "$marker" --field candidate_release_id)" = v2 ]
[ "$("$tool" activation-marker read --marker "$marker" --field previous_release_id)" = v1 ]
"$tool" activation-marker clear --marker "$marker" --candidate v2 >/dev/null
[ ! -e "$marker" ]
if "$tool" unknown >/dev/null 2>&1; then exit 2; fi
printf '%s\n' '{"status":"PASS_ENGINEERING","architecture":"aarch64","network":"none","global_python_required":false,"commands_imported":5,"activation_round_trip":true}'
"""
    (context / "smoke.sh").write_text(smoke, encoding="utf-8", newline="\n")
    return hashes


def docker_cli() -> str:
    discovered = shutil.which("docker")
    if discovered:
        return discovered
    candidate = Path("C:/Program Files/Docker/Docker/resources/bin/docker.exe")
    if candidate.is_file():
        return str(candidate)
    raise BuildError("DOCKER_CLI_MISSING")


def run_command(
    command: list[str], log: Path, *, timeout: int, env: dict[str, str]
) -> subprocess.CompletedProcess[bytes]:
    try:
        completed = subprocess.run(
            command,
            cwd=ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            check=False,
            env=env,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        log.write_text(f"{type(exc).__name__}\n", encoding="utf-8")
        raise BuildError("BUILD_COMMAND_FAILED") from exc
    log.write_bytes(completed.stdout)
    return completed


def local_docker_environment(docker: str, run_dir: Path) -> dict[str, str]:
    environment = dict(os.environ)
    endpoint = environment.get("DOCKER_HOST")
    if environment.get("DOCKER_CONTEXT") or not endpoint:
        command = [docker, "context", "inspect"]
        if environment.get("DOCKER_CONTEXT"):
            command.append(environment["DOCKER_CONTEXT"])
        command += ["--format", "{{json .Endpoints.docker.Host}}"]
        completed = run_command(
            command,
            run_dir / "docker_context.log",
            timeout=30,
            env=environment,
        )
        if completed.returncode != 0:
            raise BuildError("DOCKER_CONTEXT_UNAVAILABLE")
        endpoint = json.loads(completed.stdout.decode("utf-8"))
    if not isinstance(endpoint, str) or not (
        endpoint.startswith("npipe:////./pipe/") or endpoint.startswith("unix:///")
    ):
        raise BuildError("REMOTE_DOCKER_REFUSED")
    environment.pop("DOCKER_CONTEXT", None)
    environment["DOCKER_HOST"] = endpoint
    completed = run_command(
        [docker, "info", "--format", "{{json .OSType}}"],
        run_dir / "docker_info.log",
        timeout=30,
        env=environment,
    )
    if completed.returncode != 0 or json.loads(completed.stdout.decode("utf-8")) != "linux":
        raise BuildError("LOCAL_LINUX_DOCKER_NOT_READY")
    return environment


def elf_metadata(path: Path) -> dict:
    header = path.read_bytes()[:64]
    if len(header) < 20 or header[:4] != b"\x7fELF":
        raise BuildError("RUNTIME_TOOL_NOT_ELF")
    if header[4] != 2 or header[5] not in {1, 2}:
        raise BuildError("RUNTIME_TOOL_ELF_HEADER_INVALID")
    order = "<" if header[5] == 1 else ">"
    machine = struct.unpack_from(order + "H", header, 18)[0]
    if machine != 183:
        raise BuildError("RUNTIME_TOOL_NOT_AARCH64")
    return {"elf_class": 64, "elf_machine": machine, "elf_endianness": header[5]}


def extract_licenses(wheel_records: list[dict], destination: Path) -> list[dict]:
    destination.mkdir(parents=True)
    output: list[dict] = []
    wheelhouse = ROOT / "artifacts" / "arm64_runtime_tool_builder" / "wheelhouse"
    for record in wheel_records:
        wheel = wheelhouse / record["file"]
        with zipfile.ZipFile(wheel) as archive:
            entries = [
                item
                for item in archive.infolist()
                if ".dist-info/" in item.filename
                and any(
                    token in Path(item.filename).name.upper()
                    for token in ("LICENSE", "COPYING", "NOTICE")
                )
                and not item.is_dir()
            ]
            if not entries:
                raise BuildError(f"WHEEL_LICENSE_FILE_MISSING:{record['file']}")
            for index, entry in enumerate(entries):
                name = re.sub(r"[^A-Za-z0-9._-]", "_", record["file"])
                target = destination / f"{name}.{index}.{Path(entry.filename).name}"
                target.write_bytes(archive.read(entry))
                output.append(
                    {
                        "wheel": record["file"],
                        "source": entry.filename,
                        "path": target.relative_to(destination.parent).as_posix(),
                        "size": target.stat().st_size,
                        "sha256": sha256(target),
                    }
                )
    return output


def write_json(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def main() -> int:
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    run_dir = RUNS / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    context = run_dir / "context"
    report = {
        "schema_version": "1.0.0",
        "run_id": run_id,
        "status": "FAIL_ENGINEERING_BUILD",
        "simulated": True,
        "hardware_measured": False,
        "product_accepted": False,
        "formal_release_created": False,
        "errors": [],
    }
    docker = None
    container = None
    image = None
    staging: Path | None = None
    environment = dict(os.environ)
    try:
        contract = load_contract()
        wheels = validate_wheelhouse(contract)
        sources = write_context(context, contract, wheels)
        source_digest = aggregate_hash(sources)
        wheel_digest = aggregate_hash(
            {record["file"]: record["sha256"] for record in wheels}
        )
        build_id = (
            f"pyinstaller-{contract['builder']['version']}-"
            f"{source_digest[:12]}-{wheel_digest[:12]}"
        )
        destination = ARTIFACTS / build_id
        if destination.exists() or destination.is_symlink():
            raise BuildError("IMMUTABLE_ARTIFACT_ALREADY_EXISTS")
        docker = docker_cli()
        environment = local_docker_environment(docker, run_dir)
        image = "family-health-edge-runtime-tool:" + run_id.lower()
        build = run_command(
            [
                docker,
                "build",
                "--platform",
                "linux/arm64",
                "--network=none",
                "--build-arg",
                f"BASE_IMAGE={contract['base_image']}",
                "-t",
                image,
                str(context),
            ],
            run_dir / "build.log",
            timeout=900,
            env=environment,
        )
        if build.returncode != 0:
            raise BuildError("PYINSTALLER_ARM64_BUILD_FAILED")
        smoke = run_command(
            [
                docker,
                "run",
                "--rm",
                "--platform",
                "linux/arm64",
                "--network=none",
                "--read-only",
                "--cap-drop=ALL",
                "--security-opt=no-new-privileges",
                "--memory=256m",
                "--memory-swap=256m",
                "--cpus=1",
                "--pids-limit=64",
                "--tmpfs",
                "/tmp:rw,exec,nosuid,nodev,size=64m,mode=1777",
                "--tmpfs",
                "/state:rw,nosuid,nodev,size=1m,mode=0700",
                "--entrypoint",
                "/bin/sh",
                image,
                "/smoke.sh",
            ],
            run_dir / "smoke.log",
            timeout=180,
            env=environment,
        )
        if smoke.returncode != 0:
            raise BuildError("RUNTIME_TOOL_ARM64_SMOKE_FAILED")
        smoke_result = json.loads(smoke.stdout.decode("utf-8").splitlines()[-1])
        if (
            smoke_result.get("status") != "PASS_ENGINEERING"
            or smoke_result.get("architecture") != "aarch64"
            or smoke_result.get("network") != "none"
            or smoke_result.get("global_python_required") is not False
            or smoke_result.get("commands_imported") != 5
            or smoke_result.get("activation_round_trip") is not True
        ):
            raise BuildError("RUNTIME_TOOL_SMOKE_EVIDENCE_INVALID")
        container = "edge-runtime-tool-export-" + run_id.lower()
        create = run_command(
            [docker, "create", "--name", container, "--platform", "linux/arm64", image],
            run_dir / "create_export.log",
            timeout=60,
            env=environment,
        )
        if create.returncode != 0:
            raise BuildError("RUNTIME_TOOL_EXPORT_CONTAINER_FAILED")
        staging = ARTIFACTS / ("." + build_id + ".staging")
        if staging.exists() or staging.is_symlink():
            raise BuildError("STALE_RUNTIME_TOOL_STAGING_EXISTS")
        staging.mkdir(parents=True)
        artifact = staging / contract["artifact_name"]
        copied = run_command(
            [
                docker,
                "cp",
                f"{container}:/build/app/dist/{contract['artifact_name']}",
                str(artifact),
            ],
            run_dir / "copy_artifact.log",
            timeout=120,
            env=environment,
        )
        if copied.returncode != 0 or not artifact.is_file():
            raise BuildError("RUNTIME_TOOL_EXPORT_FAILED")
        elf = elf_metadata(artifact)
        artifact_record = {
            "path": contract["artifact_name"],
            "size": artifact.stat().st_size,
            "sha256": sha256(artifact),
            **elf,
        }
        sbom = {
            "schema_version": "1.0.0",
            "scope": "ARM64 runtime tool builder dependencies",
            "packages": [
                {
                    "wheel": record["file"],
                    "sha256": record["sha256"],
                    "license": record["license"],
                    "runtime_distribution_approved": False,
                }
                for record in wheels
            ],
        }
        write_json(staging / "sbom.json", sbom)
        licenses = extract_licenses(wheels, staging / "licenses")
        manifest = {
            "schema_version": "1.0.0",
            "build_id": build_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "status": "PASS_ENGINEERING_ARM64_TOOL_PRODUCT_BLOCKED",
            "target_platform": "linux/arm64",
            "base_image": contract["base_image"],
            "builder": contract["builder"],
            "source_sha256": sources,
            "source_aggregate_sha256": source_digest,
            "wheel_aggregate_sha256": wheel_digest,
            "artifact": artifact_record,
            "sbom_sha256": sha256(staging / "sbom.json"),
            "license_files": licenses,
            "arm64_smoke": smoke_result,
            "build_network": "none",
            "global_python_required_at_runtime": False,
            "hardware_measured": False,
            "product_accepted": False,
            "formal_release_allowed": False,
            "blockers": [
                "NAMED_RUNTIME_DISTRIBUTION_LEGAL_APPROVAL_REQUIRED",
                "REAL_RK3566_EXECUTION_REQUIRED",
                "PRODUCT_SIGNING_AND_PROVISIONING_REQUIRED",
            ],
        }
        write_json(staging / "manifest.json", manifest)
        staging.replace(destination)
        staging = None
        report.update(
            status="PASS_ENGINEERING_ARM64_TOOL_PRODUCT_BLOCKED",
            build_id=build_id,
            artifact_directory=str(destination.relative_to(ROOT)),
            artifact=artifact_record,
            source_aggregate_sha256=source_digest,
            wheel_aggregate_sha256=wheel_digest,
            arm64_smoke=smoke_result,
            blockers=manifest["blockers"],
        )
        return 0
    except (BuildError, OSError, UnicodeError, json.JSONDecodeError) as exc:
        report["errors"].append(str(exc) if isinstance(exc, BuildError) else type(exc).__name__)
        return 2
    finally:
        if docker and container:
            removed = run_command(
                [docker, "rm", "--force", container],
                run_dir / "cleanup_container.log",
                timeout=60,
                env=environment,
            )
            report["export_container_cleaned"] = removed.returncode == 0
        if docker and image:
            removed = run_command(
                [docker, "image", "rm", "--force", image],
                run_dir / "cleanup_image.log",
                timeout=120,
                env=environment,
            )
            report["builder_image_cleaned"] = removed.returncode == 0
        if context.exists():
            shutil.rmtree(context)
        if staging is not None and staging.exists():
            if not staging.resolve().is_relative_to(ARTIFACTS.resolve()):
                raise BuildError("UNSAFE_STAGING_CLEANUP_PATH")
            shutil.rmtree(staging)
        report["finished_at"] = datetime.now(timezone.utc).isoformat()
        write_json(run_dir / "audit.json", report)
        write_json(LATEST, report)
        print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    raise SystemExit(main())
