from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from runtime_backends import (
    BackendRegistryError,
    load_registry,
    load_selection,
    select_backend,
)


REGISTRY = ROOT / "model_registry" / "backend_registry.json"
SELECTION = ROOT / "configs" / "runtime_backend_selection.json"
REPORT = ROOT / "reports" / "runtime_backend_registry_verification.json"


def verify_registry() -> dict[str, object]:
    errors: list[str] = []
    try:
        registry = load_registry(REGISTRY)
    except BackendRegistryError as exc:
        return {"status": "FAIL", "errors": [exc.code]}
    try:
        selection = json.loads(SELECTION.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return {"status": "FAIL", "errors": ["BACKEND_SELECTION_INVALID"]}

    expected_selection_fields = {
        "schema_version",
        "mode",
        "product_accepted",
        "fallback_allowed",
        "asr_backend_id",
        "ocr_backend_id",
        "device_service_integration_verified",
        "meaning",
    }
    if not isinstance(selection, dict) or set(selection) != expected_selection_fields:
        errors.append("BACKEND_SELECTION_SCHEMA_INVALID")
    elif (
        selection.get("schema_version") != "1.0.0"
        or selection.get("mode") != "ENGINEERING"
        or selection.get("product_accepted") is not False
        or selection.get("fallback_allowed") is not False
        or selection.get("ocr_backend_id") is not None
        or selection.get("device_service_integration_verified") is not True
    ):
        errors.append("BACKEND_SELECTION_BOUNDARY_INVALID")

    expected_ids = {
        "asr_sherpa_cpu_xasr",
        "ocr_paddle_cpu_ppocrv5",
        "ocr_rknn_ppocrv4",
        "asr_rknn_zipformer",
        "asr_rknn_whisper",
    }
    if set(registry.backends) != expected_ids:
        errors.append("BACKEND_SET_INCOMPLETE")
    selected_asr = None
    if not errors:
        try:
            loaded_selection = load_selection(
                SELECTION,
                registry,
                product_mode=False,
            )
            selected_asr = loaded_selection.asr
            if loaded_selection.ocr is not None:
                errors.append("UNEXPECTED_OCR_SELECTION")
        except BackendRegistryError as exc:
            errors.append(exc.code)

    for backend_id in ("ocr_rknn_ppocrv4", "asr_rknn_zipformer", "asr_rknn_whisper"):
        component = registry.backends[backend_id].component
        try:
            select_backend(
                registry,
                component=component,
                backend_id=backend_id,
                product_mode=False,
            )
        except BackendRegistryError as exc:
            if exc.code != "BACKEND_NOT_ENGINEERING_READY":
                errors.append(f"UNEXPECTED_BLOCK_REASON:{backend_id}:{exc.code}")
        else:
            errors.append(f"UNVERIFIED_RKNN_BACKEND_SELECTABLE:{backend_id}")

    zipformer = registry.backends.get("asr_rknn_zipformer")
    if (
        zipformer is None
        or zipformer.implementation_module is not None
        or "engineering_worker_deferred" not in zipformer.unavailable_reasons
        or "research_set_quality_regression_observed"
        not in zipformer.unavailable_reasons
    ):
        errors.append("ASR_RKNN_RESEARCH_REGRESSION_DECISION_MISSING")

    archived_ocr = registry.backends.get("ocr_rknn_ppocrv4")
    if (
        archived_ocr is None
        or archived_ocr.implementation_module is not None
        or "product_worker_missing" not in archived_ocr.unavailable_reasons
        or "synthetic_engineering_quality_regression_observed"
        not in archived_ocr.unavailable_reasons
        or "official_research_assets_archived_outside_product_tree"
        not in archived_ocr.unavailable_reasons
    ):
        errors.append("OCR_RKNN_SYNTHETIC_REGRESSION_ARCHIVE_DECISION_MISSING")

    product_ready = [item.backend_id for item in registry.backends.values() if item.status == "PRODUCT_READY"]
    engineering_ready = [
        item.backend_id for item in registry.backends.values() if item.status == "ENGINEERING_READY"
    ]
    implemented_blocked = [
        item.backend_id
        for item in registry.backends.values()
        if item.status == "BLOCKED_ENGINEERING" and item.implementation_module is not None
    ]
    return {
        "status": "PASS_ENGINEERING_PARTIAL" if not errors else "FAIL",
        "phase": "R05_IN_PROGRESS",
        "registered_backends": len(registry.backends),
        "engineering_ready_backends": engineering_ready,
        "implemented_blocked_backends": implemented_blocked,
        "product_ready_backends": product_ready,
        "selected_asr_backend": selected_asr.backend_id if selected_asr else None,
        "asr_rknn_worker_deferred_after_research_regression": not errors,
        "selected_ocr_backend": None,
        "silent_fallback_allowed": registry.fallback_allowed,
        "device_service_integration_verified": True,
        "product_complete": registry.product_complete,
        "errors": errors,
    }


def main() -> int:
    result = verify_registry()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS_ENGINEERING_PARTIAL" else 2


if __name__ == "__main__":
    raise SystemExit(main())
