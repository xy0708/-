from __future__ import annotations

import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.run_arm64_model_simulation import REPORT, ROOT, WORKSPACE, sha256


OUTPUT = ROOT / "reports" / "arm64_model_simulation_verification.json"


def evaluate(report: dict) -> list[str]:
    errors = []
    for field in ("hardware_measured", "product_complete", "three_model_inference_verified",
                  "simulation_complete"):
        if report.get(field) is not False:
            errors.append("UNSUPPORTED_COMPLETION_CLAIM:" + field)
    if report.get("simulated") is not True or report.get("stage") != "S2_PARTIAL":
        errors.append("MODEL_SIMULATION_PROVENANCE_INVALID")
    if report.get("status") != "PARTIAL_PASS_PRODUCT_BLOCKED":
        errors.append("AVAILABLE_MODEL_SIMULATION_NOT_PASS")
    if set(report.get("blockers", [])) != {
            "OCR_PRODUCT_MODEL_AND_LICENSE_REQUIRED", "RK3566_NOT_TESTED"}:
        errors.append("MODEL_SIMULATION_BLOCKERS_INVALID")
    digest_pattern = r"[a-z0-9][a-z0-9._/-]*@sha256:[a-f0-9]{64}"
    if not re.fullmatch(digest_pattern, str(report.get("base_image", {}).get("digest", ""))):
        errors.append("MODEL_BASE_DIGEST_MISSING")
    if not re.fullmatch(digest_pattern,
                        str(report.get("candidate_image", {}).get("reference", ""))):
        errors.append("MODEL_CANDIDATE_DIGEST_MISSING")
    components = report.get("components", {})
    health = components.get("health", {})
    if (health.get("status") != "PASS_ARM64_REAL_INFERENCE" or
            health.get("product_model") is not False or
            health.get("probability_exposed_to_product") is not False):
        errors.append("HEALTH_ARM64_REAL_INFERENCE_MISSING")
    asr = components.get("asr", {})
    if (asr.get("status") != "PASS_ARM64_REAL_INFERENCE" or
            asr.get("matches_host_reference") is not True or
            asr.get("product_accepted") is not False):
        errors.append("ASR_ARM64_REAL_INFERENCE_MISSING")
    host_asr = report.get("host_references", {}).get("asr", {})
    if (host_asr.get("status") != "PASS_HOST_REFERENCE" or
            host_asr.get("runtime_version") != asr.get("version") or
            host_asr.get("final_text_sha256") != asr.get("final_text_sha256")):
        errors.append("ASR_CROSS_ARCH_REFERENCE_INVALID")
    ocr = components.get("ocr", {})
    if (ocr.get("status") != "BLOCKED_EXTERNAL" or
            ocr.get("real_arm64_inference_executed") is not False or
            ocr.get("test_double_used") is not False):
        errors.append("OCR_BLOCKER_PROVENANCE_INVALID")
    if report.get("container_cleaned") is not True:
        errors.append("MODEL_CONTAINER_CLEANUP_NOT_VERIFIED")
    if report.get("host_runtime_cleaned") is not True:
        errors.append("HOST_RUNTIME_CLEANUP_NOT_VERIFIED")
    commands = {item.get("name"): item for item in report.get("commands", [])
                if isinstance(item, dict)}
    for name in ("install_host_sherpa_runtime", "asr_host_reference", "build_model_image",
                 "create_model_container", "run_model_probe", "cleanup_own_model_container"):
        if commands.get(name, {}).get("exit_code") != 0:
            errors.append("MODEL_COMMAND_NOT_VERIFIED:" + name)
    hashes = report.get("source_sha256")
    if not isinstance(hashes, dict) or not hashes:
        errors.append("MODEL_SOURCE_HASHES_MISSING")
    else:
        required_sources = {
            "端侧上线/configs/arm64_model_simulation.json",
            "端侧上线/simulation/ModelDockerfile",
            "端侧上线/simulation/model_probe.py",
            "端侧上线/simulation/health_reference.py",
            "端侧上线/scripts/build_arm64_wheelhouse_manifest.py",
            "端侧上线/scripts/run_arm64_model_simulation.py",
            "端侧上线/scripts/verify_model_simulation_evidence.py",
        }
        if not required_sources.issubset(hashes):
            errors.append("MODEL_REQUIRED_SOURCE_HASHES_MISSING")
        for relative, digest in hashes.items():
            path = (WORKSPACE / relative).resolve()
            if (not path.is_relative_to(WORKSPACE.resolve()) or not path.is_file()
                    or sha256(path) != digest):
                errors.append("MODEL_SOURCE_CHANGED:" + relative)
    return errors


def main() -> int:
    report = json.loads(REPORT.read_text(encoding="utf-8")) if REPORT.is_file() else {}
    errors = evaluate(report)
    output = {
        "schema_version": "1.0.0", "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_ENGINEERING" if not errors else "FAIL",
        "meaning": "Health and ASR real ARM64 inference only; OCR and RK3566 remain blocked",
        "product_complete": False, "hardware_measured": False,
        "three_model_inference_verified": False, "errors": errors,
    }
    OUTPUT.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, ensure_ascii=True))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
