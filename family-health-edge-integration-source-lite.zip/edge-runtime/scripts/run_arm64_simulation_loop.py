from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from simulation.guest_probe import TEST_FILES, architecture_valid

PACKAGES = ('health_rules', 'device_service', 'integration_adapter', 'storage',
            'ocr_runtime', 'asr_runtime', 'operations', 'acceptance',
            'release_tools', 'runtime_backends', 'update_agent')
BASE_TAG = 'python:3.12.10-slim-bookworm'
ARM64_PLATFORM = 'linux/arm64'
RUNTIME_TOOL_STATUS = 'PASS_ENGINEERING_ARM64_TOOL_PRODUCT_BLOCKED'


def sha256(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def decode_output(raw: bytes) -> str:
    if raw.startswith((b'\xff\xfe', b'\xfe\xff')):
        return raw.decode('utf-16', errors='replace')
    if b'\x00' in raw[:128]:
        return raw.decode('utf-16-le', errors='replace')
    return raw.decode('utf-8', errors='replace')


def verified_runtime_tool(root: Path) -> tuple[Path, dict[str, str]]:
    evidence_path = root / 'reports/arm64_runtime_tool_verification.json'
    try:
        evidence = json.loads(evidence_path.read_text(encoding='utf-8'))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError('RUNTIME_TOOL_VERIFICATION_INVALID') from exc
    relative = evidence.get('artifact_relative_path')
    expected_hash = evidence.get('artifact_sha256')
    if (
        evidence.get('status') != RUNTIME_TOOL_STATUS
        or evidence.get('errors') != []
        or evidence.get('simulated') is not True
        or evidence.get('hardware_measured') is not False
        or evidence.get('product_accepted') is not False
        or not isinstance(relative, str)
        or not isinstance(expected_hash, str)
        or re.fullmatch(r'[0-9a-f]{64}', expected_hash) is None
    ):
        raise ValueError('RUNTIME_TOOL_VERIFICATION_NOT_ACCEPTABLE')
    candidate = root / relative
    artifact_root = (root / 'artifacts/arm64_runtime_tools').resolve()
    if (
        candidate.is_symlink()
        or not candidate.is_file()
        or not candidate.resolve().is_relative_to(artifact_root)
        or sha256(candidate) != expected_hash
    ):
        raise ValueError('RUNTIME_TOOL_ARTIFACT_INVALID')
    return candidate, {
        'build_id': str(evidence.get('build_id')),
        'source_path': relative,
        'sha256': expected_hash,
    }


def stage_context(root: Path, destination: Path) -> dict[str, str]:
    """Whitelist project code; never send the workstation workspace to a builder."""
    root = root.resolve()
    paths = [
        Path('configs/health_rules.json'),
        Path('configs/runtime_backend_selection.json'),
        Path('model_registry/backend_registry.json'),
        Path('simulation/guest_probe.py'),
    ]
    for package in PACKAGES:
        paths.extend(path.relative_to(root) for path in (root / package).glob('*.py'))
    paths.extend(Path('tests') / name for name in TEST_FILES)
    paths.extend((
        Path('scripts/__init__.py'),
        Path('scripts/activation_marker.py'),
        Path('scripts/build_release.py'),
        Path('scripts/install_release.sh'),
        Path('scripts/promote_release.py'),
        Path('scripts/recover_pending_activation.sh'),
        Path('scripts/verify_current_release.py'),
        Path('scripts/verify_release.py'),
        Path('scripts/verify_release_bundle.py'),
        Path('scripts/verify_runtime_backend_registry.py'),
        Path('tests/linux_activation_recovery_smoke.sh'),
    ))
    paths.append(Path('simulation/Dockerfile'))
    hashes = {}
    for relative in sorted(set(paths)):
        source = root / relative
        if (not source.is_file() or not source.resolve().is_relative_to(root)
                or any(part.is_symlink() for part in [source, *source.parents] if part != root)):
            raise ValueError('BUILD_CONTEXT_SOURCE_INVALID')
        target = destination / ('Dockerfile' if relative.name == 'Dockerfile' else 'app/' + relative.as_posix())
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        hashes[relative.as_posix()] = sha256(target)
    runtime_tool, runtime_record = verified_runtime_tool(root)
    runtime_target = destination / 'app/tools/family-health-edge-tool'
    runtime_target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(runtime_tool, runtime_target)
    hashes['tools/family-health-edge-tool'] = runtime_record['sha256']
    manifest = {name: digest for name, digest in hashes.items() if name != 'simulation/Dockerfile'}
    (destination / 'app/source_manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
    return hashes


def validate_guest(value: dict) -> bool:
    return (
        architecture_valid(value.get('system'), str(value.get('machine')), value.get('bits'))
        and value.get('status') == 'PASS_ARM64_SOFTWARE'
        and value.get('simulated') is True and value.get('hardware_measured') is False
        and value.get('product_complete') is False
        and value.get('three_model_inference_verified') is False
        and value.get('source_integrity_verified') is True
        and type(value.get('tests_run')) is int and value['tests_run'] >= 30
        and value.get('failures') == 0 and value.get('errors') == 0
        and value.get('skipped') == 0 and value.get('test_files') == list(TEST_FILES)
    )


def validate_recovery_smoke(value: dict) -> bool:
    return (
        value.get('status') == 'PASS_ENGINEERING'
        and value.get('architecture') in {'aarch64', 'arm64'}
        and value.get('network') == 'none'
        and value.get('hardware_measured') is False
        and value.get('signature_verifier_stubbed') is True
        and value.get('interrupted_destination_resume') is True
        and value.get('runtime_tool_real_arm64_artifact') is True
        and value.get('runtime_tool_hash_verified') is True
        and value.get('runtime_tool_activation_real') is True
    )


def local_endpoint(value: str) -> bool:
    return value.startswith('npipe:////./pipe/') or value.startswith('unix:///')


def image_inspect_arguments(reference: str) -> list[str]:
    """Select the ARM64 child manifest when Docker stores a multi-platform index."""
    return ['image', 'inspect', '--platform', ARM64_PLATFORM, reference]


def pinned_repository_digest(values: object) -> str | None:
    if not isinstance(values, list):
        return None
    return next((value for value in values if isinstance(value, str) and
                 re.fullmatch(r'[a-z0-9][a-z0-9._/-]*@sha256:[a-f0-9]{64}', value)), None)


def public_reason(exc: Exception) -> str:
    reason = str(exc)
    return reason if re.fullmatch(r'[A-Z0-9_]+', reason) else 'INVALID_ENVIRONMENT_OR_EVIDENCE'


def run_command(command: list[str], directory: Path, record_dir: Path,
                records: list, name: str, timeout: int = 30, env: dict | None = None):
    start = datetime.now(timezone.utc).isoformat()
    child_pid = None
    try:
        with subprocess.Popen(command, cwd=directory, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, env=env) as child:
            child_pid = child.pid
            try:
                raw, _ = child.communicate(timeout=timeout)
                code, reason = child.returncode, None
            except subprocess.TimeoutExpired:
                child.kill()
                raw, _ = child.communicate()
                code, reason = -1, 'COMMAND_TIMEOUT'
        output = decode_output(raw)
    except OSError:
        output, code, reason = '', -1, 'COMMAND_UNAVAILABLE'
    log = record_dir / f'{name}.log'
    log.write_text(output, encoding='utf-8')
    records.append(dict(name=name, command=command, pid=child_pid, started_at=start,
                        finished_at=datetime.now(timezone.utc).isoformat(), exit_code=code,
                        reason=reason, log=log.name, log_sha256=sha256(log)))
    return code, output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true', help='build and execute on local Docker')
    args = parser.parse_args()
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
    folder = ROOT / 'reports/arm64_simulation_runs' / run_id
    folder.mkdir(parents=True, exist_ok=False)
    report = dict(schema_version='1.0.0', run_id=run_id, status='BLOCKED_ENVIRONMENT',
                  simulated=True, hardware_measured=False, product_complete=False,
                  three_model_inference_verified=False, simulation_complete=False,
                  execute_requested=args.execute, stage='S0', commands=[], blockers=[],
                  remaining_stages=['S2_REAL_MODEL_INFERENCE', 'S3_REAL_ADAPTER_INTEGRATION', 'S4_RK3566'],
                  resume_command='.venv-edge/Scripts/python.exe scripts/run_arm64_simulation_loop.py --execute')
    records = report['commands']
    code = 3
    docker = shutil.which('docker')
    if not docker and os.name == 'nt':
        candidate = Path('C:/Program Files/Docker/Docker/resources/bin/docker.exe')
        if candidate.is_file():
            docker = str(candidate)
    container_name = 'edge-arm64-sim-' + run_id.lower()
    recovery_container_name = 'edge-arm64-recovery-' + run_id.lower()
    created_container = False
    created_recovery_container = False
    environment = dict(os.environ)
    environment.update(PYTHONUTF8='1')
    try:
        runtime_tool, runtime_record = verified_runtime_tool(ROOT)
        report['runtime_tool'] = runtime_record
        report['source_sha256'] = stage_context(ROOT, folder / 'context')
        report['plan_sha256'] = sha256(ROOT / 'ARM64_SIMULATION_LOOP.md')
        rc, _ = run_command([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-q'],
                            folder / 'context/app', folder, records, 'host_context_tests', 60, environment)
        report['host_context_tests_passed'] = rc == 0
        report['host_context_tests_are_arm64_evidence'] = False
        if rc:
            raise ValueError('STAGED_CONTEXT_HOST_TESTS_FAILED')
        if os.name == 'nt':
            run_command(['wsl.exe', '--status'], ROOT, folder, records, 'wsl_status')
        if not docker:
            report['blockers'].append('DOCKER_CLI_MISSING')
            return code
        endpoint = environment.get('DOCKER_HOST')
        if environment.get('DOCKER_CONTEXT') or not endpoint:
            context_cmd = [docker, 'context', 'inspect']
            if environment.get('DOCKER_CONTEXT'):
                context_cmd.append(environment['DOCKER_CONTEXT'])
            context_cmd += ['--format', '{{json .Endpoints.docker.Host}}']
            rc, raw = run_command(context_cmd, ROOT, folder, records, 'docker_context')
            if rc:
                report['blockers'].append('DOCKER_CONTEXT_UNAVAILABLE')
                return code
            endpoint = json.loads(raw)
        if not isinstance(endpoint, str) or not local_endpoint(endpoint):
            report['blockers'].append('REMOTE_DOCKER_REFUSED')
            return code
        environment.pop('DOCKER_CONTEXT', None)
        environment['DOCKER_HOST'] = endpoint
        def docker_run(arguments, name, timeout=30):
            return run_command([docker, *arguments], ROOT, folder, records, name, timeout, environment)
        rc, raw = docker_run(['info', '--format', '{{json .OSType}}'], 'docker_info')
        if rc or json.loads(raw) != 'linux':
            report['blockers'].append('LOCAL_LINUX_DOCKER_NOT_READY')
            return code
        if not args.execute:
            report['status'] = 'READY_TO_EXECUTE'
            report['blockers'].append('ARM64_GUEST_NOT_EXECUTED')
            return code
        rc, _ = docker_run(['pull', '--platform', ARM64_PLATFORM, BASE_TAG], 'pull_base', 600)
        if rc:
            report['status'] = 'FAIL'
            report['blockers'].append('ARM64_BASE_PULL_FAILED')
            return 2
        rc, raw = docker_run(image_inspect_arguments(BASE_TAG), 'inspect_base')
        if rc:
            raise ValueError('BASE_IMAGE_INSPECTION_FAILED')
        base = json.loads(raw)[0]
        if base.get('Architecture') != 'arm64' or base.get('Os') != 'linux':
            raise ValueError('BASE_IMAGE_NOT_ARM64_LINUX')
        digests = base.get('RepoDigests', [])
        pinned = next((x for x in digests if re.fullmatch(r'(?:docker.io/library/)?python@sha256:[a-f0-9]{64}', x)), None)
        if pinned is None:
            raise ValueError('BASE_DIGEST_MISSING')
        report['base_image'] = dict(tag=BASE_TAG, digest=pinned, image_id=base['Id'])
        tag = 'family-health-arm64-simulation:' + run_id.lower()
        rc, _ = docker_run(['build', '--platform', ARM64_PLATFORM, '--network=none',
                            '--build-arg', 'BASE_IMAGE=' + pinned, '-t', tag,
                            str(folder / 'context')], 'build', 600)
        if rc:
            raise ValueError('ARM64_BUILD_FAILED')
        rc, raw = docker_run(image_inspect_arguments(tag), 'inspect_candidate')
        if rc:
            raise ValueError('CANDIDATE_INSPECTION_FAILED')
        built = json.loads(raw)[0]
        if built.get('Architecture') != 'arm64' or built.get('Os') != 'linux':
            raise ValueError('CANDIDATE_NOT_ARM64_LINUX')
        image_id = built['Id']
        if not re.fullmatch(r'sha256:[a-f0-9]{64}', image_id):
            raise ValueError('CANDIDATE_IMAGE_ID_INVALID')
        report['candidate_image_id'] = image_id
        candidate_reference = pinned_repository_digest(built.get('RepoDigests'))
        if candidate_reference is None:
            raise ValueError('CANDIDATE_REPOSITORY_DIGEST_MISSING')
        report['candidate_image_reference'] = candidate_reference
        rc, _ = docker_run(['create', '--name', container_name, '--platform', ARM64_PLATFORM,
                            '--network=none', '--read-only', '--cap-drop=ALL',
                            '--security-opt=no-new-privileges', '--memory=4g', '--memory-swap=4g',
                            '--cpus=4', '--pids-limit=128',
                            '--tmpfs', '/tmp:rw,nosuid,nodev,size=256m,mode=1777',
                            candidate_reference], 'create')
        if rc:
            raise ValueError('CONTAINER_CREATE_FAILED')
        created_container = True
        report['stage'] = 'S1'
        rc, raw = docker_run(['start', '--attach', container_name], 'guest_run', 300)
        if rc:
            raise ValueError('ARM64_GUEST_FAILED')
        rc, state = docker_run(['inspect', '--format', '{{json .State}}', container_name], 'guest_state')
        state = json.loads(state) if rc == 0 else {}
        if state.get('ExitCode') != 0 or state.get('Running') is not False or state.get('OOMKilled') is not False:
            raise ValueError('GUEST_EXIT_OR_MEMORY_FAILURE')
        guest = json.loads(raw)
        report['guest'] = guest
        if not validate_guest(guest):
            raise ValueError('GUEST_EVIDENCE_REJECTED')
        rc, _ = docker_run([
            'create', '--name', recovery_container_name, '--platform', ARM64_PLATFORM,
            '--user', '0:0', '--network=none', '--read-only', '--cap-drop=ALL',
            '--security-opt=no-new-privileges', '--memory=256m', '--memory-swap=256m',
            '--cpus=1', '--pids-limit=64',
            '--tmpfs', '/tmp:rw,exec,nosuid,nodev,size=128m,mode=1777',
            '--tmpfs', '/runtime-tools:rw,exec,nosuid,nodev,size=4m,mode=0755',
            '--env', 'EDGE_RECOVERY_TEST_WORKSPACE=/opt/edge',
            '--env', 'EDGE_RECOVERY_TEST_TOOL_ROOT=/runtime-tools',
            '--env', 'EDGE_RUNTIME_TOOL=/opt/edge/tools/family-health-edge-tool',
            '--env', 'EDGE_RUNTIME_TOOL_SHA256=' + runtime_record['sha256'],
            '--entrypoint', '/bin/bash', candidate_reference,
            '/opt/edge/tests/linux_activation_recovery_smoke.sh',
        ], 'create_activation_recovery_container')
        if rc:
            raise ValueError('ACTIVATION_RECOVERY_CONTAINER_CREATE_FAILED')
        created_recovery_container = True
        rc, raw = docker_run(
            ['start', '--attach', recovery_container_name],
            'activation_recovery_guest_run',
            120,
        )
        if rc:
            raise ValueError('ACTIVATION_RECOVERY_GUEST_FAILED')
        rc, state = docker_run(
            ['inspect', '--format', '{{json .State}}', recovery_container_name],
            'activation_recovery_guest_state',
        )
        state = json.loads(state) if rc == 0 else {}
        if (
            state.get('ExitCode') != 0
            or state.get('Running') is not False
            or state.get('OOMKilled') is not False
        ):
            raise ValueError('ACTIVATION_RECOVERY_EXIT_OR_MEMORY_FAILURE')
        recovery_smoke = json.loads(raw)
        report['activation_recovery_smoke'] = recovery_smoke
        if not validate_recovery_smoke(recovery_smoke):
            raise ValueError('ACTIVATION_RECOVERY_EVIDENCE_REJECTED')
        report['status'] = 'PASS_ARM64_SOFTWARE'
        return 0
    except (ValueError, KeyError, TypeError, IndexError, OSError) as exc:
        report['status'] = 'FAIL'
        # Avoid arbitrary paths/contents in the public summary.
        report['blockers'].append(public_reason(exc))
        return 2
    finally:
        if created_container:
            cleanup_code, _ = run_command([docker, 'rm', '--force', container_name], ROOT,
                                          folder, records, 'cleanup_own_container', env=environment)
            report['container_cleaned'] = cleanup_code == 0
        if created_recovery_container:
            cleanup_code, _ = run_command(
                [docker, 'rm', '--force', recovery_container_name], ROOT,
                folder, records, 'cleanup_activation_recovery_container', env=environment
            )
            report['activation_recovery_container_cleaned'] = cleanup_code == 0
        report['finished_at'] = datetime.now(timezone.utc).isoformat()
        encoded = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
        (folder / 'audit.json').write_text(encoded, encoding='utf-8')
        (ROOT / 'reports/arm64_simulation_latest.json').write_text(encoded, encoding='utf-8')
        print(json.dumps({key: report[key] for key in ('run_id', 'status', 'stage', 'blockers',
                                                    'three_model_inference_verified')}, ensure_ascii=True))


if __name__ == '__main__':
    raise SystemExit(main())
