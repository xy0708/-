from __future__ import annotations

import hashlib
import json
import shutil
import sys
import zipfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = ROOT.parent / "Android迁移交付包"
APK_RELATIVE = Path("android_app/build/app/outputs/flutter-apk/app-debug.apk")

SOURCE_ROOT_FILES = (
    "同事最终验收.md",
    "Android迁移依赖.md",
    "requirement.md",
    "ANDROID_EDGE_PRODUCTION_LOOP.md",
    "EDGE_PRODUCTION_LOOP.md",
    "PRODUCT_EDGE_DEPLOYMENT_PLAN.md",
    "README.md",
    "install_android_debug.bat",
    "start_android_migration_loop.bat",
)
SOURCE_CONFIGS = (
    "android_asr_candidate.json",
    "android_runtime_registry.json",
    "device_profile.json",
    "health_rules.json",
    "linux_device_profile.archive.json",
    "linux_product_delivery_contract.archive.json",
    "product_delivery_contract.json",
    "wearable_sdk_source.json",
)
SOURCE_DOCS = (
    "docs/android_architecture.md",
    "docs/android_board_acceptance.md",
    "docs/compliance/yucheng_sdk_license_audit.md",
)
SOURCE_SCRIPTS = (
    "scripts/asset_integrity.py",
    "scripts/build_android_migration_handoff.py",
    "scripts/collect_android_preflight.py",
    "scripts/install_android_debug.py",
    "scripts/install_android_debug.ps1",
    "scripts/run_android_migration_loop.py",
    "scripts/run_flutter_android_checks.py",
    "scripts/stage_android_asr_assets.py",
    "scripts/verify_android_migration.py",
    "scripts/verify_android_handoff_archives.py",
)
SOURCE_REPORTS = (
    "reports/android_asr_asset_staging.json",
    "reports/android_device_install.json",
    "reports/android_device_preflight.json",
    "reports/android_flutter_validation.json",
    "reports/android_migration_loop_latest.json",
    "reports/android_migration_verification.json",
)
VENDOR_FILES = (
    "CHANGELOG.md",
    "LICENSE",
    "README.md",
    "analysis_options.yaml",
    "pubspec.yaml",
)
IGNORED_NAMES = {
    ".dart_tool",
    ".gradle",
    ".idea",
    ".kotlin",
    ".pytest_cache",
    ".vscode",
    "__pycache__",
    "build",
}
IGNORED_SUFFIXES = {".iml", ".pyc", ".pyo"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ignore_generated(_: str, names: list[str]) -> set[str]:
    return {
        name
        for name in names
        if name in IGNORED_NAMES or Path(name).suffix.casefold() in IGNORED_SUFFIXES
    }


def copy_file(relative: str, destination_root: Path) -> None:
    source = ROOT / relative
    if not source.is_file():
        raise FileNotFoundError(relative)
    destination = destination_root / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def copy_android_app(destination_root: Path) -> None:
    destination = destination_root / "android_app"
    shutil.copytree(ROOT / "android_app", destination, ignore=ignore_generated)
    for generated in (
        destination / ".flutter-plugins-dependencies",
        destination / "android" / "local.properties",
    ):
        if generated.exists():
            generated.unlink()


def copy_android_vendor(destination_root: Path) -> None:
    vendor_source = ROOT / "vendor" / "yucheng" / "yc_product_plugin-master" / "code"
    vendor_destination = (
        destination_root / "vendor" / "yucheng" / "yc_product_plugin-master" / "code"
    )
    vendor_destination.mkdir(parents=True, exist_ok=False)
    for folder in ("android", "lib"):
        shutil.copytree(
            vendor_source / folder,
            vendor_destination / folder,
            ignore=ignore_generated,
        )
    for filename in VENDOR_FILES:
        source = vendor_source / filename
        if source.is_file():
            shutil.copy2(source, vendor_destination / filename)

    archive_relative = Path("vendor/yucheng/yc_product_plugin-master.zip")
    archive_destination = destination_root / archive_relative
    archive_destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / archive_relative, archive_destination)


def write_manifest(folder: Path, package_type: str) -> Path:
    manifest_path = folder / "交付文件清单.json"
    files = []
    for path in sorted(item for item in folder.rglob("*") if item.is_file()):
        if path == manifest_path:
            continue
        files.append(
            {
                "path": path.relative_to(folder).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    payload = {
        "schema_version": "1.0.0",
        "package_type": package_type,
        "generated_at_local": datetime.now().astimezone().isoformat(),
        "file_count": len(files),
        "total_bytes": sum(item["bytes"] for item in files),
        "files": files,
    }
    manifest_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return manifest_path


def create_zip(folder: Path) -> Path:
    archive = folder.with_suffix(".zip")
    with zipfile.ZipFile(
        archive,
        mode="x",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=1,
        allowZip64=True,
    ) as bundle:
        for path in sorted(item for item in folder.rglob("*") if item.is_file()):
            bundle.write(path, path.relative_to(folder.parent))
    return archive


def build_source_package(destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=False)
    for relative in SOURCE_ROOT_FILES + SOURCE_DOCS + SOURCE_SCRIPTS + SOURCE_REPORTS:
        copy_file(relative, destination)
    for filename in SOURCE_CONFIGS:
        copy_file(f"configs/{filename}", destination)
    for test in sorted((ROOT / "tests").glob("test_android*.py")):
        copy_file(test.relative_to(ROOT).as_posix(), destination)
    copy_android_app(destination)
    copy_android_vendor(destination)
    write_manifest(destination, "ANDROID_MIGRATION_SOURCE")
    return create_zip(destination)


def build_install_package(destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=False)
    for relative in (
        "同事最终验收.md",
        "Android迁移依赖.md",
        "requirement.md",
        "install_android_debug.bat",
        "scripts/collect_android_preflight.py",
        "scripts/install_android_debug.py",
        "scripts/install_android_debug.ps1",
        "reports/android_flutter_validation.json",
    ):
        copy_file(relative, destination)
    copy_file(APK_RELATIVE.as_posix(), destination)
    write_manifest(destination, "ANDROID_ENGINEERING_INSTALL")
    return create_zip(destination)


def package_summary(folder: Path, archive: Path) -> dict:
    manifest = json.loads((folder / "交付文件清单.json").read_text(encoding="utf-8"))
    return {
        "folder": str(folder),
        "archive": str(archive),
        "archive_bytes": archive.stat().st_size,
        "archive_sha256": sha256(archive),
        "file_count": manifest["file_count"],
        "uncompressed_bytes": manifest["total_bytes"],
    }


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    source_folder = OUTPUT_ROOT / f"Android迁移源码_{timestamp}"
    install_folder = OUTPUT_ROOT / f"Android真机安装包_{timestamp}"
    source_archive = build_source_package(source_folder)
    install_archive = build_install_package(install_folder)
    payload = {
        "schema_version": "1.0.0",
        "status": "PASS_HANDOFF_PACKAGES_CREATED",
        "source": package_summary(source_folder, source_archive),
        "install": package_summary(install_folder, install_archive),
    }
    report = OUTPUT_ROOT / "latest_build.json"
    report.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
