from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "android_migration_loop_latest.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(name: str, command: list[str], timeout: int = 180) -> dict:
    completed = subprocess.run(
        command,
        cwd=ROOT,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
    )
    return {
        "name": name,
        "command": command,
        "exit_code": completed.returncode,
        "stdout_tail": completed.stdout[-4000:],
        "stderr_tail": completed.stderr[-4000:],
    }


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    checks = [
        run(
            "android_migration_contract",
            [sys.executable, str(ROOT / "scripts" / "verify_android_migration.py")],
        ),
        run(
            "android_migration_tests",
            [
                sys.executable,
                "-m",
                "unittest",
                "discover",
                "-s",
                "tests",
                "-p",
                "test_android*.py",
                "-v",
            ],
        ),
        run(
            "android_device_preflight",
            [sys.executable, str(ROOT / "scripts" / "collect_android_preflight.py")],
            timeout=60,
        ),
    ]
    tracked = [
        "RK3576_PHONE_WATCH_INTEGRATION_LOOP.md",
        "ANDROID_EDGE_PRODUCTION_LOOP.md",
        "configs/device_profile.json",
        "configs/product_delivery_contract.json",
        "configs/wearable_sdk_source.json",
        "configs/android_runtime_registry.json",
        "configs/android_asr_candidate.json",
        "configs/phone_edge_contract.json",
        "configs/yucheng_android_sdk_source.json",
        "docs/android_architecture.md",
        "同事最终验收.md",
        "Android迁移依赖.md",
        "docs/compliance/yucheng_sdk_license_audit.md",
        "scripts/verify_android_migration.py",
        "scripts/run_android_migration_loop.py",
        "scripts/stage_android_asr_assets.py",
        "scripts/install_android_debug.py",
        "scripts/install_android_debug.ps1",
        "scripts/build_android_migration_handoff.py",
        "scripts/verify_android_handoff_archives.py",
        "install_android_debug.bat",
        "android_app/pubspec.yaml",
        "android_app/pubspec.lock",
        "android_app/lib/main.dart",
        "android_app/lib/watch_bridge.dart",
        "android_app/lib/health_rules.dart",
        "android_app/lib/asr_model_assets.dart",
        "android_app/lib/asr_runtime.dart",
        "android_app/lib/asr_microphone.dart",
        "android_app/assets/asr_candidate.json",
        "android_app/assets/health_rules.json",
        "android_app/test/asr_runtime_test.dart",
        "android_app/test/asr_microphone_test.dart",
        "android_app/test/health_rules_test.dart",
        "android_app/android/app/build.gradle.kts",
        "android_app/android/app/src/main/AndroidManifest.xml",
        "android_app/android/app/src/main/kotlin/com/familyhealth/edge/family_health_edge_android/ModelAssetChannel.kt",
        "start_android_migration_loop.bat",
    ]
    input_hashes = {
        relative: sha256(ROOT / relative)
        for relative in tracked
        if (ROOT / relative).is_file()
    }
    local_checks = [check for check in checks if check["name"] != "android_device_preflight"]
    preflight = next(check for check in checks if check["name"] == "android_device_preflight")
    flutter_report_path = ROOT / "reports" / "android_flutter_validation.json"
    flutter_report = (
        json.loads(flutter_report_path.read_text(encoding="utf-8"))
        if flutter_report_path.is_file()
        else None
    )
    apk_path = ROOT / "android_app" / "build" / "app" / "outputs" / "flutter-apk" / "app-debug.apk"
    flutter_input_hashes = flutter_report.get("input_hashes", {}) if flutter_report else {}
    flutter_evidence_valid = bool(
        flutter_report
        and flutter_report.get("status") == "PASS_ENGINEERING_DEBUG_APK"
        and apk_path.is_file()
        and flutter_report.get("apk", {}).get("sha256") == sha256(apk_path)
        and flutter_report.get("apk_inspection", {}).get("abis") == ["arm64-v8a"]
        and flutter_report.get("apk_inspection", {}).get("asr_assets_valid") is True
        and len(flutter_input_hashes) == 15
        and all(
            (ROOT / relative).is_file()
            and sha256(ROOT / relative) == expected_hash
            for relative, expected_hash in flutter_input_hashes.items()
        )
    )
    passed = bool(
        all(check["exit_code"] == 0 for check in local_checks)
        and preflight["exit_code"] in {0, 2}
        and flutter_evidence_valid
    )
    payload = {
        "schema_version": "1.0.0",
        "run_id": datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"),
        "status": "PASS_ENGINEERING_PRODUCT_BLOCKED" if passed else "FAIL_ENGINEERING",
        "active_target": "Android",
        "product_complete": False,
        "formal_release_allowed": False,
        "checks": checks,
        "input_hashes": input_hashes,
        "flutter_validation": flutter_report,
        "flutter_evidence_valid": flutter_evidence_valid,
        "external_blockers": [
            "adb_device_not_connected",
            "wearable_binary_redistribution_rights_unknown",
            "three_model_android_runtime_not_complete",
            "release_signing_not_configured",
            "rk3576_android_acceptance_not_run",
        ],
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
