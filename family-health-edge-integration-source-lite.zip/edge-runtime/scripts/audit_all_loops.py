from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "all_loops_audit.json"


def load_reports() -> dict[str, dict]:
    paths = {
        "edge": "reports/loop_requirements_audit.json",
        "s1": "reports/arm64_simulation_latest.json",
        "s1_verification": "reports/simulation_evidence_verification.json",
        "s2": "reports/arm64_model_simulation_latest.json",
        "s2_verification": "reports/arm64_model_simulation_verification.json",
        "s3": "reports/arm64_integration_simulation_latest.json",
        "s3_verification": "reports/arm64_integration_simulation_verification.json",
        "official_lock": "reports/official_model_lock_verification.json",
        "toolchain": "reports/rknn_toolchain_lock_verification.json",
        "artifacts": "reports/official_candidate_artifacts_verification.json",
        "archive": "reports/official_research_archive_verification.json",
        "reproducibility": "reports/rknn_conversion_reproducibility_verification.json",
        "capability": "reports/rknn_exported_artifact_capability_verification.json",
        "ocr_comparison": "reports/ocr_synthetic_candidate_comparison_verification.json",
        "asr_comparison": "reports/asr_med_ch_candidate_comparison_verification.json",
        "comparison_contract": "reports/candidate_comparison_contract_verification.json",
        "runtime_registry": "reports/runtime_backend_registry_verification.json",
        "dataset_candidates": "reports/public_dataset_candidates_verification.json",
        "device": "reports/device_acceptance.json",
        "release": "reports/final_release_verification.json",
    }
    reports: dict[str, dict] = {}
    for name, relative in paths.items():
        path = ROOT / relative
        try:
            reports[name] = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            reports[name] = {}
    return reports


def report_matches(report: dict, statuses: set[str], **expected: object) -> bool:
    if report.get("status") not in statuses:
        return False
    if report.get("errors", []) != []:
        return False
    return all(report.get(key) == value for key, value in expected.items())


def evaluate(reports: dict[str, dict]) -> dict:
    edge = reports.get("edge", {})
    edge_engineering = (
        edge.get("status") in {"BLOCKED_EXTERNAL", "PASS_PRODUCT_GATE"}
        and edge.get("engineering_failures") == []
        and edge.get("contradictions") == []
    )
    arm64_engineering = all(
        (
            report_matches(
                reports.get("s1", {}),
                {"PASS_ARM64_SOFTWARE"},
                hardware_measured=False,
                three_model_inference_verified=False,
            ),
            report_matches(
                reports.get("s1_verification", {}), {"PASS_ENGINEERING"}
            ),
            report_matches(
                reports.get("s2", {}),
                {"PARTIAL_PASS_PRODUCT_BLOCKED"},
                hardware_measured=False,
                three_model_inference_verified=False,
            ),
            report_matches(
                reports.get("s2_verification", {}),
                {"PASS_ENGINEERING"},
                hardware_measured=False,
                three_model_inference_verified=False,
            ),
            report_matches(
                reports.get("s3", {}),
                {"PARTIAL_PASS_PRODUCT_BLOCKED"},
                hardware_measured=False,
                three_model_inference_verified=False,
            ),
            report_matches(
                reports.get("s3_verification", {}),
                {"PASS_ENGINEERING"},
                hardware_measured=False,
                three_model_inference_verified=False,
            ),
        )
    )
    selection_engineering = all(
        (
            report_matches(reports.get("official_lock", {}), {"PASS_ENGINEERING"}),
            report_matches(
                reports.get("toolchain", {}), {"PASS_ENGINEERING_PARTIAL"}
            ),
            report_matches(
                reports.get("ocr_comparison", {}),
                {"PASS_ENGINEERING_SYNTHETIC_PRODUCT_BLOCKED"},
                hardware_measured=False,
            ),
            report_matches(
                reports.get("asr_comparison", {}),
                {"PASS_ENGINEERING_PUBLIC_SET_PRODUCT_BLOCKED"},
                hardware_measured=False,
            ),
            report_matches(
                reports.get("comparison_contract", {}),
                {"PASS_ENGINEERING_CONTRACT_SCAFFOLD_PRODUCT_BLOCKED"},
            ),
            report_matches(
                reports.get("runtime_registry", {}), {"PASS_ENGINEERING_PARTIAL"}
            ),
            report_matches(
                reports.get("dataset_candidates", {}),
                {"PASS_ENGINEERING_PRODUCT_DATA_BLOCKED"},
                product_data_ready=False,
                charls_used=False,
            ),
        )
    )
    official_engineering = all(
        (
            report_matches(
                reports.get("artifacts", {}), {"PASS_ENGINEERING_PARTIAL"}
            ),
            report_matches(
                reports.get("archive", {}),
                {"PASS_ENGINEERING_ARCHIVED_PRODUCT_BLOCKED"},
            ),
            report_matches(
                reports.get("reproducibility", {}),
                {"PASS_ENGINEERING_REPLAY_AUDIT_PRODUCT_BLOCKED"},
                hardware_measured=False,
                product_selected=False,
            ),
            report_matches(
                reports.get("capability", {}),
                {"PASS_ENGINEERING_PRODUCT_BLOCKED"},
                hardware_measured=False,
            ),
        )
    )
    loop_checks = {
        "edge_production": edge_engineering,
        "arm64_simulation": arm64_engineering,
        "ocr_asr_backend_selection": selection_engineering,
        "rk3566_official_models": official_engineering,
    }
    engineering_failures = [name for name, passed in loop_checks.items() if not passed]
    product_complete = (
        edge.get("status") == "PASS_PRODUCT_GATE"
        and edge.get("goal_complete") is True
        and reports.get("device", {}).get("status") == "PASS_PRODUCT_GATE"
        and reports.get("device", {}).get("hardware_measured") is True
        and reports.get("release", {}).get("status") == "PASS_PRODUCT_GATE"
        and reports.get("release", {}).get("release_allowed") is True
        and reports.get("release", {}).get("formal_release_verified") is True
    )
    external_inputs = edge.get("next_external_inputs", [])
    if not isinstance(external_inputs, list):
        external_inputs = []
    all_engineering_complete = not engineering_failures
    contradictions: list[str] = []
    if product_complete and not all_engineering_complete:
        contradictions.append("PRODUCT_PASS_WITH_INCOMPLETE_ENGINEERING_LOOP")
    if all_engineering_complete and not product_complete and not external_inputs:
        contradictions.append("PRODUCT_BLOCKED_WITHOUT_EXTERNAL_INPUTS")
    status = (
        "FAIL_CONTRADICTION"
        if contradictions
        else "FAIL_ENGINEERING"
        if engineering_failures
        else "PASS_PRODUCT_GATE"
        if product_complete
        else "BLOCKED_EXTERNAL"
    )
    return {
        "status": status,
        "all_loop_documents_audited": True,
        "all_engineering_work_reachable_without_external_inputs_complete": all_engineering_complete,
        "all_product_loops_complete": product_complete,
        "loop_checks": loop_checks,
        "engineering_failures": engineering_failures,
        "contradictions": contradictions,
        "unfinished_without_external_inputs": engineering_failures,
        "unfinished_requiring_external_inputs": [] if product_complete else external_inputs,
    }


def audit_exit_code(result: dict) -> int:
    if result.get("status") == "PASS_PRODUCT_GATE":
        return 0
    if result.get("status") == "BLOCKED_EXTERNAL":
        return 2
    return 1


def main() -> int:
    result = {
        "schema_version": "1.0.0",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "documents": [
            "EDGE_PRODUCTION_LOOP.md",
            "ARM64_SIMULATION_LOOP.md",
            "OCR_ASR_BACKEND_SELECTION_LOOP.md",
            "RK3566_OFFICIAL_MODELS_PRODUCTION_LOOP.md",
        ],
        **evaluate(load_reports()),
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return audit_exit_code(result)


if __name__ == "__main__":
    raise SystemExit(main())
