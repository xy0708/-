# 三模型 ARM64 模拟验证解决方案与 Loop

## 当前新增 S3 部分集成

`start_arm64_integration_simulation.bat` 或下列命令执行 S3 的 ASR 部分集成：

```powershell
.\.venv-edge\Scripts\python.exe scripts\run_arm64_integration_simulation.py
.\.venv-edge\Scripts\python.exe scripts\verify_arm64_integration_evidence.py
```

该阶段在 Linux/aarch64 仿真中运行现有 ASR V2 的真实 Sherpa-ONNX 工作进程，使用发布根目录内相对路径和哈希绑定配置装配设备服务，并通过真实 loopback WebSocket/HTTP 完成流式输入、确认任务、取消、健康规则和资源回收。OCR 没有合规产品模型与许可，因此明确保持阻断且不使用测试替身。S3 通过只代表 ASR 与设备服务的 ARM64 工程集成通过；`hardware_measured=false`、`product_complete=false`、`three_model_inference_verified=false` 始终保持，不能替代 RK3566 真机、目标麦克风、OCR 或产品验收。

日期：2026-09-10。定位：无板卡期间的软件兼容验证；最终目标仍是可独立交付的端侧产品。

## 技术路线

Windows 11 → WSL2 → 本机 Docker Linux 引擎 → QEMU → ARM64 Linux 容器。
Docker Desktop 可提供集成的模拟支持；也可使用 WSL2 内的 Docker Engine 和已配置的 QEMU。
只连接本机引擎，不使用远程 Docker、云构建、云推理。Docker 是研发验证工具，最终设备可直接安装 ARM64 运行包。

先验证真实 ARM64 Python 和项目服务代码，再接入健康 ONNX、OCR CPU 和 ASR。资源限制是测试保护措施，不代表 RK3566 性能：4GB 内存上限、4 CPU 配额、128 PID、只读根目录、无外网、非 root、无宿主目录挂载。

## 阶段与完成门槛

| 阶段 | 执行动作 | 通过证据 |
|---|---|---|
| S0 环境 | 先在本机运行受控上下文测试，再检查 Docker CLI、本机连接、Linux daemon；固定基础镜像摘要 | 独立上下文测试、命令、退出码、镜像 ID/digest |
| S1 软件 | 显式构建 linux/arm64，在非 root 容器内运行接口、健康规则、OCR/ASR确认工作流及更新门禁测试；另以最小 root 恢复容器模拟未完成激活事务 | Linux/aarch64/64位证明、通过数量、源码哈希、旧版本指针恢复、事务标记清除、容器退出码 |
| S2 模型 | 安装锁版本 ARM64 运行库、导入已登记模型，执行现有输入的 CPU 推理及数值/文本对齐 | 每个模型真实输入/输出的本地证据与哈希；不能以测试替身代替 |
| S3 集成 | 三模块实际推理、取消、超时、资源回收、持久化恢复、离线重启 | 三模块真实适配器集成报告 |
| S4 真机 | RK3566/NPU/音频驱动、真实材料、性能、长稳、断电、升级回滚 | 原有 E04/E10/E12 真机与产品证据 |

`start_arm64_simulation.bat` 自动执行 S0/S1。S1 内 OCR/ASR 测试使用工程测试替身，只能证明工作流；健康测试执行真实规则引擎，不代表疾病模型推理。更新恢复 smoke 使用显式签名验证测试桩，只验证 Linux 上的事务标记、原子指针恢复和清理，不是密码学或断电验收。`start_arm64_model_simulation.bat` 执行 S2 可用模型验证：健康 DM/HT ONNX 和 ASR V2 已完成真实 ARM64 CPU 推理与主机对齐，OCR 因合规产品模型和许可未到位保持阻断。S2 三模型未齐、S3 未完成时 `three_model_inference_verified=false`，整个模拟任务不得标完成。

## 三个模型的后续接入

- 健康：规则引擎优先，DM/HT ONNX 仅工程候选；对齐现有 CPU 输出，禁止向产品用户暴露未经验证的疾病概率。
- OCR：沿用 PP-OCRv5；先检查已有模型格式及 Linux ARM64 CPU 运行库可用性。工程 ONNX 转换需遵守已有许可和转换边界，NPU/RKNN 必须留到真机验证。
- ASR：沿用现有 X-ASR INT8、tokens 和 Sherpa-ONNX，校验原始 manifest；ARM64 工程运行库固定为 1.13.7。1.13.4 在本机 ARM64 仿真中加载成功但返回空文本，1.13.7 已通过同版本 Windows/ARM64 文本哈希对齐。麦克风驱动和真实声学效果待真机。
- 不重新训练；不自动下载替代模型。正式独立验收仍需要授权报告和目标麦克风真人语音。CHARLS 永久排除。

## 安装和恢复

2026-09-06：普通权限安装曾返回 `0x80073d28`，随后通过管理员安装完成 WSL 2.7.13，并启用 VirtualMachinePlatform。Docker Desktop 4.89.0 已安装，Docker CLI 29.7.2 已核验；两个官方安装包均由 winget 完成哈希校验。
2026-09-10：重启完成，WSL2 与 Docker Desktop Linux 引擎已实际运行；S1 软件验证及 S2 健康/ASR 真实模型验证均已执行。Docker Desktop 商业使用仍须按官方订阅条款确认。
以下命令供以后新机器初始化使用，本机不必重复安装：

```powershell
winget install --id Microsoft.WSL --version 2.7.13 --exact --source winget
wsl --install --no-distribution
```

不自动重启、不修改现有 WSL 发行版、不停止其他 Docker 容器。基础镜像首次需要联网下载，推理/软件测试阶段使用 `--network=none`。

```powershell
cd C:\Users\45277\Desktop\模型\端侧上线
# 检查方案、受控构建上下文和本机 Docker，不安装系统软件
.\.venv-edge\Scripts\python.exe scripts\run_arm64_simulation_loop.py
# 引擎就绪后真正构建、运行 ARM64 容器
.\.venv-edge\Scripts\python.exe scripts\run_arm64_simulation_loop.py --execute
# 生成锁定 ARM64 wheel 清单并运行健康/ASR 真实模型验证；返回 3 表示预期的 OCR/RK3566 产品阻断
.\.venv-edge\Scripts\python.exe scripts\build_arm64_wheelhouse_manifest.py
.\.venv-edge\Scripts\python.exe scripts\run_arm64_model_simulation.py
.\.venv-edge\Scripts\python.exe scripts\verify_model_simulation_evidence.py
# 原有三个工程与发布门禁回归
.\.venv-edge\Scripts\python.exe scripts\run_engineering_loop.py
```

也可分别双击 `start_arm64_simulation.bat` 和 `start_arm64_model_simulation.bat`。入口只针对本机 Docker 执行，有明确超时；中断后重新执行即可，旧日志按 run ID 保留。
系统核验见 `reports/simulation_host.json`。最初管理员包装脚本曾把 WSL 的 stderr 提示当成错误，已修复；安装是否成功以该核验报告及原始安装退出码为准。

## 状态、证据和循环规则

软件报告：`reports/arm64_simulation_latest.json`；模型报告：`reports/arm64_model_simulation_latest.json`；每次运行的受控上下文、日志和报告分别保存在对应的 `*_runs/<run_id>/`。
所有结果带 `simulated=true`、`hardware_measured=false`、`product_complete=false`。基础镜像和候选镜像均按仓库 digest 固定；受控上下文只复制代码、特定工程测试、哈希锁定 wheel、已登记模型和公开测试音频，不复制整个工作区、真实健康数据、密钥、Windows 虚拟环境或训练数据。

每轮读取本方案和原端侧状态 → 预检 → 固定输入哈希 → 执行可运行阶段 → 测试与修复 → 保存报告 → 更新状态。返回码：0=S1软件模拟通过，2=已执行失败，3=环境阻塞或阶段未运行；返回0也不代表S2/S3或产品完成。
不得修改原真机报告来接纳模拟证据。S0 阻塞时继续本机工程验证，明确列出下一步；不要无限重复同一安装错误。

## 官方依据

- [微软 WSL 安装](https://learn.microsoft.com/en-us/windows/wsl/install)
- [Docker Desktop Windows 安装及要求](https://docs.docker.com/desktop/setup/install/windows-install/)
- [Docker 多平台与 QEMU 支持](https://docs.docker.com/build/building/multi-platform/)
