from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


MAX_REGISTRY_BYTES = 256 * 1024
MAX_SELECTION_BYTES = 64 * 1024
_IDENTIFIER = re.compile(r"^[a-z][a-z0-9_]{2,63}$")
_SEMVER = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_CAPABILITY = re.compile(r"^[a-z][a-z0-9_]{1,63}$")
_TOP_LEVEL_FIELDS = {
    "schema_version",
    "status",
    "product_complete",
    "fallback_policy",
    "backends",
}
_BACKEND_FIELDS = {
    "backend_id",
    "component",
    "engine",
    "status",
    "implementation_module",
    "contract_version",
    "component_version",
    "model_id",
    "model_bundle_sha256",
    "runtime_name",
    "runtime_version",
    "capabilities",
    "execution",
    "target",
    "product_accepted",
    "hardware_validated",
    "license_approved",
    "unavailable_reasons",
}
_ALLOWED_IMPLEMENTATIONS = {
    "asr_sherpa_cpu_xasr": "asr_runtime.worker",
    "ocr_rknn_ppocrv4": "ocr_runtime.rknn_worker",
}
_REQUIRED_CAPABILITIES = {
    "ocr": frozenset({"confirmation_required", "local_only", "ocr_task"}),
    "asr": frozenset(
        {"asr_stream", "confirmation_required", "local_only", "raw_audio_memory_only"}
    ),
}
_ALLOWED_STATUSES = {"ENGINEERING_READY", "BLOCKED_ENGINEERING", "PRODUCT_READY"}
_REGISTRY_BOUNDARIES = {
    "ENGINEERING_REGISTRY_PRODUCT_BLOCKED": False,
    "PRODUCT_REGISTRY_APPROVED": True,
}
_SELECTION_FIELDS = {
    "schema_version",
    "mode",
    "product_accepted",
    "fallback_allowed",
    "asr_backend_id",
    "ocr_backend_id",
    "device_service_integration_verified",
    "meaning",
}


class BackendRegistryError(ValueError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


@dataclass(frozen=True)
class BackendManifest:
    backend_id: str
    component: str
    engine: str
    status: str
    implementation_module: str | None
    contract_version: str
    component_version: str
    model_id: str
    model_bundle_sha256: str | None
    runtime_name: str
    runtime_version: str
    capabilities: tuple[str, ...]
    execution: str
    target: str
    product_accepted: bool
    hardware_validated: bool
    license_approved: bool
    unavailable_reasons: tuple[str, ...]


@dataclass(frozen=True)
class BackendRegistry:
    backends: dict[str, BackendManifest]
    fallback_allowed: bool
    product_complete: bool


@dataclass(frozen=True)
class BackendSelection:
    asr: BackendManifest
    ocr: BackendManifest | None
    product_mode: bool
    fallback_allowed: bool


def _require_identifier(value: Any, code: str) -> str:
    if not isinstance(value, str) or _IDENTIFIER.fullmatch(value) is None:
        raise BackendRegistryError(code)
    return value


def _require_semver(value: Any, code: str) -> str:
    if not isinstance(value, str) or _SEMVER.fullmatch(value) is None:
        raise BackendRegistryError(code)
    return value


def _require_boolean(value: Any, code: str) -> bool:
    if not isinstance(value, bool):
        raise BackendRegistryError(code)
    return value


def _parse_capabilities(component: str, value: Any) -> tuple[str, ...]:
    if (
        not isinstance(value, list)
        or not all(isinstance(item, str) and _CAPABILITY.fullmatch(item) for item in value)
        or len(value) != len(set(value))
    ):
        raise BackendRegistryError("BACKEND_CAPABILITIES_INVALID")
    if not _REQUIRED_CAPABILITIES[component].issubset(value):
        raise BackendRegistryError("BACKEND_CAPABILITIES_INCOMPLETE")
    return tuple(sorted(value))


def _parse_reasons(status: str, value: Any) -> tuple[str, ...]:
    if (
        not isinstance(value, list)
        or not all(isinstance(item, str) and _IDENTIFIER.fullmatch(item) for item in value)
        or len(value) != len(set(value))
    ):
        raise BackendRegistryError("BACKEND_REASONS_INVALID")
    if status == "BLOCKED_ENGINEERING" and not value:
        raise BackendRegistryError("BLOCKED_BACKEND_REASONS_MISSING")
    if status != "BLOCKED_ENGINEERING" and value:
        raise BackendRegistryError("READY_BACKEND_HAS_BLOCKERS")
    return tuple(value)


def _parse_backend(payload: Any) -> BackendManifest:
    if not isinstance(payload, dict) or set(payload) != _BACKEND_FIELDS:
        raise BackendRegistryError("BACKEND_SCHEMA_INVALID")
    backend_id = _require_identifier(payload["backend_id"], "BACKEND_ID_INVALID")
    component = payload["component"]
    if component not in _REQUIRED_CAPABILITIES:
        raise BackendRegistryError("BACKEND_COMPONENT_INVALID")
    engine = _require_identifier(payload["engine"], "BACKEND_ENGINE_INVALID")
    status = payload["status"]
    if status not in _ALLOWED_STATUSES:
        raise BackendRegistryError("BACKEND_STATUS_INVALID")
    implementation = payload["implementation_module"]
    expected_implementation = _ALLOWED_IMPLEMENTATIONS.get(backend_id)
    if implementation is not None and (
        implementation != expected_implementation or not isinstance(implementation, str)
    ):
        raise BackendRegistryError("BACKEND_IMPLEMENTATION_NOT_ALLOWLISTED")
    if status != "BLOCKED_ENGINEERING" and implementation is None:
        raise BackendRegistryError("READY_BACKEND_IMPLEMENTATION_MISSING")

    model_hash = payload["model_bundle_sha256"]
    if model_hash is not None and (
        not isinstance(model_hash, str) or _SHA256.fullmatch(model_hash) is None
    ):
        raise BackendRegistryError("BACKEND_MODEL_HASH_INVALID")
    if status != "BLOCKED_ENGINEERING" and model_hash is None:
        raise BackendRegistryError("READY_BACKEND_MODEL_HASH_MISSING")

    product_accepted = _require_boolean(payload["product_accepted"], "PRODUCT_FLAG_INVALID")
    hardware_validated = _require_boolean(payload["hardware_validated"], "HARDWARE_FLAG_INVALID")
    license_approved = _require_boolean(payload["license_approved"], "LICENSE_FLAG_INVALID")
    if status == "PRODUCT_READY" and not all(
        (product_accepted, hardware_validated, license_approved)
    ):
        raise BackendRegistryError("PRODUCT_BACKEND_GATES_INCOMPLETE")
    if status != "PRODUCT_READY" and any((product_accepted, hardware_validated, license_approved)):
        raise BackendRegistryError("NON_PRODUCT_BACKEND_GATE_OVERSTATED")

    execution = payload["execution"]
    if execution != "isolated_json_line_process":
        raise BackendRegistryError("BACKEND_EXECUTION_INVALID")
    unavailable_reasons = _parse_reasons(status, payload["unavailable_reasons"])
    if status == "BLOCKED_ENGINEERING":
        worker_missing = "product_worker_missing" in unavailable_reasons
        if implementation is None and not worker_missing:
            raise BackendRegistryError("BLOCKED_BACKEND_MISSING_WORKER_REASON")
        if implementation is not None and worker_missing:
            raise BackendRegistryError("IMPLEMENTED_BACKEND_HAS_MISSING_WORKER_REASON")

    return BackendManifest(
        backend_id=backend_id,
        component=component,
        engine=engine,
        status=status,
        implementation_module=implementation,
        contract_version=_require_semver(payload["contract_version"], "CONTRACT_VERSION_INVALID"),
        component_version=_require_semver(payload["component_version"], "COMPONENT_VERSION_INVALID"),
        model_id=_require_identifier(payload["model_id"], "MODEL_ID_INVALID"),
        model_bundle_sha256=model_hash,
        runtime_name=_require_identifier(payload["runtime_name"], "RUNTIME_NAME_INVALID"),
        runtime_version=_require_semver(payload["runtime_version"], "RUNTIME_VERSION_INVALID"),
        capabilities=_parse_capabilities(component, payload["capabilities"]),
        execution=execution,
        target=_require_identifier(payload["target"], "BACKEND_TARGET_INVALID"),
        product_accepted=product_accepted,
        hardware_validated=hardware_validated,
        license_approved=license_approved,
        unavailable_reasons=unavailable_reasons,
    )


def load_registry(path: Path) -> BackendRegistry:
    candidate = path.absolute()
    if candidate.is_symlink() or not candidate.is_file() or candidate.stat().st_size > MAX_REGISTRY_BYTES:
        raise BackendRegistryError("BACKEND_REGISTRY_PATH_UNSAFE")
    try:
        payload = json.loads(candidate.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise BackendRegistryError("BACKEND_REGISTRY_INVALID_JSON") from exc
    status = payload.get("status") if isinstance(payload, dict) else None
    product_complete = payload.get("product_complete") if isinstance(payload, dict) else None
    if (
        not isinstance(payload, dict)
        or set(payload) != _TOP_LEVEL_FIELDS
        or payload.get("schema_version") != "1.0.0"
        or status not in _REGISTRY_BOUNDARIES
        or not isinstance(product_complete, bool)
        or _REGISTRY_BOUNDARIES[status] is not product_complete
        or payload.get("fallback_policy") != "EXPLICIT_SELECTION_NO_FALLBACK"
        or not isinstance(payload.get("backends"), list)
    ):
        raise BackendRegistryError("BACKEND_REGISTRY_SCHEMA_INVALID")
    backends: dict[str, BackendManifest] = {}
    for item in payload["backends"]:
        backend = _parse_backend(item)
        if backend.backend_id in backends:
            raise BackendRegistryError("BACKEND_ID_DUPLICATED")
        backends[backend.backend_id] = backend
    if not backends:
        raise BackendRegistryError("BACKEND_REGISTRY_EMPTY")
    product_components = {
        backend.component for backend in backends.values() if backend.status == "PRODUCT_READY"
    }
    if product_complete and product_components != set(_REQUIRED_CAPABILITIES):
        raise BackendRegistryError("PRODUCT_REGISTRY_COMPONENTS_INCOMPLETE")
    if not product_complete and product_components:
        raise BackendRegistryError("ENGINEERING_REGISTRY_CONTAINS_PRODUCT_BACKEND")
    return BackendRegistry(
        backends=backends,
        fallback_allowed=False,
        product_complete=product_complete,
    )


def select_backend(
    registry: BackendRegistry,
    *,
    component: str,
    backend_id: str,
    product_mode: bool,
) -> BackendManifest:
    backend = registry.backends.get(backend_id)
    if backend is None:
        raise BackendRegistryError("BACKEND_NOT_REGISTERED")
    if backend.component != component:
        raise BackendRegistryError("BACKEND_COMPONENT_MISMATCH")
    if product_mode:
        if backend.status != "PRODUCT_READY" or not all(
            (backend.product_accepted, backend.hardware_validated, backend.license_approved)
        ):
            raise BackendRegistryError("BACKEND_NOT_PRODUCT_ACCEPTED")
    elif backend.status != "ENGINEERING_READY":
        raise BackendRegistryError("BACKEND_NOT_ENGINEERING_READY")
    return backend


def load_selection(
    path: Path,
    registry: BackendRegistry,
    *,
    product_mode: bool,
) -> BackendSelection:
    candidate = path.absolute()
    if (
        candidate.is_symlink()
        or not candidate.is_file()
        or candidate.stat().st_size > MAX_SELECTION_BYTES
    ):
        raise BackendRegistryError("BACKEND_SELECTION_PATH_UNSAFE")
    try:
        payload = json.loads(candidate.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise BackendRegistryError("BACKEND_SELECTION_INVALID_JSON") from exc
    if registry.product_complete is not product_mode:
        raise BackendRegistryError("BACKEND_REGISTRY_MODE_MISMATCH")
    expected_mode = "PRODUCT" if product_mode else "ENGINEERING"
    if (
        not isinstance(payload, dict)
        or set(payload) != _SELECTION_FIELDS
        or payload.get("schema_version") != "1.0.0"
        or payload.get("mode") != expected_mode
        or payload.get("product_accepted") is not product_mode
        or payload.get("fallback_allowed") is not registry.fallback_allowed
        or payload.get("device_service_integration_verified") is not True
        or not isinstance(payload.get("meaning"), str)
        or not payload["meaning"].strip()
        or len(payload["meaning"]) > 512
    ):
        raise BackendRegistryError("BACKEND_SELECTION_SCHEMA_INVALID")
    asr_id = payload.get("asr_backend_id")
    if not isinstance(asr_id, str):
        raise BackendRegistryError("ASR_BACKEND_SELECTION_MISSING")
    asr = select_backend(
        registry,
        component="asr",
        backend_id=asr_id,
        product_mode=product_mode,
    )
    ocr_id = payload.get("ocr_backend_id")
    if ocr_id is not None and not isinstance(ocr_id, str):
        raise BackendRegistryError("OCR_BACKEND_SELECTION_INVALID")
    ocr = (
        select_backend(
            registry,
            component="ocr",
            backend_id=ocr_id,
            product_mode=product_mode,
        )
        if isinstance(ocr_id, str)
        else None
    )
    if product_mode and ocr is None:
        raise BackendRegistryError("OCR_PRODUCT_BACKEND_SELECTION_MISSING")
    return BackendSelection(
        asr=asr,
        ocr=ocr,
        product_mode=product_mode,
        fallback_allowed=registry.fallback_allowed,
    )
