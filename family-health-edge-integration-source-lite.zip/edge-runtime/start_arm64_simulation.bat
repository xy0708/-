@echo off
cd /d "%~dp0"
".venv-edge\Scripts\python.exe" "scripts\run_arm64_simulation_loop.py" --execute
set "SIM_EXIT=%ERRORLEVEL%"
echo.
echo Exit code: %SIM_EXIT%  [0=ARM64 software pass, 2=failed, 3=environment blocked]
echo Report: reports\arm64_simulation_latest.json
pause
exit /b %SIM_EXIT%
