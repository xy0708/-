# 家庭健康管理端侧产品上线 Loop

> **历史 Linux Loop（已于 2026-10-10 被替代）**：活动目标已切换为 RK3566
> Android / `arm64-v8a`。本文件及其 Linux 报告只保留为历史工程基线；当前执行
> 入口为 `ANDROID_EDGE_PRODUCTION_LOOP.md`，不得把旧 Linux 通过状态解释为
> Android 构建、真机或产品通过。

更新日期：2026-09-01  
目标硬件：RK3566 / ARM64 Linux / 4GB RAM  
产品定位：家庭健康管理提示工具（非医疗诊断系统）

## 0. 总目标

把现有健康提示、体检报告 OCR、语音转文字三个独立工程整合为可在 RK3566 端侧设备长期离线运行、可升级、可回滚、可审计的正式产品模块。

交付对象是安装在每台用户设备上的自包含 ARM64 产品，不是开发者电脑上的 Web 页面、
统一 Demo、Windows 虚拟环境或依赖工作区路径的脚本。设备服务、稳定接口/SDK、模型、运行库、
加密存储、安装器、设备初始化和签名更新必须作为同一版本化交付链验收；最终 UI 可由独立
产品工程交付，不要求放在模型仓库。详细方案见
`PRODUCT_EDGE_DEPLOYMENT_PLAN.md`，机器边界见 `configs/product_delivery_contract.json`。

V1 的健康模块不追求疾病诊断或中国人群疾病概率预测，采用可解释规则、输入质量检查和个人历史趋势生成健康关注提示。OCR 与 ASR 负责辅助录入，所有结构化健康数据必须经用户确认后才能入库。

完成本 Loop 不等于取得监管许可。产品能否作为普通健康管理工具销售，必须结合最终预期用途、功能、宣传文案和分类界定意见判断。

## 1. 永久边界

### 1.1 健康提示边界

允许输出：

- 指标偏高、偏低或异常波动；
- 数据缺失、单位异常、测量时间过旧；
- 个人历史趋势变化；
- 健康关注等级；
- 建议复测、持续观察或咨询专业人员；
- 触发规则、输入值、单位、数据时间和规则版本。

禁止输出：

- 疾病确诊、排除诊断或治疗结论；
- 处方、用药调整或治疗方案；
- 未经中国目标人群验证的疾病概率；
- “临床级”“医院级”“诊断准确率”等无证据宣传；
- 把 NHANES、合成数据或工程 checkpoint 描述为中国人群产品模型。

统一提示语：

> 本结果仅用于家庭健康管理提示，不构成医疗诊断或治疗建议；如有不适、指标持续异常或紧急情况，请及时咨询专业医疗人员。

### 1.2 数据与模型边界

- CHARLS 永久排除：不得申请、下载、处理、训练或引用其指标作为本项目成果。
- NHANES 仅保留为工程基线与管线验证材料，不作为中国上线产品训练或验收证据。
- 合成数据仅可用于软件测试、边界测试和演示，不得用于证明真实产品性能。
- 健康 V1 默认不训练产品疾病风险模型；未来只有取得商业训练、衍生权重、部署和持续迭代权利的数据后，才可开启 ML 产品分支。
- OCR V1 以现有 PP-OCRv5 CPU 为对照，同时评估 Rockchip 官方 PP-OCRv4 Det/Rec RKNN；没有授权真实报告数据时不得正式微调，官方候选不得直接视为产品模型。
- ASR V1 以现有 X-ASR INT8 / Sherpa-ONNX CPU 为对照，同时优先评估 Rockchip 官方 Zipformer RKNN、以 Whisper RKNN 为备选；不得声称任何官方模型由本项目重新训练。
- 不得伪造数据、授权、指标、硬件结果、签字、完成状态或 `.rknn` 文件。

### 1.3 隐私边界

- 健康信息按敏感个人信息处理。
- 默认本地推理、本地存储，不上传报告图片、原始 OCR 文本、语音 PCM 或健康数值。
- 原始语音只在内存中流转，默认不落盘。
- 普通日志禁止记录报告图片、完整 OCR 文本、原始语音、姓名、证件号、联系方式和健康数值。
- 成员数据必须隔离；确认前不得入库；用户必须能够查看、更正和删除数据。
- 如未来增加云同步，必须单独建立数据流、单独同意、访问控制、保留期和安全评估，不得沿用离线版本的默认批准。

## 2. 现有工程与可复用范围

```text
健康模型/health-risk-model/
OCR/
语音转文字/家庭健康语音转文字_Codex_Goal_Loop/health_asr_codex_loop/
```

### 2.1 健康工程

- NHANES 工程基线、合成 Demo、API、ONNX 工程对齐已存在。
- `src/health_model/engineering_scores.py` 只能作为规则实现参考，当前状态仍是 `ENGINEERING_ONLY`。
- 产品 V1 必须建立独立的规则来源清单、规则版本、单位约束、缺失策略、复测策略和审核记录。
- 原有 HT、DM、Heart、Stroke 概率模型不得直接成为 V1 用户输出。

### 2.2 OCR 工程

- PP-OCRv5 本机工程基线已存在。
- 正式许可状态仍需具名法务确认。
- 没有已授权的真实体检报告开发集和独立验收集。
- 产品 ONNX、RKNN、RK3566 实机报告尚未完成。
- OCR 输出必须人工确认后才能进入健康规则模块。

### 2.3 ASR 工程

- Windows 软件链、字段提取、存储与服务测试已有工程证据。
- 当前使用官方 X-ASR INT8，不重新训练大模型。
- RK3566 真机、真实麦克风、真人录音和完整无屏交互验收尚未完成。
- ASR 结果必须播放或展示确认后才能入库。

## 3. 新上线工程目录

本 Loop 后续应建立以下目录，不复用已删除的 `统一Demo`：

```text
端侧上线/
├─ EDGE_PRODUCTION_LOOP.md
├─ LOOP_STATE.md
├─ PROGRESS.md
├─ BLOCKERS.md
├─ AGENTS.md
├─ configs/
│  ├─ product_scope.yaml
│  ├─ acceptance_contract.json
│  ├─ device_profile.json
│  └─ privacy_config.yaml
├─ docs/
│  ├─ architecture.md
│  ├─ data_flow.md
│  ├─ product_claims.md
│  ├─ compliance/
│  └─ operations/
├─ health_rules/
├─ integration_adapter/
├─ ocr_runtime/
├─ asr_runtime/
├─ device_service/
├─ storage/
├─ systemd/
├─ provisioning/
├─ update_agent/
├─ scripts/
├─ tests/
├─ reports/
├─ artifacts/
└─ release/
```

正式运行包只包含 ARM64 可执行文件、受控模型、受控配置、必要动态库、服务文件和许可清单；不得包含 Windows `.venv`、缓存、训练数据、测试原图、临时日志或开发 checkpoint。

正式运行包还不得引用开发者电脑、工作区兄弟目录或统一 Demo。模型模块必须提供可由正式
产品应用调用的版本化接口/SDK；最终界面采用何种技术由产品团队决定。

## 4. 状态定义

- `NOT_STARTED`：尚未开始。
- `IN_PROGRESS`：正在执行，已有可恢复磁盘状态。
- `PASS_ENGINEERING`：软件工程门槛通过，但不代表产品上线完成。
- `PASS_PRODUCT_GATE`：该产品门槛具有真实输入、真实证据和批准。
- `BLOCKED_EXTERNAL`：缺少硬件、许可、数据、合同、分类意见或人工批准。
- `FAIL`：已执行但未达到预先冻结的验收合同。
- `NOT_APPLICABLE`：经记录批准后确认不适用。

只有最终 Gate 返回 `PASS_PRODUCT_GATE` 才能声明该版本满足本项目的上线验收；监管许可、销售许可和宣传合规仍以真实外部结论为准。

## 5. 初始状态

| Gate | 内容 | 初始状态 | 事实依据/阻塞 |
|---|---|---|---|
| E00 | 上线 Loop | PASS_ENGINEERING | 本文件已建立 |
| E01 | 上线工程骨架与隔离环境 | NOT_STARTED | 尚未创建代码骨架 |
| E02 | 产品定位、输出和宣传边界冻结 | NOT_STARTED | 新定位尚未形成具名批准 |
| E03 | 医疗器械分类界定与法务路径 | BLOCKED_EXTERNAL | 尚无正式分类意见 |
| E04 | RK3566 板卡、系统和驱动预检 | BLOCKED_EXTERNAL | 当前没有可核验实机证据 |
| E05 | 健康 V1 规则与趋势引擎 | NOT_STARTED | 原规则仅 ENGINEERING_ONLY |
| E06 | ASR ARM64 部署 | NOT_STARTED | Windows 软件通过，RK3566 实机未验收 |
| E07 | OCR ONNX/RKNN 部署 | NOT_STARTED | 权重许可待确认，RKNN 与实机未完成 |
| E08 | 本地存储与三模块整合 | NOT_STARTED | 原统一 Demo 已删除，不作为产品基础 |
| E09 | 隐私、安全和运维 | NOT_STARTED | 尚无端侧产品级整合证据 |
| E10 | 真实输入与实机独立验收 | BLOCKED_EXTERNAL | 缺真实板卡及合规验收材料 |
| E11 | 不可变发布包、升级与回滚 | BLOCKED_EXTERNAL | 上游产品 Gate 未通过 |
| E12 | 最终上线验收 | BLOCKED_EXTERNAL | E01-E11 未全部满足 |

## 6. Gate 执行顺序

### E01：工程骨架与环境

完成：

1. 创建第 3 节目录。
2. 记录 Windows 开发环境、Linux 交叉编译环境和 RK3566 运行环境。
3. 锁定 Python/CMake/GCC、RKNN Toolkit2、RKNN Runtime、Sherpa-ONNX 和系统镜像版本。
4. 建立依赖锁、SBOM、第三方许可和 SHA-256 清单。
5. 建立 `LOOP_STATE.md`、`PROGRESS.md`、`BLOCKERS.md`。
6. 创建自动检查脚本 `scripts/verify_workspace.py`。

完成条件：目录、依赖、版本、hash 和恢复入口可由全新终端复验。

### E02：产品范围冻结

生成：

```text
configs/product_scope.yaml
docs/product_claims.md
docs/compliance/classification_assessment.md
```

必须冻结：

- 产品名称、目标用户和使用场景；
- 输入字段、输出字段和单位；
- 允许/禁止文案；
- 紧急情况处理与免责声明；
- 健康规则不确定、缺失、冲突和过期数据策略；
- OCR/ASR 人工确认流程；
- 是否包含云同步、远程访问或未成年人数据。

任何疾病诊断、疾病概率、治疗建议或患者监护功能变更，必须重新触发分类评估。

### E03：合规、许可与数据权利

生成：

```text
docs/compliance/model_license_audit.md
docs/compliance/privacy_design.md
docs/compliance/data_rights.md
docs/compliance/classification_assessment.md
```

门槛：

- PP-OCRv5 权重及依赖获得商业使用、复制、随产品分发的具名结论；
- X-ASR、Sherpa-ONNX、TTS 及依赖获得商业分发结论；
- 真实报告和真人语音分别明确开发、验收、保留、删除和展示权限；
- 医疗健康敏感个人信息具有单独同意、充分必要性和严格保护措施；
- 分类存疑时，通过国家药监局分类界定路径取得外部意见。

Codex 只能生成审计清单、技术材料和待确认项，不得代替法务或监管部门签字。

### E04：RK3566 实机预检

需要真实输入：

- RK3566 ARM64 设备、4GB RAM、存储介质；
- Linux 镜像、内核、NPU 驱动、RKNN Runtime；
- 麦克风、扬声器、声卡、GPIO/按键和网络配置；
- SSH 或串口调试通道；
- 设备序列号或匿名设备 ID。

建立 `scripts/preflight_rk3566.sh`，采集：

- CPU、内存、存储和架构；
- 内核、驱动、运行库和音频设备；
- NPU 是否可用；
- 时间、文件系统、日志和开机服务；
- 温度传感器与电源恢复能力。

无真实设备时只能完成脚本和交叉编译准备，状态保持 `BLOCKED_EXTERNAL`，不得生成假实机报告。

### E05：健康 V1 规则与趋势引擎

实现独立于旧工程 checkpoint 的产品规则引擎：

1. 输入 schema、单位、合法范围和时间戳。
2. 缺失、冲突、异常值和过期值处理。
3. 单指标关注规则。
4. 个人历史趋势、连续异常和复测策略。
5. 关注等级与建议动作。
6. 规则来源、版本、生效日期和审核状态。
7. 每次结果输出可解释触发链。
8. 禁止输出疾病概率和诊断标签。

验收：

- 规则测试与冻结的规则表逐条一致；
- 单位转换、边界值、缺失值和极端值测试全部通过；
- 无来源或未批准规则不得进入 release；
- 测试只能证明规则实现一致，不得宣称临床准确率。

未来 ML 分支只有在商业授权中国目标人群数据和独立验证到位后才能开启，并继续遵守原健康模型产品门禁。

### E06：ASR ARM64 部署

E06/E07 的官方 RKNN 候选冻结、转换、同集比较和真机选型必须先执行
`RK3566_OFFICIAL_MODELS_PRODUCTION_LOOP.md`；不得再把现有 CPU 模型误写为唯一可行路线。

执行顺序：

1. 固定现有 X-ASR INT8 模型、token、配置和 hash。
2. 在受控 Linux x86_64 环境交叉编译 Sherpa-ONNX ARM64，或使用已审计的官方 ARM64 发行物。
3. 在 RK3566 上完成文件识别、ALSA 麦克风流式识别、停止检测和字段提取。
4. 接入确认、否认、取消、超时和故障恢复状态机。
5. 确认前禁止写库；原始 PCM 默认不落盘。
6. 记录实时率、首字延迟、最终延迟、峰值内存、CPU 和温度。

真实验收集必须覆盖产品目标口令、老人语音、环境噪声、不同说话速度和设备麦克风；阈值须在测试前写入 `configs/acceptance_contract.json`，不得测试后修改。

### E07：OCR ONNX/RKNN 部署

执行顺序：

1. 冻结 PP-OCRv5 检测、识别、字典、预处理、后处理和 hash。
2. 通过许可 Gate 后导出真实 ONNX。
3. 在受控 RKNN Toolkit2 环境转换 RK3566 `.rknn`。
4. 使用合法校准材料进行 INT8 校准；不得用 NHANES、无权报告或合成数据冒充正式产品校准集。
5. 对齐原始框架、ONNX、RKNN 的检测框、文本和结构化字段。
6. 在 RK3566 测量延迟、峰值内存、NPU 占用和温度。
7. 保留旋转、模糊、压缩、复杂表格和不支持格式的拒绝/复核策略。
8. 用户确认前禁止把 OCR 字段传入健康规则引擎。

正式验收需要权利清晰的真实体检报告开发集和独立验收集。没有真实材料时可继续工程转换，但产品 Gate 保持 `BLOCKED_EXTERNAL`。

### E08：端侧整合与本地存储

实现：

- 单一设备服务调度健康、OCR 和 ASR；
- 提供供正式产品应用调用的稳定接口/SDK，统一 Demo 不作为唯一集成入口；
- 仅绑定 loopback 或 Unix Domain Socket；
- 一人一档、成员级权限与确认后写入；
- SQLite 本地存储、迁移、备份、删除和损坏恢复；
- 设备密钥不硬编码，敏感字段加密；
- 任务超时、取消、并发限制和资源回收；
- OCR/ASR/健康任一模块失败时其他模块可继续工作；
- systemd 开机启动、健康检查、崩溃重启和依赖顺序；
- 断电恢复后不重复写入、不丢失已确认记录。
- 在干净设备上不安装开发工具、不连接研发电脑也能完成首次启动和核心离线流程。

禁止把开发用 FastAPI、Windows `.venv`、缓存、测试数据和调试密钥直接复制到产品 release。

### E09：隐私、安全与运维

完成：

- 数据流图和威胁模型；
- 最小权限、成员隔离和本地认证；
- 数据加密、密钥轮换和恢复；
- 日志脱敏与日志保留期；
- 用户导出、更正、删除和撤回机制；
- 软件包、模型和配置签名/hash 校验；
- SBOM、漏洞扫描和依赖更新策略；
- 调试口、SSH、默认口令和生产模式管控；
- 事件响应、现场诊断和隐私投诉流程。

验收必须证明普通日志中不存在原始报告、完整 OCR 文本、原始语音和健康数值。

### E10：实机独立验收

在测试前冻结 `configs/acceptance_contract.json`，至少包含：

- 设备型号、系统镜像、驱动、运行库和模型 hash；
- OCR 字段准确性、拒识和人工确认指标；
- ASR 文本、健康字段、确认链和噪声场景指标；
- 健康规则实现一致性和趋势场景；
- P50/P95 延迟、峰值内存、CPU/NPU 和温度上限；
- 连续运行时长、崩溃、泄漏和自动恢复门槛；
- 断电、磁盘不足、数据库损坏、模型损坏、麦克风断开和服务崩溃；
- 无网络运行、异常网络和代理环境；
- 隐私日志扫描和网络流量检查。

规则：

- 指标阈值必须在测试前批准，测试后不得为通过验收而修改。
- 真实验收输入不得与开发调试输入混用。
- 失败样本必须保留脱敏后的错误分类和修复记录。
- 自动测试通过不代表真实产品验收通过。
- 没有 RK3566、真实报告、真人语音或具名批准时，结论只能是 `BLOCKED_EXTERNAL`。

### E11：发布、升级与回滚

正式 release 结构至少包含：

```text
release/<release_id>/
├─ bin/
│  ├─ family-health-device-service
│  ├─ integration-adapter
│  └─ update-agent
├─ models/
├─ configs/
├─ lib/
├─ systemd/
├─ migrations/
├─ licenses/
├─ sbom/
├─ reports/
├─ manifest.json
└─ rollback.json
```

要求：

- release 不可变，每个文件记录大小和 SHA-256；
- 安装前校验，安装失败自动恢复旧版本；
- 数据库迁移具备向前兼容和失败恢复；
- 模型、规则、配置和二进制版本绑定；
- 激活采用原子切换；
- 保留最后一个已验收版本；
- 支持离线升级包；
- 支持公司控制的签名 OTA、分批发布、暂停、撤回和跨 SKU 拒绝；
- 工厂初始化写入唯一设备身份、更新信任公钥和每设备数据密钥；
- 首次开机不得联网下载模型或依赖，集成方不得安装开发环境或依赖开发者工作区；
- 发布前扫描绝对开发路径、Windows 环境、统一 Demo 和未登记动态库；
- 未通过 E10 不得生成“正式上线”标签。

### E12：最终验收

只有以下全部为真，才允许本项目状态标记为 `PASS_PRODUCT_GATE`：

1. 产品范围、宣传文案和健康提示边界已批准。
2. 分类界定/法务路线已完成，未使用自我判断替代外部结论。
3. PP-OCRv5、X-ASR、Sherpa-ONNX、TTS 和所有依赖的商业分发权利已确认。
4. 健康规则来源、实现、版本和审核链完整。
5. OCR 与 ASR 真实输入独立验收通过。
6. RK3566 实机性能、稳定性、温度、断电和恢复验收通过。
7. 隐私、安全、日志和数据生命周期验收通过。
8. 安装、升级、回滚和旧版本恢复通过。
9. 正式产品应用通过冻结接口调用设备服务和三个运行时，研发电脑关机、设备断网后仍可使用。
10. 工厂初始化、设备身份、每设备密钥和签名 OTA/离线升级链通过验收。
11. release manifest、SBOM、许可、hash 和报告完整。
12. 不存在伪造数据、授权、指标、签字或硬件证据。

最终报告必须分别写明：

- 软件工程状态；
- 实机验收状态；
- 数据与许可状态；
- 隐私和安全状态；
- 分类/法务状态；
- 已知限制；
- 是否允许发布；
- 不允许发布时的真实阻塞项。

## 7. 每轮 Loop 的执行方法

每轮必须按以下顺序执行：

1. 读取本文件、`LOOP_STATE.md`、`PROGRESS.md` 和 `BLOCKERS.md`。
2. 检查长任务、设备连接、端口、磁盘、环境和上次中断状态。
3. 从 E01 到 E12 选择第一个未通过且当前可推进的 Gate。
4. 只做一个可审计的最小改动，不同时改动多个高风险边界。
5. 先运行针对性测试，再运行受影响范围的全量测试。
6. 保存命令、输入 hash、输出 hash、退出码、报告路径和错误摘要。
7. 更新 `LOOP_STATE.md`、`PROGRESS.md` 和 `BLOCKERS.md`。
8. 外部输入缺失时标记 `BLOCKED_EXTERNAL`，继续下一个不依赖该输入的工程任务。
9. 不重复训练已完成工程模型，不使用合成数据填补正式产品证据。
10. 只有 `scripts/verify_release.py` 返回 0 且全部外部门禁有真实证据时才能结束 Loop。

长任务记录必须包含：

```text
Gate:
命令:
PID:
开始时间:
输入与 SHA-256:
输出与 SHA-256:
日志:
恢复命令:
当前进度:
错误:
下一步:
```

## 8. 自动验收入口规划

上线工程建立后必须实现：

```text
scripts/verify_workspace.py
scripts/verify_product_scope.py
scripts/preflight_rk3566.sh
scripts/verify_health_rules.py
scripts/verify_asr_arm64.py
scripts/verify_ocr_rknn.py
scripts/verify_privacy.py
scripts/run_device_acceptance.py
scripts/build_release.py
scripts/verify_release.py
```

`verify_release.py` 必须 fail-closed：任何缺失证据、未知 hash、未批准配置、真实数据权利缺失、实机标志为 false 或 Gate 非 PASS 时返回非零退出码，并且不得创建正式 release。

## 9. 当前第一轮应执行的工作

不等待外部硬件即可先完成：

1. 建立上线工程骨架和状态文件。
2. 冻结产品级端侧部署计划和禁止本机依赖的机器合同。
3. 冻结健康管理提示的输入、输出、禁止文案和免责声明。
4. 把现有 `engineering_scores.py` 拆分为“可参考规则”和“待审核产品规则”，不直接复制为产品规则。
5. 建立规则来源、单位、边界和趋势测试合同。
6. 建立 PP-OCRv5、X-ASR、Sherpa-ONNX 和 TTS 的商业分发许可审计表。
7. 建立 RK3566 设备清单、系统要求、交叉编译环境和预检脚本。
8. 把原健康/OCR 文档中的 RK3568 目标迁移为真实目标 RK3566，保留变更记录。
9. 建立产品验收合同模板，所有数值阈值保持“待产品负责人批准”，不得先跑结果再倒推阈值。

外部输入到位后继续：

1. 连接真实 RK3566 并运行预检。
2. 先部署 ASR ARM64 CPU 链。
3. 再完成 OCR ONNX/RKNN 和 NPU 链。
4. 完成健康规则、本地存储、确认流程和 systemd 整合。
5. 使用权利清晰的真实报告、真人语音和真实设备执行独立验收。
6. 完成许可、隐私、安全、分类和具名批准。
7. 构建不可变 release，验证升级与回滚。

## 10. 官方参考入口

- 国家药监局医疗器械分类界定：<https://zwfw.nmpa.gov.cn/web/taskview/11100000MB0341032Y100207202300001>
- 《个人信息保护法》：<https://www.cac.gov.cn/2021-08/20/c_1631050028355286.htm>
- RKNN Toolkit2：<https://github.com/airockchip/rknn-toolkit2>
- Sherpa-ONNX Embedded Linux AArch64：<https://k2-fsa.github.io/sherpa/onnx/install/aarch64-embedded-linux.html>

以上链接仅作为工程和合规入口；具体版本、许可、监管结论和适用性必须在每次发布前重新核验。
