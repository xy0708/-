@echo off
setlocal
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "scripts\install_android_debug.ps1"
set "INSTALL_EXIT=%ERRORLEVEL%"
echo.
if "%INSTALL_EXIT%"=="0" (
  echo Android engineering APK installed and launched.
) else (
  echo Android install is blocked or failed. See reports\android_device_install.json
)
exit /b %INSTALL_EXIT%
