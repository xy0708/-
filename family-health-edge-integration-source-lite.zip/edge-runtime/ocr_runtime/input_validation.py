from __future__ import annotations

import base64
import binascii
import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any

from storage import TaskStateError


MAX_OCR_IMAGE_BYTES = 8 * 1024 * 1024
MAX_OCR_RESULT_BYTES = 256 * 1024
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


@dataclass(frozen=True)
class OcrImageInput:
    media_type: str
    data: bytes
    sha256: str

    def adapter_payload(self) -> dict[str, Any]:
        return {
            "media_type": self.media_type,
            "image_base64": base64.b64encode(self.data).decode("ascii"),
            "sha256": self.sha256,
        }


def normalize_ocr_input(payload: dict[str, Any]) -> OcrImageInput:
    image = payload.get("image")
    if not isinstance(image, dict):
        raise TaskStateError("INPUT_INVALID", "image object is required")
    media_type = image.get("media_type")
    encoded = image.get("data_base64")
    if media_type not in {"image/png", "image/jpeg"} or not isinstance(encoded, str):
        raise TaskStateError("INPUT_INVALID", "OCR accepts PNG or JPEG base64 input")
    if len(encoded) > ((MAX_OCR_IMAGE_BYTES + 2) // 3) * 4 + 8:
        raise TaskStateError("INPUT_OUT_OF_RANGE", "OCR image exceeds byte limit")
    try:
        data = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise TaskStateError("INPUT_INVALID", "invalid base64 image") from exc
    if not data or len(data) > MAX_OCR_IMAGE_BYTES:
        raise TaskStateError("INPUT_OUT_OF_RANGE", "OCR image size is invalid")
    if media_type == "image/png":
        if len(data) < 24 or not data.startswith(PNG_SIGNATURE) or data[12:16] != b"IHDR":
            raise TaskStateError("INPUT_INVALID", "PNG signature or IHDR is invalid")
        width = int.from_bytes(data[16:20], "big")
        height = int.from_bytes(data[20:24], "big")
        if width < 1 or height < 1 or width > 20000 or height > 20000:
            raise TaskStateError("INPUT_OUT_OF_RANGE", "PNG dimensions are invalid")
    elif not (len(data) >= 4 and data.startswith(b"\xff\xd8") and data.endswith(b"\xff\xd9")):
        raise TaskStateError("INPUT_INVALID", "JPEG markers are invalid")
    digest = hashlib.sha256(data).hexdigest()
    claimed = image.get("sha256")
    if claimed is not None:
        if not isinstance(claimed, str) or not re.fullmatch(r"[0-9a-f]{64}", claimed):
            raise TaskStateError("INPUT_INVALID", "image sha256 is invalid")
        if claimed != digest:
            raise TaskStateError("MODEL_HASH_MISMATCH", "image sha256 mismatch")
    return OcrImageInput(media_type, data, digest)


def validate_ocr_result(result: Any) -> dict[str, Any]:
    if not isinstance(result, dict):
        raise TaskStateError("COMPONENT_NOT_READY", "OCR adapter result must be an object")
    try:
        encoded = json.dumps(result, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise TaskStateError("COMPONENT_NOT_READY", "OCR adapter returned unsafe content") from exc
    if len(encoded) > MAX_OCR_RESULT_BYTES:
        raise TaskStateError("INPUT_OUT_OF_RANGE", "OCR result exceeds review limit")
    return result
