from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
import platform
import re
import sys
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO, Protocol


CAPABILITIES = ["confirmation_required", "local_only", "ocr_task"]
MAX_IMAGE_BYTES = 8 * 1024 * 1024
MAX_MANIFEST_BYTES = 256 * 1024
MAX_REQUEST_BYTES = 12 * 1024 * 1024
MAX_RESPONSE_BYTES = 512 * 1024
MAX_LINES = 512
MAX_LINE_CHARACTERS = 2_048
MAX_TOTAL_CHARACTERS = 65_536
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
_MEMBER_ID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_COMMIT = re.compile(r"^[0-9a-f]{40}$")
_FILE_KEYS = {
    "detector",
    "recognizer",
    "dictionary",
    "postprocess_init",
    "db_postprocess",
    "operators",
    "rec_postprocess",
}
PIPELINE = {
    "det_input_height": 480,
    "det_input_width": 480,
    "rec_input_height": 48,
    "rec_input_width": 320,
    "det_threshold": 0.3,
    "box_threshold": 0.6,
    "max_candidates": 1000,
    "unclip_ratio": 1.5,
    "use_dilation": False,
    "score_mode": "fast",
    "drop_score": 0.5,
}


class WorkerProtocolError(RuntimeError):
    pass


class ModelIntegrityError(RuntimeError):
    pass


@dataclass(frozen=True)
class Recognition:
    text: str
    confidence: float
    box: list[list[float]]


@dataclass(frozen=True)
class WorkerAssets:
    manifest: dict[str, Any]
    files: dict[str, Path]


class OcrEngine(Protocol):
    def recognize(self, image_bytes: bytes) -> list[Recognition]: ...

    def close(self) -> None: ...


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def model_bundle_sha256(detector: Path, recognizer: Path) -> str:
    digest = hashlib.sha256()
    for path in (detector, recognizer):
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
    return digest.hexdigest()


def _safe_file(release_root: Path, relative: object) -> Path:
    if not isinstance(relative, str):
        raise ModelIntegrityError("manifest file path is invalid")
    requested = Path(relative)
    if requested.is_absolute() or ".." in requested.parts:
        raise ModelIntegrityError("manifest file path escapes release root")
    candidate = release_root.joinpath(requested)
    current = release_root
    for part in requested.parts:
        current = current / part
        if current.is_symlink():
            raise ModelIntegrityError("manifest file path contains a symlink")
    if not candidate.is_file():
        raise ModelIntegrityError("manifest file is missing")
    try:
        candidate.resolve(strict=True).relative_to(release_root)
    except (OSError, ValueError) as exc:
        raise ModelIntegrityError("manifest file path is unsafe") from exc
    return candidate


def _verify_file_record(release_root: Path, record: object) -> Path:
    if not isinstance(record, dict) or set(record) != {"path", "bytes", "sha256"}:
        raise ModelIntegrityError("manifest file record is invalid")
    path = _safe_file(release_root, record["path"])
    expected_bytes = record["bytes"]
    expected_hash = record["sha256"]
    if (
        not isinstance(expected_bytes, int)
        or isinstance(expected_bytes, bool)
        or expected_bytes < 0
        or not isinstance(expected_hash, str)
        or _SHA256.fullmatch(expected_hash) is None
        or path.stat().st_size != expected_bytes
        or sha256(path) != expected_hash
    ):
        raise ModelIntegrityError("manifest file integrity check failed")
    return path


def load_and_verify_manifest(
    release_root: Path,
    manifest_path: Path,
    *,
    expected_product_mode: bool = False,
) -> WorkerAssets:
    root_input = release_root.absolute()
    if root_input.is_symlink() or not root_input.is_dir():
        raise ModelIntegrityError("release root is unsafe")
    root = root_input.resolve(strict=True)
    manifest = manifest_path.absolute()
    if (
        manifest.is_symlink()
        or not manifest.is_file()
        or manifest.stat().st_size > MAX_MANIFEST_BYTES
    ):
        raise ModelIntegrityError("worker manifest is unsafe")
    try:
        manifest.resolve(strict=True).relative_to(root)
    except (OSError, ValueError) as exc:
        raise ModelIntegrityError("worker manifest escapes release root") from exc
    try:
        payload = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ModelIntegrityError("worker manifest is invalid JSON") from exc
    required_fields = {
        "schema_version",
        "status",
        "target",
        "runtime_name",
        "runtime_version",
        "source_commit",
        "model_bundle_sha256",
        "product_accepted",
        "hardware_validated",
        "license_approved",
        "postprocess_root",
        "pipeline",
        "files",
    }
    expected_status = (
        "PRODUCT_WORKER_APPROVED"
        if expected_product_mode
        else "ENGINEERING_WORKER_IMPLEMENTED_PRODUCT_BLOCKED"
    )
    if (
        not isinstance(payload, dict)
        or set(payload) != required_fields
        or payload.get("schema_version") != "1.0.0"
        or payload.get("status") != expected_status
        or payload.get("target") != "rk3566"
        or payload.get("runtime_name") != "rknn_toolkit_lite2"
        or payload.get("runtime_version") != "2.3.2"
        or payload.get("product_accepted") is not expected_product_mode
        or payload.get("hardware_validated") is not expected_product_mode
        or payload.get("license_approved") is not expected_product_mode
        or payload.get("pipeline") != PIPELINE
        or not isinstance(payload.get("source_commit"), str)
        or _COMMIT.fullmatch(payload["source_commit"]) is None
        or not isinstance(payload.get("model_bundle_sha256"), str)
        or _SHA256.fullmatch(payload["model_bundle_sha256"]) is None
    ):
        raise ModelIntegrityError("OCR manifest boundary is invalid")
    records = payload.get("files")
    if not isinstance(records, dict) or set(records) != _FILE_KEYS:
        raise ModelIntegrityError("engineering OCR file set is invalid")
    files = {name: _verify_file_record(root, record) for name, record in records.items()}
    postprocess_root = payload.get("postprocess_root")
    if not isinstance(postprocess_root, str):
        raise ModelIntegrityError("postprocess root is invalid")
    expected_postprocess_root = (root / postprocess_root).resolve(strict=True)
    for name in ("postprocess_init", "db_postprocess", "operators", "rec_postprocess"):
        if files[name].parent.resolve(strict=True) != expected_postprocess_root / "utils":
            raise ModelIntegrityError("postprocess source is outside the frozen root")
    bundle_hash = model_bundle_sha256(files["detector"], files["recognizer"])
    if bundle_hash != payload["model_bundle_sha256"]:
        raise ModelIntegrityError("engineering OCR bundle hash mismatch")
    return WorkerAssets(payload, files)


def read_request(stream: BinaryIO) -> dict[str, Any]:
    raw = stream.readline(MAX_REQUEST_BYTES + 1)
    if not raw or len(raw) > MAX_REQUEST_BYTES or not raw.endswith(b"\n"):
        raise WorkerProtocolError("invalid request framing")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise WorkerProtocolError("invalid request JSON") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("op"), str):
        raise WorkerProtocolError("invalid request object")
    return payload


def send(result: dict[str, Any]) -> None:
    raw = json.dumps(
        {"ok": True, "result": result},
        ensure_ascii=False,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8") + b"\n"
    if len(raw) > MAX_RESPONSE_BYTES:
        raise WorkerProtocolError("response exceeds limit")
    sys.stdout.buffer.write(raw)
    sys.stdout.buffer.flush()


def send_fixed_error(code: str = "COMPONENT_NOT_READY") -> None:
    allowed = {"COMPONENT_NOT_READY", "MODEL_HASH_MISMATCH"}
    raw = json.dumps(
        {"ok": False, "error": {"code": code if code in allowed else "COMPONENT_NOT_READY"}},
        separators=(",", ":"),
    ).encode("ascii") + b"\n"
    try:
        sys.stdout.buffer.write(raw)
        sys.stdout.buffer.flush()
    except OSError:
        pass


def ready_metadata(manifest: dict[str, Any]) -> dict[str, Any]:
    return {
        "ready": True,
        "contract_version": "1.0.0",
        "component_version": "1.0.0",
        "capabilities": CAPABILITIES,
        "model_sha256": manifest["model_bundle_sha256"],
        "reason": None,
    }


def _decode_image_payload(request: dict[str, Any]) -> tuple[bytes, str]:
    payload = request.get("payload")
    if (
        request.get("op") != "create_task"
        or not isinstance(request.get("member_id"), str)
        or _MEMBER_ID.fullmatch(request["member_id"]) is None
        or not isinstance(payload, dict)
        or set(payload) != {"media_type", "image_base64", "sha256"}
    ):
        raise WorkerProtocolError("invalid OCR task request")
    media_type = payload.get("media_type")
    encoded = payload.get("image_base64")
    expected_hash = payload.get("sha256")
    if (
        media_type not in {"image/png", "image/jpeg"}
        or not isinstance(encoded, str)
        or len(encoded) > ((MAX_IMAGE_BYTES + 2) // 3) * 4 + 8
        or not isinstance(expected_hash, str)
        or _SHA256.fullmatch(expected_hash) is None
    ):
        raise WorkerProtocolError("invalid OCR image metadata")
    try:
        image = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise WorkerProtocolError("invalid OCR image encoding") from exc
    if not image or len(image) > MAX_IMAGE_BYTES:
        raise WorkerProtocolError("invalid OCR image size")
    if media_type == "image/png":
        valid_container = len(image) >= 24 and image.startswith(PNG_SIGNATURE) and image[12:16] == b"IHDR"
    else:
        valid_container = len(image) >= 4 and image.startswith(b"\xff\xd8") and image.endswith(b"\xff\xd9")
    if not valid_container or hashlib.sha256(image).hexdigest() != expected_hash:
        raise ModelIntegrityError("OCR image integrity check failed")
    return image, expected_hash


def _serialize_recognitions(items: list[Recognition]) -> tuple[list[dict[str, Any]], str]:
    if len(items) > MAX_LINES:
        raise WorkerProtocolError("OCR line count exceeds limit")
    lines: list[dict[str, Any]] = []
    text_parts: list[str] = []
    total_characters = 0
    for item in items:
        text = item.text.strip()
        box = item.box
        if (
            not text
            or len(text) > MAX_LINE_CHARACTERS
            or not isinstance(item.confidence, (int, float))
            or isinstance(item.confidence, bool)
            or not math.isfinite(float(item.confidence))
            or not 0.0 <= float(item.confidence) <= 1.0
            or len(box) != 4
            or any(
                len(point) != 2
                or any(
                    not isinstance(value, (int, float))
                    or isinstance(value, bool)
                    or not math.isfinite(float(value))
                    for value in point
                )
                for point in box
            )
        ):
            raise WorkerProtocolError("OCR engine returned invalid content")
        total_characters += len(text)
        if total_characters > MAX_TOTAL_CHARACTERS:
            raise WorkerProtocolError("OCR text exceeds limit")
        text_parts.append(text)
        lines.append(
            {
                "text": text,
                "confidence": float(item.confidence),
                "box": [[float(value) for value in point] for point in box],
            }
        )
    return lines, "\n".join(text_parts)


def execute_task(
    request: dict[str, Any], assets: WorkerAssets, engine: OcrEngine
) -> dict[str, Any]:
    image, image_hash = _decode_image_payload(request)
    lines, full_text = _serialize_recognitions(engine.recognize(image))
    return {
        "full_text": full_text,
        "lines": lines,
        "input_sha256": image_hash,
        "model_sha256": assets.manifest["model_bundle_sha256"],
        "requires_confirmation": True,
    }


def assert_rk3566_host(
    machine: str | None = None,
    compatible_path: Path = Path("/proc/device-tree/compatible"),
    system: str | None = None,
) -> None:
    architecture = (machine or platform.machine()).lower()
    operating_system = system or platform.system()
    if operating_system != "Linux" or architecture not in {"aarch64", "arm64"}:
        raise RuntimeError("RKNN OCR requires Linux aarch64")
    with compatible_path.open("rb") as stream:
        compatible = stream.read(4096).lower()
    if b"rk3566" not in compatible:
        raise RuntimeError("RKNN OCR requires an RK3566 device")


@contextmanager
def _native_logs_to_stderr():
    sys.stdout.flush()
    saved_stdout = os.dup(sys.stdout.fileno())
    try:
        os.dup2(sys.stderr.fileno(), sys.stdout.fileno())
        yield
    finally:
        os.dup2(saved_stdout, sys.stdout.fileno())
        os.close(saved_stdout)


class RknnLiteModel:
    def __init__(self, path: Path, expected_runtime_version: str) -> None:
        installed = importlib.metadata.version("rknn-toolkit-lite2")
        if installed != expected_runtime_version:
            raise RuntimeError("RKNN Lite runtime version mismatch")
        from rknnlite.api import RKNNLite

        self._runtime = RKNNLite(verbose=False)
        try:
            with _native_logs_to_stderr():
                if self._runtime.load_rknn(str(path)) != 0:
                    raise RuntimeError("RKNN model load failed")
                if self._runtime.init_runtime() != 0:
                    raise RuntimeError("RKNN runtime initialization failed")
                sdk_version = str(self._runtime.get_sdk_version())
        except Exception:
            self.close()
            raise
        if expected_runtime_version not in sdk_version:
            self.close()
            raise RuntimeError("RKNN driver/runtime compatibility check failed")

    def run(self, image: Any) -> Any:
        import numpy as np

        with _native_logs_to_stderr():
            outputs = self._runtime.inference(
                inputs=[image[np.newaxis, ...]],
                data_format=["nhwc"],
            )
        if not outputs:
            raise RuntimeError("RKNN inference returned no output")
        return np.asarray(outputs[0], dtype=np.float32)

    def close(self) -> None:
        runtime = getattr(self, "_runtime", None)
        if runtime is not None:
            with _native_logs_to_stderr():
                runtime.release()
            self._runtime = None


class PpOcrRknnEngine:
    def __init__(self, assets: WorkerAssets) -> None:
        assert_rk3566_host()
        self._np, self._cv2 = self._load_numeric_dependencies()
        self._postprocess = self._load_postprocess(assets)
        runtime_version = assets.manifest["runtime_version"]
        self._detector = RknnLiteModel(assets.files["detector"], runtime_version)
        try:
            self._recognizer = RknnLiteModel(assets.files["recognizer"], runtime_version)
        except Exception:
            self._detector.close()
            raise

    @staticmethod
    def _load_numeric_dependencies() -> tuple[Any, Any]:
        import cv2
        import numpy as np

        return np, cv2

    def _load_postprocess(self, assets: WorkerAssets) -> tuple[Any, Any, Any]:
        db_module = self._load_verified_module(
            "family_health_ppocr_db_postprocess", assets.files["db_postprocess"]
        )
        rec_module = self._load_verified_module(
            "family_health_ppocr_rec_postprocess", assets.files["rec_postprocess"]
        )
        return (
            db_module.DBPostProcess(
                thresh=PIPELINE["det_threshold"],
                box_thresh=PIPELINE["box_threshold"],
                max_candidates=PIPELINE["max_candidates"],
                unclip_ratio=PIPELINE["unclip_ratio"],
                use_dilation=PIPELINE["use_dilation"],
                score_mode=PIPELINE["score_mode"],
            ),
            db_module.DetPostProcess(),
            rec_module.CTCLabelDecode(
                character_dict_path=str(assets.files["dictionary"]),
                use_space_char=True,
            ),
        )

    @staticmethod
    def _load_verified_module(name: str, path: Path) -> Any:
        specification = importlib.util.spec_from_file_location(name, path)
        if specification is None or specification.loader is None:
            raise RuntimeError("frozen OCR postprocess module cannot be loaded")
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        return module

    def recognize(self, image_bytes: bytes) -> list[Recognition]:
        image = self._cv2.imdecode(
            self._np.frombuffer(image_bytes, dtype=self._np.uint8),
            self._cv2.IMREAD_COLOR,
        )
        if image is None:
            raise WorkerProtocolError("OCR image cannot be decoded")
        det_size = (PIPELINE["det_input_width"], PIPELINE["det_input_height"])
        resized = self._cv2.resize(image, det_size)
        detector, det_filter, decoder = self._postprocess
        det_output = self._detector.run(resized)
        shape = self._np.asarray(
            [[PIPELINE["det_input_height"], PIPELINE["det_input_width"], 1.0, 1.0]],
            dtype=self._np.float32,
        )
        boxes = detector({"maps": det_output}, shape)[0]["points"]
        boxes = det_filter.filter_tag_det_res(boxes, resized.shape)
        results: list[Recognition] = []
        for box in self._sort_boxes(boxes):
            crop = self._rotate_crop(resized, box.copy())
            rec_size = (PIPELINE["rec_input_width"], PIPELINE["rec_input_height"])
            rec_input = self._cv2.resize(crop, rec_size).astype(self._np.float32) / 255.0
            text, confidence = decoder(self._recognizer.run(rec_input))[0]
            if float(confidence) >= PIPELINE["drop_score"]:
                results.append(
                    Recognition(
                        str(text),
                        float(confidence),
                        self._np.asarray(box, dtype=self._np.float32).tolist(),
                    )
                )
        return results

    def _rotate_crop(self, image: Any, points: Any) -> Any:
        width = int(
            max(
                self._np.linalg.norm(points[0] - points[1]),
                self._np.linalg.norm(points[2] - points[3]),
            )
        )
        height = int(
            max(
                self._np.linalg.norm(points[0] - points[3]),
                self._np.linalg.norm(points[1] - points[2]),
            )
        )
        if width < 1 or height < 1:
            raise WorkerProtocolError("OCR engine returned a degenerate box")
        target = self._np.float32(
            [[0, 0], [width, 0], [width, height], [0, height]]
        )
        transform = self._cv2.getPerspectiveTransform(points, target)
        cropped = self._cv2.warpPerspective(
            image,
            transform,
            (width, height),
            borderMode=self._cv2.BORDER_REPLICATE,
            flags=self._cv2.INTER_CUBIC,
        )
        return self._np.rot90(cropped) if cropped.shape[0] / cropped.shape[1] >= 1.5 else cropped

    @staticmethod
    def _sort_boxes(boxes: Any) -> list[Any]:
        ordered = list(sorted(boxes, key=lambda box: (box[0][1], box[0][0])))
        for index in range(len(ordered) - 1):
            for prior in range(index, -1, -1):
                next_box = ordered[prior + 1]
                current_box = ordered[prior]
                if abs(next_box[0][1] - current_box[0][1]) >= 10:
                    break
                if next_box[0][0] >= current_box[0][0]:
                    break
                ordered[prior], ordered[prior + 1] = next_box, current_box
        return ordered

    def close(self) -> None:
        recognizer = getattr(self, "_recognizer", None)
        detector = getattr(self, "_detector", None)
        if recognizer is not None:
            recognizer.close()
        if detector is not None:
            detector.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--product-mode", action="store_true")
    arguments = parser.parse_args()
    try:
        assets = load_and_verify_manifest(
            arguments.release_root,
            arguments.manifest,
            expected_product_mode=arguments.product_mode,
        )
        request = read_request(sys.stdin.buffer)
        if request["op"] not in {"health", "create_task"}:
            raise WorkerProtocolError("unsupported operation")
        engine = PpOcrRknnEngine(assets)
        try:
            result = (
                ready_metadata(assets.manifest)
                if request["op"] == "health"
                else execute_task(request, assets, engine)
            )
        finally:
            engine.close()
        send(result)
        return 0
    except ModelIntegrityError:
        send_fixed_error("MODEL_HASH_MISMATCH")
        return 2
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, WorkerProtocolError):
        send_fixed_error()
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
