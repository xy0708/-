# LOOP_STATE

## 活动 RK3576 手机—手表—端侧快照（2026-10-15，Asia/Shanghai）

- 唯一活动目标：正式手机 Flutter APP + 玉成 Android SDK 2.0 + RK3576 Android 14
  `arm64-v8a`；旧 RK3566 Android 和 Linux 证据只作历史基线。
- 当前计划与门禁：`RK3576_PHONE_WATCH_INTEGRATION_LOOP.md`；最新总控 Run
  `20261015T132101Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`。契约、14 项 Android
  门禁、13 项端侧应用测试、5 项故障隔离测试和 loopback HTTP smoke 通过；
  Flutter analyze 为 0 问题，Flutter 测试 151/151 通过。
- 正式手机 APP 的手表网关默认失败关闭，模拟设备只能由测试显式注入；真实 SDK
  适配器尚未接入。健康路由现在强制成员 ID 与令牌授权匹配。
- 手机端 HTTPS/WSS 协议客户端已覆盖健康评估、OCR 任务创建/查询/取消/幂等确认
  和 ASR 16 kHz mono s16le 流；OCR 在手机侧校验 PNG/JPEG、8 MiB 和 SHA-256，
  ASR 在手机侧限制 64 KiB 分片、120 秒并拒绝原始音频落盘声明。手机个人页已有
  内存态工程配对与版本验证，OCR 页面已接入真实任务并移除静默 Mock；健康页面已
  接入用户确认脉搏的真实端侧非诊断接口，并拒绝任何诊断/疾病概率返回。手表自动
  输入和 ASR 页面仍未接入，RK3576 Android HTTPS/WSS 服务也尚未实现。
- 手机端健康、预警与登录的 Mock 回退现在默认关闭；只有显式构建参数
  `ALLOW_DEMO_DATA=true` 才能启用，并显示“仅工程演示”角标。正式模式服务失败会
  明确报错、清除失效演示令牌，并防止切换成员后残留上一人的健康数据。
- 厂家 SDK 快照与核心 AAR 已有哈希；内嵌二进制商业再分发仍无具名结论。
- 当前源码 arm64 Debug APK 已重建并哈希绑定：132,230,166 字节，SHA-256
  `b24f38742795b7d127e9ec05afd4810344e1fe3f2928b13418fbd908969bd25b`，包内只含
  `arm64-v8a`，APK Signature Scheme v2 验证通过。签名者仍是 Android Debug，且
  没有手机安装证据；release 缺少正式签名时不再回退 debug 签名。
- W09/W10 仍阻断：没有真实手表、RK3576、可用 Android HTTPS 服务、正式认证配对、
  授权、签名与独立真机验收。`product_complete=false`，`formal_release_allowed=false`。

以下 2026-10-11 的 RK3566 Android 快照保留为历史，不代表当前目标状态。

## 活动 Android 快照（2026-10-11 20:31，Asia/Shanghai）

- 唯一活动产品目标已从 ARM64 Linux 改为 RK3566 Android / `arm64-v8a`；旧
  systemd、ALSA、Unix Socket、Linux ELF/PyInstaller 与容器报告均保留为历史基线。
- Android Loop：`ANDROID_EDGE_PRODUCTION_LOOP.md`；最新 Run
  `20261011T124232Z` 为 `PASS_ENGINEERING_PRODUCT_BLOCKED`。
- Flutter 3.41.7 / Dart 3.11.5、Java 21、SDK 35/36、NDK 28.2 已完成工程构建；
  `flutter analyze` 0 问题、Flutter 测试 15/15、Android 迁移测试 11/11 通过。
- arm64 调试 APK 已生成：248,231,253 字节，SHA-256
  `92225ad4428885f314a62322b80bbd8595853d7d15b0efe07ec5c2e8d6f499f7`。
- APK 内容门禁通过：只含 `arm64-v8a`；供应商 AAR 带入的外部存储、粗略定位、
  精确定时权限及可导出 DFU/MQTT 组件已剔除；备份、明文流量和 largeHeap 已关闭。
- 健康非诊断规则已嵌入 Android APK，配置与根规则文件 SHA-256 一致；规则仍待具名
  产品/领域批准。ASR 的 X-ASR 权重、Sherpa/ONNX arm64 原生库与运行时已打包并
  通过包内哈希审计；16 kHz PCM 麦克风入口已接入并通过本地测试，但未在
  Android/RK3566 执行；OCR runtime
  仍不存在。两者都不会继承旧 Linux 运行结果。
- ADB 当前无授权设备，故 Android 版本/API/指纹、手表连通、三模型 Android 真机
  推理、RKNPU/RKNN、性能、温度和长稳均未验收。
- 手表 SDK 源码快照已固定，但仍是可变 master；内嵌 AAR/JAR/SO 未发现许可
  NOTICE，商业再分发未批准，不能进入正式销售包。
- 当前结论：Android 工程迁移第一阶段通过；`product_complete=false`、
  `formal_release_allowed=false`，不是正式 release。
- 已生成并逐文件校验 Android 迁移源码 ZIP 与真机安装 ZIP；源码包剔除 Linux 运行物、
  虚拟环境和构建缓存，安装包包含哈希绑定的 arm64 调试 APK。真机结论仍待持板同事回传。

> 以下 2026-09 内容是 Linux 历史快照，不再代表活动产品目标。

更新时间：2026-09-24（Asia/Shanghai）

## 最新执行快照（2026-09-24 17:34）

- 最新总控 Run：`20260923T142431Z`，状态 `PASS_ENGINEERING_PRODUCT_BLOCKED`；42/42 项检查符合预期，`unexpected_checks=[]`，绑定 285 个输入和 52 个输出，独立复验 `PASS_ENGINEERING`、`errors=[]`，未创建正式 release。
- 本项目全量测试：279 项运行，272 通过、7 项仅因 Windows 缺少相应符号链接/FIFO 能力而跳过；健康、OCR、ASR 三个上游工程回归均通过。
- 四份 Loop 已由 `reports/all_loops_audit.json` 统一审计：4/4 当前可本地推进的工程边界均通过，`unfinished_without_external_inputs=[]`；产品 Loop 未完成，仍只缺真 RK3566、合规真实数据、具名审批与密钥/签名基础设施。
- 公开数据检索现登记 37 项候选；中央账本已纠正为 2 份健康工程数据实际落盘并逐文件核对摘要：Rich Healthcare DM（MD5 `b468cc...2856`）和杭州 SUA/CVD HT（SHA-256 `0824bc...dc63`）。两者已用于工程 shadow 训练，但都未获本项目具名产品批准，`selected_product_dataset=null`。Common Voice 27.0 zh-CN 仍只是需账号/条款/法务复核的通用普通话工程 pilot，尚未下载；OCR 无公开中文体检报告产品训练集；CHARLS 永久排除。
- 官方模型二进制已从活动产品树迁至同级 `官方模型对比实验/artifacts/official_models`：12 个文件、650,339,242 字节；活动树对应目录不存在，归档清单与 12/12 锁定记录的大小和 SHA-256 全部一致，校验状态 `PASS_ENGINEERING_ARCHIVED_PRODUCT_BLOCKED`。
- OCR 同一组合成工程集（6 张、66 个字段）在修正为重叠切片后：当前 PP-OCRv5 CPU 完整字段精确匹配 66/66；官方 PP-OCRv4 RKNN PC 仿真 28/66，必填字段召回 53/66。该结果仅用于工程淘汰观察，不是产品准确率；官方 OCR 候选已延后且不可选择。
- ASR 同一 MED-CH 60 条研究集：当前 X-ASR CPU CER 7.9161%、实体召回 9/36；官方 Zipformer RKNN PC 仿真 CER 16.2613%、实体召回 1/36。该集商业权利未清，不构成产品赢家；官方 ASR 候选已延后且不可选择。
- 当前 ARM64 证据：S1 `20260923T031750Z-a0cbeead` 为 `PASS_ARM64_SOFTWARE`，149/149 项无跳过通过，并实际调用哈希绑定的自包含 AArch64 管理工具完成激活恢复；该单文件制品为 ELF64/AArch64，SHA-256 `16ba42ec6e60a152f0db1772a47e7066d5dce2233044c8161bb7509a511ab32f`。签名验证仍为显式测试桩，S3 `20260922T123504Z-fe0232c3` 仍只完成真实 ASR worker 与设备服务部分集成；OCR、产品授权和真 RK3566 继续阻断。
- 永久边界不变：CHARLS 未申请、未下载、未训练；合成/NHANES/研究数据不能替代中国目标人群产品数据；`hardware_measured=false`、`product_selected=false`、`formal_release_created=false`。

## 总状态

- 工程状态：`PASS_ENGINEERING_PRODUCT_BLOCKED`
- 产品上线状态：`BLOCKED_EXTERNAL`
- 正式 release：未创建，`release_allowed=false`
- 健康 V1：仅非诊断规则、趋势与提示；禁止疾病概率输出
- CHARLS：永久排除，未申请、未下载、未训练、未进入产品证据或发布包
- NHANES/合成数据：仅允许工程与演示，不是中国产品验收证据
- RK3566 实机验收：未执行；设备配置仍为 `hardware_measured=false`
- 中国公开 DM/HT 健康 ML：2 份原始数据在本地完成摘要复核，分别绑定 Rich Healthcare→DM、杭州 SUA/CVD→HT，训练来源链验证为 `training_sources_fused=false`；`PASS_ENGINEERING`，仅 shadow 候选，默认隐藏概率、未进入正式 release
- 产品交付形态：已冻结为“每台物理设备自包含 ARM64 产品”；开发 Web/统一 Demo/本机环境不得成为依赖
- 量产部署准备：`IN_PROGRESS`；组件契约和故障隔离工程门禁已通过，ARM64 自包含包、工厂初始化、真机验收和 OTA 尚未完成
- 最新总控 Run `20260923T142431Z`：42/42 检查行为符合预期，端侧 279 项测试运行（272 通过、7 项 Windows 平台能力跳过），健康、OCR、ASR 上游回归均通过；285 个输入和 52 份输出快照完成绑定，独立复验 `errors=[]`。状态仍为 `PASS_ENGINEERING_PRODUCT_BLOCKED`，未创建 release。

## RK3566 官方模型重构子 Loop

- 方案：`RK3566_OFFICIAL_MODELS_PRODUCTION_LOOP.md`；当前 R00、R01 已完成工程 Gate，R02 为 `IN_PROGRESS`。
- 已纠正技术事实：Rockchip 官方 Model Zoo 提供 RK3566 的 PP-OCRv4 Det/Rec、Zipformer、Whisper 和 wav2vec2 候选；此前“没有端侧 OCR/ASR 候选”的表述不准确。
- 当前设备服务选择未改变：ASR 仍是 X-ASR/Sherpa-ONNX CPU，OCR 选择仍为空；统一展示中的 Paddle OCR 不是产品后端。现已生成并登记 O2/A2 工程 `.rknn`，其中 O2 已有受哈希约束的工程 worker，但没有产品批准、授权同集验证或真 RK3566 验收，不能被选择为产品后端。
- 新选型原则：官方 RKNN 与现有 CPU 后端使用同一冻结数据和真机资源比较；NPU 候选若效果退化不得因“官方”身份强行入选。
- R01 证据：固定 `rknn_model_zoo@bad6c7334531becaf90a561988519b7bec34d0ab`、`rknn-toolkit2@59a913d172e7f5ff03c9076e2ec7b1b1288ffd08` 及三个上游来源；7 个 ONNX 共 515,671,301 字节，连同许可、转换脚本和运行辅助文件共 21 个文件完成大小和 SHA-256 锁定，5 个本地稀疏仓库 commit 可离线复验。
- R01 限制：PP-OCRv4 Rec 能读取，但当前 ONNX checker 因缺输出 shape 失败；RKNN SDK 为自定义许可，所有衍生权重和商业分发仍需具名法务结论。现有 `.rknn` 仅为工程候选，尚未选择产品模型。
- R02 进度：已固定 Toolkit2/Lite2/Runtime/Server 2.3.2、Ubuntu 20.04 官方 digest 和 9 个本地制品；内容寻址的 Ubuntu 20.04/Python 3.8.10/Toolkit2 2.3.2 转换镜像已重建，最小转换和 PC 模拟器 smoke 已通过，验证仍为 `PASS_ENGINEERING_PARTIAL`。
- R02 转换重放：同一固定镜像、断网、工作区只读条件下，O2/A2 五个转换均成功且日志已归档；Decoder/Joiner 逐字节复现，PP-OCRv4 Det/Rec 与 Zipformer Encoder 连续重放仍各自产生不同 SHA-256。变化区域未证明为无害元数据，审计状态为 `PASS_ENGINEERING_REPLAY_AUDIT_PRODUCT_BLOCKED`，不得据此选择产品后端。
- R02 固定环境探针：固定 Python hash seed、构建时间源、时区和单线程数值库后，5 个候选各双重转换均成功；2/5 两两一致，Det/Rec/Encoder 3/5 仍漂移。常见环境随机性已受控，但不能在缺乏格式说明与真机对齐时断言只是元数据。
- R02 导出制品能力探针：在同一锁定 Toolkit2 2.3.2 镜像、断网和工作区只读条件下，5/5 个导出 `.rknn` 均可被 `load_rknn()` 读取，但 PC 模拟器的 `init_runtime()` 对 5/5 均明确拒绝并要求目标设备。当前基于 ONNX 重建的 PC 仿真不能证明哈希漂移制品输出等价，必须在真 RK3566 上比较固定制品与重放制品。
- 本地 Toolkit2 2.3.2 公开 Python API 和仓库示例未发现确定性 seed/构建开关，核心转换逻辑主要位于已编译扩展；该阻断需 Rockchip 说明或真机冻结制品/重放制品输出等价验证关闭。
- R02 离线依赖锁：103 个 Debian 包、20 个 Python 依赖 wheel、Toolkit2 wheel 和两份构建输入共 126 项已完成大小/SHA-256 锁；`--network none --no-cache` 重建镜像与原镜像的 194 个 Debian 包、23 个 Python 包逐项一致，镜像体积由 1,316,392,244 降至 1,274,992,336 字节。验证为 `PASS_ENGINEERING_PARTIAL`、`dependency_artifact_hash_lock_complete=true`、`errors=[]`。
- R02 剩余阻断：3 个 RKNN 产物转换非确定性尚未证明无害；PC 模拟器无法执行导出的 `.rknn`，输出等价验证需要真 RK3566；唯一板卡系统镜像、内核、RKNPU 驱动和真机均未提供。
- R03/R04 进度：已生成 O2 Det/Rec 与 A2 Encoder/Decoder/Joiner FP16 RKNN；两套组件均完成 ONNX/RKNN PC 模拟器张量检查。O2 在 Rockchip 单图端到端解出 16 条文本。A2 除单条功能仿真外，已在同一 MED-CH 60 条研究工程集上与 X-ASR CPU 比较：CPU CER 7.9161%、实体召回 9/36；RKNN PC 模拟器 CER 16.2613%、实体召回 1/36；双方均 0 失败、0 空结果。
- R03/R04 限制：MED-CH 商业权利未清、不是目标麦克风独立集，两候选内部特征切分不同，PC 仿真耗时不是 RK3566 性能；当前只观察到 CPU 在本研究集质量更好，不产生产品赢家。Toolkit2 的未知目标算子/转置警告仍需真机排查；A3 按条件备选规则暂缓。机器证据为 `model_registry/official_candidate_artifacts.json`，核验结果 `PASS_ENGINEERING_PARTIAL`。
- 比较合同脚手架已登记 16 项指标并通过 fail-closed 校验；阈值、优先级、tie-breaker、授权数据 manifest 和 RK3566 profile 仍为空，等待具名批准。转换日志已按重放 run 归档；依赖 hash 锁和导出制品 PC 模拟器能力边界审计已完成，3 个漂移制品的输出等价性只能在目标设备验证，外部项齐备后才能进行产品选型。
- R05 进度：5 个后端注册表、显式选择文件和设备服务启动路径已完成工程绑定，`device_service_backend_registry_integrated=true`。O2 工程 worker 已实现 Det→裁剪→Rec→字典解码，校验两份 RKNN、字典和冻结后处理源码的大小/SHA-256，只允许 Linux/aarch64 RK3566 与 Lite2 2.3.2；图片改为有界 Base64 JSON 传输，输出不含原图且必须确认。启动器现可按显式选择装配 ASR/OCR，未知、被阻断或不匹配后端均失败关闭且不会回退。
- R05 ARM64 证据：S3 Run `20260920T113555Z-ee21ed07` 已在 Linux/aarch64 容器中用显式选中的 `asr_sherpa_cpu_xasr` 完成真实 WebSocket 推理并与 S2 文本哈希一致；未确认数据不落库，容器已清理。O2 worker 在 S1 完成 ARM64 导入/契约测试，但因容器不是 RK3566 且注册表保持阻断，S3 未调用 NPU 推理。
- R05 限制：目前只有一个工程可选后端，OCR 选择为空；O2 虽已实现工程 worker，仍因许可、授权数据、选择验收和真机缺失而不可选。A2 在当前研究集的 CER 和实体召回均明显差于 CPU，且没有真机资源收益证据，因此工程 worker 明确暂缓而非盲目实现；A3 仍为条件备选。CPU 只保留为工程路由，不能宣称产品赢家、CPU/RKNN 实际切换或产品后端冻结完成。

## 统一展示证据状态

- 统一 Demo 已改为从三项目现有 JSON 报告加载可审计实验指标，并为每份报告返回 SHA-256；单次健康模型输出改称“模型分数”，OCR 字段值仍只称置信度。
- 健康页面展示中国公开数据工程测试集：DM 测试集 24,097 人、阳性 429；HT 测试集 917 人、阳性 174。普通 Accuracy 不展示，改为 ROC-AUC、PR-AUC 和敏感度。
- OCR 明确显示真实报告测试集为 0；7 份合成样本的 100% 仅作工程链路证据，不作为真实正确率。
- ASR 现有展示报告仍保留旧运行口径；本轮锁定 Sherpa-ONNX 1.13.7 重跑同一 MED-CH 60 条后，CPU CER 为 7.9161%、实体召回 9/36（25%）。RKNN PC 模拟器 CER 为 16.2613%、实体召回 1/36；主机 RTF 不用于产品比较。数据商业许可和目标麦克风独立验收仍未完成。
- 统一 Demo 冒烟 `runtime/smoke_metrics_latest.json` 已通过 7/7 检查并真实调用三个当前模型；这不改变产品状态，仍为 `PASS_ENGINEERING_PRODUCT_BLOCKED`。

## ARM64 模拟子 Loop

- 方案：`ARM64_SIMULATION_LOOP.md`；入口：`start_arm64_simulation.bat`。
- 软件模拟 Run：`20260922T094334Z-94330e4d`；状态 `PASS_ARM64_SOFTWARE`，阶段 S1。设备安装、回滚、开机恢复、签名前晋升、最终发布复验及 systemd 启动前现统一复用签名/文件完整性与产品运行时语义联合门禁，签名正确但仍含工程运行配置的 bundle 会在激活前被拒绝。`20260922T025704Z-9b40314b` 如实保留为受限执行账户无 Docker 命名管道权限导致的 S0 环境阻断；`20260922T083940Z-b16a7f6d` 如实保留为 Docker Desktop 引擎已停止导致的 S0 环境阻断；`20260922T085922Z-b7b64fd5` 是未传 `--execute` 时仅完成预检的 `READY_TO_EXECUTE` S0 记录；`20260922T091739Z-8225ccf8` 与 `20260922T091849Z-aee00808` 分别保留为新增 ARM64 注册表测试缺验证脚本、缺冻结注册表/选择配置导致的严格白名单失败，补齐精确只读依赖后实际执行通过。
- WSL 2.7.13、Docker Desktop 4.89.0、Docker CLI/Engine 29.7.2 已就绪；本机 Linux Docker 引擎可用。
- 受控构建上下文与真实 Linux/aarch64/64 位非 root 容器测试均通过，guest 为 149/149 且 0 跳过，源码哈希一致；其中包含数据库 schema 2→3 无损迁移、成员级幂等键、数据库备份/恢复门禁、待确认结果 TTL 清理、ASR 取消、WebSocket 与 HTTP 严格输入、产品/工程后端注册表装配、嵌套恶意 capability/reason 的稳定失败关闭、产品 release 内容与运行时门禁、设备侧签名完整性与产品运行时联合复验、发布源/包的符号链接、Windows junction、FIFO/套接字/设备节点拒绝、promotion 公钥批准策略绑定、current 规范相对链接与 releases 目录防重定向，以及分页、幂等删除、日志降级和关机排空；另一个断网、只读、最小 root 容器验证了中断激活恢复和已落盘版本目录安全续装，两个容器均已清理。
- S1 中 OCR/ASR 为工程测试替身、健康为真实规则引擎；更新恢复 smoke 的签名验证为明确测试桩，只证明 Linux 事务行为，其作用仍仅是工作流兼容验证。
- 模型模拟 Run：`20260918T094803Z-56999ee8`；状态 `PARTIAL_PASS_PRODUCT_BLOCKED`，阶段 S2 partial。
- S2 已在 Linux/aarch64 guest 中执行 DM/HT ONNX 与现有 ASR V2 真实 CPU 推理：健康主机对齐最大绝对误差 `5.960464477539063e-08`；ASR 使用 Sherpa-ONNX 1.13.7，10.053125 秒样例的文本 SHA-256 与同版本 Windows 基准一致，QEMU 解码约 55.27 秒。
- Sherpa-ONNX 1.13.4 在 ARM64 仿真中实测产生空文本，未继续作为端侧候选；模型权重未更换、未重新训练。
- S3 部分集成 Run：`20260922T092755Z-d177f712`；状态 `PARTIAL_PASS_PRODUCT_BLOCKED`。运行时输入加固后重新执行：现有 ASR V2 通过发布根目录内的相对路径、哈希绑定配置、后端注册表和显式选型装配到设备服务，在 Linux/aarch64 guest 中经严格握手、短读安全及 Close 帧校验的真实 loopback WebSocket 完成流式推理，文本 SHA-256 与 S2 基准一致；流启动在同一 worker 内校验版本、能力及模型哈希，避免健康预检造成每会话重复加载；经 HTTP 取消前记录数为 0，取消成功，原始 PCM 未持久化，服务线程与容器均已清理。真实非诊断健康规则也经 HTTP 通过，独立验证 `errors=[]`。`20260922T092721Z-b174f4ad` 如实保留为受限账户 Docker 环境阻断；旧 S3 源码哈希失效导致的总控失败 `20260922T092306Z` 也未覆盖。
- OCR 工程 worker 已实现并可由同一启动器显式装配，但实际注册表仍为 `BLOCKED_ENGINEERING`、选择文件仍为 `null`；S3 未调用 OCR NPU 推理，也未用测试替身冒充。完整三模型 S3 尚未完成。
- `hardware_measured=false`、`three_model_inference_verified=false`、`simulation_complete=false`。
- 原始证据：`reports/arm64_simulation_latest.json`、`reports/arm64_model_simulation_latest.json`、`reports/arm64_integration_simulation_latest.json`、对应三份独立验证报告及 `reports/simulation_host.json`。
- 下一步：取得 OCR 具名分发许可并登记产品 ONNX/RKNN，补齐 S2/S3 三模型真实推理与集成；取得 ASR 商业分发结论和目标麦克风真人独立集；随后在真 RK3566 上执行 S4 性能、长稳、断电和升级回滚验收。

## Gate 状态

| Gate | 状态 | 已完成的工程能力 | 尚缺产品证据 |
|---|---|---|---|
| E00 | PASS_ENGINEERING | 产品边界及数据禁用策略 | 具名产品/法务批准 |
| E01 | PASS_ENGINEERING | 隔离环境、工作区、产品部署合同、可恢复 Loop 与本机受控 ARM64 仿真构建 | 生产 ARM64 构建环境、唯一板卡 SKU |
| E02 | PASS_ENGINEERING | `/v1`、OpenAPI、错误码、成员授权与确认链 | 跨团队具名批准 |
| E03 | BLOCKED_EXTERNAL | 许可/隐私/分类证据门禁 | OCR/ASR 分发及隐私法务结论 |
| E04 | BLOCKED_EXTERNAL | 严格 SSH 真机预检与导入工具 | 真 RK3566、镜像、驱动和调试入口 |
| E05 | PASS_ENGINEERING | 非诊断规则引擎；哈希绑定的 DM/HT CPU shadow 候选已通过 ARM64 仿真对齐 | 规则批准；ML 法务/产品批准、HT 外部验证、Heart/Stroke 数据及真机证据 |
| E06 | PASS_ENGINEERING | ASR 资产校验、流式状态机、原始 PCM 不落盘；V2 + Sherpa-ONNX 1.13.7 已通过 ARM64 仿真对齐并以隔离 worker 完成设备服务集成 | 商业分发结论、真 RK3566 runtime 冻结、目标麦克风真人验收 |
| E07 | PASS_ENGINEERING | OCR 资产与输入校验、确认链；PP-OCRv4 RKNN 工程 worker、全资产哈希校验、RK3566/Lite2 失败关闭及显式启动装配 | 商业分发批准、授权真实报告验收、真 RK3566 NPU 证据与产品选择 |
| E08 | PASS_ENGINEERING | loopback、成员隔离、确认后写入、提交失败可重试、创建失败清理敏感内存；待确认结果独立快照及 TTL 清理；记录游标分页、幂等删除、HTTP 完整性校验、日志故障降级、关机排空；撤回清理；在线备份/恢复路径与原子性门禁；组件握手与故障降级；隔离进程主管已通过 ARM64 S1，现有 ASR V2 工程 worker 已通过 ARM64 S3 部分集成；OCR 工程 worker 已接入显式选型启动路径但保持不可选 | OCR 产品批准/真机验收、ASR 产品批准、完整三模型自包含 ARM64 集成、产品加密 codec、设备密钥及具名批准 |
| E09 | PASS_ENGINEERING | 隐私日志、故障隔离、工程 SBOM、签名验证与运维手册；隐私门禁已由永久 false 改为真实验收与具名审批驱动 | 威胁模型具名批准、当前目标漏洞扫描、RK3566 实机加固与每设备密钥验收 |
| E10 | BLOCKED_EXTERNAL | 真实 HTTP/WebSocket 验收客户端、整批输入预校验、数据/隐私审批哈希绑定、原子不覆盖证据写入、资源上限和原始指标计算、合同/设备哈希绑定 | 真机、具名数据与隐私批准、真实授权 OCR/ASR、冻结阈值与长稳/故障证据 |
| E11 | PASS_ENGINEERING | 候选输入精确 schema、release ID/路径/重复项、符号链接/重解析点/FIFO/套接字/设备节点拒绝、复制前后哈希复验；严格 manifest/rollback schema、外部签名、产品运行时联合复验、原子安装与回滚；产品健康限时重试；root-only 激活事务、开机恢复及相同签名包安全续装已通过 ARM64 工程仿真；生命周期脚本已移除全局 Python 调用；哈希绑定的 AArch64 自包含管理工具已构建并在 S1 实际执行 | 管理工具商业分发法务批准、公司 OTA 仓库、工厂初始化、正式三模型运行时/适配层制品、真签名包与 RK3566 断电/升级验收 |
| E12 | BLOCKED_EXTERNAL | fail-closed 总门禁及逐 Gate 审计 | 全部上游产品 Gate |

## 最新总控证据

- Run ID：`20260923T142431Z`
- 结果：`PASS_ENGINEERING_PRODUCT_BLOCKED`
- 检查：42/42 行为符合预期，`unexpected_checks=[]`；新增公开数据集许可/适用性审计和四 Loop 汇总审计；正式验收原始证据仍必须先经过独立指标计算，再按证据 manifest 哈希进入设备验收；产品条件缺失时的预期阻断不等于产品验收通过
- 端侧单元测试：279 项运行，272 项通过、7 项跳过；新增 5 项健康训练来源链失败关闭测试；跳过项是当前 Windows 主机不提供相应用例所需的平台能力，等价用例已在 Linux/aarch64 S1 中执行且 149/149 无跳过通过，其中包括真实 FIFO 特殊文件拒绝测试
- 三模型回归：健康 21/21 个测试文件、OCR 105 项、ASR 111 项均退出码 0；健康产品验收文件单独使用 360 秒上限，其余健康分片及 OCR/ASR 仍为 240 秒；使用项目本地临时目录，未使用用户临时目录或 pytest cache
- Loop 审计：`goal_complete=false`、`contradictions=[]`、`engineering_failures=[]`
- 发布：`release_allowed=false`、`formal_release_verified=false`
- 健康 ML 候选：完整性审计 PASS；模型 manifest→训练报告→数据 manifest→中央公开数据账本→本地原始文件的路径、大小和摘要链已核对，DM/HT 来源分别绑定且未融合；产品启用 false、目标设备验证 false
- 原生进程主管：工程实现及 ARM64 S1 通过；现有 ASR V2 工程 worker 已通过受控运行时配置装配和 S3 loopback HTTP/WebSocket 部分集成；OCR RKNN 工程 worker 已登记并接入显式装配路径，但未选择、未在非 RK3566 容器冒充推理；`product_native_workers_registered=false`、`hardware_measured=false`
- Run 证据：总控脚本自身及证据验证器已纳入输入哈希；四份 Loop 文档、公开数据候选登记和许可审计、健康训练来源链、核心 Python、部署 shell、systemd、测试源码、正式验收原始证据 manifest、验收模板/说明、官方模型研究归档/工具链/后端注册表、AArch64 管理工具构建配置、离线 wheel、不可变二进制/SBOM/许可证、产品 runtime bundle 校验、全部发布入口的签名与产品运行时联合复验、OCR/ASR 同集比较报告、RKNN 重放/确定性/导出制品能力报告及离线依赖锁报告/manifest 自动纳入哈希；共绑定 285 个输入，52 份可变输出已原样快照到 `reports/loop_runs/20260923T142431Z/outputs/`，`snapshot_integrity_verified=true`
- 独立快照复验：`reports/loop_run_evidence_verification.json` 为 `PASS_ENGINEERING`、`errors=[]`；后续刷新普通报告不会改写本 Run 快照
- 目录：不存在正式 `release/` 或 `release_candidates/`
- 总控输入已绑定 ARM64 S1/S2/S3 证据核验、Loop Gate 审计脚本、对应配置及完整核心源码/测试哈希；证据漂移会失败关闭
- 审计入口：`reports/loop_run_latest.json`
- Run 快照核验入口：`scripts/verify_loop_run_evidence.py`
- 三模型回归证据：`reports/upstream_regression_verification.json`
- 组件契约证据：`reports/component_contract_verification.json`

## 产品部署合同

- 计划：`PRODUCT_EDGE_DEPLOYMENT_PLAN.md`
- 机器合同：`configs/product_delivery_contract.json`
- 工程校验：`PASS_ENGINEERING`
- 正式 release：`false`
- 禁止运行依赖：开发者电脑、统一 Demo、Windows `.venv`、全局 Python、绝对开发路径、首次启动在线下载模型
- 必须交付：稳定产品接口/SDK、设备服务、三个运行时、加密存储、更新代理、签名包、工厂初始化和真机证据
- UI 边界：最终 UI 可由其他产品工程交付，不要求放在模型工程；但必须完成真实集成验收

## 恢复命令

```powershell
cd C:\Users\45277\Desktop\模型\端侧上线
.\.venv-edge\Scripts\python.exe scripts\run_engineering_loop.py
```
