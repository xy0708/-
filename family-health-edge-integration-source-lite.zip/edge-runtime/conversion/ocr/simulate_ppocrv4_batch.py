from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.ocr_tiling import axis_starts, deduplicate
from simulate_ppocrv4_system import (
    DET_SIZE,
    OnnxModel,
    Recognition,
    RknnSimulatorModel,
    load_official_postprocess,
    recognize,
    sha256,
)


REPORT_STATUS = "PASS_ENGINEERING_SYNTHETIC_BATCH_SIMULATION_PRODUCT_BLOCKED"
REPORT_SCOPE = "SYNTHETIC_ENGINEERING_IMAGES_ONLY_NOT_PRODUCT_METRICS"
TILE_SIZE = 720
TILE_OVERLAP = 120


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run one frozen PP-OCRv4 ONNX/RKNN simulator pair over a batch."
    )
    parser.add_argument("--det-onnx", type=Path, required=True)
    parser.add_argument("--rec-onnx", type=Path, required=True)
    parser.add_argument("--det-rknn", type=Path, required=True)
    parser.add_argument("--rec-rknn", type=Path, required=True)
    parser.add_argument("--dictionary", type=Path, required=True)
    parser.add_argument("--official-python", type=Path, required=True)
    parser.add_argument("--image", type=Path, action="append", required=True)
    parser.add_argument("--simulator-image-id", required=True)
    parser.add_argument("--report", type=Path, required=True)
    return parser.parse_args()


def tiles(image: np.ndarray):
    height, width = image.shape[:2]
    for top in axis_starts(height, TILE_SIZE, TILE_OVERLAP):
        for left in axis_starts(width, TILE_SIZE, TILE_OVERLAP):
            yield left, top, image[top : top + TILE_SIZE, left : left + TILE_SIZE]


def global_box(
    box: list[list[float]], tile: np.ndarray, left: int, top: int
) -> list[float]:
    height, width = tile.shape[:2]
    scale_x = width / DET_SIZE[0]
    scale_y = height / DET_SIZE[1]
    return [
        coordinate
        for point in box
        for coordinate in (
            float(point[0]) * scale_x + left,
            float(point[1]) * scale_y + top,
        )
    ]


def serialize(
    results: list[Recognition], tile: np.ndarray, left: int, top: int
) -> list[dict[str, object]]:
    return [
        {
            "text": item.text,
            "confidence": item.confidence,
            "source_box": global_box(item.box, tile, left, top),
        }
        for item in results
    ]


def load_images(paths: list[Path]) -> dict[str, np.ndarray]:
    images: dict[str, np.ndarray] = {}
    for path in paths:
        image = cv2.imread(str(path), cv2.IMREAD_COLOR)
        if image is None or image.ndim != 3:
            raise ValueError(f"Could not decode image: {path.name}")
        if path.name in images:
            raise ValueError(f"Duplicate image name: {path.name}")
        images[path.name] = image
    return images


def run_candidate(
    model_class,
    det_onnx: Path,
    rec_onnx: Path,
    images: dict[str, np.ndarray],
    postprocess,
) -> dict[str, dict[str, object]]:
    detector = model_class(det_onnx, "det")
    recognizer = model_class(rec_onnx, "rec")
    outputs: dict[str, dict[str, object]] = {}
    try:
        for name, image in images.items():
            started = time.perf_counter()
            try:
                detected: list[dict[str, object]] = []
                tile_count = 0
                for left, top, tile in tiles(image):
                    tile_count += 1
                    detected.extend(
                        serialize(
                            recognize(detector, recognizer, tile, postprocess),
                            tile,
                            left,
                            top,
                        )
                    )
                lines = deduplicate(detected)
            except Exception as exc:  # Keep the failed sample in the denominator.
                outputs[name] = {
                    "status": "FAIL_ENGINEERING_INFERENCE",
                    "error_type": type(exc).__name__,
                    "elapsed_seconds_host_not_for_ranking": time.perf_counter()
                    - started,
                    "tile_count": 0,
                    "lines": [],
                }
            else:
                outputs[name] = {
                    "status": "PASS_ENGINEERING_INFERENCE",
                    "error_type": None,
                    "elapsed_seconds_host_not_for_ranking": time.perf_counter()
                    - started,
                    "tile_count": tile_count,
                    "lines": lines,
                }
    finally:
        recognizer.close()
        detector.close()
    return outputs


def main() -> int:
    args = parse_args()
    required = (
        args.det_onnx,
        args.rec_onnx,
        args.det_rknn,
        args.rec_rknn,
        args.dictionary,
        args.official_python,
        *args.image,
    )
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(", ".join(missing))
    images = load_images(args.image)
    postprocess = load_official_postprocess(args.official_python, args.dictionary)
    onnx = run_candidate(
        OnnxModel, args.det_onnx, args.rec_onnx, images, postprocess
    )
    rknn = run_candidate(
        RknnSimulatorModel, args.det_onnx, args.rec_onnx, images, postprocess
    )
    failures = [
        f"{candidate}:{name}"
        for candidate, results in (("onnx", onnx), ("rknn_simulator", rknn))
        for name, result in results.items()
        if result["status"] != "PASS_ENGINEERING_INFERENCE"
    ]
    report = {
        "schema_version": "1.0.0",
        "status": REPORT_STATUS if not failures else "FAIL_ENGINEERING_BATCH_SIMULATION",
        "scope": REPORT_SCOPE,
        "target_model": "rk3566",
        "simulator_image_id": args.simulator_image_id,
        "network_disabled": True,
        "hardware_measured": False,
        "product_accuracy_claim_allowed": False,
        "product_selection_allowed": False,
        "exported_target_rknn_loaded": False,
        "simulator_build_source": "frozen_onnx_with_same_rk3566_config",
        "preprocessing": {
            "strategy": "overlapping_tiles_then_global_iou_deduplication",
            "tile_size_pixels": TILE_SIZE,
            "tile_overlap_pixels": TILE_OVERLAP,
            "model_input_pixels": list(DET_SIZE),
            "deduplication_iou_threshold": 0.5,
            "full_page_downscale_forbidden": True,
        },
        "inputs": {
            "det_onnx_sha256": sha256(args.det_onnx),
            "rec_onnx_sha256": sha256(args.rec_onnx),
            "det_rknn_sha256": sha256(args.det_rknn),
            "rec_rknn_sha256": sha256(args.rec_rknn),
            "dictionary_sha256": sha256(args.dictionary),
            "images": {path.name: sha256(path) for path in args.image},
        },
        "samples": [
            {
                "sample_id": name,
                "image_sha256": sha256(
                    next(path for path in args.image if path.name == name)
                ),
                "onnx": onnx[name],
                "rknn_simulator": rknn[name],
            }
            for name in images
        ],
        "failures": failures,
        "limitations": [
            "Synthetic reports are engineering fixtures and are not product evidence.",
            "The PC simulator rebuilds from frozen ONNX and does not execute the exported RKNN files.",
            "Host timing is not RK3566 latency, memory, temperature or power evidence.",
        ],
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "samples": len(report["samples"]),
                "failures": failures,
            },
            ensure_ascii=True,
        )
    )
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
