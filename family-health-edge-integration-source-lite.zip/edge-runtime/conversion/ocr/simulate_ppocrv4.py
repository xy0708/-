from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import cv2
import numpy as np
import onnxruntime as ort
from rknn.api import RKNN


DET_MEAN = np.asarray([0.485, 0.456, 0.406], dtype=np.float32).reshape(1, 1, 3)
DET_STD = np.asarray([0.229, 0.224, 0.225], dtype=np.float32).reshape(1, 1, 3)
INPUT_SIZES = {"ppocrv4_det": (480, 480), "ppocrv4_rec": (320, 48)}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compare PP-OCRv4 ONNX with RKNN PC simulation.")
    parser.add_argument("--profile", choices=tuple(INPUT_SIZES), required=True)
    parser.add_argument("--onnx", type=Path, required=True)
    parser.add_argument("--rknn", type=Path, required=True)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    return parser.parse_args()


def load_image(path: Path, profile: str) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"Could not decode image: {path}")
    return cv2.resize(image, INPUT_SIZES[profile])


def normalized_image(image: np.ndarray, profile: str) -> np.ndarray:
    scaled = image.astype(np.float32) / 255.0
    if profile == "ppocrv4_det":
        return (scaled - DET_MEAN) / DET_STD
    return scaled


def run_onnx(model_path: Path, image: np.ndarray, profile: str) -> np.ndarray:
    normalized = normalized_image(image, profile)
    model_input = normalized.transpose(2, 0, 1)[np.newaxis, ...]
    session = ort.InferenceSession(str(model_path), providers=["CPUExecutionProvider"])
    input_name = session.get_inputs()[0].name
    return np.asarray(session.run(None, {input_name: model_input})[0], dtype=np.float32)


def configure_simulator(runtime: RKNN, profile: str) -> int:
    if profile == "ppocrv4_det":
        return runtime.config(
            mean_values=[[123.675, 116.28, 103.53]],
            std_values=[[58.395, 57.12, 57.375]],
            target_platform="rk3566",
        )
    return runtime.config(target_platform="rk3566")


def run_rknn_simulator(onnx_path: Path, image: np.ndarray, profile: str) -> np.ndarray:
    runtime = RKNN(verbose=False)
    try:
        if configure_simulator(runtime, profile) != 0:
            raise RuntimeError("RKNN simulator config failed")
        if runtime.load_onnx(model=str(onnx_path)) != 0:
            raise RuntimeError("RKNN simulator ONNX load failed")
        if runtime.build(do_quantization=False) != 0:
            raise RuntimeError("RKNN simulator build failed")
        if runtime.init_runtime() != 0:
            raise RuntimeError("RKNN PC simulator initialization failed")
        model_input = image if profile == "ppocrv4_det" else normalized_image(image, profile)
        outputs = runtime.inference(inputs=[model_input])
        if not outputs:
            raise RuntimeError("RKNN PC simulator returned no output")
        return np.asarray(outputs[0], dtype=np.float32)
    finally:
        runtime.release()


def comparison(reference: np.ndarray, candidate: np.ndarray) -> dict[str, object]:
    same_shape = reference.shape == candidate.shape
    result: dict[str, object] = {
        "onnx_shape": list(reference.shape),
        "rknn_shape": list(candidate.shape),
        "same_shape": same_shape,
    }
    if not same_shape:
        return result

    difference = np.abs(reference - candidate)
    reference_flat = reference.reshape(-1).astype(np.float64)
    candidate_flat = candidate.reshape(-1).astype(np.float64)
    denominator = float(np.linalg.norm(reference_flat) * np.linalg.norm(candidate_flat))
    result.update(
        {
            "max_absolute_error": float(difference.max()),
            "mean_absolute_error": float(difference.mean()),
            "p99_absolute_error": float(np.percentile(difference, 99)),
            "cosine_similarity": (
                float(np.dot(reference_flat, candidate_flat) / denominator)
                if denominator
                else None
            ),
        }
    )
    return result


def main() -> int:
    args = parse_args()
    paths = (args.onnx, args.rknn, args.image)
    if any(not path.is_file() for path in paths):
        missing = [str(path) for path in paths if not path.is_file()]
        raise FileNotFoundError(", ".join(missing))

    image = load_image(args.image, args.profile)
    onnx_output = run_onnx(args.onnx, image, args.profile)
    rknn_output = run_rknn_simulator(args.onnx, image, args.profile)
    metrics = comparison(onnx_output, rknn_output)
    status = "PASS_ENGINEERING_SIMULATOR_EXECUTION" if metrics["same_shape"] else "FAIL_OUTPUT_SHAPE_MISMATCH"
    report = {
        "status": status,
        "scope": "PC_SIMULATOR_ONLY",
        "profile": args.profile,
        "target_model": "rk3566",
        "simulator_build_source": "onnx_with_same_rk3566_config",
        "exported_rknn_loaded_by_simulator": False,
        "hardware_measured": False,
        "product_accuracy_claim_allowed": False,
        "threshold_frozen": False,
        "inputs": {
            "onnx_sha256": sha256(args.onnx),
            "rknn_sha256": sha256(args.rknn),
            "image_sha256": sha256(args.image),
        },
        "comparison": metrics,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if status.startswith("PASS_") else 2


if __name__ == "__main__":
    raise SystemExit(main())
