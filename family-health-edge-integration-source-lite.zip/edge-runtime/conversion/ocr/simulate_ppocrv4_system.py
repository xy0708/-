from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import cv2
import numpy as np
import onnxruntime as ort
from rknn.api import RKNN


DET_SIZE = (480, 480)
REC_SIZE = (320, 48)
DET_MEAN = np.asarray([0.485, 0.456, 0.406], dtype=np.float32).reshape(1, 1, 3)
DET_STD = np.asarray([0.229, 0.224, 0.225], dtype=np.float32).reshape(1, 1, 3)


class Model(Protocol):
    def run(self, image: np.ndarray) -> np.ndarray: ...

    def close(self) -> None: ...


@dataclass(frozen=True)
class Recognition:
    text: str
    confidence: float
    box: list[list[float]]


class OnnxModel:
    def __init__(self, path: Path, profile: str) -> None:
        self.profile = profile
        self.session = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name

    def run(self, image: np.ndarray) -> np.ndarray:
        normalized = normalize(image, self.profile)
        model_input = normalized.transpose(2, 0, 1)[np.newaxis, ...]
        return np.asarray(
            self.session.run(None, {self.input_name: model_input})[0],
            dtype=np.float32,
        )

    def close(self) -> None:
        return None


class RknnSimulatorModel:
    def __init__(self, onnx_path: Path, profile: str) -> None:
        self.profile = profile
        self.runtime = RKNN(verbose=False)
        if self._configure() != 0:
            raise RuntimeError(f"RKNN simulator config failed: {profile}")
        if self.runtime.load_onnx(model=str(onnx_path)) != 0:
            raise RuntimeError(f"RKNN simulator ONNX load failed: {profile}")
        if self.runtime.build(do_quantization=False) != 0:
            raise RuntimeError(f"RKNN simulator build failed: {profile}")
        if self.runtime.init_runtime() != 0:
            raise RuntimeError(f"RKNN PC simulator initialization failed: {profile}")

    def _configure(self) -> int:
        if self.profile == "det":
            return self.runtime.config(
                mean_values=[[123.675, 116.28, 103.53]],
                std_values=[[58.395, 57.12, 57.375]],
                target_platform="rk3566",
            )
        return self.runtime.config(target_platform="rk3566")

    def run(self, image: np.ndarray) -> np.ndarray:
        model_input = image if self.profile == "det" else normalize(image, self.profile)
        outputs = self.runtime.inference(
            inputs=[model_input[np.newaxis, ...]],
            data_format=["nhwc"],
        )
        if not outputs:
            raise RuntimeError(f"RKNN PC simulator returned no output: {self.profile}")
        return np.asarray(outputs[0], dtype=np.float32)

    def close(self) -> None:
        self.runtime.release()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare decoded PP-OCRv4 ONNX and RKNN PC-simulator output."
    )
    parser.add_argument("--det-onnx", type=Path, required=True)
    parser.add_argument("--rec-onnx", type=Path, required=True)
    parser.add_argument("--det-rknn", type=Path, required=True)
    parser.add_argument("--rec-rknn", type=Path, required=True)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--dictionary", type=Path, required=True)
    parser.add_argument("--official-python", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    return parser.parse_args()


def normalize(image: np.ndarray, profile: str) -> np.ndarray:
    scaled = image.astype(np.float32) / 255.0
    if profile == "det":
        return (scaled - DET_MEAN) / DET_STD
    return scaled


def load_official_postprocess(official_python: Path, dictionary: Path):
    sys.path.insert(0, str(official_python.resolve()))
    from utils.db_postprocess import DBPostProcess, DetPostProcess
    from utils.rec_postprocess import CTCLabelDecode

    detector = DBPostProcess(
        thresh=0.3,
        box_thresh=0.6,
        max_candidates=1000,
        unclip_ratio=1.5,
        use_dilation=False,
        score_mode="fast",
    )
    return (
        detector,
        DetPostProcess(),
        CTCLabelDecode(character_dict_path=str(dictionary), use_space_char=True),
        rotate_crop_image,
        sort_text_boxes,
    )


def rotate_crop_image(image: np.ndarray, points: np.ndarray) -> np.ndarray:
    """Apply the perspective crop used by Rockchip's PP-OCR system example."""

    crop_width = int(
        max(
            np.linalg.norm(points[0] - points[1]),
            np.linalg.norm(points[2] - points[3]),
        )
    )
    crop_height = int(
        max(
            np.linalg.norm(points[0] - points[3]),
            np.linalg.norm(points[1] - points[2]),
        )
    )
    target = np.float32(
        [[0, 0], [crop_width, 0], [crop_width, crop_height], [0, crop_height]]
    )
    transform = cv2.getPerspectiveTransform(points, target)
    cropped = cv2.warpPerspective(
        image,
        transform,
        (crop_width, crop_height),
        borderMode=cv2.BORDER_REPLICATE,
        flags=cv2.INTER_CUBIC,
    )
    if cropped.shape[0] / cropped.shape[1] >= 1.5:
        cropped = np.rot90(cropped)
    return cropped


def sort_text_boxes(boxes: np.ndarray) -> list[np.ndarray]:
    """Sort boxes top-to-bottom and left-to-right like the official example."""

    ordered = list(sorted(boxes, key=lambda box: (box[0][1], box[0][0])))
    for index in range(len(ordered) - 1):
        for prior in range(index, -1, -1):
            next_box = ordered[prior + 1]
            current_box = ordered[prior]
            if abs(next_box[0][1] - current_box[0][1]) >= 10:
                break
            if next_box[0][0] >= current_box[0][0]:
                break
            ordered[prior], ordered[prior + 1] = next_box, current_box
    return ordered


def detect_boxes(model: Model, image: np.ndarray, db_postprocess, det_postprocess) -> np.ndarray:
    resized = cv2.resize(image, DET_SIZE)
    output = model.run(resized)
    shape = np.asarray([[DET_SIZE[1], DET_SIZE[0], 1.0, 1.0]], dtype=np.float32)
    result = db_postprocess({"maps": output}, shape)
    return det_postprocess.filter_tag_det_res(result[0]["points"], resized.shape)


def recognize(
    detector: Model,
    recognizer: Model,
    image: np.ndarray,
    postprocess,
) -> list[Recognition]:
    db_postprocess, det_postprocess, ctc_decode, crop_image, sort_boxes = postprocess
    resized = cv2.resize(image, DET_SIZE)
    boxes = detect_boxes(detector, image, db_postprocess, det_postprocess)
    results: list[Recognition] = []
    for box in sort_boxes(boxes):
        crop = crop_image(resized, box.copy())
        rec_input = cv2.resize(crop, REC_SIZE)
        decoded = ctc_decode(recognizer.run(rec_input))[0]
        text, confidence = decoded
        if float(confidence) >= 0.5:
            results.append(
                Recognition(
                    text=str(text),
                    confidence=float(confidence),
                    box=np.asarray(box, dtype=np.float32).tolist(),
                )
            )
    return results


def serialize(results: list[Recognition]) -> list[dict[str, object]]:
    return [
        {"text": item.text, "confidence": item.confidence, "box": item.box}
        for item in results
    ]


def run_backend(
    backend: str,
    det_onnx: Path,
    rec_onnx: Path,
    image: np.ndarray,
    postprocess,
) -> list[Recognition]:
    model_class = OnnxModel if backend == "onnx" else RknnSimulatorModel
    detector = model_class(det_onnx, "det")
    recognizer = model_class(rec_onnx, "rec")
    try:
        return recognize(detector, recognizer, image, postprocess)
    finally:
        recognizer.close()
        detector.close()


def main() -> int:
    args = parse_args()
    required = (
        args.det_onnx,
        args.rec_onnx,
        args.det_rknn,
        args.rec_rknn,
        args.image,
        args.dictionary,
        args.official_python,
    )
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(", ".join(missing))

    image = cv2.imread(str(args.image), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"Could not decode image: {args.image}")
    postprocess = load_official_postprocess(args.official_python, args.dictionary)
    onnx_results = run_backend("onnx", args.det_onnx, args.rec_onnx, image, postprocess)
    rknn_results = run_backend("rknn", args.det_onnx, args.rec_onnx, image, postprocess)
    onnx_text = [item.text for item in onnx_results]
    rknn_text = [item.text for item in rknn_results]
    exact_match = bool(onnx_text) and onnx_text == rknn_text
    status = (
        "PASS_ENGINEERING_FUNCTIONAL_SIMULATION"
        if exact_match
        else "FAIL_DECODED_OUTPUT_MISMATCH"
    )
    report = {
        "status": status,
        "scope": "PC_SIMULATOR_SINGLE_OFFICIAL_SAMPLE_ONLY",
        "target_model": "rk3566",
        "official_postprocess_used": True,
        "exported_rknn_loaded_by_simulator": False,
        "simulator_build_source": "onnx_with_same_rk3566_config",
        "hardware_measured": False,
        "product_accuracy_claim_allowed": False,
        "ocr_metric_claim_allowed": False,
        "threshold_frozen": False,
        "inputs": {
            "det_onnx_sha256": sha256(args.det_onnx),
            "rec_onnx_sha256": sha256(args.rec_onnx),
            "det_rknn_sha256": sha256(args.det_rknn),
            "rec_rknn_sha256": sha256(args.rec_rknn),
            "image_sha256": sha256(args.image),
            "dictionary_sha256": sha256(args.dictionary),
        },
        "comparison": {
            "onnx_detection_count": len(onnx_results),
            "rknn_detection_count": len(rknn_results),
            "decoded_text_exact_match": exact_match,
            "onnx_text": onnx_text,
            "rknn_text": rknn_text,
        },
        "onnx_results": serialize(onnx_results),
        "rknn_simulator_results": serialize(rknn_results),
        "limitations": [
            "One bundled Rockchip sample is not an accuracy dataset.",
            "PC simulator output does not measure RK3566 latency, memory, temperature or power.",
            "The simulator rebuilds from the frozen ONNX and configuration because exported target RKNN files cannot be loaded by the host simulator.",
        ],
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if status.startswith("PASS_") else 2


if __name__ == "__main__":
    raise SystemExit(main())
