from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from rknn.api import RKNN


PPOCRV4_DET_MEAN_VALUES = [[123.675, 116.28, 103.53]]
PPOCRV4_DET_STD_VALUES = [[58.395, 57.12, 57.375]]
SUPPORTED_PROFILES = ("ppocrv4_det", "ppocrv4_rec", "zipformer", "whisper")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a minimal reproducible RK3566 conversion smoke.")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--profile", choices=SUPPORTED_PROFILES, default="ppocrv4_det")
    return parser.parse_args()


def configure(converter: RKNN, profile: str) -> int:
    if profile == "ppocrv4_det":
        return converter.config(
            mean_values=PPOCRV4_DET_MEAN_VALUES,
            std_values=PPOCRV4_DET_STD_VALUES,
            target_platform="rk3566",
        )
    return converter.config(target_platform="rk3566")


def preprocessing_contract(profile: str) -> dict[str, object]:
    if profile == "ppocrv4_det":
        return {
            "mode": "embedded",
            "input_layout": "NHWC",
            "input_dtype": "uint8",
            "mean_values": PPOCRV4_DET_MEAN_VALUES,
            "std_values": PPOCRV4_DET_STD_VALUES,
        }
    return {"mode": "external_or_model_specific", "embedded": False}


def convert(input_path: Path, output_path: Path, profile: str) -> None:
    converter = RKNN(verbose=True)
    try:
        if configure(converter, profile) != 0:
            raise RuntimeError("RKNN config failed")
        if converter.load_onnx(model=str(input_path)) != 0:
            raise RuntimeError("RKNN ONNX load failed")
        if converter.build(do_quantization=False) != 0:
            raise RuntimeError("RKNN build failed")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        if converter.export_rknn(str(output_path)) != 0:
            raise RuntimeError("RKNN export failed")
    finally:
        converter.release()


def main() -> int:
    args = parse_args()
    input_path = args.input.resolve()
    output_path = args.output.resolve()
    report_path = args.report.resolve()
    if not input_path.is_file():
        raise FileNotFoundError(input_path)

    convert(input_path, output_path, args.profile)
    report = {
        "status": "PASS_ENGINEERING_CONVERSION_ONLY",
        "target": "rk3566",
        "profile": args.profile,
        "quantization": False,
        "preprocessing": preprocessing_contract(args.profile),
        "hardware_measured": False,
        "simulator_inference_verified": False,
        "product_selected": False,
        "input": {
            "path": str(args.input),
            "bytes": input_path.stat().st_size,
            "sha256": sha256(input_path),
        },
        "output": {
            "path": str(args.output),
            "bytes": output_path.stat().st_size,
            "sha256": sha256(output_path),
        },
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
