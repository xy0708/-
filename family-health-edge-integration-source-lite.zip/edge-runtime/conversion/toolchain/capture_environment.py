from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import subprocess
import sys
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def command_output(command: list[str]) -> str:
    completed = subprocess.run(command, check=True, capture_output=True, text=True)
    return completed.stdout.strip()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Capture the immutable RKNN converter environment.")
    parser.add_argument("--image-id", required=True)
    parser.add_argument("--report", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    pip_packages = sorted(
        ({"name": dist.metadata["Name"], "version": dist.version} for dist in importlib.metadata.distributions()),
        key=lambda item: (str(item["name"]).lower(), str(item["version"])),
    )
    dpkg_lines = command_output(["dpkg-query", "-W", "-f=${Package}\t${Version}\n"]).splitlines()
    pip_check = command_output([sys.executable, "-m", "pip", "check"])
    tracked_files = [
        Path("conversion/toolchain/Dockerfile.ubuntu20.04-cp38-rknn2.3.2"),
        Path("conversion/toolchain/Dockerfile.ppocr-simulator"),
        Path("conversion/toolchain/smoke_convert.py"),
        Path("conversion/ocr/simulate_ppocrv4.py"),
        Path("conversion/ocr/simulate_ppocrv4_system.py"),
        Path("conversion/asr/simulate_zipformer_components.py"),
        Path("conversion/asr/simulate_zipformer_audio.py"),
        Path("conversion/toolchain/Dockerfile.zipformer-simulator"),
        Path(
            "vendor/rockchip/rknn-toolkit2/rknn-toolkit2/docker/docker_file/ubuntu_20_04_cp38/"
            "rknn_toolkit2-2.3.2-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl"
        ),
    ]
    file_hashes = {
        str(path): {"bytes": path.stat().st_size, "sha256": sha256(path)}
        for path in tracked_files
    }
    report = {
        "status": "PASS_ENGINEERING_ENVIRONMENT_CAPTURE",
        "scope": "LOCAL_CONTENT_ADDRESSED_DOCKER_IMAGE",
        "image_id": args.image_id,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "rknn_toolkit2": importlib.metadata.version("rknn-toolkit2"),
        "pip_check": pip_check,
        "pip_packages": pip_packages,
        "dpkg_packages": dpkg_lines,
        "tracked_file_hashes": file_hashes,
        "dependency_versions_complete": True,
        "dependency_artifact_hash_lock_complete": False,
        "rebuild_caveat": "The image ID fixes this local image, but downloaded apt/pip artifacts do not yet have a complete external hash lock.",
        "hardware_measured": False,
        "formal_release_allowed": False,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("status", "image_id", "python", "rknn_toolkit2", "pip_check")}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
