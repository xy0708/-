from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from rknn.api import RKNN


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Probe whether the Toolkit2 PC simulator can load an exported RKNN."
    )
    parser.add_argument("--model", type=Path, action="append", required=True)
    parser.add_argument("--report", type=Path, required=True)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def probe_model(model: Path) -> dict[str, object]:
    if not model.is_file():
        raise FileNotFoundError(model)

    runtime = RKNN(verbose=False)
    load_code = -1
    init_code = -1
    try:
        load_code = runtime.load_rknn(str(model))
        if load_code == 0:
            init_code = runtime.init_runtime()
    finally:
        runtime.release()

    return {
        "model": model.name,
        "bytes": model.stat().st_size,
        "sha256": sha256(model),
        "load_code": load_code,
        "init_code": init_code,
        "pc_simulator_exported_rknn_load_supported": load_code == 0 and init_code == 0,
    }


def main() -> int:
    args = parse_args()
    records = [probe_model(model) for model in args.model]
    supported = all(
        record["pc_simulator_exported_rknn_load_supported"] for record in records
    )
    result = {
        "schema_version": "1.0.0",
        "status": (
            "PASS_PC_SIMULATOR_EXPORTED_RKNN_INFERENCE"
            if supported
            else "PC_SIMULATOR_EXPORTED_RKNN_INFERENCE_UNSUPPORTED"
        ),
        "runtime": {"name": "rknn-toolkit2", "version": "2.3.2"},
        "records": records,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, sort_keys=True))
    return 0 if supported else 2


if __name__ == "__main__":
    raise SystemExit(main())
