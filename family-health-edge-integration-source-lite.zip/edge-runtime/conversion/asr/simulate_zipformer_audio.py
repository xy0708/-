from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path

import kaldifeat
import numpy as np
import onnxruntime as ort
import scipy.signal
import soundfile as sf
import torch
from rknn.api import RKNN


SAMPLE_RATE = 16000
SEGMENT_FRAMES = 103
SEGMENT_OFFSET = 96
CONTEXT_SIZE = 2


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare complete Zipformer ONNX and RKNN PC-simulator transcripts."
    )
    parser.add_argument("--encoder-onnx", type=Path, required=True)
    parser.add_argument("--decoder-onnx", type=Path, required=True)
    parser.add_argument("--joiner-onnx", type=Path, required=True)
    parser.add_argument("--encoder-rknn", type=Path, required=True)
    parser.add_argument("--decoder-rknn", type=Path, required=True)
    parser.add_argument("--joiner-rknn", type=Path, required=True)
    parser.add_argument("--audio", type=Path, required=True)
    parser.add_argument("--vocab", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    return parser.parse_args()


def read_vocab(path: Path) -> dict[int, str]:
    vocab: dict[int, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        token_and_id = line.rsplit(" ", 1)
        token = token_and_id[0] if len(token_and_id) == 2 else ""
        token_id = int(token_and_id[-1])
        vocab[token_id] = token
    return vocab


def load_audio(path: Path) -> tuple[torch.Tensor, int, int]:
    waveform, original_rate = sf.read(str(path), dtype="float32")
    original_channels = 1 if waveform.ndim == 1 else waveform.shape[1]
    if waveform.ndim != 1:
        waveform = waveform.mean(axis=1)
    if original_rate != SAMPLE_RATE:
        desired_length = int(round(len(waveform) / original_rate * SAMPLE_RATE))
        waveform = scipy.signal.resample(waveform, desired_length).astype(np.float32)
    return torch.tensor(waveform, dtype=torch.float32), original_rate, original_channels


def create_fbank(audio: torch.Tensor) -> kaldifeat.OnlineFbank:
    options = kaldifeat.FbankOptions()
    options.frame_opts.samp_freq = SAMPLE_RATE
    options.mel_opts.num_bins = 80
    options.mel_opts.high_freq = -400
    options.frame_opts.dither = 0
    options.frame_opts.snip_edges = False
    fbank = kaldifeat.OnlineFbank(options)
    fbank.accept_waveform(sampling_rate=SAMPLE_RATE, waveform=audio)
    return fbank


def empty_encoder_state(session: ort.InferenceSession) -> list[np.ndarray]:
    state: list[np.ndarray] = []
    for model_input in session.get_inputs():
        shape = tuple(int(dimension) for dimension in model_input.shape)
        dtype = np.int64 if model_input.type == "tensor(int64)" else np.float32
        state.append(np.zeros(shape, dtype=dtype))
    return state


class OnnxBackend:
    def __init__(self, encoder: Path, decoder: Path, joiner: Path) -> None:
        providers = ["CPUExecutionProvider"]
        self.encoder = ort.InferenceSession(str(encoder), providers=providers)
        self.decoder = ort.InferenceSession(str(decoder), providers=providers)
        self.joiner = ort.InferenceSession(str(joiner), providers=providers)
        self.reset()

    def reset(self) -> None:
        self.encoder_state = empty_encoder_state(self.encoder)

    def run_encoder(self, frames: torch.Tensor) -> np.ndarray:
        self.encoder_state[0] = frames.numpy()
        feed = {
            model_input.name: value
            for model_input, value in zip(self.encoder.get_inputs(), self.encoder_state)
        }
        outputs = self.encoder.run(None, feed)
        self.encoder_state[1:] = outputs[1:]
        return outputs[0]

    def run_decoder(self, token_ids: np.ndarray) -> np.ndarray:
        name = self.decoder.get_inputs()[0].name
        return self.decoder.run(None, {name: token_ids})[0]

    def run_joiner(self, encoder_out: np.ndarray, decoder_out: np.ndarray) -> np.ndarray:
        inputs = self.joiner.get_inputs()
        return self.joiner.run(
            None, {inputs[0].name: encoder_out, inputs[1].name: decoder_out}
        )[0]

    def release(self) -> None:
        self.encoder = None
        self.decoder = None
        self.joiner = None


def create_rknn_simulator(model_path: Path) -> RKNN:
    runtime = RKNN(verbose=False)
    if runtime.config(target_platform="rk3566") != 0:
        raise RuntimeError(f"RKNN config failed: {model_path}")
    if runtime.load_onnx(model=str(model_path)) != 0:
        raise RuntimeError(f"RKNN ONNX load failed: {model_path}")
    if runtime.build(do_quantization=False) != 0:
        raise RuntimeError(f"RKNN build failed: {model_path}")
    if runtime.init_runtime() != 0:
        raise RuntimeError(f"RKNN PC simulator initialization failed: {model_path}")
    return runtime


def rknn_input_layout(values: list[np.ndarray]) -> list[np.ndarray]:
    return [
        np.transpose(value, (0, 2, 3, 1)) if value.ndim == 4 else value
        for value in values
    ]


class RknnSimulatorBackend:
    def __init__(self, encoder: Path, decoder: Path, joiner: Path) -> None:
        self.encoder_metadata = ort.InferenceSession(
            str(encoder), providers=["CPUExecutionProvider"]
        )
        self.encoder = create_rknn_simulator(encoder)
        self.decoder = create_rknn_simulator(decoder)
        self.joiner = create_rknn_simulator(joiner)
        self.reset()

    def reset(self) -> None:
        self.encoder_state = empty_encoder_state(self.encoder_metadata)

    def run_encoder(self, frames: torch.Tensor) -> np.ndarray:
        self.encoder_state[0] = frames.numpy()
        outputs = self.encoder.inference(inputs=rknn_input_layout(self.encoder_state))
        self.encoder_state[1:] = outputs[1:]
        return outputs[0]

    def run_decoder(self, token_ids: np.ndarray) -> np.ndarray:
        return self.decoder.inference(inputs=[token_ids])[0]

    def run_joiner(self, encoder_out: np.ndarray, decoder_out: np.ndarray) -> np.ndarray:
        return self.joiner.inference(inputs=[encoder_out, decoder_out])[0]

    def release(self) -> None:
        self.encoder.release()
        self.decoder.release()
        self.joiner.release()


def greedy_decode(backend: object, audio: torch.Tensor) -> tuple[list[int], list[int]]:
    backend.reset()
    fbank = create_fbank(audio)
    original_frame_count = fbank.num_frames_ready
    processed_frames = 0
    frame_offset = 0
    hypothesis = [0] * CONTEXT_SIZE
    decoder_out = backend.run_decoder(np.asarray([hypothesis], dtype=np.int64))
    timestamps: list[int] = []

    while original_frame_count - processed_frames > 0:
        remaining = original_frame_count - processed_frames
        if remaining < SEGMENT_FRAMES:
            padding_seconds = (SEGMENT_FRAMES - remaining) / 100.0
            fbank.accept_waveform(
                sampling_rate=SAMPLE_RATE,
                waveform=torch.zeros(int(padding_seconds * SAMPLE_RATE), dtype=torch.float32),
            )
        frames = torch.cat(
            [fbank.get_frame(processed_frames + i) for i in range(SEGMENT_FRAMES)], dim=0
        ).reshape(1, SEGMENT_FRAMES, 80)
        encoder_out = backend.run_encoder(frames).squeeze(0)
        for frame in encoder_out:
            logits = backend.run_joiner(frame.reshape(1, -1), decoder_out)
            token_id = int(np.argmax(logits))
            if token_id not in (0, 2):
                timestamps.append(frame_offset)
                hypothesis.append(token_id)
                decoder_input = np.asarray([hypothesis[-CONTEXT_SIZE:]], dtype=np.int64)
                decoder_out = backend.run_decoder(decoder_input)
            frame_offset += 1
        processed_frames += SEGMENT_OFFSET
    return hypothesis[CONTEXT_SIZE:], timestamps


def decode_text(tokens: list[int], vocab: dict[int, str]) -> str:
    return "".join(vocab.get(token, "") for token in tokens).replace("▁", " ").strip()


def timed_transcription(backend: object, audio: torch.Tensor) -> dict[str, object]:
    started = time.perf_counter()
    tokens, timestamps = greedy_decode(backend, audio)
    elapsed = time.perf_counter() - started
    return {"tokens": tokens, "timestamps": timestamps, "host_seconds": elapsed}


def main() -> int:
    args = parse_args()
    required = (
        args.encoder_onnx,
        args.decoder_onnx,
        args.joiner_onnx,
        args.encoder_rknn,
        args.decoder_rknn,
        args.joiner_rknn,
        args.audio,
        args.vocab,
    )
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(", ".join(missing))

    audio, original_rate, original_channels = load_audio(args.audio)
    vocab = read_vocab(args.vocab)

    onnx_backend = OnnxBackend(args.encoder_onnx, args.decoder_onnx, args.joiner_onnx)
    try:
        onnx_result = timed_transcription(onnx_backend, audio)
    finally:
        onnx_backend.release()

    rknn_backend = RknnSimulatorBackend(
        args.encoder_onnx, args.decoder_onnx, args.joiner_onnx
    )
    try:
        rknn_result = timed_transcription(rknn_backend, audio)
    finally:
        rknn_backend.release()

    onnx_result["text"] = decode_text(onnx_result["tokens"], vocab)
    rknn_result["text"] = decode_text(rknn_result["tokens"], vocab)
    transcript_matches = onnx_result["text"] == rknn_result["text"]
    tokens_match = onnx_result["tokens"] == rknn_result["tokens"]
    status = (
        "PASS_ENGINEERING_FUNCTIONAL_SIMULATION"
        if transcript_matches and tokens_match
        else "INCONCLUSIVE_FUNCTIONAL_SIMULATION_MISMATCH"
    )
    report = {
        "status": status,
        "scope": "PC_SIMULATOR_SINGLE_OFFICIAL_SAMPLE_ONLY",
        "target_model": "rk3566",
        "exported_rknn_loaded_by_simulator": False,
        "rknn_rank4_input_adapter": "NCHW_TO_NHWC",
        "hardware_measured": False,
        "product_accuracy_claim_allowed": False,
        "wer_or_cer_claim_allowed": False,
        "host_timing_is_device_performance": False,
        "sample": {
            "audio_sha256": sha256(args.audio),
            "duration_seconds": len(audio) / SAMPLE_RATE,
            "original_sample_rate": original_rate,
            "original_channels": original_channels,
            "vocab_sha256": sha256(args.vocab),
        },
        "model_hashes": {
            "encoder_onnx": sha256(args.encoder_onnx),
            "decoder_onnx": sha256(args.decoder_onnx),
            "joiner_onnx": sha256(args.joiner_onnx),
            "encoder_rknn": sha256(args.encoder_rknn),
            "decoder_rknn": sha256(args.decoder_rknn),
            "joiner_rknn": sha256(args.joiner_rknn),
        },
        "dependencies": {
            "kaldifeat": kaldifeat.__version__,
            "torch": torch.__version__,
            "onnxruntime": ort.__version__,
            "soundfile": sf.__version__,
        },
        "onnx": onnx_result,
        "rknn_pc_simulator": rknn_result,
        "comparison": {
            "transcript_exact_match": transcript_matches,
            "token_sequence_exact_match": tokens_match,
        },
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if status.startswith("PASS_") else 2


if __name__ == "__main__":
    raise SystemExit(main())
