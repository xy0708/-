from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import sherpa_onnx
import soundfile as sf


ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks.comparison.asr_med_ch import (
    CANDIDATE_STATUS,
    evaluate_samples,
    load_dataset,
    predictions_digest,
    sha256,
)
from benchmarks.comparison.asr_single_sample import verify_cpu_model_manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--subset-report", type=Path, required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


class CpuRecognizer:
    def __init__(self, model_dir: Path) -> None:
        self.recognizer = sherpa_onnx.OnlineRecognizer.from_transducer(
            tokens=str(model_dir / "tokens.txt"),
            encoder=str(model_dir / "encoder.int8.onnx"),
            decoder=str(model_dir / "decoder.onnx"),
            joiner=str(model_dir / "joiner.int8.onnx"),
            num_threads=1,
            sample_rate=16_000,
            feature_dim=80,
            decoding_method="greedy_search",
            model_type="zipformer2",
            enable_endpoint_detection=False,
            provider="cpu",
        )

    def transcribe(self, path: Path) -> str:
        samples, sample_rate = sf.read(path, dtype="float32", always_2d=True)
        if sample_rate != 16_000:
            raise ValueError("sample rate mismatch")
        mono = np.ascontiguousarray(samples.mean(axis=1, dtype=np.float32))
        stream = self.recognizer.create_stream()
        chunk_samples = 1_600
        for start in range(0, mono.size, chunk_samples):
            stream.accept_waveform(sample_rate, mono[start : start + chunk_samples])
            while self.recognizer.is_ready(stream):
                self.recognizer.decode_stream(stream)
        stream.accept_waveform(sample_rate, np.zeros(sample_rate, dtype=np.float32))
        while self.recognizer.is_ready(stream):
            self.recognizer.decode_stream(stream)
        stream.input_finished()
        while self.recognizer.is_ready(stream):
            self.recognizer.decode_stream(stream)
        result = self.recognizer.get_result(stream)
        text = result if isinstance(result, str) else getattr(result, "text", "")
        return text.strip() if isinstance(text, str) else ""


def main() -> int:
    args = parse_args()
    samples, dataset = load_dataset(
        project_root=args.project_root,
        manifest_path=args.manifest,
        metadata_path=args.metadata,
        subset_report_path=args.subset_report,
    )
    model_dir = args.model_dir.resolve(strict=True)
    bundle_hash = verify_cpu_model_manifest(model_dir, args.model_manifest)
    recognizer = CpuRecognizer(model_dir)
    metrics, predictions = evaluate_samples(samples, recognizer.transcribe)
    report = {
        "schema_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": CANDIDATE_STATUS,
        "scope": "MED_CH_60_RESEARCH_ENGINEERING_ONLY",
        "candidate_id": "asr_sherpa_cpu_xasr",
        "execution": "WINDOWS_X86_64_CPU_REAL_INFERENCE",
        "runtime": {"name": "sherpa_onnx", "version": sherpa_onnx.__version__},
        "model_bundle_sha256": bundle_hash,
        "model_manifest_sha256": sha256(args.model_manifest),
        "dataset": dataset,
        "metrics": metrics,
        "predictions": predictions,
        "predictions_sha256": predictions_digest(predictions),
        "product_selection_allowed": False,
        "hardware_measured": False,
        "target_microphone_evidence": False,
    }
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"status": report["status"], "metrics": metrics}, ensure_ascii=True))
    return 0 if metrics["failures"] == 0 and metrics["empty_results"] == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
