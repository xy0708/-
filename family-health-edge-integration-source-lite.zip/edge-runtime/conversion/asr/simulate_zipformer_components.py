from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import onnxruntime as ort
from rknn.api import RKNN


COMPONENTS = ("encoder", "decoder", "joiner")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare Zipformer ONNX outputs with RKNN PC-simulator outputs."
    )
    parser.add_argument("--component", choices=COMPONENTS, required=True)
    parser.add_argument("--onnx", type=Path, required=True)
    parser.add_argument("--rknn", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260917)
    return parser.parse_args()


def concrete_shape(model_input: ort.NodeArg) -> tuple[int, ...]:
    if any(not isinstance(dimension, int) or dimension <= 0 for dimension in model_input.shape):
        raise ValueError(f"Dynamic input shape is not supported: {model_input.name}={model_input.shape}")
    return tuple(model_input.shape)


def build_inputs(session: ort.InferenceSession, component: str, seed: int) -> list[np.ndarray]:
    generator = np.random.default_rng(seed)
    inputs: list[np.ndarray] = []
    for model_input in session.get_inputs():
        shape = concrete_shape(model_input)
        if model_input.type == "tensor(int64)":
            value = np.zeros(shape, dtype=np.int64)
        elif model_input.type == "tensor(float)":
            should_exercise_signal_path = (
                component == "joiner" or (component == "encoder" and model_input.name == "x")
            )
            value = (
                generator.normal(0.0, 0.5, size=shape).astype(np.float32)
                if should_exercise_signal_path
                else np.zeros(shape, dtype=np.float32)
            )
        else:
            raise TypeError(f"Unsupported input type: {model_input.name}={model_input.type}")
        inputs.append(value)
    return inputs


def run_onnx(session: ort.InferenceSession, inputs: list[np.ndarray]) -> list[np.ndarray]:
    feed = {
        model_input.name: value
        for model_input, value in zip(session.get_inputs(), inputs)
    }
    return [np.asarray(output) for output in session.run(None, feed)]


def rknn_input_layout(inputs: list[np.ndarray]) -> list[np.ndarray]:
    return [
        np.transpose(value, (0, 2, 3, 1)) if value.ndim == 4 else value
        for value in inputs
    ]


def run_rknn_simulator(model_path: Path, inputs: list[np.ndarray]) -> list[np.ndarray]:
    runtime = RKNN(verbose=False)
    try:
        if runtime.config(target_platform="rk3566") != 0:
            raise RuntimeError("RKNN simulator config failed")
        if runtime.load_onnx(model=str(model_path)) != 0:
            raise RuntimeError("RKNN simulator ONNX load failed")
        if runtime.build(do_quantization=False) != 0:
            raise RuntimeError("RKNN simulator build failed")
        if runtime.init_runtime() != 0:
            raise RuntimeError("RKNN PC simulator initialization failed")
        outputs = runtime.inference(inputs=rknn_input_layout(inputs))
        if not outputs:
            raise RuntimeError("RKNN PC simulator returned no outputs")
        return [np.asarray(output) for output in outputs]
    finally:
        runtime.release()


def float_metrics(reference: np.ndarray, candidate: np.ndarray) -> dict[str, float | None]:
    difference = np.abs(reference.astype(np.float64) - candidate.astype(np.float64))
    reference_flat = reference.reshape(-1).astype(np.float64)
    candidate_flat = candidate.reshape(-1).astype(np.float64)
    denominator = float(np.linalg.norm(reference_flat) * np.linalg.norm(candidate_flat))
    return {
        "max_absolute_error": float(difference.max(initial=0.0)),
        "mean_absolute_error": float(difference.mean()) if difference.size else 0.0,
        "p99_absolute_error": float(np.percentile(difference, 99)) if difference.size else 0.0,
        "cosine_similarity": (
            float(np.dot(reference_flat, candidate_flat) / denominator) if denominator else None
        ),
    }


def compare_output(reference: np.ndarray, candidate: np.ndarray, name: str) -> dict[str, object]:
    same_shape = reference.shape == candidate.shape
    result: dict[str, object] = {
        "name": name,
        "onnx_shape": list(reference.shape),
        "rknn_shape": list(candidate.shape),
        "same_shape": same_shape,
        "onnx_dtype": str(reference.dtype),
        "rknn_dtype": str(candidate.dtype),
        "finite": bool(np.isfinite(candidate).all()),
    }
    if not same_shape:
        return result
    if np.issubdtype(reference.dtype, np.integer):
        result["exact_match"] = bool(np.array_equal(reference, candidate))
    else:
        result.update(float_metrics(reference, candidate))
    return result


def main() -> int:
    args = parse_args()
    if not args.onnx.is_file() or not args.rknn.is_file():
        raise FileNotFoundError(f"Missing ONNX or RKNN input: {args.onnx}, {args.rknn}")

    session = ort.InferenceSession(str(args.onnx), providers=["CPUExecutionProvider"])
    inputs = build_inputs(session, args.component, args.seed)
    onnx_outputs = run_onnx(session, inputs)
    rknn_outputs = run_rknn_simulator(args.onnx, inputs)
    output_names = [output.name for output in session.get_outputs()]
    output_count_matches = len(onnx_outputs) == len(rknn_outputs)
    comparisons = [
        compare_output(reference, candidate, name)
        for reference, candidate, name in zip(
            onnx_outputs, rknn_outputs, output_names
        )
    ]
    execution_passed = output_count_matches and all(
        comparison["same_shape"] and comparison["finite"] for comparison in comparisons
    )
    report = {
        "status": (
            "PASS_ENGINEERING_SIMULATOR_EXECUTION"
            if execution_passed
            else "FAIL_ENGINEERING_SIMULATOR_EXECUTION"
        ),
        "scope": "PC_SIMULATOR_SYNTHETIC_TENSOR_ONLY",
        "component": args.component,
        "target_model": "rk3566",
        "simulator_build_source": "onnx_with_same_rk3566_config",
        "exported_rknn_loaded_by_simulator": False,
        "rknn_rank4_input_adapter": "NCHW_TO_NHWC",
        "synthetic_input": True,
        "audio_or_transcript_evaluated": False,
        "hardware_measured": False,
        "product_accuracy_claim_allowed": False,
        "numeric_acceptance_threshold_frozen": False,
        "seed": args.seed,
        "inputs": {
            "onnx_sha256": sha256(args.onnx),
            "rknn_sha256": sha256(args.rknn),
            "names": [model_input.name for model_input in session.get_inputs()],
        },
        "output_count_matches": output_count_matches,
        "comparisons": comparisons,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if execution_passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
