from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIR = Path(__file__).resolve().parent
for import_root in (ROOT, SCRIPT_DIR):
    if str(import_root) not in sys.path:
        sys.path.insert(0, str(import_root))

from benchmarks.comparison.asr_med_ch import (
    CANDIDATE_STATUS,
    evaluate_samples,
    load_dataset,
    predictions_digest,
    sha256,
)
from simulate_zipformer_audio import (
    RknnSimulatorBackend,
    decode_text,
    greedy_decode,
    load_audio,
    read_vocab,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--subset-report", type=Path, required=True)
    parser.add_argument("--encoder-onnx", type=Path, required=True)
    parser.add_argument("--decoder-onnx", type=Path, required=True)
    parser.add_argument("--joiner-onnx", type=Path, required=True)
    parser.add_argument("--vocab", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    samples, dataset = load_dataset(
        project_root=args.project_root,
        manifest_path=args.manifest,
        metadata_path=args.metadata,
        subset_report_path=args.subset_report,
    )
    vocab = read_vocab(args.vocab)
    backend = RknnSimulatorBackend(
        args.encoder_onnx, args.decoder_onnx, args.joiner_onnx
    )

    def transcribe(path: Path) -> str:
        audio, original_rate, original_channels = load_audio(path)
        if original_rate != 16_000 or original_channels != 1:
            raise ValueError("sample format mismatch")
        tokens, _ = greedy_decode(backend, audio)
        return decode_text(tokens, vocab)

    try:
        metrics, predictions = evaluate_samples(samples, transcribe)
    finally:
        backend.release()
    report = {
        "schema_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": CANDIDATE_STATUS,
        "scope": "MED_CH_60_RESEARCH_ENGINEERING_ONLY",
        "candidate_id": "asr_rknn_zipformer",
        "execution": "X86_64_PC_SIMULATOR_FROM_FROZEN_ONNX",
        "runtime": {"name": "rknn_toolkit2_pc_simulator", "version": "2.3.2"},
        "exported_target_rknn_loaded": False,
        "source_model_sha256": {
            "encoder_onnx": sha256(args.encoder_onnx),
            "decoder_onnx": sha256(args.decoder_onnx),
            "joiner_onnx": sha256(args.joiner_onnx),
            "vocab": sha256(args.vocab),
        },
        "dataset": dataset,
        "metrics": metrics,
        "predictions": predictions,
        "predictions_sha256": predictions_digest(predictions),
        "product_selection_allowed": False,
        "hardware_measured": False,
        "target_microphone_evidence": False,
    }
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"status": report["status"], "metrics": metrics}, ensure_ascii=True))
    return 0 if metrics["failures"] == 0 and metrics["empty_results"] == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
