# 端侧上线工程规则

1. 每轮先读取活动的 `RK3576_PHONE_WATCH_INTEGRATION_LOOP.md` 和 `ANDROID_EDGE_PRODUCTION_LOOP.md`，再读取历史 `EDGE_PRODUCTION_LOOP.md`、模型比较 `RK3566_OFFICIAL_MODELS_PRODUCTION_LOOP.md`、`LOOP_STATE.md`、`PROGRESS.md` 和 `BLOCKERS.md`。
2. Android 是唯一活动产品目标；Linux/systemd/ALSA/ELF/PyInstaller 证据只作历史基线，不得继承为 Android Gate。
3. 依次推进 A00-A12；外部输入缺失时标记 `BLOCKED_EXTERNAL`，继续可独立推进的工程任务。
4. 健康 V1 只允许可解释规则、输入质量和个人趋势提示，禁止疾病诊断、疾病概率、处方和治疗建议。
5. CHARLS 永久排除。NHANES 和合成数据不得作为中国上线产品性能证据。
6. OCR/ASR/手表结果确认前禁止入库；原始报告、语音和完整健康值默认不上传。
7. 没有真实 RK3576 Android、真实手表、真实授权验收材料、许可结论或具名批准时，不得将对应 Gate 标记为产品通过。
8. 旧 `scripts/verify_release.py` 只验证历史 Linux 包；Android 正式 release 验证器完成前不得生成正式 release。
9. 代码优先使用 Python 标准库，新增第三方依赖必须锁版本、登记许可和进入 SBOM。
10. OCR/ASR Android 选型继续比较 RKNN 与 CPU 后端；历史 RK3566/RK3568 结果不得冒充 RK3576，官方示例只获得候选资格，不得直接标记为产品通过。

本机工程验证命令：

```powershell
.\.venv-edge\Scripts\python.exe -m unittest discover -s tests -p "test_android*.py" -v
.\.venv-edge\Scripts\python.exe scripts\verify_android_migration.py
.\.venv-edge\Scripts\python.exe scripts\run_android_migration_loop.py
```
