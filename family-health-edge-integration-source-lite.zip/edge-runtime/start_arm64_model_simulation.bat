@echo off
setlocal
cd /d "%~dp0"
".venv-edge\Scripts\python.exe" "scripts\build_arm64_wheelhouse_manifest.py"
if errorlevel 1 goto :failed
".venv-edge\Scripts\python.exe" "scripts\run_arm64_model_simulation.py"
set "rc=%errorlevel%"
if "%rc%"=="3" (
  echo Available real models passed ARM64 simulation; OCR and RK3566 remain blocked.
) else if not "%rc%"=="0" (
  goto :failed
)
pause
exit /b %rc%
:failed
echo ARM64 model simulation failed. See reports\arm64_model_simulation_latest.json
pause
exit /b 2
