# 家庭健康管理 Android 端侧产品 Loop

更新日期：2026-10-13  
活动目标：RK3576 / Android 14 / `arm64-v8a`  
产品定位：家庭健康管理提示工具（非医疗诊断系统）

> 手表—手机—端侧的当前执行计划以
> `RK3576_PHONE_WATCH_INTEGRATION_LOOP.md` 为准。本文件继续管理三模型 Android
> 迁移门禁；其中所有 RK3566 真机要求已被 RK3576 真机要求替代，旧证据只作历史参考。

## 0. 迁移结论

原工程的活动交付目标是 ARM64 Linux，依赖 systemd、Unix Domain Socket、
ALSA、Linux Shell 安装器和 AArch64 ELF/PyInstaller。这些成果保留为历史工程
基线，但不能作为 Android 产品运行时或真机证据。

从本文件生效起，Android 是唯一活动产品目标。Linux 模拟和历史报告只能用于
回归参考；禁止把它们标记为 Android 构建、Android 真机或产品验收通过。

## 1. 永久边界

- 健康模块只输出非诊断提示、输入质量和个人趋势；不得输出疾病确诊、处方、
  治疗建议或未经目标人群验证的疾病概率。
- CHARLS 永久排除。NHANES、合成数据和研究数据不得作为中国上线性能证据。
- OCR、ASR 和手表健康数据必须标注来源、单位、时间与确认状态；未经用户确认
  不得进入正式健康档案。
- 原始报告、原始语音和完整手表健康数据默认不上传，不进入普通日志。
- 只允许发布 `arm64-v8a` 产品 ABI；不得把 x86 模拟器或历史RK3566/RK3568结果冒充RK3576。
- 未取得 SDK、AAR/JAR/SO、模型和数据的商业分发权利前，只能通过工程 Gate。
- 用户已确认目标系统为Android 14；未接入真实开发板前，API实值、系统签名、
  启动方式、RKNPU驱动和RKNN Runtime仍保持未知，不把计划值当真机证据。

## 2. 产品架构

```text
Android Flutter App
├─ WatchAdapter       手表扫描、连接、同步、字段规范化
├─ HealthRuntime      非诊断规则；ML 仅 shadow
├─ OcrRuntime         Camera/Image -> pending result
├─ AsrRuntime         Microphone -> pending result
├─ LocalRepository    成员隔离、确认后写入、删除/导出
├─ Android Keystore   每设备密钥包装
└─ UpdateClient       签名 APK/系统 OTA、回滚与版本绑定
```

模型权重可复用不代表 Linux 进程可复用。Android 侧必须重新验证 JNI/AAR、
ONNX Runtime 或 RKNN Runtime 的 ABI、生命周期、线程、内存、温度和故障恢复。
Linux 的 systemd 服务由 Android 进程生命周期、必要时的前台服务和厂商批准的
开机策略替代；普通应用不得假设 root、系统签名或静默自启动权限。

## 3. Gate

| Gate | 内容 | 当前状态 | 完成条件 |
|---|---|---|---|
| A00 | 目标系统纠正与历史证据封存 | PASS_ENGINEERING | 活动合同为 Android，Linux 合同只读归档 |
| A01 | Android 工具链冻结 | PASS_ENGINEERING | Flutter/Java/SDK/NDK、Gradle 依赖、工程构建与输入哈希已记录 |
| A02 | Android 产品应用骨架 | PASS_ENGINEERING | applicationId、ABI、最小权限、release 不使用 debug 签名，分析/测试/构建通过 |
| A03 | 手表 SDK 来源与许可 | BLOCKED_EXTERNAL | 固定不可变 commit/release；全部内嵌二进制获得商业分发结论 |
| A04 | BLE 权限和连接状态机 | PASS_ENGINEERING_PARTIAL | 权限桥、扫描/连接/关闭已实现；重连、超时、并发与真手表待验收 |
| A05 | 手表字段适配与数据边界 | IN_PROGRESS | 来源、时间、单位、待确认与数量上限已实现；供应商字段语义/异常值/真手表待验收 |
| A06 | 三模型 Android Runtime | IN_PROGRESS | 非诊断健康规则已嵌入并测试；ASR 模型、arm64 原生库、运行时及 16 kHz PCM 麦克风采集已打入调试 APK并通过本地测试，但未在 Android/RK3576 执行；OCR runtime 尚不存在 |
| A07 | Android 本地存储与密钥 | NOT_STARTED | Keystore、加密库、成员隔离、迁移、备份、删除与恢复通过 |
| A08 | 离线整合与故障隔离 | NOT_STARTED | 无研发电脑/互联网可用；任一模块失败不拖垮其他模块 |
| A09 | 构建、签名、SBOM 与隐私 | IN_PROGRESS | ABI/权限/组件/备份/明文流量工程审计通过；release 签名、SBOM、许可和安全审查待完成 |
| A10 | RK3576 Android 真机验收 | BLOCKED_EXTERNAL | ADB 设备指纹、性能、温度、长稳、断电和外设实测通过 |
| A11 | 安装、升级与回滚 | BLOCKED_EXTERNAL | 干净板安装、签名升级、中断恢复、回滚与跨 SKU 拒绝通过 |
| A12 | 最终产品验收 | BLOCKED_EXTERNAL | A00-A11 产品门禁和具名批准全部通过 |

## 4. A01 工具链门禁

必须记录 Flutter、Dart、Java、Android SDK、Build Tools、NDK、Gradle、固定的
SDK/API/ABI、依赖锁、APK 内容、签名证书和 SBOM。本机没有 ADB 设备时必须明确
`BLOCKED_EXTERNAL`。

## 5. A03-A05 手表 SDK 门禁

当前候选来自 `https://gitee.com/yucheng_3/yc_product_plugin`。源代码仓库顶层
显示 MIT，但插件目录的 `LICENSE` 仍是占位文本，9 个 AAR/JAR 和原生 SO 内
未发现许可证/NOTICE，故不得推断所有二进制均可随产品商业分发。

接入前必须：

1. 固定不可变 commit 或供应商 release，不把可变 `master.zip` 当正式来源。
2. 获取 SDK、内嵌二进制、算法结果和固件升级能力的商业分发/再分发书面结论。
3. 移除示例中的后台定位、联系人、电话、全盘存储、写系统设置等无关权限。
4. Android 12+ 使用蓝牙扫描/连接运行时授权；旧版只在确需扫描时使用带
   `maxSdkVersion=30` 的定位权限。
5. 禁止 SDK 调试日志输出健康值；数据先经字段适配、单位校验和确认状态机。

## 6. A06 三模型迁移门禁

- 健康：优先把非诊断规则移入 Dart/Kotlin 纯逻辑层；ONNX shadow 模型需用
  Android arm64 ONNX Runtime 重新做逐样本对齐与真机资源测试。
- OCR：选定产品后端前保留空路由；若使用 RKNN，必须集成 Android 可分发的
  `librknnrt.so`/JNI 并在真实报告集与 RK3576 Android 上验收。
- ASR：当前使用固定 `sherpa_onnx 1.13.7` Android arm64 JNI 与冻结 X-ASR
  权重；APK 内模型、许可证和原生库已经逐项做大小/SHA-256 校验，运行时先把权重
  校验复制到应用私有目录再初始化。`record 6.1.2` 已提供 16 kHz、单声道 PCM16
  采集，停止/取消、跨块解码、单会话和原始音频不落盘已通过本地测试。该状态仍只
  证明工程已打包和主机测试通过；还需在目标 Android 板验证权限、停止检测、字段提取、
  后台策略、目标麦克风效果和 RK3576 资源指标。
- 三模型的开发集、测试集和独立验收集继续物理隔离；普通 Accuracy 不是默认指标。

## 7. A07-A11 产品门禁

- 敏感数据使用应用私有存储；密钥由 Android Keystore 包装，不硬编码。
- 备份、截屏、明文流量和调试导出默认关闭；日志只含固定事件码和匿名任务 ID。
- release 不使用 debug keystore；包名、签名证书和版本回滚策略必须冻结。
- 厂商系统若要求 system app、开机启动、静默安装或受保护蓝牙能力，必须取得
  板卡厂商/AOSP 镜像支持并作为单独产品 Gate。
- 真机验收绑定系统指纹、API、安全补丁、SoC、ABI、RKNPU、RKNN Runtime、
  APK、模型和测试输入 SHA-256。

## 8. 每轮执行方法

1. 读取本文件、`LOOP_STATE.md`、`PROGRESS.md`、`BLOCKERS.md` 和旧 Loop。
2. 检查 ADB、工具链、长任务、磁盘、上次报告和输入漂移。
3. 从 A00 开始选择第一个可独立推进的未通过 Gate。
4. 每轮完成一个可审计的主要改动；修复行为必须增加或更新测试。
5. 先运行定向测试，再运行 Android 迁移 Loop；能构建时再运行 Flutter/Gradle。
6. 保存命令、退出码、输入/输出 SHA-256、报告和失败摘要。
7. 外部条件缺失时继续其他工程任务，不制造通过状态。
8. 只有真实板卡、授权、签名和独立验收全部通过后才允许结束。

## 9. 当前恢复入口

```powershell
cd C:\Users\45277\Desktop\模型\端侧上线
.\.venv-edge\Scripts\python.exe scripts\run_android_migration_loop.py
```

Flutter/Gradle 构建必须使用实际 Windows 用户权限执行；受限账户无法写
`C:\flutter` 缓存时应报告环境阻断，不得无限等待或伪造构建成功。
