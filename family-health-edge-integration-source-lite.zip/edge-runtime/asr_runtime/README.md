# ASR ARM64 Runtime

目标：在 RK3566 ARM64 CPU 上运行现有 X-ASR INT8 / Sherpa-ONNX 流式识别。

本目录不包含重新训练逻辑。源模型继续由现有 ASR 工程管理；端侧 release 只复制 manifest 允许且 hash 完全匹配的 encoder、decoder、joiner、tokens 和 BPE 文件。

当前工程状态：已锁定并审计 Sherpa-ONNX 1.13.7 ARM64 运行库，现有 X-ASR 候选已完成 ARM64 容器内真实推理和 S3 部分服务集成。它仍只是工程候选，不是产品结论。

当前产品阻塞：尚缺商业分发具名批准、商业可用目标麦克风真人独立验收集、统一内部划分、真 RK3566 性能/温度/稳定性测量及产品 worker 验收。
