from __future__ import annotations

import re
import unicodedata
from datetime import date, timedelta
from typing import Any


_DIGITS = {
    "零": 0,
    "〇": 0,
    "一": 1,
    "二": 2,
    "两": 2,
    "三": 3,
    "四": 4,
    "五": 5,
    "六": 6,
    "七": 7,
    "八": 8,
    "九": 9,
}
_SMALL_UNITS = {"十": 10, "百": 100, "千": 1000}
_NUMBER = re.compile(r"[零〇一二两三四五六七八九十百千万点]+")
_OWNER = re.compile(r"(?P<owner>爸爸|妈妈|爷爷|奶奶|外公|外婆|哥哥|弟弟|姐姐|妹妹)")
_PRESSURE_EXPLICIT = re.compile(
    r"高压[^\d]{0,8}(?P<high>\d{2,3})[^\d]{0,12}低压[^\d]{0,8}(?P<low>\d{2,3})"
)
_PRESSURE_PAIR = re.compile(
    r"血压[^\d]{0,12}(?P<high>\d{2,3})\s*(?:/|比|和|、|,|，|\s)\s*(?P<low>\d{2,3})"
)
_GLUCOSE = re.compile(r"(?:空腹|餐后)?血糖(?:值)?[^\d]{0,10}(?P<value>\d{1,2}(?:\.\d+)?)")
_HEART_RATE = re.compile(r"(?:心率|脉搏)[^\d]{0,10}(?P<value>\d{2,3})")
_TEMPERATURE = re.compile(r"(?:体温|温度)[^\d]{0,10}(?P<value>\d{2}(?:\.\d+)?)")
_WEIGHT = re.compile(r"体重[^\d]{0,10}(?P<value>\d{1,3}(?:\.\d+)?)\s*(?P<unit>kg|斤)?")
_HEIGHT_METERS = re.compile(r"身高[^\d]{0,10}(?P<meters>\d)\s*米\s*(?P<centimeters>\d{1,2})")
_HEIGHT = re.compile(r"身高[^\d]{0,10}(?P<value>\d{1,3}(?:\.\d+)?)\s*(?P<unit>cm|米|m)?")
_RANGES = {
    "blood_glucose": (1.0, 40.0),
    "heart_rate": (20.0, 250.0),
    "temperature": (30.0, 45.0),
    "weight": (2.0, 500.0),
    "height": (30.0, 250.0),
}
_RELATIVE_DAYS = {"前天": -2, "昨天": -1, "今天": 0, "明天": 1, "后天": 2}


def _chinese_integer(value: str) -> int:
    if not any(character in _SMALL_UNITS or character == "万" for character in value):
        return int("".join(str(_DIGITS[character]) for character in value if character in _DIGITS) or "0")
    total = section = number = 0
    for character in value:
        if character in _DIGITS:
            number = _DIGITS[character]
        elif character in _SMALL_UNITS:
            section += (number or 1) * _SMALL_UNITS[character]
            number = 0
        elif character == "万":
            total += (section + number) * 10_000
            section = number = 0
    return total + section + number


def _number_text(value: str) -> str:
    if "点" not in value:
        return str(_chinese_integer(value))
    integer, fractional = value.split("点", 1)
    digits = "".join(str(_DIGITS[character]) for character in fractional if character in _DIGITS)
    return f"{_chinese_integer(integer)}.{digits}" if digits else str(_chinese_integer(integer))


def normalize_spoken_text(text: str) -> str:
    value = unicodedata.normalize("NFKC", text).strip().lower()
    value = _NUMBER.sub(lambda match: _number_text(match.group()), value)
    for source, target in {
        "毫米汞柱": "mmhg",
        "毫摩尔每升": "mmol/l",
        "公斤": "kg",
        "千克": "kg",
        "厘米": "cm",
        "公分": "cm",
        "摄氏度": "度",
    }.items():
        value = value.replace(source, target)
    return re.sub(r"\s+", " ", value)


def _measured_on(text: str, today: date) -> str:
    explicit = re.search(r"(?:(\d{4})年)?(\d{1,2})月(\d{1,2})[日号]?", text)
    if explicit:
        try:
            return date(
                int(explicit.group(1) or today.year),
                int(explicit.group(2)),
                int(explicit.group(3)),
            ).isoformat()
        except ValueError:
            return today.isoformat()
    for phrase, offset in _RELATIVE_DAYS.items():
        if phrase in text:
            return (today + timedelta(days=offset)).isoformat()
    return today.isoformat()


def _measurement(
    metric: str,
    value: float,
    unit: str,
    *,
    value_secondary: float | None = None,
) -> dict[str, Any]:
    if metric == "blood_pressure":
        valid = 50 <= value <= 260 and value_secondary is not None and 30 <= value_secondary <= 160
    else:
        lower, upper = _RANGES[metric]
        valid = lower <= value <= upper
    return {
        "metric": metric,
        "value": round(value, 4),
        "value_secondary": round(value_secondary, 4) if value_secondary is not None else None,
        "unit": unit,
        "confidence": 0.94 if valid else 0.4,
        "warning": None if valid else "数值超出常见录入范围，请人工核对",
    }


def extract_confirmable_fields(text: str, *, today: date | None = None) -> dict[str, Any]:
    """Extract local entry candidates; every returned value still needs user confirmation."""

    if not isinstance(text, str) or len(text) > 16_384:
        raise ValueError("ASR text is invalid")
    normalized = normalize_spoken_text(text)
    owner_match = _OWNER.search(normalized)
    measurements: list[dict[str, Any]] = []
    pressure = _PRESSURE_EXPLICIT.search(normalized) or _PRESSURE_PAIR.search(normalized)
    if pressure:
        measurements.append(
            _measurement(
                "blood_pressure",
                float(pressure.group("high")),
                "mmHg",
                value_secondary=float(pressure.group("low")),
            )
        )
    for pattern, metric, unit in (
        (_GLUCOSE, "blood_glucose", "mmol/L"),
        (_HEART_RATE, "heart_rate", "bpm"),
        (_TEMPERATURE, "temperature", "°C"),
    ):
        match = pattern.search(normalized)
        if match:
            measurements.append(_measurement(metric, float(match.group("value")), unit))
    weight = _WEIGHT.search(normalized)
    if weight:
        value = float(weight.group("value"))
        if weight.group("unit") == "斤":
            value *= 0.5
        measurements.append(_measurement("weight", value, "kg"))
    spoken_height = _HEIGHT_METERS.search(normalized)
    if spoken_height:
        value = float(spoken_height.group("meters")) * 100 + float(spoken_height.group("centimeters"))
        measurements.append(_measurement("height", value, "cm"))
    else:
        height = _HEIGHT.search(normalized)
        if height:
            value = float(height.group("value"))
            if height.group("unit") in {"米", "m"}:
                value *= 100
            measurements.append(_measurement("height", value, "cm"))
    return {
        "owner": owner_match.group("owner") if owner_match else "本人",
        "measured_on": _measured_on(normalized, today or date.today()),
        "measurements": measurements,
        "requires_confirmation": bool(measurements),
    }
