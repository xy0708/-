from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any, BinaryIO

from .field_extraction import extract_confirmable_fields


REQUIRED_MODEL_FILES = (
    "decoder.onnx",
    "encoder.int8.onnx",
    "joiner.int8.onnx",
    "tokens.txt",
)
CAPABILITIES = [
    "asr_stream",
    "confirmation_required",
    "local_only",
    "raw_audio_memory_only",
]
MAX_REQUEST_BYTES = 12 * 1024 * 1024
MAX_RESPONSE_BYTES = 512 * 1024
MAX_CHUNK_BYTES = 64 * 1024
MAX_TOTAL_BYTES = 16_000 * 2 * 120
_MEMBER_ID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")


class WorkerProtocolError(RuntimeError):
    pass


def ready_metadata(manifest: dict[str, Any]) -> dict[str, Any]:
    """Return the bounded contract handshake shared by health and stream start."""

    return {
        "ready": True,
        "contract_version": "1.0.0",
        "component_version": "0.1.0",
        "capabilities": CAPABILITIES,
        "model_sha256": manifest["model_bundle_sha256"],
        "reason": None,
    }


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def model_bundle_sha256(files: dict[str, dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for name in REQUIRED_MODEL_FILES:
        item = files.get(name)
        expected = item.get("sha256") if isinstance(item, dict) else None
        if not isinstance(expected, str) or re.fullmatch(r"[0-9a-fA-F]{64}", expected) is None:
            raise ValueError("model manifest hash is invalid")
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(bytes.fromhex(expected))
    return digest.hexdigest()


def load_and_verify_manifest(
    model_dir: Path,
    manifest_path: Path,
    *,
    expected_product_mode: bool = False,
) -> dict[str, Any]:
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("ASR manifest boundary is invalid")
    if expected_product_mode:
        if (
            payload.get("schema_version") != "1.0.0"
            or payload.get("status") != "PRODUCT_MODEL_APPROVED"
            or payload.get("product_accepted") is not True
            or payload.get("hardware_measured") is not True
            or payload.get("license_approved") is not True
        ):
            raise ValueError("product ASR manifest boundary is invalid")
    elif (
        payload.get("status") != "ENGINEERING_MODEL_AVAILABLE_PRODUCT_LICENSE_PENDING"
        or payload.get("product_accepted") is not False
        or payload.get("hardware_measured") is not False
        or payload.get("license_approved") is True
    ):
        raise ValueError("engineering ASR manifest boundary is invalid")
    files = payload.get("model_files")
    if not isinstance(files, dict) or set(files) != set(REQUIRED_MODEL_FILES):
        raise ValueError("engineering ASR model file set is invalid")
    for name in REQUIRED_MODEL_FILES:
        path = model_dir / name
        item = files[name]
        if (
            not path.is_file()
            or path.is_symlink()
            or not isinstance(item.get("bytes"), int)
            or path.stat().st_size != item["bytes"]
            or sha256(path) != str(item.get("sha256", "")).lower()
        ):
            raise ValueError("engineering ASR model integrity check failed")
    bundle = model_bundle_sha256(files)
    if payload.get("model_bundle_sha256") != bundle:
        raise ValueError("engineering ASR bundle hash mismatch")
    return payload


def read_request(stream: BinaryIO) -> dict[str, Any]:
    raw = stream.readline(MAX_REQUEST_BYTES + 1)
    if not raw or len(raw) > MAX_REQUEST_BYTES or not raw.endswith(b"\n"):
        raise WorkerProtocolError("invalid request framing")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise WorkerProtocolError("invalid request JSON") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("op"), str):
        raise WorkerProtocolError("invalid request object")
    return payload


def send(result: dict[str, Any]) -> None:
    raw = json.dumps(
        {"ok": True, "result": result},
        ensure_ascii=False,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8") + b"\n"
    if len(raw) > MAX_RESPONSE_BYTES:
        raise WorkerProtocolError("response exceeds limit")
    sys.stdout.buffer.write(raw)
    sys.stdout.buffer.flush()


def send_fixed_error(code: str = "COMPONENT_NOT_READY") -> None:
    allowed = {"COMPONENT_NOT_READY", "MODEL_HASH_MISMATCH"}
    raw = json.dumps(
        {"ok": False, "error": {"code": code if code in allowed else "COMPONENT_NOT_READY"}},
        separators=(",", ":"),
    ).encode("ascii") + b"\n"
    try:
        sys.stdout.buffer.write(raw)
        sys.stdout.buffer.flush()
    except OSError:
        pass


def result_text(recognizer: Any, stream: Any) -> str:
    value = recognizer.get_result(stream)
    if isinstance(value, str):
        return value.strip()
    text = getattr(value, "text", "")
    return text.strip() if isinstance(text, str) else ""


def create_recognizer(model_dir: Path, expected_runtime_version: str) -> tuple[Any, Any]:
    import numpy as np
    import sherpa_onnx

    if sherpa_onnx.__version__ != expected_runtime_version:
        raise RuntimeError("runtime version mismatch")
    recognizer = sherpa_onnx.OnlineRecognizer.from_transducer(
        tokens=str(model_dir / "tokens.txt"),
        encoder=str(model_dir / "encoder.int8.onnx"),
        decoder=str(model_dir / "decoder.onnx"),
        joiner=str(model_dir / "joiner.int8.onnx"),
        num_threads=1,
        sample_rate=16_000,
        feature_dim=80,
        decoding_method="greedy_search",
        model_type="zipformer2",
        enable_endpoint_detection=False,
        provider="cpu",
    )
    return recognizer, np


def validate_open_request(request: dict[str, Any]) -> None:
    config = request.get("config")
    if (
        not isinstance(request.get("member_id"), str)
        or _MEMBER_ID.fullmatch(request["member_id"]) is None
        or not isinstance(config, dict)
        or config.get("sample_rate_hz") != 16_000
        or config.get("channels") != 1
        or config.get("sample_format") != "s16le"
    ):
        raise WorkerProtocolError("invalid stream configuration")


def serve_stream(recognizer: Any, np: Any) -> None:
    stream = recognizer.create_stream()
    total_bytes = 0
    while True:
        request = read_request(sys.stdin.buffer)
        operation = request["op"]
        if operation == "feed_pcm":
            encoded = request.get("pcm_s16le_base64")
            if not isinstance(encoded, str):
                raise WorkerProtocolError("PCM payload is missing")
            try:
                pcm = base64.b64decode(encoded, validate=True)
            except (ValueError, binascii.Error) as exc:
                raise WorkerProtocolError("PCM payload is invalid") from exc
            if not pcm or len(pcm) > MAX_CHUNK_BYTES or len(pcm) % 2:
                raise WorkerProtocolError("PCM chunk is invalid")
            total_bytes += len(pcm)
            if total_bytes > MAX_TOTAL_BYTES:
                raise WorkerProtocolError("PCM duration exceeds limit")
            samples = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
            stream.accept_waveform(16_000, np.ascontiguousarray(samples))
            while recognizer.is_ready(stream):
                recognizer.decode_stream(stream)
            send({"text": result_text(recognizer, stream) or None})
        elif operation == "finish":
            stream.accept_waveform(16_000, np.zeros(16_000, dtype=np.float32))
            while recognizer.is_ready(stream):
                recognizer.decode_stream(stream)
            stream.input_finished()
            while recognizer.is_ready(stream):
                recognizer.decode_stream(stream)
            text = result_text(recognizer, stream)
            send({"text": text, "fields": extract_confirmable_fields(text)})
            return
        elif operation == "close":
            send({"closed": True})
            return
        else:
            raise WorkerProtocolError("unsupported stream operation")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--runtime-version", required=True)
    parser.add_argument("--product-mode", action="store_true")
    arguments = parser.parse_args()
    try:
        model_dir = arguments.model_dir.resolve(strict=True)
        manifest = load_and_verify_manifest(
            model_dir,
            arguments.manifest.resolve(strict=True),
            expected_product_mode=arguments.product_mode,
        )
        request = read_request(sys.stdin.buffer)
        operation = request["op"]
        if operation == "health":
            create_recognizer(model_dir, arguments.runtime_version)
            send(ready_metadata(manifest))
            return 0
        if operation != "open_stream":
            raise WorkerProtocolError("unsupported first operation")
        validate_open_request(request)
        recognizer, np = create_recognizer(model_dir, arguments.runtime_version)
        send({"started": True, **ready_metadata(manifest)})
        serve_stream(recognizer, np)
        return 0
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, WorkerProtocolError):
        send_fixed_error()
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
