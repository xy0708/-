from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from integration_adapter import ComponentOperationError
from storage import RecordStore, TaskStateError


class StreamingRecognizer(Protocol):
    def feed_pcm(self, pcm_s16le: bytes) -> str | None: ...

    def finish(self) -> dict[str, Any]: ...

    def close(self) -> None: ...


class StreamingAdapter(Protocol):
    def open_stream(self, member_id: str, config: dict[str, Any]) -> StreamingRecognizer: ...


@dataclass(frozen=True)
class AsrStreamLimits:
    sample_rate_hz: int = 16000
    channels: int = 1
    sample_width_bytes: int = 2
    max_chunk_bytes: int = 64 * 1024
    max_duration_seconds: int = 120

    @property
    def max_total_bytes(self) -> int:
        return (
            self.sample_rate_hz
            * self.channels
            * self.sample_width_bytes
            * self.max_duration_seconds
        )


class AsrStreamSession:
    """One in-memory ASR stream. Raw PCM is never retained by this class."""

    def __init__(
        self,
        store: RecordStore,
        adapter: StreamingAdapter,
        member_id: str,
        config: dict[str, Any],
        *,
        limits: AsrStreamLimits = AsrStreamLimits(),
    ) -> None:
        expected = {
            "sample_rate_hz": limits.sample_rate_hz,
            "channels": limits.channels,
            "sample_format": "s16le",
        }
        if any(config.get(key) != value for key, value in expected.items()):
            raise TaskStateError("INPUT_INVALID", "ASR audio format must be 16 kHz mono s16le")
        self.store = store
        self.member_id = member_id
        self.limits = limits
        try:
            self._recognizer = adapter.open_stream(member_id, config)
        except ComponentOperationError as exc:
            raise TaskStateError(exc.code, "ASR runtime operation failed") from exc
        except TaskStateError:
            raise
        except TimeoutError as exc:
            raise TaskStateError("COMPONENT_TIMEOUT", "ASR runtime timed out") from exc
        except Exception as exc:
            raise TaskStateError("COMPONENT_NOT_READY", "ASR runtime failed safely") from exc
        self._state = "streaming"
        self._bytes_received = 0
        self._pending_task_id: str | None = None

    @property
    def state(self) -> str:
        return self._state

    @property
    def bytes_received(self) -> int:
        return self._bytes_received

    def feed(self, chunk: bytes) -> dict[str, Any]:
        if self._state != "streaming":
            raise TaskStateError("TASK_ALREADY_CONFIRMED", "ASR stream is not accepting audio")
        if not chunk or len(chunk) > self.limits.max_chunk_bytes or len(chunk) % 2:
            raise TaskStateError("INPUT_INVALID", "invalid PCM chunk")
        if self._bytes_received + len(chunk) > self.limits.max_total_bytes:
            self.cancel()
            raise TaskStateError("INPUT_OUT_OF_RANGE", "ASR stream exceeds maximum duration")
        self._bytes_received += len(chunk)
        try:
            partial = self._recognizer.feed_pcm(chunk)
        except ComponentOperationError as exc:
            self.cancel()
            raise TaskStateError(exc.code, "ASR runtime operation failed") from exc
        except TimeoutError as exc:
            self.cancel()
            raise TaskStateError("COMPONENT_TIMEOUT", "ASR runtime timed out") from exc
        except Exception as exc:
            self.cancel()
            raise TaskStateError("COMPONENT_NOT_READY", "ASR runtime failed safely") from exc
        return {
            "type": "partial" if partial else "audio_accepted",
            "text": partial,
            "bytes_received": self._bytes_received,
        }

    def finish(self) -> dict[str, Any]:
        if self._state != "streaming":
            raise TaskStateError("TASK_ALREADY_CONFIRMED", "ASR stream is already closed")
        try:
            result = self._recognizer.finish()
        except ComponentOperationError as exc:
            self._state = "cancelled"
            raise TaskStateError(exc.code, "ASR runtime operation failed") from exc
        except TimeoutError as exc:
            self._state = "cancelled"
            raise TaskStateError("COMPONENT_TIMEOUT", "ASR runtime timed out") from exc
        except Exception as exc:
            self._state = "cancelled"
            raise TaskStateError("COMPONENT_NOT_READY", "ASR runtime failed safely") from exc
        finally:
            try:
                self._recognizer.close()
            except Exception:
                pass
        if not isinstance(result, dict):
            self._state = "cancelled"
            raise TaskStateError("COMPONENT_NOT_READY", "ASR adapter returned an invalid result")
        try:
            task = self.store.create_task(self.member_id, "asr", result)
        except Exception:
            self._state = "cancelled"
            raise
        self._pending_task_id = str(task["task_id"])
        self._state = "final_pending_confirmation"
        return {
            "type": "final_pending_confirmation",
            "task": task,
            "result": result,
            "raw_audio_persisted": False,
        }

    def cancel(self) -> None:
        if self._state == "streaming":
            try:
                self._recognizer.close()
            except Exception:
                pass
            self._state = "cancelled"
        elif self._state == "final_pending_confirmation":
            try:
                if self._pending_task_id is not None:
                    self.store.cancel_task(self._pending_task_id, self.member_id)
            except Exception:
                # The store's bounded TTL sweeper remains the fail-safe cleanup path.
                pass
            finally:
                self._pending_task_id = None
                self._state = "cancelled"
