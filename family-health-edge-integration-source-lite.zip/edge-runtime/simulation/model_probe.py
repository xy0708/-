from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
import struct
import time
import wave
from pathlib import Path

import numpy as np
import onnxruntime as ort
import sherpa_onnx


ROOT = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def probability(outputs: list[object]) -> float:
    for output in outputs:
        if isinstance(output, np.ndarray) and output.ndim == 2 and output.shape == (1, 2):
            return float(output[0, 1])
    raise RuntimeError("HEALTH_PROBABILITY_OUTPUT_MISSING")


def run_health(evidence: dict) -> dict:
    manifest_path = ROOT / "models" / "health" / "model_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if (manifest.get("product_model") is not False or
            manifest.get("clinical_diagnosis") is not False or
            set(manifest.get("models", {})) != {"dm", "ht"}):
        raise RuntimeError("HEALTH_ENGINEERING_BOUNDARY_INVALID")
    errors = []
    task_results = {}
    for task in ("dm", "ht"):
        expected = evidence["health_reference"]["tasks"][task]
        item = manifest["models"][task]
        path = ROOT / "models" / "health" / f"{task}.onnx"
        if sha256(path) != item["onnx_sha256"] or item["onnx_sha256"] != expected["onnx_sha256"]:
            raise RuntimeError("HEALTH_MODEL_HASH_MISMATCH")
        options = ort.SessionOptions()
        options.intra_op_num_threads = 1
        options.inter_op_num_threads = 1
        session = ort.InferenceSession(str(path), sess_options=options,
                                       providers=["CPUExecutionProvider"])
        values = np.asarray([expected["values"]], dtype=np.float32)
        observed = probability(session.run(None, {session.get_inputs()[0].name: values}))
        difference = abs(observed - float(expected["raw_probability"]))
        if difference > 1e-5:
            errors.append(task + ":NUMERIC_ALIGNMENT_FAILED")
        task_results[task] = {
            "onnx_sha256": item["onnx_sha256"],
            "max_abs_error_vs_host": difference,
            "output_sha256": hashlib.sha256(struct.pack("!d", observed)).hexdigest(),
        }
    return {"status": "PASS_ARM64_REAL_INFERENCE" if not errors else "FAIL",
            "runtime": "onnxruntime_cpu", "version": ort.__version__,
            "tasks": task_results, "errors": errors, "product_model": False,
            "probability_exposed_to_product": False}


def wav_samples(path: Path) -> tuple[np.ndarray, int]:
    with wave.open(str(path), "rb") as stream:
        if stream.getsampwidth() != 2 or stream.getcomptype() != "NONE":
            raise RuntimeError("ASR_SAMPLE_FORMAT_UNSUPPORTED")
        channels, rate, frames = stream.getnchannels(), stream.getframerate(), stream.getnframes()
        raw = stream.readframes(frames)
    values = np.frombuffer(raw, dtype="<i2").astype(np.float32).reshape(-1, channels)
    return np.ascontiguousarray(values.mean(axis=1) / 32768.0), rate


def run_asr(evidence: dict) -> dict:
    model = ROOT / "models" / "asr"
    required = {name: model / name for name in (
        "encoder.int8.onnx", "decoder.onnx", "joiner.int8.onnx", "tokens.txt"
    )}
    for name, path in required.items():
        if sha256(path).upper() != evidence["asr_files"][name]["sha256"].upper():
            raise RuntimeError("ASR_MODEL_HASH_MISMATCH")
    wav = model / "sample.wav"
    if sha256(wav) != evidence["asr_sample_sha256"]:
        raise RuntimeError("ASR_SAMPLE_HASH_MISMATCH")
    recognizer = sherpa_onnx.OnlineRecognizer.from_transducer(
        tokens=str(required["tokens.txt"]), encoder=str(required["encoder.int8.onnx"]),
        decoder=str(required["decoder.onnx"]), joiner=str(required["joiner.int8.onnx"]),
        num_threads=1, sample_rate=16000, feature_dim=80, decoding_method="greedy_search",
        model_type="zipformer2", enable_endpoint_detection=False, provider="cpu",
    )
    samples, rate = wav_samples(wav)
    if rate != 16000:
        raise RuntimeError("ASR_SAMPLE_RATE_INVALID")
    stream = recognizer.create_stream()
    started = time.perf_counter()
    for start in range(0, samples.size, 1600):
        stream.accept_waveform(rate, samples[start:start + 1600])
        while recognizer.is_ready(stream):
            recognizer.decode_stream(stream)
    stream.accept_waveform(rate, np.zeros(rate, dtype=np.float32))
    while recognizer.is_ready(stream):
        recognizer.decode_stream(stream)
    stream.input_finished()
    while recognizer.is_ready(stream):
        recognizer.decode_stream(stream)
    result = recognizer.get_result(stream)
    text = result.strip() if isinstance(result, str) else str(getattr(result, "text", "")).strip()
    text_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
    passed = bool(text) and text_hash == evidence["asr_reference_text_sha256"]
    return {"status": "PASS_ARM64_REAL_INFERENCE" if passed else "FAIL",
            "runtime": "sherpa-onnx", "version": sherpa_onnx.__version__,
            "model_hashes_verified": True, "sample_sha256": sha256(wav),
            "audio_seconds": samples.size / rate,
            "emulated_decode_seconds": time.perf_counter() - started,
            "final_text_sha256": text_hash, "matches_host_reference": passed,
            "product_accepted": False}


def main() -> int:
    evidence = json.loads((ROOT / "evidence.json").read_text(encoding="utf-8"))
    report = {
        "schema_version": "1.0.0", "stage": "S2_AVAILABLE_MODELS",
        "system": platform.system(), "machine": platform.machine(),
        "bits": struct.calcsize("P") * 8, "simulated": True,
        "hardware_measured": False, "product_complete": False,
        "three_model_inference_verified": False, "status": "FAIL",
    }
    if report["system"] != "Linux" or report["machine"].lower() not in {"aarch64", "arm64"} or report["bits"] != 64:
        report["error"] = "NOT_LINUX_ARM64"
        print(json.dumps(report, ensure_ascii=True))
        return 2
    installed = {name: importlib.metadata.version(name) for name in evidence["requirements"]}
    report["requirements"] = installed
    if installed != evidence["requirements"]:
        report["error"] = "RUNTIME_VERSION_MISMATCH"
        print(json.dumps(report, ensure_ascii=True))
        return 2
    try:
        report["health"] = run_health(evidence)
        report["asr"] = run_asr(evidence)
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as exc:
        # This is internal engineering evidence, not a product response. Keep the
        # exception class and a bounded message so cross-architecture failures
        # can be diagnosed without silently converting everything to one code.
        report["error"] = "MODEL_PROBE_FAILED"
        report["error_type"] = type(exc).__name__
        report["error_detail"] = str(exc)[:500]
        print(json.dumps(report, ensure_ascii=True))
        return 2
    if report["health"]["status"] == report["asr"]["status"] == "PASS_ARM64_REAL_INFERENCE":
        report["status"] = "PASS_AVAILABLE_REAL_MODELS"
    print(json.dumps(report, ensure_ascii=True))
    return 0 if report["status"] == "PASS_AVAILABLE_REAL_MODELS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
