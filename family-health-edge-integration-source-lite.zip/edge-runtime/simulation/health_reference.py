from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import onnxruntime as ort


PROBE_VALUES = {
    "age": 52.0, "gender": 1.0, "height": 168.0, "weight": 72.0,
    "bmi": 25.5, "sbp": 138.0, "dbp": 86.0, "glucose": 108.0,
    "total_cholesterol": 190.0, "hdl": 48.0, "ldl": 115.0,
    "triglycerides": 150.0, "creatinine": 0.9, "bun": 15.0,
    "smoking_current": 0.0, "uric_acid": 6.1,
}


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def probability(outputs: list[object]) -> float:
    for output in outputs:
        if isinstance(output, np.ndarray) and output.ndim == 2 and output.shape == (1, 2):
            return float(output[0, 1])
    raise RuntimeError("HEALTH_PROBABILITY_OUTPUT_MISSING")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest_path = args.manifest.resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if (manifest.get("product_model") is not False or
            manifest.get("clinical_diagnosis") is not False or
            set(manifest.get("models", {})) != {"dm", "ht"}):
        raise RuntimeError("HEALTH_ENGINEERING_BOUNDARY_INVALID")
    tasks = {}
    for task in ("dm", "ht"):
        item = manifest["models"][task]
        model = manifest_path.parent / f"{task}.onnx"
        if model.name != Path(item["onnx_file"]).name or sha256(model) != item["onnx_sha256"]:
            raise RuntimeError("HEALTH_MODEL_HASH_MISMATCH")
        features = item["features"]
        values = np.asarray([[PROBE_VALUES[name] for name in features]], dtype=np.float32)
        options = ort.SessionOptions()
        options.intra_op_num_threads = 1
        options.inter_op_num_threads = 1
        session = ort.InferenceSession(str(model), sess_options=options,
                                       providers=["CPUExecutionProvider"])
        value = probability(session.run(None, {session.get_inputs()[0].name: values}))
        tasks[task] = {"features": features, "values": values[0].tolist(),
                       "raw_probability": value, "onnx_sha256": item["onnx_sha256"]}
    output = {"status": "PASS_HOST_REFERENCE", "input_origin": "FIXED_ENGINEERING_PROBE",
              "onnxruntime_version": ort.__version__, "tasks": tasks,
              "product_model": False, "clinical_diagnosis": False}
    args.output.resolve().write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n",
                                     encoding="utf-8")
    print(json.dumps({"status": output["status"], "tasks": sorted(tasks)}, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
