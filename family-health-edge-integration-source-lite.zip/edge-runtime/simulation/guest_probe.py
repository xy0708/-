"""Execute real ARM64 project code; test adapters are explicitly not model inference."""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import platform
import struct
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TEST_FILES = (
    'test_health_rules.py', 'test_storage.py', 'test_device_application.py',
    'test_asr_stream_session.py', 'test_ocr_input_validation.py',
    'test_component_contracts.py', 'test_fault_isolation.py', 'test_auth_config.py',
    'test_component_supervisor.py', 'test_asr_worker.py', 'test_runtime_bootstrap.py',
    'test_websocket_protocol.py', 'test_websocket_integration.py',
    'test_acceptance_local_client.py', 'test_server_policy.py',
    'test_release_bundle.py', 'test_update_activation.py',
    'test_update_health_gate.py', 'test_update_rollback_gate.py',
    'test_release_inputs.py', 'test_database_recovery.py',
    'test_current_release.py',
    'test_product_release_verification.py',
    'test_runtime_backend_registry.py',
)


def architecture_valid(system: str, machine: str, bits: int) -> bool:
    return system == 'Linux' and machine.lower() in {'aarch64', 'arm64'} and bits == 64


def main() -> int:
    report = {
        'schema_version': '1.0.0', 'simulated': True, 'hardware_measured': False,
        'product_complete': False, 'three_model_inference_verified': False,
        'stage': 'S1_SOFTWARE_ONLY', 'system': platform.system(),
        'machine': platform.machine(), 'bits': struct.calcsize('P') * 8,
        'python_version': platform.python_version(), 'tests_run': 0,
        'failures': 0, 'errors': 0, 'skipped': 0,
        'ocr_asr_adapters': 'ENGINEERING_TEST_DOUBLES',
        'health_execution': 'REAL_RULE_ENGINE_NOT_ML',
        'test_files': list(TEST_FILES), 'status': 'FAIL',
    }
    if not architecture_valid(report['system'], report['machine'], report['bits']):
        report['reason'] = 'NOT_LINUX_ARM64'
    else:
        manifest = json.loads((ROOT / 'source_manifest.json').read_text(encoding='utf-8'))
        report['source_integrity_verified'] = all(
            hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
            for name, digest in manifest.items()
        )
        if not manifest or not report['source_integrity_verified']:
            report['reason'] = 'SOURCE_HASH_MISMATCH'
            print(json.dumps(report, ensure_ascii=True))
            return 2
        capture = io.StringIO()
        with contextlib.redirect_stdout(capture), contextlib.redirect_stderr(capture):
            suite = unittest.TestSuite()
            loader = unittest.TestLoader()
            for name in TEST_FILES:
                suite.addTests(loader.discover(str(ROOT / 'tests'), pattern=name))
            result = unittest.TextTestRunner(stream=capture, verbosity=0).run(suite)
        report.update(tests_run=result.testsRun, failures=len(result.failures),
                      errors=len(result.errors), skipped=len(result.skipped))
        # Do not include fixture values or tracebacks in ordinary output.
        report['failed_test_ids'] = [test.id() for test, _ in result.errors + result.failures]
        if result.wasSuccessful() and result.testsRun > 0 and not result.skipped:
            report['status'] = 'PASS_ARM64_SOFTWARE'
    print(json.dumps(report, ensure_ascii=True))
    return 0 if report['status'] == 'PASS_ARM64_SOFTWARE' else 2


if __name__ == '__main__':
    raise SystemExit(main())
