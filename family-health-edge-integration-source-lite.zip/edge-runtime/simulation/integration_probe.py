from __future__ import annotations

import base64
import hashlib
import importlib.metadata
import json
import platform
import socket
import struct
import sys
import threading
import urllib.error
import urllib.request
import wave
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from device_service import DeviceApplication, TokenAuthorizer
from device_service.runtime_bootstrap import load_runtime_adapters
from device_service.server import BoundedThreadingHTTPServer, DeviceRequestHandler
from device_service.websocket import encode_client_frame, read_server_frame, websocket_accept
from storage import PlaintextEngineeringCodec, RecordStore


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def wav_pcm(path: Path) -> tuple[bytes, int, float]:
    with wave.open(str(path), "rb") as source:
        if (
            source.getnchannels() != 1
            or source.getsampwidth() != 2
            or source.getframerate() != 16_000
            or source.getcomptype() != "NONE"
        ):
            raise RuntimeError("ASR_SAMPLE_FORMAT_INVALID")
        frames = source.getnframes()
        pcm = source.readframes(frames)
        if source.readframes(1):
            raise RuntimeError("ASR_SAMPLE_READ_INCOMPLETE")
    return pcm, 16_000, frames / 16_000


def http_json(
    port: int, token: str, method: str, path: str, body: dict[str, object]
) -> tuple[int, dict[str, object]]:
    request = urllib.request.Request(
        f"http://127.0.0.1:{port}{path}",
        data=json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8"),
        method=method,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(request, timeout=15) as response:
            status = response.status
            raw = response.read(1024 * 1024 + 1)
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read(1024 * 1024 + 1)
    if len(raw) > 1024 * 1024:
        raise RuntimeError("HTTP_RESPONSE_TOO_LARGE")
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("HTTP_RESPONSE_INVALID")
    return status, value


def websocket_asr(
    port: int, token: str, member_id: str, pcm: bytes
) -> dict[str, object]:
    sock = socket.create_connection(("127.0.0.1", port), timeout=15)
    sock.settimeout(180)
    stream = sock.makefile("rwb", buffering=0)
    try:
        key = base64.b64encode(b"0123456789abcdef").decode("ascii")
        request = (
            "GET /v1/asr/stream HTTP/1.1\r\n"
            f"Host: 127.0.0.1:{port}\r\n"
            "Upgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\n"
            f"Sec-WebSocket-Key: {key}\r\nAuthorization: Bearer {token}\r\n"
            f"X-Edge-Member-Id: {member_id}\r\nOrigin: null\r\n\r\n"
        )
        stream.write(request.encode("ascii"))
        status_line = stream.readline().decode("ascii", errors="strict")
        headers: dict[str, str] = {}
        while True:
            line = stream.readline()
            if line in {b"\r\n", b""}:
                break
            name, value = line.decode("ascii", errors="strict").split(":", 1)
            headers[name.casefold()] = value.strip()
        if (
            " 101 " not in status_line
            or headers.get("sec-websocket-accept") != websocket_accept(key)
        ):
            raise RuntimeError("ASR_WEBSOCKET_HANDSHAKE_FAILED")
        start = json.dumps(
            {
                "type": "start",
                "sample_rate_hz": 16_000,
                "channels": 1,
                "sample_format": "s16le",
            }
        ).encode("utf-8")
        stream.write(encode_client_frame(0x1, start))
        _, raw = read_server_frame(stream, max_payload_bytes=1024 * 1024)
        if json.loads(raw).get("type") != "started":
            raise RuntimeError("ASR_WEBSOCKET_START_FAILED")
        for offset in range(0, len(pcm), 3_200):
            stream.write(encode_client_frame(0x2, pcm[offset : offset + 3_200]))
            _, raw = read_server_frame(stream, max_payload_bytes=1024 * 1024)
            if json.loads(raw).get("type") not in {"partial", "audio_accepted"}:
                raise RuntimeError("ASR_WEBSOCKET_FEED_FAILED")
        stream.write(encode_client_frame(0x1, b'{"type":"stop"}'))
        _, raw = read_server_frame(stream, max_payload_bytes=1024 * 1024)
        final = json.loads(raw)
        if not isinstance(final, dict) or final.get("type") != "final_pending_confirmation":
            raise RuntimeError("ASR_WEBSOCKET_FINAL_FAILED")
        return final
    finally:
        stream.close()
        sock.close()


def main() -> int:
    evidence = json.loads((ROOT / "evidence.json").read_text(encoding="utf-8"))
    report = {
        "schema_version": "1.0.0",
        "stage": "S3_ASR_DEVICE_SERVICE_PARTIAL",
        "system": platform.system(),
        "machine": platform.machine(),
        "bits": struct.calcsize("P") * 8,
        "simulated": True,
        "hardware_measured": False,
        "product_complete": False,
        "three_model_inference_verified": False,
        "status": "FAIL",
    }
    if (
        report["system"] != "Linux"
        or str(report["machine"]).lower() not in {"aarch64", "arm64"}
        or report["bits"] != 64
    ):
        report["error"] = "NOT_LINUX_ARM64"
        print(json.dumps(report, ensure_ascii=True))
        return 2

    store: RecordStore | None = None
    server: BoundedThreadingHTTPServer | None = None
    thread: threading.Thread | None = None
    try:
        installed = {
            name: importlib.metadata.version(name) for name in evidence["requirements"]
        }
        if installed != evidence["requirements"]:
            raise RuntimeError("RUNTIME_VERSION_MISMATCH")
        model_dir = ROOT / "models" / "asr"
        sample = model_dir / "sample.wav"
        if sha256(sample) != evidence["sample_sha256"]:
            raise RuntimeError("ASR_SAMPLE_HASH_MISMATCH")
        pcm, _, audio_seconds = wav_pcm(sample)
        adapters = load_runtime_adapters(
            ROOT / "configs" / "runtime_adapters.json",
            engineering=True,
            registry_path=ROOT / "model_registry" / "backend_registry.json",
            selection_path=ROOT / "configs" / "runtime_backend_selection.json",
        )
        adapter = adapters.asr
        if adapter is None or adapters.ocr is not None:
            raise RuntimeError("RUNTIME_BOOTSTRAP_BOUNDARY_FAILED")
        store = RecordStore(
            Path("/tmp/edge-s3-engineering.db"),
            PlaintextEngineeringCodec(),
            allow_unencrypted_engineering=True,
        )
        token = "s3-engineering-token-00000000000000000000"
        app = DeviceApplication(
            store,
            TokenAuthorizer({token: {"engineering-member"}}),
            asr_adapter=adapter,
        )
        server = BoundedThreadingHTTPServer(("127.0.0.1", 0), DeviceRequestHandler)
        server.application = app  # type: ignore[attr-defined]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        port = int(server.server_address[1])
        finished = websocket_asr(port, token, "engineering-member", pcm)
        final_text = finished["result"].get("text")
        if not isinstance(final_text, str) or not final_text:
            raise RuntimeError("ASR_FINAL_TEXT_EMPTY")
        final_hash = hashlib.sha256(final_text.encode("utf-8")).hexdigest()
        if final_hash != evidence["reference_text_sha256"]:
            raise RuntimeError("ASR_REFERENCE_TEXT_MISMATCH")
        if (
            finished.get("raw_audio_persisted") is not False
            or store.list_records("engineering-member") != []
        ):
            raise RuntimeError("ASR_CONFIRMATION_OR_PRIVACY_BOUNDARY_FAILED")
        task_id = finished["task"]["task_id"]
        cancel_status, _ = http_json(
            port,
            token,
            "DELETE",
            f"/v1/tasks/{task_id}",
            {"member_id": "engineering-member"},
        )
        if cancel_status != 200 or store.list_records("engineering-member") != []:
            raise RuntimeError("ASR_PENDING_TASK_CANCEL_FAILED")

        status, health_result = http_json(
            port,
            token,
            "POST",
            "/v1/health/evaluate",
            {
                "confirmed": True,
                "measurements": [
                    {
                        "metric": "weight",
                        "value": 70,
                        "unit": "kg",
                        "measured_at": datetime.now(timezone.utc).isoformat(),
                        "confirmed": True,
                    }
                ],
            },
        )
        value = health_result.get("result", {})
        if (
            status != 200
            or value.get("diagnosis") is not None
            or value.get("disease_probability") is not None
        ):
            raise RuntimeError("HEALTH_RULE_BOUNDARY_FAILED")
        ocr_state = app.ocr_adapter.health()
        if ocr_state.get("ready") is not False:
            raise RuntimeError("OCR_MUST_REMAIN_BLOCKED")

        report.update(
            status="PASS_ASR_DEVICE_SERVICE_INTEGRATION",
            requirements=installed,
            health={
                "status": "PASS_REAL_NON_DIAGNOSTIC_RULE_ENGINE",
                "loopback_http_verified": True,
                "diagnosis_exposed": False,
                "disease_probability_exposed": False,
            },
            asr={
                "status": "PASS_REAL_ISOLATED_WORKER_INTEGRATION",
                "runtime": "sherpa-onnx",
                "version": installed["sherpa-onnx"],
                "model_bundle_sha256": evidence["model_bundle_sha256"],
                "sample_sha256": evidence["sample_sha256"],
                "audio_seconds": audio_seconds,
                "final_text_sha256": final_hash,
                "matches_s2_reference": True,
                "runtime_config_bootstrap_verified": True,
                "backend_registry_selection_verified": True,
                "loopback_websocket_verified": True,
                "raw_audio_persisted": False,
                "confirmed_record_count": 0,
                "pending_task_cancelled": True,
                "product_accepted": False,
            },
            ocr={
                "status": "BLOCKED_EXTERNAL",
                "real_worker_invoked": False,
                "test_double_used": False,
            },
        )
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as exc:
        report["error"] = "INTEGRATION_PROBE_FAILED"
        report["error_type"] = type(exc).__name__
    finally:
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None:
            thread.join(timeout=10)
        report["loopback_server_cleaned"] = thread is None or not thread.is_alive()
        if report["loopback_server_cleaned"] is not True:
            report["status"] = "FAIL"
            report["error"] = "LOOPBACK_SERVER_CLEANUP_FAILED"
        if store is not None:
            store.close()
    print(json.dumps(report, ensure_ascii=True))
    return 0 if report["status"] == "PASS_ASR_DEVICE_SERVICE_INTEGRATION" else 2


if __name__ == "__main__":
    raise SystemExit(main())
