from __future__ import annotations

import hashlib
import json
import unicodedata
from pathlib import Path
from typing import Any

from .text import edit_distance, normalize_nfkc


REPORT_SCHEMA_VERSION = "1.0.0"
REPORT_STATUS = "PASS_ENGINEERING_SINGLE_SAMPLE_COMPARISON_PRODUCT_BLOCKED"
REPORT_SCOPE = "SINGLE_OFFICIAL_AUDIO_ENGINEERING_ONLY"
RUNTIME_FILE_ORDER = (
    "decoder.onnx",
    "encoder.int8.onnx",
    "joiner.int8.onnx",
    "tokens.txt",
)


class ComparisonEvidenceError(ValueError):
    """Raised when ASR comparison inputs violate the engineering boundary."""


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def transcript_digest(text: str) -> str:
    return hashlib.sha256(normalize_nfkc(text).encode("utf-8")).hexdigest()


def fold_for_pairwise_comparison(text: str) -> str:
    normalized = normalize_nfkc(text).lower()
    return "".join(
        character
        for character in normalized
        if unicodedata.category(character)[0] in {"L", "N"}
    )


def disagreement(left: str, right: str) -> dict[str, Any]:
    literal_left = normalize_nfkc(left)
    literal_right = normalize_nfkc(right)
    folded_left = fold_for_pairwise_comparison(left)
    folded_right = fold_for_pairwise_comparison(right)
    literal_distance = edit_distance(literal_left, literal_right)
    folded_distance = edit_distance(folded_left, folded_right)
    return {
        "literal_nfkc_exact_match": literal_left == literal_right,
        "literal_nfkc_edit_distance": literal_distance,
        "literal_nfkc_disagreement_rate": literal_distance
        / max(len(literal_left), len(literal_right), 1),
        "folded_alphanumeric_exact_match": folded_left == folded_right,
        "folded_alphanumeric_edit_distance": folded_distance,
        "folded_alphanumeric_disagreement_rate": folded_distance
        / max(len(folded_left), len(folded_right), 1),
        "folding_rule": "NFKC, lowercase, retain Unicode letter/number categories only",
        "metric_meaning": (
            "Pairwise candidate disagreement without a reference transcript; these "
            "values are not CER, WER, accuracy, or a product ranking."
        ),
    }


def verify_cpu_model_manifest(model_dir: Path, manifest_path: Path) -> str:
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ComparisonEvidenceError("CPU ASR manifest is unreadable") from exc
    records = manifest.get("files")
    if manifest.get("passed") is not True or not isinstance(records, list):
        raise ComparisonEvidenceError("CPU ASR manifest boundary is invalid")
    by_name = {
        record.get("name"): record for record in records if isinstance(record, dict)
    }
    digest = hashlib.sha256()
    for name in RUNTIME_FILE_ORDER:
        record = by_name.get(name)
        path = model_dir / name
        if (
            not isinstance(record, dict)
            or not path.is_file()
            or path.is_symlink()
            or record.get("bytes") != path.stat().st_size
            or str(record.get("sha256", "")).lower() != sha256(path)
        ):
            raise ComparisonEvidenceError("CPU ASR model integrity check failed")
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(bytes.fromhex(str(record["sha256"])))
    return digest.hexdigest()


def load_rknn_transcript(path: Path, expected_audio_sha256: str) -> tuple[str, float]:
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ComparisonEvidenceError("RKNN ASR report is unreadable") from exc
    sample = report.get("sample")
    result = report.get("rknn_pc_simulator")
    text = result.get("text") if isinstance(result, dict) else None
    host_seconds = result.get("host_seconds") if isinstance(result, dict) else None
    if (
        report.get("status") != "PASS_ENGINEERING_FUNCTIONAL_SIMULATION"
        or report.get("scope") != "PC_SIMULATOR_SINGLE_OFFICIAL_SAMPLE_ONLY"
        or report.get("exported_rknn_loaded_by_simulator") is not False
        or report.get("hardware_measured") is not False
        or report.get("product_accuracy_claim_allowed") is not False
        or report.get("wer_or_cer_claim_allowed") is not False
        or not isinstance(sample, dict)
        or sample.get("audio_sha256") != expected_audio_sha256
        or not isinstance(text, str)
        or not text.strip()
        or not isinstance(host_seconds, (int, float))
        or host_seconds <= 0
    ):
        raise ComparisonEvidenceError("RKNN ASR evidence boundary is invalid")
    return text.strip(), float(host_seconds)


def load_registry_hash(path: Path, backend_id: str) -> str:
    try:
        registry = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ComparisonEvidenceError("backend registry is unreadable") from exc
    backends = registry.get("backends")
    matches = [
        backend
        for backend in backends
        if isinstance(backend, dict) and backend.get("backend_id") == backend_id
    ] if isinstance(backends, list) else []
    if len(matches) != 1 or not isinstance(matches[0].get("model_bundle_sha256"), str):
        raise ComparisonEvidenceError("backend registry candidate is invalid")
    return matches[0]["model_bundle_sha256"]


def validate_report(
    report: object,
    *,
    audio_path: Path,
    cpu_manifest_path: Path,
    rknn_report_path: Path,
    registry_path: Path,
    host_wheels: list[Path],
    verifier_path: Path,
) -> list[str]:
    errors: list[str] = []
    if not isinstance(report, dict):
        return ["REPORT_NOT_OBJECT"]
    expected_hashes = {
        "audio_sha256": sha256(audio_path),
        "cpu_manifest_sha256": sha256(cpu_manifest_path),
        "rknn_simulator_report_sha256": sha256(rknn_report_path),
        "backend_registry_sha256": sha256(registry_path),
        "cpu_verifier_sha256": sha256(verifier_path),
        "host_wheel_sha256": {wheel.name: sha256(wheel) for wheel in host_wheels},
    }
    if (
        report.get("schema_version") != REPORT_SCHEMA_VERSION
        or report.get("status") != REPORT_STATUS
        or report.get("scope") != REPORT_SCOPE
    ):
        errors.append("REPORT_BOUNDARY_INVALID")
    for field in (
        "reference_transcript_available",
        "cer_or_wer_claim_allowed",
        "accuracy_claim_allowed",
        "product_selection_allowed",
        "hardware_measured",
        "host_timing_comparable_for_ranking",
        "target_microphone_data_used",
    ):
        if report.get(field) is not False:
            errors.append(f"UNSAFE_TRUE_FLAG:{field}")
    if report.get("source_hashes") != expected_hashes:
        errors.append("SOURCE_HASH_MISMATCH")
    candidates = report.get("candidates")
    expected_candidates = {"asr_sherpa_cpu_xasr", "asr_rknn_zipformer"}
    if not isinstance(candidates, dict) or set(candidates) != expected_candidates:
        errors.append("CANDIDATE_SET_INVALID")
    comparison = report.get("comparison")
    if not isinstance(comparison, dict):
        errors.append("COMPARISON_MISSING")
    else:
        for metric in (
            "literal_nfkc_disagreement_rate",
            "folded_alphanumeric_disagreement_rate",
        ):
            value = comparison.get(metric)
            if not isinstance(value, (int, float)) or not 0 <= value <= 1:
                errors.append(f"DISAGREEMENT_INVALID:{metric}")
        meaning = str(comparison.get("metric_meaning", "")).lower()
        if "not cer" not in meaning or "not" not in meaning or "product ranking" not in meaning:
            errors.append("PAIRWISE_METRIC_MISLABELED")
    conclusion = report.get("conclusion")
    if (
        not isinstance(conclusion, dict)
        or conclusion.get("result") != "NO_PRODUCT_WINNER"
        or conclusion.get("winner") is not None
    ):
        errors.append("PRODUCT_WINNER_OVERSTATED")
    return errors
