from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Sequence

from .text import edit_distance, normalize_nfkc, text_digest


REPORT_SCHEMA_VERSION = "1.0.0"
REPORT_STATUS = "PASS_ENGINEERING_SINGLE_SAMPLE_COMPARISON_PRODUCT_BLOCKED"
REPORT_SCOPE = "SINGLE_OFFICIAL_NON_HEALTH_SAMPLE_ENGINEERING_ONLY"


class ComparisonEvidenceError(ValueError):
    """Raised when source evidence cannot support the bounded comparison."""


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalize_line(text: str) -> str:
    return normalize_nfkc(text)


def compare_line_outputs(
    cpu_lines: Sequence[str], rknn_lines: Sequence[str]
) -> dict[str, Any]:
    cpu = [normalize_line(line) for line in cpu_lines]
    rknn = [normalize_line(line) for line in rknn_lines]
    cpu_text = "\n".join(cpu)
    rknn_text = "\n".join(rknn)
    distance = edit_distance(cpu_text, rknn_text)
    denominator = max(len(cpu_text), len(rknn_text), 1)
    positioned_matches = sum(
        left == right for left, right in zip(cpu, rknn, strict=False)
    )
    return {
        "same_line_count": len(cpu) == len(rknn),
        "cpu_line_count": len(cpu),
        "rknn_line_count": len(rknn),
        "positioned_line_exact_match_count": positioned_matches,
        "all_positioned_lines_exact_match": cpu == rknn,
        "pairwise_character_edit_distance": distance,
        "pairwise_character_disagreement_rate": distance / denominator,
        "metric_meaning": (
            "Pairwise candidate disagreement without ground truth; this is not OCR "
            "character error rate or accuracy."
        ),
    }


def load_rknn_lines(path: Path, expected_image_sha256: str) -> list[str]:
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ComparisonEvidenceError("RKNN simulator report is unreadable") from exc
    comparison = report.get("comparison")
    inputs = report.get("inputs")
    lines = comparison.get("rknn_text") if isinstance(comparison, dict) else None
    if (
        report.get("status") != "PASS_ENGINEERING_FUNCTIONAL_SIMULATION"
        or report.get("scope") != "PC_SIMULATOR_SINGLE_OFFICIAL_SAMPLE_ONLY"
        or report.get("hardware_measured") is not False
        or report.get("product_accuracy_claim_allowed") is not False
        or report.get("ocr_metric_claim_allowed") is not False
        or not isinstance(inputs, dict)
        or inputs.get("image_sha256") != expected_image_sha256
        or not isinstance(lines, list)
        or not lines
        or not all(isinstance(line, str) and line.strip() for line in lines)
    ):
        raise ComparisonEvidenceError("RKNN simulator evidence boundary is invalid")
    return lines


def validate_report(
    report: object,
    *,
    image_path: Path,
    cpu_manifest_path: Path,
    rknn_report_path: Path,
) -> list[str]:
    errors: list[str] = []
    if not isinstance(report, dict):
        return ["REPORT_NOT_OBJECT"]
    expected_hashes = {
        "image_sha256": sha256(image_path),
        "cpu_manifest_sha256": sha256(cpu_manifest_path),
        "rknn_simulator_report_sha256": sha256(rknn_report_path),
    }
    source_hashes = report.get("source_hashes")
    if (
        report.get("schema_version") != REPORT_SCHEMA_VERSION
        or report.get("status") != REPORT_STATUS
        or report.get("scope") != REPORT_SCOPE
    ):
        errors.append("REPORT_BOUNDARY_INVALID")
    for field in (
        "ground_truth_available",
        "accuracy_claim_allowed",
        "product_selection_allowed",
        "hardware_measured",
        "host_timing_comparable_for_ranking",
        "authorized_health_report_data_used",
    ):
        if report.get(field) is not False:
            errors.append(f"UNSAFE_TRUE_FLAG:{field}")
    if source_hashes != expected_hashes:
        errors.append("SOURCE_HASH_MISMATCH")
    candidates = report.get("candidates")
    if not isinstance(candidates, dict) or set(candidates) != {
        "ocr_paddle_cpu_ppocrv5",
        "ocr_rknn_ppocrv4",
    }:
        errors.append("CANDIDATE_SET_INVALID")
    comparison = report.get("comparison")
    if not isinstance(comparison, dict):
        errors.append("COMPARISON_MISSING")
    else:
        rate = comparison.get("pairwise_character_disagreement_rate")
        if not isinstance(rate, (int, float)) or not 0 <= rate <= 1:
            errors.append("PAIRWISE_DISAGREEMENT_INVALID")
        if "accuracy" in str(comparison.get("metric_meaning", "")).lower() and (
            "not" not in str(comparison.get("metric_meaning", "")).lower()
        ):
            errors.append("PAIRWISE_METRIC_MISLABELED")
    conclusion = report.get("conclusion")
    if (
        not isinstance(conclusion, dict)
        or conclusion.get("winner") is not None
        or conclusion.get("result") != "NO_PRODUCT_WINNER"
    ):
        errors.append("PRODUCT_WINNER_OVERSTATED")
    return errors
