from __future__ import annotations

import hashlib
import json
import statistics
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .text import edit_distance


USAGE = "research evaluation only; commercial license review required"
CANDIDATE_STATUS = "PASS_ENGINEERING_PUBLIC_SET_EVALUATION_PRODUCT_BLOCKED"
COMPARISON_STATUS = "PASS_ENGINEERING_PUBLIC_SET_COMPARISON_PRODUCT_BLOCKED"


class DatasetEvidenceError(ValueError):
    pass


@dataclass(frozen=True)
class EvaluationSample:
    sample_id: str
    audio_path: Path
    audio_sha256: str
    reference: str
    source_sid: str
    speaker: str
    duration_seconds: float
    entities: tuple[str, ...]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalize_for_cer(text: str) -> str:
    normalized = unicodedata.normalize("NFKC", text).lower()
    return "".join(
        character
        for character in normalized
        if "\u3400" <= character <= "\u9fff"
        or "0" <= character <= "9"
        or "a" <= character <= "z"
    )


def percentile(values: list[float], quantile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = (len(ordered) - 1) * quantile
    lower = int(index)
    upper = min(lower + 1, len(ordered) - 1)
    weight = index - lower
    return ordered[lower] * (1 - weight) + ordered[upper] * weight


def _metadata_entities(path: Path) -> dict[str, tuple[str, ...]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    audios = payload.get("audios")
    if not isinstance(audios, list):
        raise DatasetEvidenceError("MED-CH metadata is invalid")
    result: dict[str, tuple[str, ...]] = {}
    for audio in audios:
        if not isinstance(audio, dict) or not isinstance(audio.get("segments"), list):
            continue
        for segment in audio["segments"]:
            if not isinstance(segment, dict) or not isinstance(segment.get("sid"), str):
                continue
            entities = segment.get("entities", [])
            result[segment["sid"]] = tuple(
                str(entity) for entity in entities if str(entity).strip()
            ) if isinstance(entities, list) else ()
    return result


def load_dataset(
    *,
    project_root: Path,
    manifest_path: Path,
    metadata_path: Path,
    subset_report_path: Path,
) -> tuple[list[EvaluationSample], dict[str, Any]]:
    project = project_root.resolve(strict=True)
    manifest = manifest_path.resolve(strict=True)
    metadata = metadata_path.resolve(strict=True)
    subset_report = json.loads(subset_report_path.read_text(encoding="utf-8"))
    if (
        subset_report.get("dataset") != "speechcolab/GigaSpeechBench"
        or subset_report.get("subset") != "Vertical-Domain/data/MED-CH"
        or subset_report.get("usage") != USAGE
        or subset_report.get("sample_count") != 60
        or subset_report.get("full_archive_stored") is not False
        or subset_report.get("metadata_sha256", "").lower() != sha256(metadata)
    ):
        raise DatasetEvidenceError("MED-CH subset report boundary is invalid")
    entities_by_sid = _metadata_entities(metadata)
    rows = [
        json.loads(line)
        for line in manifest.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(rows) != 60:
        raise DatasetEvidenceError("MED-CH manifest must contain 60 samples")
    allowed_audio_root = (manifest.parent / "audio").resolve(strict=True)
    samples: list[EvaluationSample] = []
    seen_ids: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            raise DatasetEvidenceError("MED-CH manifest row is invalid")
        sample_id = row.get("id")
        source_sid = row.get("source_sid")
        speaker = row.get("speaker")
        reference = row.get("text")
        relative_audio = row.get("audio")
        duration = row.get("duration_seconds")
        expected_hash = str(row.get("sha256", "")).lower()
        if (
            not isinstance(sample_id, str)
            or sample_id in seen_ids
            or not isinstance(source_sid, str)
            or not isinstance(speaker, str)
            or not isinstance(reference, str)
            or not normalize_for_cer(reference)
            or not isinstance(relative_audio, str)
            or not isinstance(duration, (int, float))
            or duration <= 0
        ):
            raise DatasetEvidenceError("MED-CH manifest row fields are invalid")
        audio = (project / relative_audio).resolve(strict=True)
        if audio.parent != allowed_audio_root or audio.is_symlink():
            raise DatasetEvidenceError("MED-CH audio path is unsafe")
        actual_hash = sha256(audio)
        if actual_hash != expected_hash:
            raise DatasetEvidenceError("MED-CH audio hash mismatch")
        seen_ids.add(sample_id)
        samples.append(
            EvaluationSample(
                sample_id=sample_id,
                audio_path=audio,
                audio_sha256=actual_hash,
                reference=reference,
                source_sid=source_sid,
                speaker=speaker,
                duration_seconds=float(duration),
                entities=entities_by_sid.get(source_sid, ()),
            )
        )
    source_aids = subset_report.get("source_aids")
    dataset = {
        "dataset": "speechcolab/GigaSpeechBench",
        "subset": "Vertical-Domain/data/MED-CH",
        "usage": USAGE,
        "commercial_rights_cleared": False,
        "samples": len(samples),
        "speakers": len({sample.speaker for sample in samples}),
        "source_audio_count": subset_report.get("source_audio_count"),
        "source_aids_count": len(source_aids) if isinstance(source_aids, list) else None,
        "total_duration_seconds": round(
            sum(sample.duration_seconds for sample in samples), 6
        ),
        "manifest_sha256": sha256(manifest),
        "metadata_sha256": sha256(metadata),
        "subset_report_sha256": sha256(subset_report_path),
        "audio_set_sha256": _audio_set_digest(samples),
        "reference_set_sha256": _reference_set_digest(samples),
    }
    return samples, dataset


def _audio_set_digest(samples: list[EvaluationSample]) -> str:
    digest = hashlib.sha256()
    for sample in samples:
        digest.update(sample.sample_id.encode("utf-8"))
        digest.update(bytes.fromhex(sample.audio_sha256))
    return digest.hexdigest()


def _reference_set_digest(samples: list[EvaluationSample]) -> str:
    digest = hashlib.sha256()
    for sample in samples:
        normalized = normalize_for_cer(sample.reference)
        digest.update(sample.sample_id.encode("utf-8"))
        digest.update(hashlib.sha256(normalized.encode("utf-8")).digest())
    return digest.hexdigest()


def evaluate_samples(
    samples: list[EvaluationSample],
    recognize: Callable[[Path], str],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    predictions: list[dict[str, Any]] = []
    latencies: list[float] = []
    rtfs: list[float] = []
    total_reference_chars = 0
    total_edit_distance = 0
    total_entities = 0
    entity_hits = 0
    failures = 0
    empty_results = 0
    for sample in samples:
        started = time.perf_counter()
        failure_code: str | None = None
        try:
            prediction = recognize(sample.audio_path)
        except Exception as exc:  # Candidate failure stays in the denominator.
            prediction = ""
            failure_code = type(exc).__name__
            failures += 1
        latency = time.perf_counter() - started
        reference = normalize_for_cer(sample.reference)
        predicted = normalize_for_cer(prediction)
        distance = edit_distance(reference, predicted)
        normalized_entities = [
            value for value in (normalize_for_cer(item) for item in sample.entities) if value
        ]
        hits = sum(entity in predicted for entity in normalized_entities)
        total_reference_chars += len(reference)
        total_edit_distance += distance
        total_entities += len(normalized_entities)
        entity_hits += hits
        if not predicted:
            empty_results += 1
        latencies.append(latency)
        rtfs.append(latency / sample.duration_seconds)
        predictions.append(
            {
                "id": sample.sample_id,
                "audio_sha256": sample.audio_sha256,
                "reference_normalized_sha256": hashlib.sha256(
                    reference.encode("utf-8")
                ).hexdigest(),
                "prediction_normalized_sha256": hashlib.sha256(
                    predicted.encode("utf-8")
                ).hexdigest(),
                "reference_chars": len(reference),
                "prediction_chars": len(predicted),
                "edit_distance": distance,
                "duration_seconds": sample.duration_seconds,
                "latency_seconds": round(latency, 6),
                "rtf": round(latency / sample.duration_seconds, 6),
                "entity_count": len(normalized_entities),
                "entity_hits": hits,
                "failure_code": failure_code,
            }
        )
    metrics = {
        "samples": len(samples),
        "reference_chars": total_reference_chars,
        "edit_distance": total_edit_distance,
        "cer": total_edit_distance / max(total_reference_chars, 1),
        "failures": failures,
        "empty_results": empty_results,
        "entity_count": total_entities,
        "entity_hits": entity_hits,
        "entity_recall": entity_hits / total_entities if total_entities else None,
        "average_latency_seconds": statistics.fmean(latencies),
        "p50_latency_seconds": percentile(latencies, 0.5),
        "p95_latency_seconds": percentile(latencies, 0.95),
        "average_rtf": statistics.fmean(rtfs),
        "p50_rtf": percentile(rtfs, 0.5),
        "p95_rtf": percentile(rtfs, 0.95),
    }
    return metrics, predictions


def predictions_digest(predictions: list[dict[str, Any]]) -> str:
    rendered = json.dumps(
        predictions, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    return hashlib.sha256(rendered.encode("utf-8")).hexdigest()


def validate_candidate_report(report: object, candidate_id: str) -> list[str]:
    errors: list[str] = []
    if not isinstance(report, dict):
        return ["CANDIDATE_REPORT_NOT_OBJECT"]
    if (
        report.get("schema_version") != "1.0.0"
        or report.get("status") != CANDIDATE_STATUS
        or report.get("candidate_id") != candidate_id
        or report.get("scope") != "MED_CH_60_RESEARCH_ENGINEERING_ONLY"
        or report.get("product_selection_allowed") is not False
        or report.get("hardware_measured") is not False
        or report.get("target_microphone_evidence") is not False
    ):
        errors.append("CANDIDATE_BOUNDARY_INVALID")
    dataset = report.get("dataset")
    if (
        not isinstance(dataset, dict)
        or dataset.get("usage") != USAGE
        or dataset.get("commercial_rights_cleared") is not False
        or dataset.get("samples") != 60
    ):
        errors.append("DATASET_BOUNDARY_INVALID")
    metrics = report.get("metrics")
    if not isinstance(metrics, dict) or metrics.get("samples") != 60:
        errors.append("METRICS_INVALID")
    else:
        cer = metrics.get("cer")
        if not isinstance(cer, (int, float)) or not 0 <= cer:
            errors.append("CER_INVALID")
        if not isinstance(metrics.get("failures"), int) or not isinstance(
            metrics.get("empty_results"), int
        ):
            errors.append("FAILURE_METRICS_INVALID")
    predictions = report.get("predictions")
    if not isinstance(predictions, list) or len(predictions) != 60:
        errors.append("PREDICTION_EVIDENCE_INVALID")
    elif report.get("predictions_sha256") != predictions_digest(predictions):
        errors.append("PREDICTION_EVIDENCE_HASH_MISMATCH")
    return errors


def candidate_report_is_current(
    report: object,
    *,
    candidate_id: str,
    expected_dataset: dict[str, Any],
    expected_identity: dict[str, Any],
) -> bool:
    if validate_candidate_report(report, candidate_id):
        return False
    assert isinstance(report, dict)
    if report.get("dataset") != expected_dataset:
        return False
    return all(report.get(key) == value for key, value in expected_identity.items())
