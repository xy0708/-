from __future__ import annotations

from typing import Any


def axis_starts(length: int, tile_size: int, overlap: int) -> list[int]:
    if length <= tile_size:
        return [0]
    stride = tile_size - overlap
    if stride <= 0:
        raise ValueError("tile overlap must be smaller than tile size")
    starts = list(range(0, length - tile_size + 1, stride))
    final = length - tile_size
    if starts[-1] != final:
        starts.append(final)
    return starts


def bounds(line: dict[str, Any]) -> tuple[float, float, float, float]:
    box = line["source_box"]
    if not isinstance(box, list) or len(box) != 8:
        raise ValueError("Invalid OCR box")
    x_values = [float(value) for value in box[0::2]]
    y_values = [float(value) for value in box[1::2]]
    return min(x_values), min(y_values), max(x_values), max(y_values)


def intersection_over_union(left: dict[str, Any], right: dict[str, Any]) -> float:
    left_x1, left_y1, left_x2, left_y2 = bounds(left)
    right_x1, right_y1, right_x2, right_y2 = bounds(right)
    width = max(0.0, min(left_x2, right_x2) - max(left_x1, right_x1))
    height = max(0.0, min(left_y2, right_y2) - max(left_y1, right_y1))
    intersection = width * height
    left_area = max(0.0, left_x2 - left_x1) * max(0.0, left_y2 - left_y1)
    right_area = max(0.0, right_x2 - right_x1) * max(0.0, right_y2 - right_y1)
    union = left_area + right_area - intersection
    return intersection / union if union > 0 else 0.0


def deduplicate(lines: list[dict[str, Any]]) -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    for candidate in sorted(
        lines, key=lambda item: float(item["confidence"]), reverse=True
    ):
        if any(intersection_over_union(candidate, kept) >= 0.5 for kept in selected):
            continue
        selected.append(candidate)
    return sorted(selected, key=lambda item: (bounds(item)[1], bounds(item)[0]))
