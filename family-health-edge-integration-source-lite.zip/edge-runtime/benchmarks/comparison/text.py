from __future__ import annotations

import hashlib
import unicodedata
from collections.abc import Sequence


def normalize_nfkc(text: str) -> str:
    return unicodedata.normalize("NFKC", text.strip())


def text_digest(lines: Sequence[str]) -> str:
    normalized = "\n".join(normalize_nfkc(line) for line in lines)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def edit_distance(left: str, right: str) -> int:
    if len(left) > len(right):
        left, right = right, left
    previous = list(range(len(left) + 1))
    for right_index, right_character in enumerate(right, start=1):
        current = [right_index]
        for left_index, left_character in enumerate(left, start=1):
            current.append(
                min(
                    current[-1] + 1,
                    previous[left_index] + 1,
                    previous[left_index - 1]
                    + (left_character != right_character),
                )
            )
        previous = current
    return previous[-1]
