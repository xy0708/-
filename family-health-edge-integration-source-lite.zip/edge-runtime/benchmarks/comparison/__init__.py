"""Candidate comparison helpers with explicit evidence boundaries."""
