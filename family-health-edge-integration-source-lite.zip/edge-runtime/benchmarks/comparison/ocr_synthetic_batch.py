from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Sequence


REPORT_STATUS = "PASS_ENGINEERING_SYNTHETIC_COMPARISON_PRODUCT_BLOCKED"
REPORT_SCOPE = "SYNTHETIC_HEALTH_REPORT_ENGINEERING_ONLY_NOT_PRODUCT_METRICS"
CANDIDATES = {"ocr_paddle_cpu_ppocrv5", "ocr_rknn_ppocrv4"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def score_extracted_indicators(
    extracted: Sequence[Any], expected: Sequence[dict[str, object]]
) -> dict[str, int | float]:
    by_name: dict[str, list[Any]] = {}
    for indicator in extracted:
        by_name.setdefault(str(indicator.standard_name), []).append(indicator)
    detected = 0
    values = 0
    units = 0
    exact_fields = 0
    for item in expected:
        candidates = by_name.get(str(item["standard_name"]), [])
        if not candidates:
            continue
        actual = candidates.pop(0)
        detected += 1
        value_matches = actual.raw_value == item["raw_value"]
        unit_matches = actual.normalized_unit == item["raw_unit"]
        values += int(value_matches)
        units += int(unit_matches)
        exact_fields += int(value_matches and unit_matches)
    denominator = max(len(expected), 1)
    return {
        "expected_fields": len(expected),
        "detected_fields": detected,
        "exact_value_fields": values,
        "exact_unit_fields": units,
        "exact_complete_fields": exact_fields,
        "required_field_recall": detected / denominator,
        "exact_value_rate": values / denominator,
        "exact_unit_rate": units / denominator,
        "field_exact_match_rate": exact_fields / denominator,
    }


def aggregate_sample_scores(samples: Sequence[dict[str, Any]]) -> dict[str, int | float]:
    totals = {
        "expected_fields": 0,
        "detected_fields": 0,
        "exact_value_fields": 0,
        "exact_unit_fields": 0,
        "exact_complete_fields": 0,
    }
    failures = 0
    empty_results = 0
    for sample in samples:
        metrics = sample["metrics"]
        for field in totals:
            totals[field] += int(metrics[field])
        failures += int(sample["status"] != "PASS_ENGINEERING_INFERENCE")
        empty_results += int(int(sample["raw_line_count"]) == 0)
    fields = max(totals["expected_fields"], 1)
    sample_count = max(len(samples), 1)
    return {
        **totals,
        "sample_count": len(samples),
        "failed_samples": failures,
        "empty_samples": empty_results,
        "required_field_recall": totals["detected_fields"] / fields,
        "exact_value_rate": totals["exact_value_fields"] / fields,
        "exact_unit_rate": totals["exact_unit_fields"] / fields,
        "field_exact_match_rate": totals["exact_complete_fields"] / fields,
        "failure_rate": failures / sample_count,
        "empty_result_rate": empty_results / sample_count,
    }


def validate_report(report: object, expected_hashes: dict[str, str]) -> list[str]:
    errors: list[str] = []
    if not isinstance(report, dict):
        return ["REPORT_NOT_OBJECT"]
    if (
        report.get("schema_version") != "1.0.0"
        or report.get("status") != REPORT_STATUS
        or report.get("scope") != REPORT_SCOPE
    ):
        errors.append("REPORT_BOUNDARY_INVALID")
    for field in (
        "product_acceptance_evidence",
        "formal_data_used",
        "authorized_health_report_data_used",
        "hardware_measured",
        "product_selection_allowed",
        "accuracy_claim_allowed",
        "host_timing_comparable_for_ranking",
    ):
        if report.get(field) is not False:
            errors.append(f"UNSAFE_TRUE_FLAG:{field}")
    if report.get("source_hashes") != expected_hashes:
        errors.append("SOURCE_HASH_MISMATCH")
    candidates = report.get("candidates")
    if not isinstance(candidates, dict) or set(candidates) != CANDIDATES:
        errors.append("CANDIDATE_SET_INVALID")
    else:
        sample_counts = set()
        for name, candidate in candidates.items():
            if not isinstance(candidate, dict):
                errors.append(f"CANDIDATE_INVALID:{name}")
                continue
            samples = candidate.get("samples")
            aggregate = candidate.get("aggregate")
            if not isinstance(samples, list) or len(samples) < 2:
                errors.append(f"CANDIDATE_SAMPLES_INVALID:{name}")
                continue
            if not isinstance(aggregate, dict):
                errors.append(f"CANDIDATE_AGGREGATE_INVALID:{name}")
                continue
            sample_counts.add(len(samples))
            for metric in (
                "required_field_recall",
                "exact_value_rate",
                "exact_unit_rate",
                "field_exact_match_rate",
                "failure_rate",
                "empty_result_rate",
            ):
                value = aggregate.get(metric)
                if (
                    isinstance(value, bool)
                    or not isinstance(value, (int, float))
                    or not 0 <= value <= 1
                ):
                    errors.append(f"CANDIDATE_METRIC_INVALID:{name}:{metric}")
        if len(sample_counts) != 1:
            errors.append("CANDIDATE_SAMPLE_COUNT_MISMATCH")
    conclusion = report.get("conclusion")
    if (
        not isinstance(conclusion, dict)
        or conclusion.get("result") != "NO_PRODUCT_WINNER"
        or conclusion.get("winner") is not None
    ):
        errors.append("PRODUCT_WINNER_OVERSTATED")
    return errors
