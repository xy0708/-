"""Reproducible engineering benchmarks; never product acceptance evidence."""
