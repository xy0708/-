import 'dart:convert';

import 'package:flutter/services.dart';

final class AsrAssetFile {
  const AsrAssetFile({
    required this.name,
    required this.bytes,
    required this.sha256,
  });

  final String name;
  final int bytes;
  final String sha256;

  Map<String, Object> toPlatformRequest(String assetPrefix) => <String, Object>{
    'assetPath': '$assetPrefix/$name',
    'name': name,
    'bytes': bytes,
    'sha256': sha256,
  };
}

final class AsrCandidate {
  const AsrCandidate({
    required this.id,
    required this.runtimeVersion,
    required this.sampleRate,
    required this.numThreads,
    required this.assetPrefix,
    required this.files,
    required this.productEnabled,
  });

  final String id;
  final String runtimeVersion;
  final int sampleRate;
  final int numThreads;
  final String assetPrefix;
  final List<AsrAssetFile> files;
  final bool productEnabled;

  factory AsrCandidate.fromJson(Map<String, dynamic> json) {
    final Map<String, dynamic> runtime = Map<String, dynamic>.from(
      json['runtime'] as Map,
    );
    final Map<String, dynamic> model = Map<String, dynamic>.from(
      json['model'] as Map,
    );
    final Map<String, dynamic> rawFiles = Map<String, dynamic>.from(
      model['files'] as Map,
    );
    return AsrCandidate(
      id: json['candidate_id'] as String,
      runtimeVersion: runtime['version'] as String,
      sampleRate: runtime['sample_rate_hz'] as int,
      numThreads: runtime['num_threads'] as int,
      assetPrefix: model['asset_prefix'] as String,
      files: rawFiles.entries
          .map((MapEntry<String, dynamic> entry) {
            final Map<String, dynamic> value = Map<String, dynamic>.from(
              entry.value as Map,
            );
            return AsrAssetFile(
              name: entry.key,
              bytes: value['bytes'] as int,
              sha256: value['sha256'] as String,
            );
          })
          .toList(growable: false),
      productEnabled: json['product_enabled'] as bool,
    );
  }

  AsrAssetFile file(String name) => files.singleWhere(
    (AsrAssetFile file) => file.name == name,
    orElse: () => throw StateError('Missing ASR asset specification: $name'),
  );
}

Future<AsrCandidate> loadAsrCandidate() async {
  final String raw = await rootBundle.loadString('assets/asr_candidate.json');
  return AsrCandidate.fromJson(jsonDecode(raw) as Map<String, dynamic>);
}

abstract interface class AsrAssetGateway {
  Future<Map<String, String>> provision(AsrCandidate candidate);
}

final class AndroidAsrAssetGateway implements AsrAssetGateway {
  const AndroidAsrAssetGateway();

  static const MethodChannel _channel = MethodChannel(
    'com.familyhealth.edge/model_assets',
  );

  @override
  Future<Map<String, String>> provision(AsrCandidate candidate) async {
    final Map<Object?, Object?>? raw = await _channel
        .invokeMapMethod<Object?, Object?>('provision', <String, Object>{
          'modelId': candidate.id,
          'files': candidate.files
              .map(
                (AsrAssetFile file) =>
                    file.toPlatformRequest(candidate.assetPrefix),
              )
              .toList(growable: false),
        });
    if (raw == null || raw.length != candidate.files.length) {
      throw StateError('Android did not provision the complete ASR model.');
    }
    return raw.map(
      (Object? key, Object? value) =>
          MapEntry(key! as String, value! as String),
    );
  }
}
