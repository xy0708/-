import 'dart:convert';

import 'package:flutter/services.dart';

const String healthDisclaimer =
    '本结果仅用于家庭健康管理提示，不构成医疗诊断或治疗建议；如有不适、指标持续异常或紧急情况，请及时咨询专业医疗人员。';
const int maxMeasurements = 64;
const int maxHistoryPerMeasurement = 365;

final class HealthRuleInputException implements Exception {
  const HealthRuleInputException(this.code, this.message);

  final String code;
  final String message;

  @override
  String toString() => '$code: $message';
}

final class UnitConversion {
  const UnitConversion({required this.multiply, required this.add});

  final double multiply;
  final double add;
}

final class MetricRule {
  const MetricRule({
    required this.canonicalUnit,
    required this.conversions,
    required this.maxAgeDays,
    required this.minimumHistory,
    required this.relativeChangeThreshold,
  });

  final String canonicalUnit;
  final Map<String, UnitConversion> conversions;
  final double? maxAgeDays;
  final int minimumHistory;
  final double? relativeChangeThreshold;

  factory MetricRule.fromJson(Map<String, dynamic> json) {
    final Map<String, dynamic> conversionJson = Map<String, dynamic>.from(
      json['conversions'] as Map? ?? const {},
    );
    final Map<String, dynamic> trend = Map<String, dynamic>.from(
      json['trend'] as Map? ?? const {},
    );
    return MetricRule(
      canonicalUnit: json['canonical_unit'] as String,
      conversions: conversionJson.map((String unit, dynamic value) {
        final Map<String, dynamic> item = Map<String, dynamic>.from(
          value as Map,
        );
        return MapEntry(
          unit,
          UnitConversion(
            multiply: (item['multiply'] as num).toDouble(),
            add: (item['add'] as num? ?? 0).toDouble(),
          ),
        );
      }),
      maxAgeDays: (json['max_age_days'] as num?)?.toDouble(),
      minimumHistory: (trend['minimum_history'] as num? ?? 0).toInt(),
      relativeChangeThreshold: (trend['relative_change_threshold'] as num?)
          ?.toDouble(),
    );
  }
}

final class HealthRuleConfig {
  const HealthRuleConfig({
    required this.ruleVersion,
    required this.approvalStatus,
    required this.metrics,
  });

  final String ruleVersion;
  final String approvalStatus;
  final Map<String, MetricRule> metrics;

  bool get productReleaseAllowed =>
      approvalStatus == 'APPROVED_FOR_PRODUCT_RELEASE';

  factory HealthRuleConfig.fromJson(Map<String, dynamic> json) {
    final Map<String, dynamic> metricJson = Map<String, dynamic>.from(
      json['metrics'] as Map,
    );
    return HealthRuleConfig(
      ruleVersion: json['rule_version'] as String,
      approvalStatus: json['approval_status'] as String,
      metrics: metricJson.map(
        (String name, dynamic value) => MapEntry(
          name,
          MetricRule.fromJson(Map<String, dynamic>.from(value as Map)),
        ),
      ),
    );
  }
}

Future<HealthRuleConfig> loadHealthRuleConfig() async {
  final String raw = await rootBundle.loadString('assets/health_rules.json');
  return HealthRuleConfig.fromJson(jsonDecode(raw) as Map<String, dynamic>);
}

final class HealthHistoryPoint {
  const HealthHistoryPoint({
    required this.value,
    required this.unit,
    required this.confirmed,
  });

  final double value;
  final String unit;
  final bool confirmed;
}

final class HealthMeasurement {
  const HealthMeasurement({
    required this.metric,
    required this.value,
    required this.unit,
    required this.measuredAt,
    required this.confirmed,
    this.referenceLow,
    this.referenceHigh,
    this.referenceSource,
    this.history = const <HealthHistoryPoint>[],
  });

  final String metric;
  final double value;
  final String unit;
  final DateTime measuredAt;
  final bool confirmed;
  final double? referenceLow;
  final double? referenceHigh;
  final String? referenceSource;
  final List<HealthHistoryPoint> history;
}

final class HealthRuleEngine {
  const HealthRuleEngine(this.config);

  final HealthRuleConfig config;

  Map<String, Object?> evaluate({
    required List<HealthMeasurement> measurements,
    required bool confirmed,
    required DateTime now,
  }) {
    if (!confirmed) {
      throw const HealthRuleInputException(
        'TASK_NOT_CONFIRMED',
        '健康提示只接受已确认输入',
      );
    }
    if (measurements.isEmpty) {
      throw const HealthRuleInputException(
        'INPUT_INVALID',
        'measurements 不能为空',
      );
    }
    if (measurements.length > maxMeasurements) {
      throw const HealthRuleInputException(
        'INPUT_OUT_OF_RANGE',
        'measurements 超过单次请求上限',
      );
    }
    final List<Map<String, Object?>> results = measurements
        .map(
          (HealthMeasurement item) => _evaluateMeasurement(item, now.toUtc()),
        )
        .toList(growable: false);
    final Set<String> levels = results
        .expand(
          (Map<String, Object?> result) =>
              (result['triggers'] as List<Map<String, Object?>>).map(
                (Map<String, Object?> trigger) => trigger['level']! as String,
              ),
        )
        .toSet();
    final String attentionLevel = levels.contains('INPUT_REVIEW_REQUIRED')
        ? 'INPUT_REVIEW_REQUIRED'
        : levels.contains('ATTENTION')
        ? 'ATTENTION'
        : levels.contains('OBSERVE')
        ? 'OBSERVE'
        : 'NO_RULE_TRIGGERED';
    return <String, Object?>{
      'scope': 'NON_DIAGNOSTIC_HEALTH_MANAGEMENT',
      'rule_version': config.ruleVersion,
      'approval_status': config.approvalStatus,
      'product_release_allowed': config.productReleaseAllowed,
      'disease_probability': null,
      'diagnosis': null,
      'attention_level': attentionLevel,
      'measurements': results,
      'disclaimer': healthDisclaimer,
    };
  }

  Map<String, Object?> _evaluateMeasurement(
    HealthMeasurement item,
    DateTime now,
  ) {
    if (!item.confirmed) {
      throw HealthRuleInputException(
        'TASK_NOT_CONFIRMED',
        '${item.metric} 尚未由用户确认',
      );
    }
    _requireFinite(item.value, 'value');
    if (item.measuredAt.toUtc().isAfter(now)) {
      throw HealthRuleInputException(
        'INPUT_INVALID',
        '${item.metric} 的 measuredAt 不能晚于当前时间',
      );
    }
    final MetricRule rule = _ruleFor(item.metric);
    final double value = _canonicalize(
      rule,
      item.metric,
      item.value,
      item.unit,
    );
    final double? referenceLow = _canonicalOptional(
      rule,
      item.metric,
      item.referenceLow,
      item.unit,
      'referenceLow',
    );
    final double? referenceHigh = _canonicalOptional(
      rule,
      item.metric,
      item.referenceHigh,
      item.unit,
      'referenceHigh',
    );
    if (referenceLow != null &&
        referenceHigh != null &&
        referenceLow > referenceHigh) {
      throw HealthRuleInputException(
        'INPUT_INVALID',
        '${item.metric} 的参考区间上下限冲突',
      );
    }
    if (item.history.length > maxHistoryPerMeasurement) {
      throw const HealthRuleInputException('INPUT_OUT_OF_RANGE', '单个指标历史记录过多');
    }

    final List<Map<String, Object?>> triggers = <Map<String, Object?>>[];
    final List<String> warnings = <String>[];
    if (referenceLow == null && referenceHigh == null) {
      warnings.add('REFERENCE_RANGE_MISSING');
    } else if (referenceLow != null && value < referenceLow) {
      triggers.add(_trigger('BELOW_PROVIDED_REFERENCE', 'ATTENTION'));
    } else if (referenceHigh != null && value > referenceHigh) {
      triggers.add(_trigger('ABOVE_PROVIDED_REFERENCE', 'ATTENTION'));
    }

    final double ageDays =
        now.difference(item.measuredAt.toUtc()).inMilliseconds / 86400000;
    if (rule.maxAgeDays != null && ageDays > rule.maxAgeDays!) {
      triggers.add(<String, Object?>{
        'code': 'MEASUREMENT_STALE',
        'level': 'INPUT_REVIEW_REQUIRED',
        'age_days': _roundSix(ageDays),
      });
    }

    final List<double> historyValues = item.history
        .where((HealthHistoryPoint point) => point.confirmed)
        .map((HealthHistoryPoint point) {
          _requireFinite(point.value, 'history.value');
          return _canonicalize(rule, item.metric, point.value, point.unit);
        })
        .toList(growable: false);
    final Map<String, Object?>? trend = _trend(rule, value, historyValues);
    if (trend != null) triggers.add(trend);

    return <String, Object?>{
      'metric': item.metric,
      'value': _roundSix(value),
      'unit': rule.canonicalUnit,
      'measured_at': item.measuredAt.toUtc().toIso8601String(),
      'reference_low': referenceLow,
      'reference_high': referenceHigh,
      'reference_source': item.referenceSource,
      'triggers': triggers,
      'warnings': warnings,
      'no_rule_triggered_is_not_proof_of_health': triggers.isEmpty,
    };
  }

  MetricRule _ruleFor(String metric) {
    final MetricRule? rule = config.metrics[metric];
    if (rule == null) {
      throw HealthRuleInputException('INPUT_INVALID', '不支持的指标：$metric');
    }
    return rule;
  }

  double _canonicalize(
    MetricRule rule,
    String metric,
    double value,
    String unit,
  ) {
    if (unit == rule.canonicalUnit) return value;
    final UnitConversion? conversion = rule.conversions[unit];
    if (conversion == null) {
      throw HealthRuleInputException(
        'INPUT_UNIT_UNSUPPORTED',
        '$metric 不支持单位 $unit，期望 ${rule.canonicalUnit}',
      );
    }
    return value * conversion.multiply + conversion.add;
  }

  double? _canonicalOptional(
    MetricRule rule,
    String metric,
    double? value,
    String unit,
    String field,
  ) {
    if (value == null) return null;
    _requireFinite(value, field);
    return _canonicalize(rule, metric, value, unit);
  }

  Map<String, Object?>? _trend(
    MetricRule rule,
    double current,
    List<double> history,
  ) {
    final double? threshold = rule.relativeChangeThreshold;
    if (threshold == null || history.length < rule.minimumHistory) return null;
    final List<double> baselineValues = history.sublist(
      history.length - rule.minimumHistory,
    );
    final double baseline =
        baselineValues.reduce((double a, double b) => a + b) /
        baselineValues.length;
    if (baseline == 0) return null;
    final double relativeChange = (current - baseline) / baseline.abs();
    if (relativeChange.abs() < threshold) return null;
    return <String, Object?>{
      'code': 'PERSONAL_TREND_CHANGE',
      'level': 'OBSERVE',
      'relative_change': _roundSix(relativeChange),
      'baseline_count': baselineValues.length,
    };
  }

  static Map<String, Object?> _trigger(String code, String level) =>
      <String, Object?>{'code': code, 'level': level};

  static void _requireFinite(double value, String field) {
    if (!value.isFinite) {
      throw HealthRuleInputException('INPUT_INVALID', '$field 必须是有限数值');
    }
  }

  static double _roundSix(double value) =>
      (value * 1000000).roundToDouble() / 1000000;
}
