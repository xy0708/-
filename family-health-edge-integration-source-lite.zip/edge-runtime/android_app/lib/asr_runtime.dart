import 'dart:typed_data';

import 'package:sherpa_onnx/sherpa_onnx.dart' as sherpa;

import 'asr_model_assets.dart';

const int maxAsrSessionSeconds = 120;
const int maxDecodeStepsPerCall = 4096;

final class AsrInputException implements Exception {
  const AsrInputException(this.code, this.message);

  final String code;
  final String message;

  @override
  String toString() => '$code: $message';
}

final class PendingAsrTranscript {
  const PendingAsrTranscript({
    required this.text,
    required this.modelCandidateId,
    required this.runtimeVersion,
  });

  final String text;
  final String modelCandidateId;
  final String runtimeVersion;
  bool get requiresConfirmation => true;
  bool get rawAudioStored => false;
  String get source => 'sherpa_onnx_android_cpu';
}

abstract interface class StreamingAsrBackend {
  void accept(Float32List samples, int sampleRate);
  void decodeAvailable();
  void finishInput();
  String currentText();
  void close();
}

final class AsrSession {
  AsrSession({
    required StreamingAsrBackend backend,
    required this.sampleRate,
    required this.modelCandidateId,
    required this.runtimeVersion,
    required void Function() onClosed,
  }) : _backend = backend,
       _onClosed = onClosed;

  final StreamingAsrBackend _backend;
  final void Function() _onClosed;
  final int sampleRate;
  final String modelCandidateId;
  final String runtimeVersion;
  int _sampleCount = 0;
  bool _closed = false;

  void acceptPcm(Float32List samples, {required int sampleRate}) {
    _requireOpen();
    if (sampleRate != this.sampleRate) {
      throw AsrInputException(
        'ASR_SAMPLE_RATE_UNSUPPORTED',
        'Expected ${this.sampleRate} Hz audio.',
      );
    }
    if (samples.isEmpty) {
      throw const AsrInputException('ASR_INPUT_EMPTY', 'PCM chunk is empty.');
    }
    final int nextSampleCount = _sampleCount + samples.length;
    if (nextSampleCount > sampleRate * maxAsrSessionSeconds) {
      throw const AsrInputException(
        'ASR_DURATION_LIMIT',
        'ASR session exceeded its duration limit.',
      );
    }
    for (final double sample in samples) {
      if (!sample.isFinite || sample < -1 || sample > 1) {
        throw const AsrInputException(
          'ASR_PCM_INVALID',
          'PCM samples must be finite and normalized to [-1, 1].',
        );
      }
    }
    _backend.accept(samples, sampleRate);
    _backend.decodeAvailable();
    _sampleCount = nextSampleCount;
  }

  PendingAsrTranscript finish() {
    _requireOpen();
    if (_sampleCount == 0) {
      throw const AsrInputException(
        'ASR_INPUT_EMPTY',
        'Cannot finish an ASR session without audio.',
      );
    }
    try {
      _backend.finishInput();
      _backend.decodeAvailable();
      return PendingAsrTranscript(
        text: _backend.currentText().trim(),
        modelCandidateId: modelCandidateId,
        runtimeVersion: runtimeVersion,
      );
    } finally {
      _closeBackend();
    }
  }

  void cancel() {
    if (_closed) return;
    _closeBackend();
  }

  void _requireOpen() {
    if (_closed) throw StateError('ASR session is already closed.');
  }

  void _closeBackend() {
    if (_closed) return;
    _closed = true;
    _backend.close();
    _onClosed();
  }
}

final class SherpaAsrEngine {
  SherpaAsrEngine._({
    required sherpa.OnlineRecognizer recognizer,
    required this.candidate,
  }) : _recognizer = recognizer;

  final sherpa.OnlineRecognizer _recognizer;
  final AsrCandidate candidate;
  bool _sessionActive = false;
  bool _disposed = false;

  static Future<SherpaAsrEngine> initialize({
    AsrAssetGateway gateway = const AndroidAsrAssetGateway(),
  }) async {
    final AsrCandidate candidate = await loadAsrCandidate();
    if (candidate.runtimeVersion != '1.13.7') {
      throw StateError('Unreviewed sherpa_onnx runtime version.');
    }
    if (candidate.productEnabled) {
      throw StateError('Engineering ASR candidate cannot be product-enabled.');
    }
    final Map<String, String> paths = await gateway.provision(candidate);
    await sherpa.initBindingsAsync();
    final sherpa.OnlineRecognizer recognizer = sherpa.OnlineRecognizer(
      sherpa.OnlineRecognizerConfig(
        feat: sherpa.FeatureConfig(sampleRate: candidate.sampleRate),
        model: sherpa.OnlineModelConfig(
          transducer: sherpa.OnlineTransducerModelConfig(
            encoder: paths['encoder.int8.onnx']!,
            decoder: paths['decoder.onnx']!,
            joiner: paths['joiner.int8.onnx']!,
          ),
          tokens: paths['tokens.txt']!,
          bpeVocab: paths['bpe.model']!,
          numThreads: candidate.numThreads,
          provider: 'cpu',
          debug: false,
        ),
        decodingMethod: 'greedy_search',
        enableEndpoint: true,
      ),
    );
    return SherpaAsrEngine._(recognizer: recognizer, candidate: candidate);
  }

  AsrSession startSession() {
    if (_disposed) throw StateError('ASR engine is disposed.');
    if (_sessionActive) {
      throw StateError('Only one ASR session may run at a time.');
    }
    _sessionActive = true;
    return AsrSession(
      backend: SherpaStreamingAsrBackend(_recognizer),
      sampleRate: candidate.sampleRate,
      modelCandidateId: candidate.id,
      runtimeVersion: candidate.runtimeVersion,
      onClosed: () => _sessionActive = false,
    );
  }

  void dispose() {
    if (_sessionActive) {
      throw StateError(
        'Cancel or finish the active ASR session before disposal.',
      );
    }
    if (_disposed) return;
    _disposed = true;
    _recognizer.free();
  }
}

final class SherpaStreamingAsrBackend implements StreamingAsrBackend {
  SherpaStreamingAsrBackend(this._recognizer)
    : _stream = _recognizer.createStream();

  final sherpa.OnlineRecognizer _recognizer;
  final sherpa.OnlineStream _stream;
  bool _closed = false;

  @override
  void accept(Float32List samples, int sampleRate) {
    _requireOpen();
    _stream.acceptWaveform(samples: samples, sampleRate: sampleRate);
  }

  @override
  void decodeAvailable() {
    _requireOpen();
    int steps = 0;
    while (_recognizer.isReady(_stream) && steps < maxDecodeStepsPerCall) {
      _recognizer.decode(_stream);
      steps += 1;
    }
    if (_recognizer.isReady(_stream)) {
      throw StateError('ASR decode-step safety limit reached.');
    }
  }

  @override
  void finishInput() {
    _requireOpen();
    _stream.inputFinished();
  }

  @override
  String currentText() {
    _requireOpen();
    return _recognizer.getResult(_stream).text;
  }

  @override
  void close() {
    if (_closed) return;
    _closed = true;
    _stream.free();
  }

  void _requireOpen() {
    if (_closed) throw StateError('ASR backend is closed.');
  }
}
