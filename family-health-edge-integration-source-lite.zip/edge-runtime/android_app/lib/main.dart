import 'dart:async';

import 'package:flutter/material.dart';

import 'asr_microphone.dart';
import 'asr_runtime.dart';
import 'watch_bridge.dart';

void main() => runApp(const FamilyHealthEdgeApp());

class FamilyHealthEdgeApp extends StatelessWidget {
  const FamilyHealthEdgeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '家庭健康终端',
      theme: ThemeData(colorSchemeSeed: const Color(0xff087f73)),
      home: const WatchConnectionPage(),
    );
  }
}

class WatchConnectionPage extends StatefulWidget {
  const WatchConnectionPage({super.key});

  @override
  State<WatchConnectionPage> createState() => _WatchConnectionPageState();
}

class _WatchConnectionPageState extends State<WatchConnectionPage> {
  final BlePermissionGateway _permissions = const BlePermissionGateway();
  final WatchGateway _watch = YuchengWatchGateway();
  List<WatchDevice> _devices = const <WatchDevice>[];
  String _status = '尚未初始化';
  String _asrStatus = 'ASR 尚未在此设备初始化';
  String? _asrTranscript;
  bool _busy = false;
  bool _isRecording = false;
  String? _connectedDeviceId;
  SherpaAsrEngine? _asrEngine;
  AsrMicrophoneController? _asrMicrophone;

  Future<void> _run(
    Future<void> Function() operation, {
    required void Function(String message) recordFailure,
    required String failureMessage,
  }) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await operation();
    } catch (_) {
      if (mounted) setState(() => recordFailure(failureMessage));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _runWatch(Future<void> Function() operation) => _run(
    operation,
    recordFailure: (String message) => _status = message,
    failureMessage: '操作失败，请检查权限、蓝牙和设备状态',
  );

  Future<void> _runAsr(
    Future<void> Function() operation, {
    required String failureMessage,
  }) => _run(
    operation,
    recordFailure: (String message) {
      _asrStatus = message;
      _isRecording = false;
    },
    failureMessage: failureMessage,
  );

  Future<void> _initializeAndScan() => _runWatch(() async {
    final bool granted = await _permissions.request();
    if (!granted) {
      setState(() => _status = '未获得蓝牙权限');
      return;
    }
    await _watch.initialize();
    final List<WatchDevice> devices = await _watch.scan();
    setState(() {
      _devices = devices;
      _status = devices.isEmpty ? '未发现手表' : '发现 ${devices.length} 台设备';
    });
  });

  Future<void> _connect(WatchDevice device) => _runWatch(() async {
    final bool connected = await _watch.connect(device.id);
    setState(() {
      _connectedDeviceId = connected ? device.id : null;
      _status = connected ? '已连接 ${device.name}' : '连接失败';
    });
  });

  Future<void> _sync() => _runWatch(() async {
    if (_connectedDeviceId == null) {
      setState(() => _status = '请先连接手表');
      return;
    }
    final List<PendingWatchRecord> records = await _watch
        .syncPendingHealthData();
    setState(() => _status = '已读取 ${records.length} 条待确认数据，尚未写入健康档案');
  });

  Future<void> _initializeAsr() => _runAsr(() async {
    await _ensureAsrMicrophone();
    setState(() => _asrStatus = '离线 ASR 已初始化，可开始录音；结果不会自动写入档案');
  }, failureMessage: 'ASR 初始化失败；模型哈希、存储空间或原生运行库可能异常');

  Future<AsrMicrophoneController> _ensureAsrMicrophone() async {
    final AsrMicrophoneController? existing = _asrMicrophone;
    if (existing != null) return existing;
    final SherpaAsrEngine engine = await SherpaAsrEngine.initialize();
    final AsrMicrophoneController microphone = AsrMicrophoneController(
      startSession: engine.startSession,
      sampleRate: engine.candidate.sampleRate,
      onFailure: _handleAsrStreamFailure,
    );
    if (!mounted) {
      await microphone.dispose();
      engine.dispose();
      throw StateError('ASR page was disposed during initialization.');
    }
    _asrEngine = engine;
    _asrMicrophone = microphone;
    return microphone;
  }

  Future<void> _startAsrRecording() => _runAsr(() async {
    final AsrMicrophoneController microphone = await _ensureAsrMicrophone();
    await microphone.start();
    setState(() {
      _asrTranscript = null;
      _isRecording = true;
      _asrStatus = '正在本地识别，最长 120 秒；原始音频不落盘';
    });
  }, failureMessage: '无法开始录音；请检查麦克风权限、设备和 ASR 运行时');

  Future<void> _stopAsrRecording() => _runAsr(() async {
    final AsrMicrophoneController? microphone = _asrMicrophone;
    if (microphone == null || !microphone.isRecording) {
      setState(() {
        _isRecording = false;
        _asrStatus = '当前没有正在进行的录音';
      });
      return;
    }
    final PendingAsrTranscript result = await microphone.stop();
    setState(() {
      _isRecording = false;
      _asrTranscript = result.text;
      _asrStatus = result.text.isEmpty
          ? '未识别到有效语音；没有写入健康档案'
          : '识别结果待用户确认；没有写入健康档案';
    });
  }, failureMessage: '停止录音或离线识别失败；结果已丢弃且未写入档案');

  Future<void> _cancelAsrRecording() => _runAsr(() async {
    await _asrMicrophone?.cancel();
    setState(() {
      _isRecording = false;
      _asrTranscript = null;
      _asrStatus = '已取消录音；音频和识别结果均未保存';
    });
  }, failureMessage: '取消录音失败；请重新启动应用后再试');

  void _handleAsrStreamFailure(Object error) {
    if (!mounted) return;
    setState(() {
      _isRecording = false;
      _asrStatus = switch (error) {
        AsrInputException(code: 'ASR_DURATION_LIMIT') =>
          '录音已达到 120 秒上限，结果已丢弃',
        _ => '录音流异常，结果已丢弃且未写入档案',
      };
    });
  }

  @override
  void dispose() {
    final AsrMicrophoneController? microphone = _asrMicrophone;
    final SherpaAsrEngine? engine = _asrEngine;
    if (microphone == null) {
      engine?.dispose();
    } else {
      unawaited(
        microphone
            .dispose()
            .then<void>((_) => engine?.dispose())
            .catchError((Object _) {}),
      );
    }
    _watch.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('家庭健康终端')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: <Widget>[
            const Text(
              'Android 端侧迁移',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text('手表、健康规则与离线 ASR 已进入 Android；OCR 尚未迁移，全部产品门禁仍未通过。'),
            const SizedBox(height: 16),
            Text(_status),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _busy ? null : _initializeAndScan,
              child: const Text('授权并扫描手表'),
            ),
            for (final WatchDevice device in _devices)
              ListTile(
                title: Text(device.name),
                subtitle: Text('信号 ${device.rssi} dBm'),
                trailing: TextButton(
                  onPressed: _busy ? null : () => _connect(device),
                  child: Text(_connectedDeviceId == device.id ? '已连接' : '连接'),
                ),
              ),
            const SizedBox(height: 8),
            OutlinedButton(
              onPressed: _busy ? null : _sync,
              child: const Text('读取待确认健康数据'),
            ),
            const SizedBox(height: 20),
            Text(_asrStatus),
            const SizedBox(height: 8),
            OutlinedButton(
              onPressed: _busy || _isRecording ? null : _initializeAsr,
              child: const Text('初始化离线 ASR 工程运行时'),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: _busy
                  ? null
                  : (_isRecording ? _stopAsrRecording : _startAsrRecording),
              icon: Icon(_isRecording ? Icons.stop : Icons.mic),
              label: Text(_isRecording ? '停止并生成待确认文字' : '开始离线语音识别'),
            ),
            if (_isRecording)
              TextButton(
                onPressed: _busy ? null : _cancelAsrRecording,
                child: const Text('取消且不保留结果'),
              ),
            if (_asrTranscript case final String transcript)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: SelectableText(
                    transcript.isEmpty ? '（空结果）' : transcript,
                  ),
                ),
              ),
            const SizedBox(height: 20),
            const Text(
              '本结果仅用于家庭健康管理提示，不构成医疗诊断或治疗建议。手表数据需用户确认后才能进入健康档案。',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
