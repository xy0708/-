import 'dart:async';
import 'dart:typed_data';

import 'package:record/record.dart';

import 'asr_runtime.dart';

const Duration microphoneStopTimeout = Duration(seconds: 5);

abstract interface class PcmAudioSource {
  Future<Stream<Uint8List>> start({required int sampleRate});

  Future<void> stop();

  Future<void> cancel();

  Future<void> dispose();
}

final class RecordPcmAudioSource implements PcmAudioSource {
  RecordPcmAudioSource({AudioRecorder? recorder})
    : _recorder = recorder ?? AudioRecorder();

  final AudioRecorder _recorder;
  bool _disposed = false;

  @override
  Future<Stream<Uint8List>> start({required int sampleRate}) async {
    _requireOpen();
    if (!await _recorder.hasPermission()) {
      throw const AsrInputException(
        'ASR_MIC_PERMISSION_DENIED',
        'Microphone permission was not granted.',
      );
    }
    if (!await _recorder.isEncoderSupported(AudioEncoder.pcm16bits)) {
      throw const AsrInputException(
        'ASR_PCM_STREAM_UNSUPPORTED',
        'This Android device cannot provide a PCM16 microphone stream.',
      );
    }
    return _recorder.startStream(
      RecordConfig(
        encoder: AudioEncoder.pcm16bits,
        sampleRate: sampleRate,
        numChannels: 1,
        autoGain: false,
        echoCancel: false,
        noiseSuppress: false,
      ),
    );
  }

  @override
  Future<void> stop() async {
    _requireOpen();
    await _recorder.stop();
  }

  @override
  Future<void> cancel() async {
    if (_disposed) return;
    await _recorder.cancel();
  }

  @override
  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    await _recorder.dispose();
  }

  void _requireOpen() {
    if (_disposed) throw StateError('Microphone source is disposed.');
  }
}

final class Pcm16LittleEndianDecoder {
  int? _pendingLowByte;

  Float32List decode(Uint8List bytes) {
    if (bytes.isEmpty) return Float32List(0);
    final List<double> samples = <double>[];
    int index = 0;
    final int? pendingLowByte = _pendingLowByte;
    if (pendingLowByte != null) {
      samples.add(_normalize(pendingLowByte, bytes[0]));
      _pendingLowByte = null;
      index = 1;
    }
    while (index + 1 < bytes.length) {
      samples.add(_normalize(bytes[index], bytes[index + 1]));
      index += 2;
    }
    if (index < bytes.length) _pendingLowByte = bytes[index];
    return Float32List.fromList(samples);
  }

  void finish() {
    if (_pendingLowByte != null) {
      _pendingLowByte = null;
      throw const AsrInputException(
        'ASR_PCM_TRUNCATED',
        'PCM16 stream ended with an incomplete sample.',
      );
    }
  }

  static double _normalize(int lowByte, int highByte) {
    int value = lowByte | (highByte << 8);
    if (value >= 0x8000) value -= 0x10000;
    return value / 32768.0;
  }
}

enum _MicrophoneState { idle, starting, recording, stopping, disposed }

final class AsrMicrophoneController {
  AsrMicrophoneController({
    required AsrSession Function() startSession,
    required this.sampleRate,
    PcmAudioSource? audioSource,
    this.onFailure,
  }) : _startSession = startSession,
       _audioSource = audioSource ?? RecordPcmAudioSource();

  final AsrSession Function() _startSession;
  final PcmAudioSource _audioSource;
  final int sampleRate;
  final void Function(Object error)? onFailure;
  _MicrophoneState _state = _MicrophoneState.idle;
  AsrSession? _session;
  Future<void>? _pump;
  Object? _pumpFailure;
  StackTrace? _pumpFailureStack;
  Pcm16LittleEndianDecoder? _decoder;

  bool get isRecording => _state == _MicrophoneState.recording;

  Future<void> start() async {
    if (_state == _MicrophoneState.disposed) {
      throw StateError('ASR microphone controller is disposed.');
    }
    if (_state != _MicrophoneState.idle) {
      throw StateError('ASR microphone session is already active.');
    }
    _state = _MicrophoneState.starting;
    bool audioStarted = false;
    try {
      final Stream<Uint8List> audio = await _audioSource.start(
        sampleRate: sampleRate,
      );
      audioStarted = true;
      final AsrSession session = _startSession();
      _session = session;
      _decoder = Pcm16LittleEndianDecoder();
      _pumpFailure = null;
      _pumpFailureStack = null;
      _pump = _consume(audio, session).then<void>(
        (_) {},
        onError: (Object error, StackTrace stackTrace) {
          _pumpFailure = error;
          _pumpFailureStack = stackTrace;
          session.cancel();
          onFailure?.call(error);
          unawaited(_audioSource.cancel());
        },
      );
      _state = _MicrophoneState.recording;
    } catch (_) {
      _state = _MicrophoneState.idle;
      if (audioStarted) await _audioSource.cancel();
      rethrow;
    }
  }

  Future<PendingAsrTranscript> stop() async {
    if (_state != _MicrophoneState.recording) {
      throw StateError('No ASR microphone session is active.');
    }
    _state = _MicrophoneState.stopping;
    final AsrSession session = _session!;
    try {
      await _audioSource.stop();
      await _pump!.timeout(microphoneStopTimeout);
      final Object? failure = _pumpFailure;
      if (failure != null) {
        Error.throwWithStackTrace(failure, _pumpFailureStack ?? StackTrace.current);
      }
      return session.finish();
    } catch (_) {
      session.cancel();
      rethrow;
    } finally {
      _clearSession();
    }
  }

  Future<void> cancel() async {
    if (_state == _MicrophoneState.disposed ||
        _state == _MicrophoneState.idle) {
      return;
    }
    final AsrSession? session = _session;
    try {
      await _audioSource.cancel();
      await _pump?.timeout(microphoneStopTimeout);
    } finally {
      session?.cancel();
      _clearSession();
    }
  }

  Future<void> dispose() async {
    if (_state == _MicrophoneState.disposed) return;
    await cancel();
    _state = _MicrophoneState.disposed;
    await _audioSource.dispose();
  }

  Future<void> _consume(
    Stream<Uint8List> audio,
    AsrSession session,
  ) async {
    final Pcm16LittleEndianDecoder decoder = _decoder!;
    await for (final Uint8List bytes in audio) {
      final Float32List samples = decoder.decode(bytes);
      if (samples.isNotEmpty) {
        session.acceptPcm(samples, sampleRate: sampleRate);
      }
    }
    decoder.finish();
  }

  void _clearSession() {
    _session = null;
    _pump = null;
    _pumpFailure = null;
    _pumpFailureStack = null;
    _decoder = null;
    if (_state != _MicrophoneState.disposed) {
      _state = _MicrophoneState.idle;
    }
  }
}
