import 'package:flutter/services.dart';
import 'package:yc_product_plugin/yc_product_plugin.dart';

const int maxWatchSamplesPerSync = 2000;

final class WatchDevice {
  const WatchDevice({required this.id, required this.name, required this.rssi});

  final String id;
  final String name;
  final int rssi;
}

final class PendingWatchRecord {
  const PendingWatchRecord({
    required this.kind,
    required this.capturedAtSeconds,
    required this.values,
    required this.units,
  });

  final String kind;
  final int capturedAtSeconds;
  final Map<String, num> values;
  final Map<String, String> units;
  bool get requiresConfirmation => true;
  String get source => 'wearable_sdk';
}

abstract interface class WatchGateway {
  Future<void> initialize();
  Future<List<WatchDevice>> scan({int seconds = 6});
  Future<bool> connect(String deviceId);
  Future<List<PendingWatchRecord>> syncPendingHealthData();
  Future<void> close();
}

final class BlePermissionGateway {
  const BlePermissionGateway();

  static const MethodChannel _channel = MethodChannel(
    'com.familyhealth.edge/ble_permissions',
  );

  Future<bool> isGranted() async =>
      await _channel.invokeMethod<bool>('isGranted') ?? false;

  Future<bool> request() async =>
      await _channel.invokeMethod<bool>('request') ?? false;
}

final class YuchengWatchGateway implements WatchGateway {
  YuchengWatchGateway({YcProductPlugin? plugin})
    : _plugin = plugin ?? YcProductPlugin();

  final YcProductPlugin _plugin;
  final Map<String, BluetoothDevice> _devices = <String, BluetoothDevice>{};
  bool _initialized = false;

  @override
  Future<void> initialize() async {
    if (_initialized) return;
    await _plugin.initPlugin(isReconnectEnable: true, isLogEnable: false);
    _initialized = true;
  }

  @override
  Future<List<WatchDevice>> scan({int seconds = 6}) async {
    _requireInitialized();
    final int boundedSeconds = seconds.clamp(1, 30);
    final List<BluetoothDevice> discovered =
        await _plugin.scanDevice(time: boundedSeconds) ?? <BluetoothDevice>[];
    _devices
      ..clear()
      ..addEntries(
        discovered
            .where(_hasUsableIdentifier)
            .map(
              (BluetoothDevice device) =>
                  MapEntry(device.deviceIdentifier, device),
            ),
      );
    return _devices.values
        .map(
          (BluetoothDevice device) => WatchDevice(
            id: device.deviceIdentifier,
            name: device.name.trim().isEmpty ? '未命名手表' : device.name.trim(),
            rssi: device.rssiValue,
          ),
        )
        .toList(growable: false);
  }

  @override
  Future<bool> connect(String deviceId) async {
    _requireInitialized();
    final BluetoothDevice? device = _devices[deviceId];
    if (device == null) {
      throw ArgumentError.value(
        deviceId,
        'deviceId',
        'Device was not returned by the latest scan.',
      );
    }
    return await _plugin.connectDevice(device) ?? false;
  }

  @override
  Future<List<PendingWatchRecord>> syncPendingHealthData() async {
    _requireInitialized();
    final List<PendingWatchRecord> records = <PendingWatchRecord>[];
    for (final int type in <int>[
      HealthDataType.step,
      HealthDataType.sleep,
      HealthDataType.heartRate,
      HealthDataType.bloodPressure,
      HealthDataType.combinedData,
    ]) {
      final PluginResponse<List>? response = await _plugin
          .queryDeviceHealthData(type);
      if (response == null || response.statusCode != PluginState.succeed) {
        continue;
      }
      for (final dynamic sample in response.data) {
        final PendingWatchRecord? normalized = _normalize(sample);
        if (normalized != null) records.add(normalized);
        if (records.length >= maxWatchSamplesPerSync) {
          return List<PendingWatchRecord>.unmodifiable(records);
        }
      }
    }
    return List<PendingWatchRecord>.unmodifiable(records);
  }

  @override
  Future<void> close() async {
    _plugin.cancelListening();
    if (_initialized) await _plugin.disconnectDevice();
    _devices.clear();
    _initialized = false;
  }

  void _requireInitialized() {
    if (!_initialized) throw StateError('Watch gateway is not initialized.');
  }

  static bool _hasUsableIdentifier(BluetoothDevice device) =>
      device.deviceIdentifier.trim().isNotEmpty;

  static PendingWatchRecord? _normalize(dynamic sample) {
    if (sample is StepDataInfo) {
      return PendingWatchRecord(
        kind: 'steps',
        capturedAtSeconds: sample.endTimeStamp,
        values: <String, num>{
          'steps': sample.step,
          'distance': sample.distance,
          'calories': sample.calories,
        },
        units: const <String, String>{
          'steps': 'count',
          'distance': 'vendor_defined',
          'calories': 'vendor_defined',
        },
      );
    }
    if (sample is SleepDataInfo) {
      return PendingWatchRecord(
        kind: 'sleep',
        capturedAtSeconds: sample.endTimeStamp,
        values: <String, num>{
          'deep_sleep_seconds': sample.deepSleepSeconds,
          'light_sleep_seconds': sample.lightSleepSeconds,
          'rem_sleep_seconds': sample.remSleepSeconds,
        },
        units: const <String, String>{
          'deep_sleep_seconds': 's',
          'light_sleep_seconds': 's',
          'rem_sleep_seconds': 's',
        },
      );
    }
    if (sample is HeartRateDataInfo) {
      return PendingWatchRecord(
        kind: 'heart_rate',
        capturedAtSeconds: sample.startTimeStamp,
        values: <String, num>{'heart_rate': sample.heartRate},
        units: const <String, String>{'heart_rate': 'bpm'},
      );
    }
    if (sample is BloodPressureDataInfo) {
      return PendingWatchRecord(
        kind: 'blood_pressure',
        capturedAtSeconds: sample.startTimeStamp,
        values: <String, num>{
          'systolic': sample.systolicBloodPressure,
          'diastolic': sample.diastolicBloodPressure,
        },
        units: const <String, String>{'systolic': 'mmHg', 'diastolic': 'mmHg'},
      );
    }
    if (sample is CombinedDataDataInfo) {
      return PendingWatchRecord(
        kind: 'combined',
        capturedAtSeconds: sample.startTimeStamp,
        values: <String, num>{
          'blood_oxygen': sample.bloodOxygen,
          'respiration_rate': sample.respirationRate,
          'blood_glucose': sample.bloodGlucose,
          'temperature': sample.temperature,
          'hrv': sample.hrv,
        },
        units: const <String, String>{
          'blood_oxygen': '%',
          'respiration_rate': 'breaths/min',
          'blood_glucose': 'vendor_defined',
          'temperature': 'degC',
          'hrv': 'ms',
        },
      );
    }
    return null;
  }
}
