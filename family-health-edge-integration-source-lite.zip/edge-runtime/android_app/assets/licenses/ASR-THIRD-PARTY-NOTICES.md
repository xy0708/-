# Third-party notices

This product bundles offline ASR/TTS runtime artifacts. The corresponding license texts are retained in
`third_party/` and must remain in every binary or device distribution.

## X-ASR-zh-en model

- Upstream: <https://github.com/Gilgamesh-J/X-ASR>
- License: Apache License 2.0
- Local text: `third_party/X-ASR-LICENSE`
- Usage: V2/V3 offline streaming speech recognition model.

## sherpa-onnx runtime

- Upstream: <https://github.com/k2-fsa/sherpa-onnx>
- Version: 1.13.4
- License: Apache License 2.0
- Local text: `third_party/SHERPA-ONNX-LICENSE`

## MeloTTS Chinese-English model

- Converted model: <https://huggingface.co/csukuangfj/vits-melo-tts-zh_en>
- Upstream: <https://github.com/myshell-ai/MeloTTS>
- License: MIT
- Copyright: MyShell.ai, 2024
- Local text: `third_party/MELOTTS-LICENSE`
- Usage: offline V3 confirmation and medication-reminder speech output.

## Evaluation data exclusion

GigaSpeechBench MED-CH was used only for internal V2 evaluation. Its source audio is not included in the
V3 product distribution and was not used to train or fine-tune the product model. THCHS-30 and historical
FunASR training artifacts are also excluded.

## Distribution conditions

- Preserve these notices and all three local license texts.
- Preserve relevant copyright notices.
- Do not imply upstream authors provide warranties or medical endorsement.
- Re-run the license audit when changing model/runtime versions or adding data/model assets.
