package com.familyhealth.edge.terminal

import android.content.Context
import android.content.res.AssetManager
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

internal class ModelAssetChannel(private val context: Context) : AutoCloseable {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    fun attach(flutterEngine: FlutterEngine) {
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL,
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "provision" -> provision(call, result)
                else -> result.notImplemented()
            }
        }
    }

    private fun provision(call: MethodCall, result: MethodChannel.Result) {
        val request = try {
            ProvisionRequest.from(call.arguments)
        } catch (error: IllegalArgumentException) {
            result.error("MODEL_ASSET_REQUEST_INVALID", error.message, null)
            return
        }
        executor.execute {
            try {
                val paths = provisionFiles(request)
                postResult { result.success(paths) }
            } catch (error: Exception) {
                postResult {
                    result.error("MODEL_ASSET_PROVISION_FAILED", error.message, null)
                }
            }
        }
    }

    private fun provisionFiles(request: ProvisionRequest): Map<String, String> {
        val modelRoot = File(context.filesDir, "models/${request.modelId}")
        if (!modelRoot.exists() && !modelRoot.mkdirs()) {
            throw IllegalStateException("Cannot create private model directory.")
        }
        val canonicalRoot = modelRoot.canonicalFile
        return request.files.associate { specification ->
            val destination = File(canonicalRoot, specification.name).canonicalFile
            if (destination.parentFile != canonicalRoot) {
                throw IllegalArgumentException("Model destination escaped its private directory.")
            }
            if (!matches(destination, specification)) {
                copyVerifiedAsset(specification, destination)
            }
            specification.name to destination.absolutePath
        }
    }

    private fun copyVerifiedAsset(specification: AssetSpecification, destination: File) {
        val temporary = File.createTempFile(".${specification.name}.", ".tmp", destination.parentFile)
        try {
            context.assets.open(
                "flutter_assets/${specification.assetPath}",
                AssetManager.ACCESS_STREAMING,
            ).use { input ->
                FileOutputStream(temporary).use { output ->
                    input.copyTo(output, COPY_BUFFER_BYTES)
                    output.fd.sync()
                }
            }
            if (!matches(temporary, specification)) {
                throw IllegalStateException("Packaged model asset failed its size or SHA-256 check.")
            }
            try {
                Files.move(
                    temporary.toPath(),
                    destination.toPath(),
                    StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING,
                )
            } catch (_: AtomicMoveNotSupportedException) {
                Files.move(
                    temporary.toPath(),
                    destination.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                )
            }
        } finally {
            temporary.delete()
        }
    }

    private fun matches(file: File, specification: AssetSpecification): Boolean =
        file.isFile &&
            file.length() == specification.bytes &&
            sha256(file) == specification.sha256

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(COPY_BUFFER_BYTES)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { byte ->
            "%02x".format(byte.toInt() and 0xff)
        }
    }

    private fun postResult(action: () -> Unit) {
        android.os.Handler(context.mainLooper).post(action)
    }

    override fun close() {
        executor.shutdownNow()
    }

    private data class ProvisionRequest(
        val modelId: String,
        val files: List<AssetSpecification>,
    ) {
        companion object {
            fun from(arguments: Any?): ProvisionRequest {
                val map = arguments as? Map<*, *>
                    ?: throw IllegalArgumentException("Arguments must be a map.")
                val modelId = map["modelId"] as? String
                    ?: throw IllegalArgumentException("modelId is required.")
                require(SAFE_NAME.matches(modelId)) { "modelId contains unsafe characters." }
                val rawFiles = map["files"] as? List<*>
                    ?: throw IllegalArgumentException("files is required.")
                require(rawFiles.isNotEmpty() && rawFiles.size <= MAX_FILES) {
                    "files must contain 1 to $MAX_FILES entries."
                }
                return ProvisionRequest(
                    modelId = modelId,
                    files = rawFiles.map(AssetSpecification::from),
                )
            }
        }
    }

    private data class AssetSpecification(
        val assetPath: String,
        val name: String,
        val bytes: Long,
        val sha256: String,
    ) {
        companion object {
            fun from(value: Any?): AssetSpecification {
                val map = value as? Map<*, *>
                    ?: throw IllegalArgumentException("Each file must be a map.")
                val assetPath = map["assetPath"] as? String
                    ?: throw IllegalArgumentException("assetPath is required.")
                val name = map["name"] as? String
                    ?: throw IllegalArgumentException("name is required.")
                val bytes = (map["bytes"] as? Number)?.toLong()
                    ?: throw IllegalArgumentException("bytes is required.")
                val sha256 = (map["sha256"] as? String)?.lowercase()
                    ?: throw IllegalArgumentException("sha256 is required.")
                require(assetPath.startsWith("assets/asr/") && !assetPath.contains("..")) {
                    "assetPath is outside the ASR asset namespace."
                }
                require(SAFE_NAME.matches(name)) { "Model filename contains unsafe characters." }
                require(bytes in 1..MAX_FILE_BYTES) { "Model file size is outside the limit." }
                require(SHA256.matches(sha256)) { "sha256 must contain 64 hexadecimal characters." }
                return AssetSpecification(assetPath, name, bytes, sha256)
            }
        }
    }

    private companion object {
        const val CHANNEL = "com.familyhealth.edge/model_assets"
        const val COPY_BUFFER_BYTES = 1024 * 1024
        const val MAX_FILES = 16
        const val MAX_FILE_BYTES = 512L * 1024L * 1024L
        val SAFE_NAME = Regex("[A-Za-z0-9._-]+")
        val SHA256 = Regex("[0-9a-f]{64}")
    }
}
