package com.familyhealth.edge.terminal

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val permissionChannel = "com.familyhealth.edge/ble_permissions"
    private val requestCode = 4107
    private var pendingPermissionResult: MethodChannel.Result? = null
    private lateinit var modelAssetChannel: ModelAssetChannel

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        modelAssetChannel = ModelAssetChannel(applicationContext)
        modelAssetChannel.attach(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, permissionChannel)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isGranted" -> result.success(hasBlePermissions())
                    "request" -> requestBlePermissions(result)
                    else -> result.notImplemented()
                }
            }
    }

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    private fun hasBlePermissions(): Boolean = requiredPermissions().all {
        ActivityCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestBlePermissions(result: MethodChannel.Result) {
        if (hasBlePermissions()) {
            result.success(true)
            return
        }
        if (pendingPermissionResult != null) {
            result.error("PERMISSION_REQUEST_BUSY", "A BLE permission request is already active.", null)
            return
        }
        pendingPermissionResult = result
        ActivityCompat.requestPermissions(this, requiredPermissions(), requestCode)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != this.requestCode) return
        pendingPermissionResult?.success(hasBlePermissions())
        pendingPermissionResult = null
    }

    override fun onDestroy() {
        if (::modelAssetChannel.isInitialized) modelAssetChannel.close()
        super.onDestroy()
    }
}
