import 'dart:typed_data';

import 'package:family_health_edge_android/asr_runtime.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test(
    'accepted audio produces a pending transcript without storing audio',
    () {
      final FakeStreamingBackend backend = FakeStreamingBackend('  血压一百二十  ');
      bool released = false;
      final AsrSession session = AsrSession(
        backend: backend,
        sampleRate: 16000,
        modelCandidateId: 'candidate',
        runtimeVersion: '1.13.7',
        onClosed: () => released = true,
      );
      session.acceptPcm(
        Float32List.fromList(<double>[0, 0.25, -0.25]),
        sampleRate: 16000,
      );
      final PendingAsrTranscript result = session.finish();
      expect(result.text, '血压一百二十');
      expect(result.requiresConfirmation, isTrue);
      expect(result.rawAudioStored, isFalse);
      expect(backend.closed, isTrue);
      expect(released, isTrue);
    },
  );

  test('invalid PCM and sample rates fail before reaching the backend', () {
    final FakeStreamingBackend backend = FakeStreamingBackend('');
    final AsrSession session = AsrSession(
      backend: backend,
      sampleRate: 16000,
      modelCandidateId: 'candidate',
      runtimeVersion: '1.13.7',
      onClosed: () {},
    );
    expect(
      () => session.acceptPcm(Float32List(1), sampleRate: 8000),
      throwsA(isA<AsrInputException>()),
    );
    expect(
      () => session.acceptPcm(
        Float32List.fromList(<double>[double.nan]),
        sampleRate: 16000,
      ),
      throwsA(isA<AsrInputException>()),
    );
    expect(backend.acceptedSamples, 0);
    session.cancel();
  });

  test('empty finish fails and cancel is idempotent', () {
    final FakeStreamingBackend backend = FakeStreamingBackend('');
    final AsrSession session = AsrSession(
      backend: backend,
      sampleRate: 16000,
      modelCandidateId: 'candidate',
      runtimeVersion: '1.13.7',
      onClosed: () {},
    );
    expect(session.finish, throwsA(isA<AsrInputException>()));
    session.cancel();
    session.cancel();
    expect(backend.closeCalls, 1);
  });
}

final class FakeStreamingBackend implements StreamingAsrBackend {
  FakeStreamingBackend(this.text);

  final String text;
  int acceptedSamples = 0;
  int closeCalls = 0;
  bool closed = false;

  @override
  void accept(Float32List samples, int sampleRate) {
    acceptedSamples += samples.length;
  }

  @override
  void decodeAvailable() {}

  @override
  void finishInput() {}

  @override
  String currentText() => text;

  @override
  void close() {
    closeCalls += 1;
    closed = true;
  }
}
