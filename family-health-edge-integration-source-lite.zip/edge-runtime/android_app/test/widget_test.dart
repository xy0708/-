import 'package:flutter_test/flutter_test.dart';
import 'package:family_health_edge_android/main.dart';

void main() {
  testWidgets('shows Android migration and safety boundary', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const FamilyHealthEdgeApp());

    expect(find.text('Android 端侧迁移'), findsOneWidget);
    expect(find.text('授权并扫描手表'), findsOneWidget);
    expect(find.text('初始化离线 ASR 工程运行时'), findsOneWidget);
    expect(find.textContaining('OCR 尚未迁移'), findsOneWidget);
    expect(find.textContaining('不构成医疗诊断或治疗建议'), findsOneWidget);
  });
}
