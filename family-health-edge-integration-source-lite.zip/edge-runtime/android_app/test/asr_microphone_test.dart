import 'dart:async';
import 'dart:typed_data';

import 'package:family_health_edge_android/asr_microphone.dart';
import 'package:family_health_edge_android/asr_runtime.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('PCM16 decoder preserves samples split across chunks', () {
    final Pcm16LittleEndianDecoder decoder = Pcm16LittleEndianDecoder();
    expect(decoder.decode(Uint8List.fromList(<int>[0x00])), isEmpty);
    final Float32List samples = decoder.decode(
      Uint8List.fromList(<int>[0x80, 0xff, 0x7f]),
    );
    expect(samples[0], -1);
    expect(samples[1], closeTo(32767 / 32768, 0.000001));
    decoder.finish();
  });

  test('microphone stream produces a pending non-persistent transcript', () async {
    final FakePcmAudioSource source = FakePcmAudioSource();
    final FakeStreamingBackend backend = FakeStreamingBackend('  心率七十二  ');
    final AsrMicrophoneController controller = AsrMicrophoneController(
      startSession: () => createSession(backend),
      sampleRate: 16000,
      audioSource: source,
    );

    await controller.start();
    source.add(Uint8List.fromList(<int>[0x00, 0x00, 0xff, 0x7f]));
    final PendingAsrTranscript result = await controller.stop();

    expect(result.text, '心率七十二');
    expect(result.requiresConfirmation, isTrue);
    expect(result.rawAudioStored, isFalse);
    expect(backend.acceptedSamples, 2);
    expect(source.stopCalls, 1);
    expect(controller.isRecording, isFalse);
    await controller.dispose();
  });

  test('truncated PCM fails closed and releases the ASR session', () async {
    final FakePcmAudioSource source = FakePcmAudioSource();
    final FakeStreamingBackend backend = FakeStreamingBackend('');
    final AsrMicrophoneController controller = AsrMicrophoneController(
      startSession: () => createSession(backend),
      sampleRate: 16000,
      audioSource: source,
    );

    await controller.start();
    source.add(Uint8List.fromList(<int>[0x01]));
    await expectLater(controller.stop(), throwsA(isA<AsrInputException>()));

    expect(backend.closeCalls, 1);
    expect(controller.isRecording, isFalse);
    await controller.dispose();
  });

  test('audio-source failure does not create an ASR session', () async {
    final FakePcmAudioSource source = FakePcmAudioSource(
      startError: const AsrInputException(
        'ASR_MIC_PERMISSION_DENIED',
        'permission denied',
      ),
    );
    bool sessionCreated = false;
    final AsrMicrophoneController controller = AsrMicrophoneController(
      startSession: () {
        sessionCreated = true;
        return createSession(FakeStreamingBackend(''));
      },
      sampleRate: 16000,
      audioSource: source,
    );

    await expectLater(controller.start(), throwsA(isA<AsrInputException>()));

    expect(sessionCreated, isFalse);
    expect(source.cancelCalls, 0);
    await controller.dispose();
  });
}

AsrSession createSession(FakeStreamingBackend backend) => AsrSession(
  backend: backend,
  sampleRate: 16000,
  modelCandidateId: 'candidate',
  runtimeVersion: '1.13.7',
  onClosed: () {},
);

final class FakePcmAudioSource implements PcmAudioSource {
  FakePcmAudioSource({this.startError});

  final Object? startError;
  final StreamController<Uint8List> _controller =
      StreamController<Uint8List>.broadcast();
  int stopCalls = 0;
  int cancelCalls = 0;
  bool _closed = false;

  void add(Uint8List bytes) => _controller.add(bytes);

  @override
  Future<Stream<Uint8List>> start({required int sampleRate}) async {
    final Object? error = startError;
    if (error != null) throw error;
    return _controller.stream;
  }

  @override
  Future<void> stop() async {
    stopCalls += 1;
    await _close();
  }

  @override
  Future<void> cancel() async {
    cancelCalls += 1;
    await _close();
  }

  @override
  Future<void> dispose() => _close();

  Future<void> _close() async {
    if (_closed) return;
    _closed = true;
    await _controller.close();
  }
}

final class FakeStreamingBackend implements StreamingAsrBackend {
  FakeStreamingBackend(this.text);

  final String text;
  int acceptedSamples = 0;
  int closeCalls = 0;

  @override
  void accept(Float32List samples, int sampleRate) {
    acceptedSamples += samples.length;
  }

  @override
  void decodeAvailable() {}

  @override
  void finishInput() {}

  @override
  String currentText() => text;

  @override
  void close() {
    closeCalls += 1;
  }
}
