import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:family_health_edge_android/health_rules.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late HealthRuleConfig config;
  late HealthRuleEngine engine;
  final DateTime now = DateTime.utc(2026, 8, 25);

  setUpAll(() async {
    config = await loadHealthRuleConfig();
    engine = HealthRuleEngine(config);
  });

  HealthMeasurement measurement({
    double value = 6.1,
    String unit = 'mmol/L',
    bool confirmed = true,
    double? referenceLow = 3.9,
    double? referenceHigh = 6.0,
    DateTime? measuredAt,
    List<HealthHistoryPoint> history = const <HealthHistoryPoint>[],
  }) => HealthMeasurement(
    metric: 'fasting_glucose',
    value: value,
    unit: unit,
    measuredAt: measuredAt ?? DateTime.parse('2026-08-24T08:00:00+08:00'),
    confirmed: confirmed,
    referenceLow: referenceLow,
    referenceHigh: referenceHigh,
    referenceSource: 'fixture_reference_only',
    history: history,
  );

  Map<String, Object?> evaluate(HealthMeasurement item) => engine.evaluate(
    measurements: <HealthMeasurement>[item],
    confirmed: true,
    now: now,
  );

  test('reference attention never becomes diagnosis or probability', () {
    final Map<String, Object?> result = evaluate(measurement());
    expect(result['attention_level'], 'ATTENTION');
    expect(result['diagnosis'], isNull);
    expect(result['disease_probability'], isNull);
    expect(result['product_release_allowed'], isFalse);
  });

  test('missing reference does not claim normal health', () {
    final Map<String, Object?> result = evaluate(
      measurement(value: 5, referenceLow: null, referenceHigh: null),
    );
    final Map<String, Object?> item =
        (result['measurements'] as List<Map<String, Object?>>).single;
    expect(result['attention_level'], 'NO_RULE_TRIGGERED');
    expect(item['warnings'], contains('REFERENCE_RANGE_MISSING'));
    expect(item['no_rule_triggered_is_not_proof_of_health'], isTrue);
  });

  test('converts glucose and its supplied reference interval', () {
    final Map<String, Object?> result = evaluate(
      measurement(
        value: 108,
        unit: 'mg/dL',
        referenceLow: 70,
        referenceHigh: 100,
      ),
    );
    final Map<String, Object?> item =
        (result['measurements'] as List<Map<String, Object?>>).single;
    expect(item['value'] as double, closeTo(5.994, 0.000001));
    expect(item['reference_high'] as double, closeTo(5.55, 0.000001));
  });

  test('rejects unconfirmed, future, nonfinite and unsupported input', () {
    final List<HealthMeasurement> invalid = <HealthMeasurement>[
      measurement(confirmed: false),
      measurement(measuredAt: now.add(const Duration(days: 1))),
      measurement(value: double.nan),
      measurement(unit: 'unknown'),
    ];
    for (final HealthMeasurement item in invalid) {
      expect(() => evaluate(item), throwsA(isA<HealthRuleInputException>()));
    }
  });

  test('rejects conflicting reference interval', () {
    expect(
      () => evaluate(measurement(referenceLow: 7, referenceHigh: 6)),
      throwsA(
        isA<HealthRuleInputException>().having(
          (HealthRuleInputException error) => error.code,
          'code',
          'INPUT_INVALID',
        ),
      ),
    );
  });

  test('trend triggers only when a threshold is explicitly configured', () {
    final Map<String, dynamic> json =
        jsonDecode(
              '''{"rule_version":"v","approval_status":"PENDING","metrics":{"weight":{"canonical_unit":"kg","conversions":{},"max_age_days":30,"trend":{"minimum_history":3,"relative_change_threshold":0.1}}}}''',
            )
            as Map<String, dynamic>;
    final HealthRuleEngine trendEngine = HealthRuleEngine(
      HealthRuleConfig.fromJson(json),
    );
    final Map<String, Object?> result = trendEngine.evaluate(
      measurements: <HealthMeasurement>[
        HealthMeasurement(
          metric: 'weight',
          value: 80,
          unit: 'kg',
          measuredAt: DateTime.utc(2026, 8, 24),
          confirmed: true,
          history: const <HealthHistoryPoint>[
            HealthHistoryPoint(value: 70, unit: 'kg', confirmed: true),
            HealthHistoryPoint(value: 70, unit: 'kg', confirmed: true),
            HealthHistoryPoint(value: 70, unit: 'kg', confirmed: true),
          ],
        ),
      ],
      confirmed: true,
      now: now,
    );
    expect(result['attention_level'], 'OBSERVE');
  });

  test('product release remains blocked pending named approval', () {
    expect(config.approvalStatus, 'PENDING_NAMED_PRODUCT_AND_DOMAIN_REVIEW');
    expect(config.productReleaseAllowed, isFalse);
  });
}
