from __future__ import annotations

import copy
import json
import math
import os
import sqlite3
import tempfile
import threading
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Protocol


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat()


class StoragePolicyError(RuntimeError):
    pass


class TaskStateError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def _is_redirecting_path(path: Path) -> bool:
    if path.is_symlink():
        return True
    if os.name == "nt":
        try:
            return bool(os.lstat(path).st_file_attributes & 0x400)
        except (FileNotFoundError, AttributeError, OSError):
            return False
    return False


def _resolve_backup_destination(destination: Path, allowed_root: Path) -> tuple[Path, Path]:
    root_input = Path(os.path.abspath(allowed_root))
    if _is_redirecting_path(root_input) or not root_input.is_dir():
        raise StoragePolicyError("allowed_root must be an existing non-redirected directory")
    root = root_input.resolve(strict=True)
    absolute = Path(os.path.abspath(destination))
    if absolute == root_input or root_input not in absolute.parents:
        raise StoragePolicyError("backup destination must stay inside allowed_root")
    current = root_input
    for part in absolute.relative_to(root_input).parts:
        current = current / part
        if _is_redirecting_path(current):
            raise StoragePolicyError("backup destination refuses redirected paths")
    resolved = absolute.resolve(strict=False)
    if resolved == root or root not in resolved.parents:
        raise StoragePolicyError("backup destination must stay inside allowed_root")
    return resolved, root_input


def _validate_json_payload(
    payload: dict[str, Any],
    *,
    maximum_bytes: int,
    maximum_depth: int = 6,
    maximum_nodes: int = 512,
) -> dict[str, Any]:
    """Bound and detach untrusted component/user JSON before memory or SQLite."""
    if not isinstance(payload, dict):
        raise TaskStateError("INPUT_INVALID", "payload must be a JSON object")
    remaining_nodes = maximum_nodes

    def visit(value: Any, depth: int) -> None:
        nonlocal remaining_nodes
        remaining_nodes -= 1
        if remaining_nodes < 0 or depth > maximum_depth:
            raise TaskStateError("INPUT_INVALID", "payload is too complex")
        if value is None or isinstance(value, (bool, int)):
            return
        if isinstance(value, float):
            if not math.isfinite(value):
                raise TaskStateError("INPUT_INVALID", "payload contains a non-finite number")
            return
        if isinstance(value, str):
            if len(value) > 16384:
                raise TaskStateError("INPUT_INVALID", "payload string is too long")
            return
        if isinstance(value, list):
            for item in value:
                visit(item, depth + 1)
            return
        if isinstance(value, dict):
            for key, item in value.items():
                if not isinstance(key, str) or not key or len(key) > 128:
                    raise TaskStateError("INPUT_INVALID", "payload key is invalid")
                visit(item, depth + 1)
            return
        raise TaskStateError("INPUT_INVALID", "payload contains an unsupported value")

    visit(payload, 0)
    try:
        encoded = json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise TaskStateError("INPUT_INVALID", "payload is not valid JSON") from exc
    if len(encoded) > maximum_bytes:
        raise TaskStateError("INPUT_INVALID", "payload exceeds the size limit")
    detached = json.loads(encoded.decode("utf-8"))
    if not isinstance(detached, dict):
        raise TaskStateError("INPUT_INVALID", "payload must be a JSON object")
    return detached


class PayloadCodec(Protocol):
    secure_for_product: bool
    name: str

    def encode(self, payload: dict[str, Any]) -> bytes: ...

    def decode(self, payload: bytes) -> dict[str, Any]: ...


class PlaintextEngineeringCodec:
    secure_for_product = False
    name = "PLAINTEXT_ENGINEERING_TEST_ONLY"

    def encode(self, payload: dict[str, Any]) -> bytes:
        return json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

    def decode(self, payload: bytes) -> dict[str, Any]:
        value = json.loads(payload.decode("utf-8"))
        if not isinstance(value, dict):
            raise StoragePolicyError("stored payload is not a JSON object")
        return value


class RecordStore:
    def __init__(
        self,
        path: Path,
        codec: PayloadCodec,
        *,
        allow_unencrypted_engineering: bool = False,
        pending_sweep_interval_seconds: float = 0.25,
    ) -> None:
        if not codec.secure_for_product and not allow_unencrypted_engineering:
            raise StoragePolicyError(
                "product storage requires an approved encryption-at-rest codec; "
                "plaintext is allowed only in explicit engineering tests"
            )
        if (
            not isinstance(pending_sweep_interval_seconds, (int, float))
            or isinstance(pending_sweep_interval_seconds, bool)
            or not math.isfinite(float(pending_sweep_interval_seconds))
            or not 0.01 <= float(pending_sweep_interval_seconds) <= 60
        ):
            raise StoragePolicyError("pending sweep interval must be within 0.01-60 seconds")
        self.path = path
        self.codec = codec
        self.engineering_only = not codec.secure_for_product
        self._lock = threading.RLock()
        # Unconfirmed OCR/ASR output is sensitive and must never be persisted.
        # A restart intentionally invalidates pending results.
        self._pending_results: dict[str, dict[str, Any]] = {}
        self._pending_expirations: dict[str, datetime] = {}
        self._pending_sweep_interval_seconds = float(pending_sweep_interval_seconds)
        self._pending_sweeper_stop = threading.Event()
        path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA foreign_keys=ON")
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA synchronous=FULL")
        self._migrate()
        if os.name != "nt":
            path.chmod(0o600)
        self._pending_sweeper = threading.Thread(
            target=self._sweep_pending_results,
            name="record-store-pending-sweeper",
            daemon=True,
        )
        self._pending_sweeper.start()

    def _sweep_pending_results(self) -> None:
        while not self._pending_sweeper_stop.wait(self._pending_sweep_interval_seconds):
            current = utc_now()
            with self._lock:
                expired = [
                    task_id
                    for task_id, expires_at in self._pending_expirations.items()
                    if expires_at <= current
                ]
                for task_id in expired:
                    self._pending_results.pop(task_id, None)
                    self._pending_expirations.pop(task_id, None)

    def _migrate(self) -> None:
        with self._lock:
            self._connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS tasks (
                    task_id TEXT PRIMARY KEY,
                    member_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN ('pending_confirmation','confirmed','cancelled','expired')),
                    result_blob BLOB NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    confirmed_record_id TEXT
                );
                CREATE TABLE IF NOT EXISTS records (
                    record_id TEXT PRIMARY KEY,
                    member_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    payload_blob BLOB NOT NULL,
                    source_task_id TEXT NOT NULL UNIQUE,
                    idempotency_key TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT,
                    version INTEGER NOT NULL DEFAULT 1,
                    UNIQUE(member_id,idempotency_key)
                );
                CREATE INDEX IF NOT EXISTS idx_records_member_created
                    ON records(member_id, created_at);
                CREATE TABLE IF NOT EXISTS schema_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                INSERT OR REPLACE INTO schema_meta(key, value) VALUES ('schema_version', '1');
                """
            )
            columns = {
                row["name"]
                for row in self._connection.execute("PRAGMA table_info(records)").fetchall()
            }
            if "updated_at" not in columns:
                self._connection.execute("ALTER TABLE records ADD COLUMN updated_at TEXT")
            if "version" not in columns:
                self._connection.execute(
                    "ALTER TABLE records ADD COLUMN version INTEGER NOT NULL DEFAULT 1"
                )
            unique_indexes = set()
            for index in self._connection.execute("PRAGMA index_list(records)").fetchall():
                if index["unique"]:
                    unique_indexes.add(
                        tuple(
                            row["name"]
                            for row in self._connection.execute(
                                "SELECT name FROM pragma_index_info(?) ORDER BY seqno",
                                (index["name"],),
                            ).fetchall()
                        )
                    )
            if ("idempotency_key",) in unique_indexes:
                self._connection.execute("BEGIN IMMEDIATE")
                try:
                    self._connection.execute(
                        """
                        CREATE TABLE records_v3_migration (
                            record_id TEXT PRIMARY KEY,
                            member_id TEXT NOT NULL,
                            kind TEXT NOT NULL,
                            payload_blob BLOB NOT NULL,
                            source_task_id TEXT NOT NULL UNIQUE,
                            idempotency_key TEXT NOT NULL,
                            created_at TEXT NOT NULL,
                            updated_at TEXT,
                            version INTEGER NOT NULL DEFAULT 1,
                            UNIQUE(member_id,idempotency_key)
                        )
                        """
                    )
                    self._connection.execute(
                        "INSERT INTO records_v3_migration "
                        "SELECT record_id,member_id,kind,payload_blob,source_task_id,"
                        "idempotency_key,created_at,updated_at,version FROM records"
                    )
                    self._connection.execute("DROP TABLE records")
                    self._connection.execute(
                        "ALTER TABLE records_v3_migration RENAME TO records"
                    )
                    self._connection.execute(
                        "CREATE INDEX idx_records_member_created "
                        "ON records(member_id,created_at)"
                    )
                    self._connection.execute("COMMIT")
                except Exception:
                    if self._connection.in_transaction:
                        self._connection.execute("ROLLBACK")
                    raise
            self._connection.execute(
                "INSERT OR REPLACE INTO schema_meta(key, value) VALUES ('schema_version', '3')"
            )

    def close(self) -> None:
        self._pending_sweeper_stop.set()
        if threading.current_thread() is not self._pending_sweeper:
            self._pending_sweeper.join(timeout=2)
        with self._lock:
            self._pending_results.clear()
            self._pending_expirations.clear()
            self._connection.close()

    def schema_version(self) -> str:
        with self._lock:
            row = self._connection.execute(
                "SELECT value FROM schema_meta WHERE key='schema_version'"
            ).fetchone()
        if row is None:
            raise StoragePolicyError("database schema version is missing")
        return str(row[0])

    def create_task(
        self,
        member_id: str,
        kind: str,
        result: dict[str, Any],
        *,
        ttl_seconds: int = 900,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        if not member_id or kind not in {"ocr", "asr"}:
            raise TaskStateError("INPUT_INVALID", "member_id 或任务类型无效")
        if ttl_seconds <= 0 or ttl_seconds > 3600:
            raise TaskStateError("INPUT_INVALID", "任务有效期必须在 1-3600 秒")
        result = _validate_json_payload(result, maximum_bytes=256 * 1024)
        current = now or utc_now()
        task_id = uuid.uuid4().hex
        empty_result_blob = self.codec.encode({})
        with self._lock:
            self._connection.execute(
                "INSERT INTO tasks(task_id,member_id,kind,status,result_blob,created_at,expires_at) "
                "VALUES(?,?,?,?,?,?,?)",
                (
                    task_id,
                    member_id,
                    kind,
                    "pending_confirmation",
                    empty_result_blob,
                    iso_utc(current),
                    iso_utc(current + timedelta(seconds=ttl_seconds)),
                ),
            )
            self._pending_results[task_id] = result
            self._pending_expirations[task_id] = current + timedelta(seconds=ttl_seconds)
        return {
            "task_id": task_id,
            "member_id": member_id,
            "kind": kind,
            "status": "pending_confirmation",
            "requires_confirmation": True,
            "expires_at": iso_utc(current + timedelta(seconds=ttl_seconds)),
        }

    def get_task(self, task_id: str, member_id: str) -> dict[str, Any]:
        with self._lock:
            row = self._connection.execute(
                "SELECT * FROM tasks WHERE task_id=? AND member_id=?", (task_id, member_id)
            ).fetchone()
            if row is None:
                raise TaskStateError("TASK_NOT_FOUND", "任务不存在")
            if (
                row["status"] == "pending_confirmation"
                and datetime.fromisoformat(row["expires_at"]) <= utc_now()
            ):
                self._connection.execute(
                    "UPDATE tasks SET status='expired' WHERE task_id=?", (task_id,)
                )
                self._pending_results.pop(task_id, None)
                self._pending_expirations.pop(task_id, None)
                raise TaskStateError("TASK_EXPIRED", "任务已过期")
            if row["status"] == "pending_confirmation" and task_id not in self._pending_results:
                self._connection.execute(
                    "UPDATE tasks SET status='expired' WHERE task_id=?", (task_id,)
                )
                self._pending_expirations.pop(task_id, None)
                raise TaskStateError("TASK_EXPIRED", "pending result was cleared by restart")
            result = copy.deepcopy(self._pending_results.get(task_id))
        return {
            "task_id": row["task_id"],
            "member_id": row["member_id"],
            "kind": row["kind"],
            "status": row["status"],
            "result": result,
            "created_at": row["created_at"],
            "expires_at": row["expires_at"],
            "requires_confirmation": row["status"] == "pending_confirmation",
        }

    def cancel_task(self, task_id: str, member_id: str) -> bool:
        with self._lock:
            cursor = self._connection.execute(
                "UPDATE tasks SET status='cancelled' "
                "WHERE task_id=? AND member_id=? AND status='pending_confirmation'",
                (task_id, member_id),
            )
            if cursor.rowcount == 1:
                self._pending_results.pop(task_id, None)
                self._pending_expirations.pop(task_id, None)
        return cursor.rowcount == 1

    def confirm_task(
        self,
        task_id: str,
        member_id: str,
        idempotency_key: str,
        confirmed_payload: dict[str, Any],
        *,
        now: datetime | None = None,
    ) -> tuple[dict[str, Any], bool]:
        if not idempotency_key or len(idempotency_key) > 128:
            raise TaskStateError("INPUT_INVALID", "idempotency_key 无效")
        confirmed_payload = _validate_json_payload(
            confirmed_payload, maximum_bytes=128 * 1024
        )
        current = now or utc_now()
        with self._lock:
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                existing = self._connection.execute(
                    "SELECT * FROM records WHERE member_id=? AND idempotency_key=?",
                    (member_id, idempotency_key),
                ).fetchone()
                if existing is not None:
                    if existing["source_task_id"] != task_id:
                        raise TaskStateError("STORAGE_CONFLICT", "幂等键已用于其他任务")
                    self._connection.execute("COMMIT")
                    return self._record_from_row(existing), True

                task = self._connection.execute(
                    "SELECT * FROM tasks WHERE task_id=? AND member_id=?", (task_id, member_id)
                ).fetchone()
                if task is None:
                    raise TaskStateError("TASK_NOT_FOUND", "任务不存在")
                if task["status"] != "pending_confirmation":
                    raise TaskStateError("TASK_ALREADY_CONFIRMED", "任务已确认或不可确认")
                if task_id not in self._pending_results:
                    self._connection.execute(
                        "UPDATE tasks SET status='expired' WHERE task_id=?", (task_id,)
                    )
                    self._connection.execute("COMMIT")
                    self._pending_expirations.pop(task_id, None)
                    raise TaskStateError("TASK_EXPIRED", "pending result was cleared by restart")
                if datetime.fromisoformat(task["expires_at"]) <= current:
                    self._connection.execute(
                        "UPDATE tasks SET status='expired' WHERE task_id=?", (task_id,)
                    )
                    self._connection.execute("COMMIT")
                    self._pending_results.pop(task_id, None)
                    self._pending_expirations.pop(task_id, None)
                    raise TaskStateError("TASK_EXPIRED", "任务已过期")

                record_id = uuid.uuid4().hex
                self._connection.execute(
                    "INSERT INTO records(record_id,member_id,kind,payload_blob,source_task_id,idempotency_key,created_at) "
                    "VALUES(?,?,?,?,?,?,?)",
                    (
                        record_id,
                        member_id,
                        task["kind"],
                        self.codec.encode(confirmed_payload),
                        task_id,
                        idempotency_key,
                        iso_utc(current),
                    ),
                )
                self._connection.execute(
                    "UPDATE tasks SET status='confirmed',confirmed_record_id=? WHERE task_id=?",
                    (record_id, task_id),
                )
                row = self._connection.execute(
                    "SELECT * FROM records WHERE record_id=?", (record_id,)
                ).fetchone()
                self._connection.execute("COMMIT")
                self._pending_results.pop(task_id, None)
                self._pending_expirations.pop(task_id, None)
                return self._record_from_row(row), False
            except Exception:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise

    def _record_from_row(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "record_id": row["record_id"],
            "member_id": row["member_id"],
            "kind": row["kind"],
            "payload": self.codec.decode(row["payload_blob"]),
            "source_task_id": row["source_task_id"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "version": row["version"],
        }

    def correct_record(
        self,
        member_id: str,
        record_id: str,
        corrected_payload: dict[str, Any],
        expected_version: int,
        *,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        if expected_version < 1:
            raise TaskStateError("INPUT_INVALID", "expected_version must be positive")
        corrected_payload = _validate_json_payload(
            corrected_payload, maximum_bytes=128 * 1024
        )
        with self._lock:
            cursor = self._connection.execute(
                "UPDATE records SET payload_blob=?,updated_at=?,version=version+1 "
                "WHERE member_id=? AND record_id=? AND version=?",
                (
                    self.codec.encode(corrected_payload),
                    iso_utc(now or utc_now()),
                    member_id,
                    record_id,
                    expected_version,
                ),
            )
            if cursor.rowcount != 1:
                exists = self._connection.execute(
                    "SELECT 1 FROM records WHERE member_id=? AND record_id=?",
                    (member_id, record_id),
                ).fetchone()
                if exists is None:
                    raise TaskStateError("TASK_NOT_FOUND", "record not found")
                raise TaskStateError("STORAGE_CONFLICT", "record version conflict")
            row = self._connection.execute(
                "SELECT * FROM records WHERE member_id=? AND record_id=?",
                (member_id, record_id),
            ).fetchone()
        return self._record_from_row(row)

    def list_records(self, member_id: str) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._connection.execute(
                "SELECT * FROM records WHERE member_id=? ORDER BY created_at,record_id",
                (member_id,),
            ).fetchall()
        return [self._record_from_row(row) for row in rows]

    def list_records_page(
        self,
        member_id: str,
        *,
        limit: int,
        after: tuple[str, str] | None = None,
    ) -> tuple[list[dict[str, Any]], bool]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise TaskStateError("INPUT_INVALID", "record page limit must be within 1-100")
        parameters: list[Any] = [member_id]
        predicate = "member_id=?"
        if after is not None:
            if (
                not isinstance(after, tuple)
                or len(after) != 2
                or not all(isinstance(value, str) and value for value in after)
            ):
                raise TaskStateError("INPUT_INVALID", "record page cursor is invalid")
            created_at, record_id = after
            predicate += " AND (created_at>? OR (created_at=? AND record_id>?))"
            parameters.extend((created_at, created_at, record_id))
        parameters.append(limit + 1)
        with self._lock:
            rows = self._connection.execute(
                f"SELECT * FROM records WHERE {predicate} "
                "ORDER BY created_at,record_id LIMIT ?",
                parameters,
            ).fetchall()
            has_more = len(rows) > limit
            records = [self._record_from_row(row) for row in rows[:limit]]
        return records, has_more

    def delete_record(self, member_id: str, record_id: str) -> bool:
        with self._lock:
            cursor = self._connection.execute(
                "DELETE FROM records WHERE member_id=? AND record_id=?",
                (member_id, record_id),
            )
        return cursor.rowcount == 1

    def withdraw_member(self, member_id: str) -> dict[str, int]:
        """Delete all local member data after explicit consent withdrawal."""
        with self._lock:
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                pending_task_ids = [
                    str(row[0])
                    for row in self._connection.execute(
                        "SELECT task_id FROM tasks WHERE member_id=?", (member_id,)
                    ).fetchall()
                ]
                records = self._connection.execute(
                    "DELETE FROM records WHERE member_id=?", (member_id,)
                ).rowcount
                tasks = self._connection.execute(
                    "DELETE FROM tasks WHERE member_id=?", (member_id,)
                ).rowcount
                self._connection.execute("COMMIT")
                for task_id in pending_task_ids:
                    self._pending_results.pop(task_id, None)
                    self._pending_expirations.pop(task_id, None)
            except Exception:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise
        return {"deleted_records": records, "deleted_tasks": tasks}

    def integrity_check(self) -> bool:
        with self._lock:
            rows = self._connection.execute("PRAGMA integrity_check").fetchall()
        return bool(rows) and all(row[0] == "ok" for row in rows)

    def create_backup(self, destination: Path, *, allowed_root: Path) -> None:
        """Publish a verified online backup once, inside an explicit trusted root."""
        destination, root_input = _resolve_backup_destination(destination, allowed_root)
        if destination.exists():
            raise StoragePolicyError("backup destination already exists")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination, _ = _resolve_backup_destination(destination, root_input)
        if destination.exists():
            raise StoragePolicyError("backup destination already exists")
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{destination.name}.backup-", dir=destination.parent
        )
        os.close(descriptor)
        staged = Path(temporary_name)
        try:
            backup = sqlite3.connect(staged)
            try:
                with self._lock:
                    self._connection.backup(backup)
            finally:
                backup.close()
            verification = sqlite3.connect(staged)
            try:
                rows = verification.execute("PRAGMA integrity_check").fetchall()
            finally:
                verification.close()
            if not rows or any(row[0] != "ok" for row in rows):
                raise StoragePolicyError("created backup failed SQLite integrity check")
            if os.name != "nt":
                staged.chmod(0o600)
            with staged.open("r+b") as stream:
                stream.flush()
                os.fsync(stream.fileno())
            destination, _ = _resolve_backup_destination(destination, root_input)
            try:
                os.link(staged, destination)
            except FileExistsError as exc:
                raise StoragePolicyError("backup destination already exists") from exc
            staged.unlink()
            if os.name != "nt":
                directory_descriptor = os.open(destination.parent, os.O_RDONLY)
                try:
                    os.fsync(directory_descriptor)
                finally:
                    os.close(directory_descriptor)
        finally:
            if staged.exists():
                staged.unlink()
