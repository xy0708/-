from __future__ import annotations

import hashlib
import os
import shutil
import sqlite3
import tempfile
import uuid
from pathlib import Path

from .database import StoragePolicyError


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sqlite_integrity_ok(path: Path) -> bool:
    connection = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
    try:
        rows = connection.execute("PRAGMA integrity_check").fetchall()
        return bool(rows) and all(row[0] == "ok" for row in rows)
    finally:
        connection.close()


def _is_redirecting_path(path: Path) -> bool:
    return path.is_symlink() or (
        hasattr(path, "is_junction") and path.is_junction()
    )


def _resolve_confined_path(
    path: Path,
    *,
    root_input: Path,
    resolved_root: Path,
    require_exists: bool,
) -> Path:
    absolute = Path(os.path.abspath(path))
    if absolute == root_input or root_input not in absolute.parents:
        raise StoragePolicyError("database and backup must stay inside allowed_root")
    current = root_input
    for part in absolute.relative_to(root_input).parts:
        current = current / part
        if _is_redirecting_path(current):
            raise StoragePolicyError("database recovery refuses redirected paths")
    resolved = absolute.resolve(strict=require_exists)
    if resolved == resolved_root or resolved_root not in resolved.parents:
        raise StoragePolicyError("database and backup must stay inside allowed_root")
    return resolved


def restore_database_from_backup(
    database: Path,
    backup: Path,
    *,
    expected_backup_sha256: str,
    allowed_root: Path,
) -> Path | None:
    """Atomically restore a stopped SQLite service and retain the previous DB."""
    root_input = Path(os.path.abspath(allowed_root))
    if _is_redirecting_path(root_input) or not root_input.is_dir():
        raise StoragePolicyError("allowed_root must be an existing non-redirected directory")
    root = root_input.resolve(strict=True)
    database = _resolve_confined_path(
        database,
        root_input=root_input,
        resolved_root=root,
        require_exists=False,
    )
    backup = _resolve_confined_path(
        backup,
        root_input=root_input,
        resolved_root=root,
        require_exists=True,
    )
    if database == backup:
        raise StoragePolicyError("database and backup must be different files")
    if not backup.is_file():
        raise StoragePolicyError("backup must be a regular file")
    if database.exists() and not database.is_file():
        raise StoragePolicyError("database must be a regular file when present")
    if len(expected_backup_sha256) != 64 or sha256(backup) != expected_backup_sha256:
        raise StoragePolicyError("backup SHA-256 mismatch")
    if not sqlite_integrity_ok(backup):
        raise StoragePolicyError("backup SQLite integrity check failed")
    for suffix in ("-wal", "-shm"):
        if Path(str(database) + suffix).exists():
            raise StoragePolicyError("database sidecar exists; service may still be running")

    database.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{database.name}.restore-", dir=database.parent
    )
    os.close(fd)
    staged = Path(temporary_name)
    previous: Path | None = None
    try:
        shutil.copyfile(backup, staged)
        with staged.open("r+b") as stream:
            stream.flush()
            os.fsync(stream.fileno())
        if sha256(staged) != expected_backup_sha256 or not sqlite_integrity_ok(staged):
            raise StoragePolicyError("staged restore verification failed")
        if database.exists():
            previous = database.with_name(
                f"{database.name}.pre_restore.{uuid.uuid4().hex}.bak"
            )
            os.replace(database, previous)
        try:
            os.replace(staged, database)
        except Exception:
            if previous is not None and previous.exists() and not database.exists():
                os.replace(previous, database)
            raise
        if os.name != "nt":
            database.chmod(0o600)
            directory_fd = os.open(database.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        return previous
    finally:
        if staged.exists():
            staged.unlink()
