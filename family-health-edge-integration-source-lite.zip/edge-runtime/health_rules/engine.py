from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "health_rules.json"
DISCLAIMER = (
    "本结果仅用于家庭健康管理提示，不构成医疗诊断或治疗建议；"
    "如有不适、指标持续异常或紧急情况，请及时咨询专业医疗人员。"
)
MAX_MEASUREMENTS = 64
MAX_HISTORY_PER_MEASUREMENT = 365


class RuleInputError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def load_rule_config(path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _finite_number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise RuleInputError("INPUT_INVALID", f"{field} 必须是有限数值")
    number = float(value)
    if not math.isfinite(number):
        raise RuleInputError("INPUT_INVALID", f"{field} 必须是有限数值")
    return number


def _parse_timestamp(value: Any) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise RuleInputError("INPUT_INVALID", "measured_at 必须是 ISO-8601 时间")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise RuleInputError("INPUT_INVALID", "measured_at 必须是 ISO-8601 时间") from exc
    if parsed.tzinfo is None:
        raise RuleInputError("INPUT_INVALID", "measured_at 必须包含时区")
    return parsed.astimezone(timezone.utc)


def _canonicalize(metric: str, value: float, unit: str, config: dict[str, Any]) -> tuple[float, str]:
    metric_config = config.get("metrics", {}).get(metric)
    if not metric_config:
        raise RuleInputError("INPUT_INVALID", f"不支持的指标：{metric}")
    canonical_unit = metric_config["canonical_unit"]
    if unit == canonical_unit:
        return value, canonical_unit
    conversion = metric_config.get("conversions", {}).get(unit)
    if not conversion:
        raise RuleInputError(
            "INPUT_UNIT_UNSUPPORTED", f"{metric} 不支持单位 {unit}，期望 {canonical_unit}"
        )
    converted = value * float(conversion["multiply"]) + float(conversion.get("add", 0.0))
    return converted, canonical_unit


def _canonical_optional_reference(
    metric: str,
    value: Any,
    unit: str,
    config: dict[str, Any],
    field: str,
) -> float | None:
    if value is None:
        return None
    number = _finite_number(value, field)
    converted, _ = _canonicalize(metric, number, unit, config)
    return converted


def _trend_trigger(
    current: float,
    history: list[float],
    trend_config: dict[str, Any],
) -> dict[str, Any] | None:
    threshold = trend_config.get("relative_change_threshold")
    minimum_history = int(trend_config.get("minimum_history", 0))
    if threshold is None or len(history) < minimum_history:
        return None
    baseline_values = history[-minimum_history:]
    baseline = sum(baseline_values) / len(baseline_values)
    if baseline == 0:
        return None
    relative_change = (current - baseline) / abs(baseline)
    if abs(relative_change) < float(threshold):
        return None
    direction = "上升" if relative_change > 0 else "下降"
    return {
        "code": "PERSONAL_TREND_CHANGE",
        "level": "OBSERVE",
        "message": f"与近期个人记录均值相比出现明显{direction}，建议核对测量条件并持续观察。",
        "relative_change": round(relative_change, 6),
        "baseline_count": len(baseline_values),
    }


def _evaluate_measurement(item: dict[str, Any], config: dict[str, Any], now: datetime) -> dict[str, Any]:
    metric = item.get("metric")
    unit = item.get("unit")
    if not isinstance(metric, str) or not metric:
        raise RuleInputError("INPUT_INVALID", "metric 不能为空")
    if not isinstance(unit, str) or not unit:
        raise RuleInputError("INPUT_INVALID", "unit 不能为空")
    if item.get("confirmed") is not True:
        raise RuleInputError("TASK_NOT_CONFIRMED", f"{metric} 尚未由用户确认")

    measured_at = _parse_timestamp(item.get("measured_at"))
    if measured_at > now:
        raise RuleInputError("INPUT_INVALID", f"{metric} 的 measured_at 不能晚于当前时间")
    raw_value = _finite_number(item.get("value"), "value")
    value, canonical_unit = _canonicalize(metric, raw_value, unit, config)
    reference_low = _canonical_optional_reference(
        metric, item.get("reference_low"), unit, config, "reference_low"
    )
    reference_high = _canonical_optional_reference(
        metric, item.get("reference_high"), unit, config, "reference_high"
    )
    if reference_low is not None and reference_high is not None and reference_low > reference_high:
        raise RuleInputError("INPUT_INVALID", f"{metric} 的参考区间上下限冲突")

    triggers: list[dict[str, Any]] = []
    warnings: list[str] = []
    if reference_low is None and reference_high is None:
        warnings.append("REFERENCE_RANGE_MISSING")
    elif reference_low is not None and value < reference_low:
        triggers.append(
            {
                "code": "BELOW_PROVIDED_REFERENCE",
                "level": "ATTENTION",
                "message": "该值低于随本次输入提供的参考下限，建议核对报告和测量条件。",
            }
        )
    elif reference_high is not None and value > reference_high:
        triggers.append(
            {
                "code": "ABOVE_PROVIDED_REFERENCE",
                "level": "ATTENTION",
                "message": "该值高于随本次输入提供的参考上限，建议核对报告和测量条件。",
            }
        )

    metric_config = config["metrics"][metric]
    max_age_days = metric_config.get("max_age_days")
    age_days = (now - measured_at).total_seconds() / 86400
    if max_age_days is not None and age_days > float(max_age_days):
        triggers.append(
            {
                "code": "MEASUREMENT_STALE",
                "level": "INPUT_REVIEW_REQUIRED",
                "message": "该记录时间较早，不应直接代表当前状态，建议更新测量。",
                "age_days": round(age_days, 3),
            }
        )

    history = item.get("history", [])
    if not isinstance(history, list):
        raise RuleInputError("INPUT_INVALID", "history 必须是数组")
    if len(history) > MAX_HISTORY_PER_MEASUREMENT:
        raise RuleInputError("INPUT_OUT_OF_RANGE", "单个指标历史记录过多")
    history_values: list[float] = []
    for index, historical in enumerate(history):
        if not isinstance(historical, dict) or historical.get("confirmed") is not True:
            continue
        history_unit = historical.get("unit")
        if not isinstance(history_unit, str):
            continue
        historical_value = _finite_number(historical.get("value"), f"history[{index}].value")
        converted, _ = _canonicalize(metric, historical_value, history_unit, config)
        history_values.append(converted)

    trend = _trend_trigger(value, history_values, metric_config.get("trend", {}))
    if trend:
        triggers.append(trend)

    return {
        "metric": metric,
        "value": round(value, 6),
        "unit": canonical_unit,
        "measured_at": measured_at.isoformat(),
        "reference_low": reference_low,
        "reference_high": reference_high,
        "reference_source": item.get("reference_source"),
        "triggers": triggers,
        "warnings": warnings,
        "no_rule_triggered_is_not_proof_of_health": not triggers,
    }


def evaluate_payload(
    payload: dict[str, Any],
    config: dict[str, Any] | None = None,
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise RuleInputError("INPUT_INVALID", "请求体必须是对象")
    if payload.get("confirmed") is not True:
        raise RuleInputError("TASK_NOT_CONFIRMED", "健康提示只接受已确认输入")
    measurements = payload.get("measurements")
    if not isinstance(measurements, list) or not measurements:
        raise RuleInputError("INPUT_INVALID", "measurements 必须是非空数组")
    if len(measurements) > MAX_MEASUREMENTS:
        raise RuleInputError("INPUT_OUT_OF_RANGE", "measurements 超过单次请求上限")

    rule_config = config or load_rule_config()
    current_time = now or datetime.now(timezone.utc)
    results = [_evaluate_measurement(item, rule_config, current_time) for item in measurements]
    levels = {
        trigger["level"]
        for result in results
        for trigger in result["triggers"]
    }
    if "INPUT_REVIEW_REQUIRED" in levels:
        attention_level = "INPUT_REVIEW_REQUIRED"
    elif "ATTENTION" in levels:
        attention_level = "ATTENTION"
    elif "OBSERVE" in levels:
        attention_level = "OBSERVE"
    else:
        attention_level = "NO_RULE_TRIGGERED"

    approved = rule_config.get("approval_status") == "APPROVED_FOR_PRODUCT_RELEASE"
    return {
        "scope": "NON_DIAGNOSTIC_HEALTH_MANAGEMENT",
        "rule_version": rule_config["rule_version"],
        "approval_status": rule_config["approval_status"],
        "product_release_allowed": approved,
        "disease_probability": None,
        "diagnosis": None,
        "attention_level": attention_level,
        "measurements": results,
        "disclaimer": DISCLAIMER,
    }
