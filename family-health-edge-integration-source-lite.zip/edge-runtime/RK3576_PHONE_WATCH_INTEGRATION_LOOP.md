# RK3576 手表—手机—模型联动 Loop

更新日期：2026-10-14  
活动目标：手机 Flutter APP + 玉成 Android SDK 2.0 + RK3576 / Android 14 / `arm64-v8a`  
当前阶段：硬件前集成候选版；无手表和 RK3576 真机，不得声明真机或产品验收通过。

## 1. 冻结架构

```text
玉成手表
  └─ BLE ─> FamilyHealthPhone-main（手机）
                ├─ 本地缓存、去重、成员绑定
                ├─ 体检图片 / 语音 / 已确认健康数据
                └─ 家庭 Wi-Fi HTTPS ─> RK3576 Android 14
                                           ├─ 健康提示运行时
                                           ├─ OCR 运行时
                                           └─ ASR 运行时
                         <─ 结构化结果、状态和固定错误码 ─┘
```

- 手机负责 BLE、手表协议和待发送队列；RK3576 不直接连接手表。
- RK3576 是家庭局域网内的端侧模型服务，不依赖云端完成核心流程。
- 首版使用同一家庭 Wi-Fi；手动地址是工程入口，自动发现和扫码绑定后补。
- RK3576 热点仅为备选，必须由目标 Android 固件实测或厂商系统权限证明。
- 正式传输必须使用设备认证和加密；仅合成数据仿真允许受控的开发传输。

## 2. 永久真实性边界

- 没有真实手表，不得把 SDK 编译通过描述为 BLE、字段或固件兼容通过。
- 没有真实 RK3576，不得把 PC、模拟器、RK3566/RK3568 或 CPU 结果描述为
  RK3576 NPU、温度、内存、长稳或后台保活证据。
- 现有 RK3566/RK3568 `.rknn` 只能作为历史候选；必须重新建立 RK3576 转换、
  Runtime、驱动和逐输出验收证据。
- 手表字段按能力发现；未被具体型号声明支持的字段必须保持“不可用”，不得补零冒充。
- 健康模块仅输出非诊断提示；OCR、ASR和手表结果未经确认不得写入正式健康档案。
- CHARLS 永久排除；NHANES和合成数据不得作为中国产品性能证据。

## 3. Gate

| Gate | 内容 | 当前状态 | 完成条件 |
|---|---|---|---|
| W00 | 目标与职责冻结 | PASS_ENGINEERING | 手机负责BLE、RK3576负责模型、云端非核心路径 |
| W01 | 厂家SDK来源冻结 | PASS_ENGINEERING_PRODUCT_BLOCKED | 已固定提交、仓库快照与4.0.11核心AAR哈希；嵌入二进制商业再分发仍待书面确认 |
| W02 | 手机手表网关 | IN_PROGRESS | 正式 APP 默认失败关闭，模拟手表仅显式注入；厂家真实适配器仍待实现和实测 |
| W03 | 字段规范化 | IN_PROGRESS | 心率与步数字段已按示例源码建立单位、UTC时间、质量与幂等ID；睡眠及其余字段待真表和文档核验 |
| W04 | 手机—端侧协议 | IN_PROGRESS | 手机 HTTPS 客户端与成员级鉴权已实现并定向测试；RK3576 Android HTTPS 服务、绑定和弱网仍待完成 |
| W05 | RK3576三模型路由 | IN_PROGRESS | 健康/OCR/ASR接口可由手机调用；模块失败彼此隔离 |
| W06 | 无硬件仿真闭环 | IN_PROGRESS | 已确认心率报文走通旧 loopback HTTP，并实测缺成员/跨成员拒绝；手机到 RK3576 三模型和 APP 显示闭环未通过 |
| W07 | 离线与隐私 | NOT_STARTED | 缓存、续传、去重、成员隔离、最少日志和删除流程通过 |
| W08 | Android构建候选 | IN_PROGRESS | 手机 Debug APK 曾构建，但后续源码已变更；本轮 Flutter 工具被沙箱阻断，当前源码尚无新 APK 证据 |
| W09 | 手表与RK3576真机 | BLOCKED_EXTERNAL | 真实BLE、Android 14、网络、NPU、温度、长稳、断电实测 |
| W10 | 发布与最终验收 | BLOCKED_EXTERNAL | 正式包名/签名、许可、隐私、升级回滚及具名批准全部通过 |

## 4. 无真机阶段执行顺序

1. 冻结 `configs/phone_edge_contract.json` 和 SDK 来源记录。
2. 在正式手机 APP 中建立 `WatchGateway`，模拟实现必须确定性、可测试。
3. 厂家实现只位于适配层；业务 Provider 不直接调用厂家类或远端“扫描接口”。
4. 冻结手表字段信封；不支持字段缺省为不可用，不使用虚构正常值。
5. 对齐手机请求与 `device_service` 的 `/v1` 健康、OCR、ASR契约。
6. 使用合成输入完成本机仿真闭环，保存输入、输出和代码哈希。
7. 运行手机 `flutter analyze/test/build` 与端侧 Python 定向/总控测试。
8. 将所有硬件门禁保持 `BLOCKED_EXTERNAL`，生成真机接管清单。

## 5. 真机到位后的强制顺序

1. 记录手表型号、固件、SDK真实版本和支持能力。
2. 验证BLE扫描、授权、连接、重连、历史同步、时区和单位。
3. 记录RK3576板卡SKU、Android指纹、安全补丁、RKNPU驱动和RKNN Runtime。
4. 在相同家庭Wi-Fi验证发现、绑定、加密、弱网、断电和队列续传。
5. 对三模型执行真实输入、资源、温度和长稳验收；失败不得退化为伪成功。
6. 完成签名升级/回滚、隐私删除和独立验收后，才能评审W10。

## 6. 每轮恢复入口

```powershell
cd C:\Users\45277\Desktop\模型\端侧上线
.\.venv-edge\Scripts\python.exe scripts\run_rk3576_phone_edge_loop.py
```

每轮只完成一个可审计主改动：先定向测试，再跑总控；失败报告不得覆盖，外部
阻塞不得被模拟结果解除。

2026-10-14 本轮 Run `20261014T095121Z`：契约、14 项 Android 门禁、13 项成员级
应用测试、5 项故障隔离测试和 loopback HTTP smoke 通过。Flutter analyze/test 因
当前执行沙箱拒绝 Dart snapshot 路径解析而未运行，状态为
`PARTIAL_ENGINEERING_ENV_BLOCKED`，不能沿用前一版 APK 声称当前源码已构建。
