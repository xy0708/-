from __future__ import annotations

import json
import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path


MAX_ACTIVATION_MARKER_BYTES = 4096
_RELEASE_ID = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$")
_FIELDS = {"schema_version", "candidate_release_id", "previous_release_id"}


class ActivationMarkerError(ValueError):
    pass


@dataclass(frozen=True)
class ActivationRecord:
    candidate_release_id: str
    previous_release_id: str | None


def _validate_release_id(value: object, field: str) -> str:
    if not isinstance(value, str) or _RELEASE_ID.fullmatch(value) is None:
        raise ActivationMarkerError(f"{field}_invalid")
    return value


def _fsync_parent(path: Path) -> None:
    if os.name != "posix":
        return
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def require_root_owned_activation_path(marker: Path, *, marker_required: bool) -> None:
    """Enforce the privileged update-state boundary used by device CLI tools."""

    parent = marker.parent
    if parent.is_symlink() or not parent.is_dir():
        raise ActivationMarkerError("activation_marker_parent_unsafe")
    if os.name != "posix":
        return
    parent_stat = parent.stat()
    if parent_stat.st_uid != 0 or parent_stat.st_mode & 0o077:
        raise ActivationMarkerError("activation_marker_parent_permissions_invalid")
    if marker.is_symlink():
        raise ActivationMarkerError("activation_marker_missing_or_unsafe")
    if marker_required:
        if not marker.is_file():
            raise ActivationMarkerError("activation_marker_missing_or_unsafe")
        marker_stat = marker.stat()
        if marker_stat.st_uid != 0 or marker_stat.st_mode & 0o077:
            raise ActivationMarkerError("activation_marker_owner_or_permissions_invalid")


def read_activation_marker(marker: Path) -> ActivationRecord:
    if marker.is_symlink() or not marker.is_file():
        raise ActivationMarkerError("activation_marker_missing_or_unsafe")
    size = marker.stat().st_size
    if size <= 0 or size > MAX_ACTIVATION_MARKER_BYTES:
        raise ActivationMarkerError("activation_marker_size_invalid")
    if os.name == "posix" and marker.stat().st_mode & 0o077:
        raise ActivationMarkerError("activation_marker_permissions_invalid")
    try:
        payload = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ActivationMarkerError("activation_marker_json_invalid") from exc
    if not isinstance(payload, dict) or set(payload) != _FIELDS:
        raise ActivationMarkerError("activation_marker_schema_invalid")
    if payload.get("schema_version") != "1.0.0":
        raise ActivationMarkerError("activation_marker_version_unsupported")
    candidate = _validate_release_id(
        payload.get("candidate_release_id"), "candidate_release_id"
    )
    previous_raw = payload.get("previous_release_id")
    previous = (
        None
        if previous_raw is None
        else _validate_release_id(previous_raw, "previous_release_id")
    )
    if previous == candidate:
        raise ActivationMarkerError("activation_marker_transition_invalid")
    return ActivationRecord(candidate, previous)


def prepare_activation_marker(
    marker: Path, candidate_release_id: str, previous_release_id: str | None
) -> ActivationRecord:
    candidate = _validate_release_id(candidate_release_id, "candidate_release_id")
    previous = (
        None
        if previous_release_id is None
        else _validate_release_id(previous_release_id, "previous_release_id")
    )
    if previous == candidate:
        raise ActivationMarkerError("activation_marker_transition_invalid")
    parent = marker.parent
    if parent.is_symlink() or not parent.is_dir():
        raise ActivationMarkerError("activation_marker_parent_unsafe")
    if marker.exists() or marker.is_symlink():
        raise ActivationMarkerError("pending_activation_already_exists")
    payload = {
        "schema_version": "1.0.0",
        "candidate_release_id": candidate,
        "previous_release_id": previous,
    }
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=".pending-activation.", dir=parent
    )
    temporary = Path(temporary_name)
    try:
        os.chmod(temporary, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, ensure_ascii=True, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, marker)
        _fsync_parent(parent)
    except Exception:
        try:
            os.close(descriptor)
        except OSError:
            pass
        temporary.unlink(missing_ok=True)
        raise
    return ActivationRecord(candidate, previous)


def clear_activation_marker(marker: Path, candidate_release_id: str) -> None:
    expected = _validate_release_id(candidate_release_id, "candidate_release_id")
    record = read_activation_marker(marker)
    if record.candidate_release_id != expected:
        raise ActivationMarkerError("activation_marker_candidate_mismatch")
    marker.unlink()
    _fsync_parent(marker.parent)
