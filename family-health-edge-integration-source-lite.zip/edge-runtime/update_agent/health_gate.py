from __future__ import annotations

import json
from dataclasses import dataclass
from time import monotonic, sleep
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, Request, build_opener


MAX_HEALTH_BYTES = 64 * 1024
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "::1"})


@dataclass(frozen=True)
class HealthGateResult:
    passed: bool
    failures: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": "PASS_PRODUCT_HEALTH" if self.passed else "FAIL_CLOSED",
            "failures": list(self.failures),
        }


def check_product_health(payload: Any) -> HealthGateResult:
    """Validate the product-ready subset of the public health contract.

    HTTP success alone is deliberately insufficient: the service reports degraded
    component state with HTTP 200 so monitoring remains observable.
    """

    failures: list[str] = []
    if not isinstance(payload, dict) or payload.get("status") != "success":
        return HealthGateResult(False, ("HEALTH_ENVELOPE_INVALID",))
    result = payload.get("result")
    if not isinstance(result, dict):
        return HealthGateResult(False, ("HEALTH_RESULT_INVALID",))
    if result.get("status") != "ok":
        failures.append("SERVICE_DEGRADED")
    if result.get("network_scope") != "loopback_only":
        failures.append("NETWORK_SCOPE_INVALID")
    if result.get("product_complete") is not True:
        failures.append("PRODUCT_COMPLETE_FALSE")

    storage = result.get("storage")
    if not isinstance(storage, dict):
        failures.append("STORAGE_HEALTH_INVALID")
    else:
        if storage.get("ready") is not True:
            failures.append("STORAGE_NOT_READY")
        if storage.get("product_secure") is not True:
            failures.append("STORAGE_NOT_PRODUCT_SECURE")

    health_rules = result.get("health_rules")
    if not isinstance(health_rules, dict):
        failures.append("HEALTH_RULES_INVALID")
    else:
        if health_rules.get("ready") is not True:
            failures.append("HEALTH_RULES_NOT_READY")
        if health_rules.get("non_diagnostic") is not True:
            failures.append("HEALTH_RULES_BOUNDARY_INVALID")

    for name in ("ocr", "asr"):
        component = result.get(name)
        if not isinstance(component, dict) or component.get("ready") is not True:
            failures.append(f"{name.upper()}_NOT_READY")

    return HealthGateResult(not failures, tuple(sorted(set(failures))))


def fetch_product_health(url: str, *, timeout_seconds: float = 10.0) -> HealthGateResult:
    parsed = urlsplit(url)
    if (
        parsed.scheme != "http"
        or parsed.hostname not in _LOOPBACK_HOSTS
        or parsed.username is not None
        or parsed.password is not None
        or parsed.path != "/v1/health"
        or parsed.query
        or parsed.fragment
    ):
        return HealthGateResult(False, ("HEALTH_URL_NOT_LOOPBACK",))
    if isinstance(timeout_seconds, bool) or not 0.1 <= float(timeout_seconds) <= 30:
        return HealthGateResult(False, ("HEALTH_TIMEOUT_INVALID",))
    try:
        request = Request(url, headers={"Accept": "application/json"}, method="GET")
        # Ignore environment proxy settings: update health must never leave the device.
        opener = build_opener(ProxyHandler({}))
        with opener.open(request, timeout=float(timeout_seconds)) as response:
            if response.status != 200:
                return HealthGateResult(False, ("HEALTH_HTTP_STATUS_INVALID",))
            raw = response.read(MAX_HEALTH_BYTES + 1)
    except (OSError, HTTPError, URLError, TimeoutError, ValueError):
        return HealthGateResult(False, ("HEALTH_REQUEST_FAILED",))
    if len(raw) > MAX_HEALTH_BYTES:
        return HealthGateResult(False, ("HEALTH_RESPONSE_TOO_LARGE",))
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return HealthGateResult(False, ("HEALTH_RESPONSE_INVALID",))
    return check_product_health(payload)


def wait_for_product_health(
    url: str,
    *,
    startup_timeout_seconds: float = 10.0,
    request_timeout_seconds: float = 2.0,
    poll_interval_seconds: float = 0.25,
) -> HealthGateResult:
    """Poll strict product health within one bounded startup deadline."""

    values = (startup_timeout_seconds, request_timeout_seconds, poll_interval_seconds)
    if any(isinstance(value, bool) for value in values):
        return HealthGateResult(False, ("HEALTH_WAIT_CONFIGURATION_INVALID",))
    try:
        startup_timeout = float(startup_timeout_seconds)
        request_timeout = float(request_timeout_seconds)
        poll_interval = float(poll_interval_seconds)
    except (TypeError, ValueError):
        return HealthGateResult(False, ("HEALTH_WAIT_CONFIGURATION_INVALID",))
    if not (
        0.1 <= startup_timeout <= 120
        and 0.1 <= request_timeout <= 30
        and 0.01 <= poll_interval <= 5
    ):
        return HealthGateResult(False, ("HEALTH_WAIT_CONFIGURATION_INVALID",))

    deadline = monotonic() + startup_timeout
    last = HealthGateResult(False, ("HEALTH_REQUEST_FAILED",))
    while True:
        remaining = deadline - monotonic()
        if remaining < 0.1:
            break
        last = fetch_product_health(
            url,
            timeout_seconds=min(request_timeout, remaining),
        )
        if last.passed:
            return last
        if "HEALTH_URL_NOT_LOOPBACK" in last.failures or "HEALTH_TIMEOUT_INVALID" in last.failures:
            return last
        remaining = deadline - monotonic()
        if remaining <= 0:
            break
        sleep(min(poll_interval, remaining))
    return HealthGateResult(
        False,
        tuple(sorted(set(last.failures) | {"HEALTH_STARTUP_TIMEOUT"})),
    )
