from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


MAX_ROLLBACK_BYTES = 64 * 1024
_RELEASE_ID = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$")
_FIELDS = {
    "schema_version",
    "previous_release_id",
    "database_rollback_compatible",
}


@dataclass(frozen=True)
class RollbackGateResult:
    passed: bool
    failures: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": "PASS_ROLLBACK_TRANSITION" if self.passed else "FAIL_CLOSED",
            "failures": list(self.failures),
        }


def check_rollback_transition(
    current_bundle: Path, target_release_id: str
) -> RollbackGateResult:
    """Authorize only the predecessor named by current signed rollback metadata.

    The caller verifies both bundle signatures while holding the installer lock. This
    function enforces the transition and database-compatibility part of that policy.
    """

    if _RELEASE_ID.fullmatch(target_release_id) is None:
        return RollbackGateResult(False, ("TARGET_RELEASE_ID_INVALID",))
    try:
        bundle = current_bundle.resolve(strict=True)
        metadata = bundle / "rollback.json"
        if metadata.is_symlink() or not metadata.is_file():
            return RollbackGateResult(False, ("CURRENT_ROLLBACK_METADATA_UNSAFE",))
        if metadata.stat().st_size > MAX_ROLLBACK_BYTES:
            return RollbackGateResult(False, ("CURRENT_ROLLBACK_METADATA_TOO_LARGE",))
        payload = json.loads(metadata.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return RollbackGateResult(False, ("CURRENT_ROLLBACK_METADATA_INVALID",))
    if not isinstance(payload, dict) or set(payload) != _FIELDS:
        return RollbackGateResult(False, ("CURRENT_ROLLBACK_METADATA_INVALID",))
    failures: list[str] = []
    if payload.get("schema_version") != "1.0.0":
        failures.append("ROLLBACK_SCHEMA_INCOMPATIBLE")
    if payload.get("previous_release_id") != target_release_id:
        failures.append("TARGET_NOT_SIGNED_PREDECESSOR")
    if payload.get("database_rollback_compatible") is not True:
        failures.append("DATABASE_ROLLBACK_NOT_APPROVED")
    return RollbackGateResult(not failures, tuple(sorted(failures)))
