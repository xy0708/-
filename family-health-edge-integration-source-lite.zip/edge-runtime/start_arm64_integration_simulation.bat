@echo off
setlocal
cd /d "%~dp0"
".venv-edge\Scripts\python.exe" "scripts\build_arm64_wheelhouse_manifest.py"
if errorlevel 1 goto :failed
".venv-edge\Scripts\python.exe" "scripts\run_arm64_integration_simulation.py"
if errorlevel 1 goto :failed
".venv-edge\Scripts\python.exe" "scripts\verify_arm64_integration_evidence.py"
if errorlevel 1 goto :failed
echo ARM64 ASR and device-service engineering integration passed.
echo OCR, RK3566 hardware, product licenses and acceptance remain blocked.
pause
exit /b 0
:failed
echo ARM64 integration simulation failed. See reports\arm64_integration_simulation_latest.json
pause
exit /b 2
