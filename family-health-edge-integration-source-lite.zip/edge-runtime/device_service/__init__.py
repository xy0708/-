"""Local-only edge device API application."""

from .application import DeviceApplication, TokenAuthorizer

__all__ = ["DeviceApplication", "TokenAuthorizer"]
