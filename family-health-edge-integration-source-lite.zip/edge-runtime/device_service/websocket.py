from __future__ import annotations

import base64
import hashlib
import json
import secrets
from typing import BinaryIO


GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
DATA_OPCODES = {0x1, 0x2}
CONTROL_OPCODES = {0x8, 0x9, 0xA}
SUPPORTED_OPCODES = DATA_OPCODES | CONTROL_OPCODES


class WebSocketProtocolError(RuntimeError):
    pass


def websocket_accept(key: str) -> str:
    try:
        decoded = base64.b64decode(key, validate=True)
    except ValueError as exc:
        raise WebSocketProtocolError("invalid websocket key") from exc
    if len(decoded) != 16:
        raise WebSocketProtocolError("invalid websocket key length")
    digest = hashlib.sha1((key + GUID).encode("ascii"), usedforsecurity=False).digest()
    return base64.b64encode(digest).decode("ascii")


def _read_exact(stream: BinaryIO, length: int) -> bytes:
    value = bytearray()
    while len(value) < length:
        chunk = stream.read(length - len(value))
        if not chunk:
            raise WebSocketProtocolError("unexpected end of websocket frame")
        value.extend(chunk)
    return bytes(value)


def _validate_control_payload(opcode: int, payload: bytes) -> None:
    if opcode != 0x8:
        return
    if len(payload) == 1:
        raise WebSocketProtocolError("invalid websocket close payload")
    if len(payload) < 2:
        return
    status_code = int.from_bytes(payload[:2], "big")
    standard_code = 1000 <= status_code <= 1014 and status_code not in {1004, 1005, 1006}
    application_code = 3000 <= status_code <= 4999
    if not (standard_code or application_code):
        raise WebSocketProtocolError("invalid websocket close status")
    try:
        payload[2:].decode("utf-8")
    except UnicodeDecodeError as exc:
        raise WebSocketProtocolError("invalid websocket close reason") from exc


def read_client_frame(stream: BinaryIO, *, max_payload_bytes: int) -> tuple[int, bytes]:
    first, second = _read_exact(stream, 2)
    final = bool(first & 0x80)
    opcode = first & 0x0F
    if first & 0x70:
        raise WebSocketProtocolError("websocket reserved bits are not supported")
    masked = bool(second & 0x80)
    length_code = second & 0x7F
    if not final:
        raise WebSocketProtocolError("fragmented websocket frames are not supported")
    if opcode not in SUPPORTED_OPCODES:
        raise WebSocketProtocolError("unsupported websocket opcode")
    if not masked:
        raise WebSocketProtocolError("client websocket frame must be masked")
    length = length_code
    if length_code == 126:
        length = int.from_bytes(_read_exact(stream, 2), "big")
        if length < 126:
            raise WebSocketProtocolError("noncanonical websocket length")
    elif length_code == 127:
        encoded_length = _read_exact(stream, 8)
        if encoded_length[0] & 0x80:
            raise WebSocketProtocolError("invalid websocket length")
        length = int.from_bytes(encoded_length, "big")
        if length <= 65535:
            raise WebSocketProtocolError("noncanonical websocket length")
    if opcode in CONTROL_OPCODES and length > 125:
        raise WebSocketProtocolError("websocket control frame exceeds limit")
    if length > max_payload_bytes:
        raise WebSocketProtocolError("websocket frame exceeds limit")
    mask = _read_exact(stream, 4)
    payload = _read_exact(stream, length)
    decoded = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
    _validate_control_payload(opcode, decoded)
    return opcode, decoded


def write_server_frame(stream: BinaryIO, opcode: int, payload: bytes = b"") -> None:
    if opcode not in SUPPORTED_OPCODES:
        raise WebSocketProtocolError("unsupported websocket opcode")
    if opcode in CONTROL_OPCODES and len(payload) > 125:
        raise WebSocketProtocolError("websocket control frame exceeds limit")
    if len(payload) > 65535:
        raise WebSocketProtocolError("server websocket frame exceeds limit")
    _validate_control_payload(opcode, payload)
    header = bytes([0x80 | opcode])
    if len(payload) < 126:
        header += bytes([len(payload)])
    else:
        header += bytes([126]) + len(payload).to_bytes(2, "big")
    stream.write(header + payload)
    stream.flush()


def write_json(stream: BinaryIO, payload: dict) -> None:
    encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
    write_server_frame(stream, 0x1, encoded)


def encode_client_frame(opcode: int, payload: bytes = b"") -> bytes:
    if opcode not in SUPPORTED_OPCODES:
        raise WebSocketProtocolError("unsupported websocket opcode")
    if opcode in CONTROL_OPCODES and len(payload) > 125:
        raise WebSocketProtocolError("websocket control frame exceeds limit")
    if len(payload) > 65535:
        raise WebSocketProtocolError("client websocket frame exceeds limit")
    _validate_control_payload(opcode, payload)
    mask = secrets.token_bytes(4)
    first = bytes([0x80 | opcode])
    if len(payload) < 126:
        header = first + bytes([0x80 | len(payload)])
    else:
        header = first + bytes([0x80 | 126]) + len(payload).to_bytes(2, "big")
    encoded = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
    return header + mask + encoded


def read_server_frame(stream: BinaryIO, *, max_payload_bytes: int) -> tuple[int, bytes]:
    first, second = _read_exact(stream, 2)
    if first & 0x70:
        raise WebSocketProtocolError("websocket reserved bits are not supported")
    if not first & 0x80:
        raise WebSocketProtocolError("fragmented server frame is unsupported")
    if second & 0x80:
        raise WebSocketProtocolError("server frame must not be masked")
    opcode = first & 0x0F
    if opcode not in SUPPORTED_OPCODES:
        raise WebSocketProtocolError("unsupported websocket opcode")
    length_code = second & 0x7F
    length = length_code
    if length_code == 126:
        length = int.from_bytes(_read_exact(stream, 2), "big")
        if length < 126:
            raise WebSocketProtocolError("noncanonical websocket length")
    elif length_code == 127:
        encoded_length = _read_exact(stream, 8)
        if encoded_length[0] & 0x80:
            raise WebSocketProtocolError("invalid websocket length")
        length = int.from_bytes(encoded_length, "big")
        if length <= 65535:
            raise WebSocketProtocolError("noncanonical websocket length")
    if opcode in CONTROL_OPCODES and length > 125:
        raise WebSocketProtocolError("websocket control frame exceeds limit")
    if length > max_payload_bytes:
        raise WebSocketProtocolError("server websocket frame exceeds limit")
    payload = _read_exact(stream, length)
    _validate_control_payload(opcode, payload)
    return opcode, payload
