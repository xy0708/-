from __future__ import annotations

import argparse
import json
import os
import secrets
import socket
import sys
import threading
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from device_service.application import ComponentAdapter, DeviceApplication, TokenAuthorizer
from device_service.runtime_bootstrap import load_runtime_adapters
from storage import PlaintextEngineeringCodec, RecordStore, StoragePolicyError
from operations import PrivacySafeEventLog
from storage import TaskStateError
from device_service.websocket import (
    WebSocketProtocolError,
    read_client_frame,
    websocket_accept,
    write_json,
    write_server_frame,
)


MAX_BODY_BYTES = 12 * 1024 * 1024
SOCKET_TIMEOUT_SECONDS = 10
MAX_CONCURRENT_REQUESTS = 16
MAX_RELEASE_MANIFEST_BYTES = 4 * 1024 * 1024
_RELEASE_ID = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$")


def load_verified_release_id(path: Path) -> str:
    candidate = path.absolute()
    if candidate.is_symlink() or not candidate.is_file():
        raise ValueError("release manifest is missing or unsafe")
    resolved = candidate.resolve(strict=True)
    if resolved.stat().st_size > MAX_RELEASE_MANIFEST_BYTES:
        raise ValueError("release manifest is too large")
    try:
        payload = json.loads(resolved.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError("release manifest is invalid") from exc
    if (
        not isinstance(payload, dict)
        or set(payload) != {"schema_version", "release_id", "created_at", "files"}
        or payload.get("schema_version") != "1.0.0"
        or not isinstance(payload.get("release_id"), str)
        or _RELEASE_ID.fullmatch(payload["release_id"]) is None
        or payload["release_id"] != resolved.parent.name
        or not isinstance(payload.get("created_at"), str)
        or not isinstance(payload.get("files"), list)
        or not payload["files"]
    ):
        raise ValueError("release manifest boundary is invalid")
    return payload["release_id"]


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    # Product shutdown/OTA must drain active handlers before storage is closed.
    # Socket and component-operation timeouts keep this wait bounded.
    daemon_threads = False
    block_on_close = True

    def __init__(self, *args: Any, max_concurrent_requests: int = MAX_CONCURRENT_REQUESTS, **kwargs: Any) -> None:
        if max_concurrent_requests < 1:
            raise ValueError("max_concurrent_requests must be positive")
        self._request_slots = threading.BoundedSemaphore(max_concurrent_requests)
        super().__init__(*args, **kwargs)

    def process_request(self, request: socket.socket, client_address: Any) -> None:
        if not self._request_slots.acquire(blocking=False):
            request.close()
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._request_slots.release()
            raise

    def shutdown_request(self, request: socket.socket) -> None:
        try:
            super().shutdown_request(request)
        finally:
            self._request_slots.release()


class DeviceRequestHandler(BaseHTTPRequestHandler):
    server_version = "FamilyHealthEdge/0.1"
    protocol_version = "HTTP/1.1"

    def setup(self) -> None:
        super().setup()
        self.connection.settimeout(SOCKET_TIMEOUT_SECONDS)

    def log_message(self, format: str, *args: Any) -> None:
        # Intentionally omit request paths and bodies from ordinary logs.
        return

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/v1/asr/stream" and self.headers.get("Upgrade", "").lower() == "websocket":
            # The handler owns this connection until the WebSocket closes; do
            # not re-enter the HTTP request parser afterward.
            self.close_connection = True
            self._handle_asr_websocket()
            return
        self._dispatch("GET")

    def do_POST(self) -> None:  # noqa: N802
        self._dispatch("POST")

    def do_DELETE(self) -> None:  # noqa: N802
        self._dispatch("DELETE")

    def _dispatch(self, method: str) -> None:
        if self.headers.get_all("Transfer-Encoding", []):
            self.close_connection = True
            self._write(422, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        content_lengths = self.headers.get_all("Content-Length", [])
        if len(content_lengths) > 1:
            self.close_connection = True
            self._write(422, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.close_connection = True
            self._write(422, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        if length < 0:
            self.close_connection = True
            self._write(422, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        if length > MAX_BODY_BYTES:
            self.close_connection = True
            self._write(413, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        try:
            raw = _read_http_body(self.rfile, length) if length else b""
        except (TimeoutError, OSError, ValueError):
            self.close_connection = True
            self._write(422, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._write(422, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        if not isinstance(body, dict):
            self._write(422, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        headers = {key.lower(): value for key, value in self.headers.items()}
        app: DeviceApplication = self.server.application  # type: ignore[attr-defined]
        try:
            status, payload = app.dispatch(method, self.path, headers, body)
        except Exception:
            status, payload = 500, {
                "status": "error",
                "request_id": secrets.token_hex(16),
                "task_id": None,
                "requires_confirmation": False,
                "contract_version": app.contract_version,
                "component_version": app.component_version,
                "result": None,
                "warnings": [],
                "error": {
                    "code": "INTERNAL_ERROR",
                    "message": "The local service failed safely",
                    "retryable": False,
                },
            }
        event_log: PrivacySafeEventLog | None = getattr(self.server, "event_log", None)
        if event_log is not None:
            event_log_healthy = bool(getattr(self.server, "event_log_healthy", True))
            if method == "GET" and self.path == "/v1/health":
                result = payload.get("result")
                if isinstance(result, dict):
                    result["event_log"] = {
                        "ready": event_log_healthy,
                        "reason": None if event_log_healthy else "EVENT_LOG_UNAVAILABLE",
                    }
                    if not event_log_healthy:
                        result["status"] = "degraded"
            error = payload.get("error")
            error_code = error.get("code") if isinstance(error, dict) else None
            try:
                event_log.request_completed(
                    status=status,
                    request_id=str(payload.get("request_id", "missing")),
                    error_code=error_code if isinstance(error_code, str) else None,
                    operation=_operation_code(method, self.path),
                )
            except (OSError, ValueError):
                if event_log_healthy:
                    print("EVENT_LOG_UNAVAILABLE", file=sys.stderr)
                self.server.event_log_healthy = False  # type: ignore[attr-defined]
            else:
                self.server.event_log_healthy = True  # type: ignore[attr-defined]
        self._write(status, payload)

    def _write(self, status: int, payload: dict[str, Any]) -> None:
        data = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if self.close_connection:
                self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)
        except OSError:
            # The operation may already be complete; a peer disconnect is not a
            # server fault and must not emit native socket details or a traceback.
            self.close_connection = True

    def _handle_asr_websocket(self) -> None:
        request_id = secrets.token_hex(16)
        connection_tokens = {
            token.strip().lower()
            for token in self.headers.get("Connection", "").split(",")
            if token.strip()
        }
        if self.request_version != "HTTP/1.1" or "upgrade" not in connection_tokens:
            self._write(400, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        member_id = self.headers.get("X-Edge-Member-Id", "")
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,64}", member_id):
            self._write(422, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        headers = {key.lower(): value for key, value in self.headers.items()}
        app: DeviceApplication = self.server.application  # type: ignore[attr-defined]
        allowed, auth_code = app.authorize_member_request(headers, member_id)
        if not allowed:
            status = 401 if auth_code == "AUTH_REQUIRED" else 403
            self._write(status, {"status": "error", "error": {"code": auth_code}})
            return
        origin = self.headers.get("Origin")
        if origin not in {None, "null"} and not re.fullmatch(
            r"http://(?:127\.0\.0\.1|localhost)(?::[0-9]{1,5})?", origin
        ):
            self._write(403, {"status": "error", "error": {"code": "AUTH_INVALID"}})
            return
        if self.headers.get("Sec-WebSocket-Version") != "13":
            self._write(400, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        try:
            accept = websocket_accept(self.headers.get("Sec-WebSocket-Key", ""))
        except WebSocketProtocolError:
            self._write(400, {"status": "error", "error": {"code": "INPUT_INVALID"}})
            return
        self.send_response(101, "Switching Protocols")
        self.send_header("Upgrade", "websocket")
        self.send_header("Connection", "Upgrade")
        self.send_header("Sec-WebSocket-Accept", accept)
        self.end_headers()
        self.wfile.flush()

        session = None
        final_code = "NONE"
        try:
            while True:
                opcode, payload = read_client_frame(
                    self.rfile, max_payload_bytes=64 * 1024
                )
                if opcode == 0x8:
                    if session is not None:
                        session.cancel()
                    write_server_frame(self.wfile, 0x8, payload)
                    break
                if opcode == 0x9:
                    write_server_frame(self.wfile, 0xA, payload)
                    continue
                if opcode == 0x2:
                    if session is None:
                        raise TaskStateError("INPUT_INVALID", "start message is required")
                    write_json(self.wfile, session.feed(payload))
                    continue
                if opcode != 0x1:
                    continue
                try:
                    message = json.loads(payload.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise TaskStateError("INPUT_INVALID", "invalid websocket JSON") from exc
                if not isinstance(message, dict):
                    raise TaskStateError("INPUT_INVALID", "websocket message must be an object")
                message_type = message.get("type")
                if message_type == "start" and session is None:
                    session = app.open_asr_stream(member_id, message)
                    write_json(
                        self.wfile,
                        {"type": "started", "raw_audio_persisted": False},
                    )
                elif message_type == "stop" and session is not None:
                    write_json(self.wfile, session.finish())
                    write_server_frame(self.wfile, 0x8)
                    break
                elif message_type == "cancel" and session is not None:
                    session.cancel()
                    write_json(self.wfile, {"type": "cancelled"})
                    write_server_frame(self.wfile, 0x8)
                    break
                else:
                    raise TaskStateError("INPUT_INVALID", "invalid websocket state transition")
        except (TaskStateError, WebSocketProtocolError, TimeoutError, OSError) as exc:
            if session is not None:
                session.cancel()
            final_code = exc.code if isinstance(exc, TaskStateError) else "INPUT_INVALID"
            try:
                write_json(self.wfile, {"type": "error", "error": {"code": final_code}})
                write_server_frame(self.wfile, 0x8)
            except OSError:
                pass
        except Exception:
            if session is not None:
                session.cancel()
            final_code = "INTERNAL_ERROR"
            try:
                write_json(self.wfile, {"type": "error", "error": {"code": final_code}})
                write_server_frame(self.wfile, 0x8)
            except OSError:
                pass
        finally:
            event_log: PrivacySafeEventLog | None = getattr(self.server, "event_log", None)
            if event_log is not None:
                event_log.request_completed(
                    status=101,
                    request_id=request_id,
                    error_code=None if final_code == "NONE" else final_code,
                    operation="ASR_STREAM",
                )


def _operation_code(method: str, path: str) -> str:
    route_path = path.partition("?")[0]
    if method == "GET" and route_path == "/v1/health":
        return "HEALTH_STATUS"
    if method == "GET" and route_path == "/v1/version":
        return "VERSION_READ"
    if method == "POST" and route_path == "/v1/health/evaluate":
        return "HEALTH_EVALUATE"
    if method == "POST" and route_path == "/v1/ocr/tasks":
        return "OCR_TASK_CREATE"
    if re.fullmatch(r"/v1/tasks/[0-9a-f]{32}", route_path):
        return "TASK_READ" if method == "GET" else "TASK_CANCEL"
    if method == "POST" and route_path == "/v1/records/confirm":
        return "RECORD_CONFIRM"
    if re.fullmatch(r"/v1/members/[A-Za-z0-9._-]{1,64}/records", route_path):
        return "RECORD_LIST"
    if re.fullmatch(
        r"/v1/members/[A-Za-z0-9._-]{1,64}/records/[0-9a-f]{32}/correct",
        route_path,
    ):
        return "RECORD_CORRECT"
    if re.fullmatch(
        r"/v1/members/[A-Za-z0-9._-]{1,64}/records/[0-9a-f]{32}", route_path
    ):
        return "RECORD_DELETE"
    if re.fullmatch(
        r"/v1/members/[A-Za-z0-9._-]{1,64}/withdraw-consent", route_path
    ):
        return "CONSENT_WITHDRAW"
    return "UNKNOWN"


def _read_http_body(stream: Any, length: int) -> bytes:
    body = bytearray()
    while len(body) < length:
        chunk = stream.read(length - len(body))
        if not chunk:
            raise ValueError("truncated HTTP request body")
        body.extend(chunk)
    return bytes(body)


def build_application(
    database: Path,
    token: str | None,
    engineering: bool,
    *,
    authorizer: TokenAuthorizer | None = None,
    release_id: str | None = None,
    ocr_adapter: ComponentAdapter | None = None,
    asr_adapter: ComponentAdapter | None = None,
    runtime_product_accepted: bool = False,
) -> DeviceApplication:
    if not engineering:
        raise StoragePolicyError(
            "product mode is blocked until an approved encryption-at-rest codec is configured"
        )
    store = RecordStore(
        database,
        PlaintextEngineeringCodec(),
        allow_unencrypted_engineering=True,
    )
    if authorizer is None:
        if token is None:
            store.close()
            raise ValueError("a token or explicit authorizer is required")
        authorizer = TokenAuthorizer.engineering_wildcard(token)
    return DeviceApplication(
        store,
        authorizer,
        release_id=release_id,
        ocr_adapter=ocr_adapter,
        asr_adapter=asr_adapter,
        runtime_product_accepted=runtime_product_accepted,
    )


def _close_server_resources(
    server: BoundedThreadingHTTPServer, application: DeviceApplication
) -> None:
    try:
        # With non-daemon handler threads, this closes the listener and waits for
        # active requests before the shared RecordStore is closed.
        server.server_close()
    finally:
        application.store.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18100)
    parser.add_argument("--database", type=Path, default=ROOT / "runtime" / "edge_engineering.db")
    parser.add_argument("--event-log", type=Path, default=ROOT / "runtime" / "events.jsonl")
    parser.add_argument("--auth-grants", type=Path)
    parser.add_argument("--runtime-config", type=Path)
    parser.add_argument("--backend-registry", type=Path)
    parser.add_argument("--backend-selection", type=Path)
    parser.add_argument("--release-manifest", type=Path)
    parser.add_argument("--engineering", action="store_true")
    args = parser.parse_args()
    if args.host != "127.0.0.1":
        raise SystemExit("refusing to bind outside 127.0.0.1")
    token = os.environ.get("EDGE_LOCAL_TOKEN")
    authorizer = None
    if args.auth_grants is not None:
        authorizer = TokenAuthorizer.from_environment_config(args.auth_grants, os.environ)
    elif not token:
        if not args.engineering:
            raise SystemExit("--auth-grants is required outside engineering mode")
        token = secrets.token_urlsafe(32)
        token_path = ROOT / "runtime" / "engineering_token.txt"
        token_path.parent.mkdir(parents=True, exist_ok=True)
        token_path.write_text(token + "\n", encoding="utf-8")
        if os.name != "nt":
            token_path.chmod(0o600)
        print(f"Engineering token written to {token_path}", file=sys.stderr)
    backend_paths = (
        args.runtime_config,
        args.backend_registry,
        args.backend_selection,
    )
    if any(path is not None for path in backend_paths) and not all(
        path is not None for path in backend_paths
    ):
        raise SystemExit(
            "--runtime-config, --backend-registry and --backend-selection must be provided together"
        )
    if not args.engineering and not all(path is not None for path in backend_paths):
        raise SystemExit("product mode requires all runtime backend control files")
    if not args.engineering:
        if args.release_manifest is None:
            raise SystemExit("product mode requires --release-manifest")
        try:
            release_id = load_verified_release_id(args.release_manifest)
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    else:
        release_id = os.environ.get("EDGE_RELEASE_ID")
    adapters = None
    if args.runtime_config is not None:
        assert args.backend_registry is not None and args.backend_selection is not None
        adapters = load_runtime_adapters(
            args.runtime_config,
            engineering=args.engineering,
            registry_path=args.backend_registry,
            selection_path=args.backend_selection,
        )
    application = build_application(
        args.database,
        token,
        args.engineering,
        authorizer=authorizer,
        release_id=release_id,
        ocr_adapter=adapters.ocr if adapters is not None else None,
        asr_adapter=adapters.asr if adapters is not None else None,
        runtime_product_accepted=(
            adapters.product_mode if adapters is not None else False
        ),
    )
    server = BoundedThreadingHTTPServer((args.host, args.port), DeviceRequestHandler)
    server.application = application  # type: ignore[attr-defined]
    server.event_log = PrivacySafeEventLog(args.event_log)  # type: ignore[attr-defined]
    server.event_log_healthy = True  # type: ignore[attr-defined]
    try:
        server.serve_forever(poll_interval=0.25)
    finally:
        _close_server_resources(server, application)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
