from __future__ import annotations

import re
import secrets
import uuid
import json
import sqlite3
import base64
import binascii
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from collections.abc import Mapping
from typing import Any, Protocol
from urllib.parse import parse_qs, urlsplit

from health_rules import RuleInputError, evaluate_payload
from integration_adapter import (
    COMPONENT_CONTRACT_VERSION,
    ComponentContractError,
    ComponentOperationError,
    normalize_component_health,
)
from storage import RecordStore, TaskStateError
from asr_runtime import AsrStreamSession
from ocr_runtime import normalize_ocr_input, validate_ocr_result


_RELEASE_ID = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,78}[A-Za-z0-9])?$")


class ComponentAdapter(Protocol):
    name: str

    def health(self) -> dict[str, Any]: ...

    def create_task(self, member_id: str, payload: dict[str, Any]) -> dict[str, Any]: ...


class UnavailableAdapter:
    def __init__(self, name: str, reason: str) -> None:
        self.name = name
        self.reason = reason

    def health(self) -> dict[str, Any]:
        capabilities = {
            "ocr": ["confirmation_required", "local_only", "ocr_task"],
            "asr": [
                "asr_stream",
                "confirmation_required",
                "local_only",
                "raw_audio_memory_only",
            ],
        }.get(self.name, ["local_only"])
        return {
            "ready": False,
            "reason": self.reason,
            "contract_version": COMPONENT_CONTRACT_VERSION,
            "component_version": "0.0.0",
            "capabilities": capabilities,
        }

    def create_task(self, member_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        raise TaskStateError("COMPONENT_NOT_READY", f"{self.name} 尚未完成端侧部署")


@dataclass(frozen=True)
class AuthPrincipal:
    member_ids: frozenset[str]
    engineering_wildcard: bool = False

    def permits(self, member_id: str) -> bool:
        return self.engineering_wildcard or member_id in self.member_ids


class TokenAuthorizer:
    """Constant-time bearer-token authentication with explicit member scopes."""

    def __init__(
        self,
        grants: dict[str, set[str] | frozenset[str]],
        *,
        engineering_wildcard_tokens: set[str] | frozenset[str] = frozenset(),
    ) -> None:
        if not grants and not engineering_wildcard_tokens:
            raise ValueError("at least one local runtime token grant is required")
        entries: list[tuple[str, AuthPrincipal]] = []
        seen_tokens: set[str] = set()
        for token, member_ids in grants.items():
            self._validate_token(token)
            if token in seen_tokens:
                raise ValueError("duplicate runtime token grant")
            seen_tokens.add(token)
            cleaned = frozenset(member_id.strip() for member_id in member_ids if member_id.strip())
            if not cleaned:
                raise ValueError("a product token grant must contain at least one member_id")
            try:
                for member_id in cleaned:
                    _validate_member_id(member_id)
            except TaskStateError as exc:
                raise ValueError("auth grant contains an invalid member_id") from exc
            entries.append((token, AuthPrincipal(cleaned)))
        for token in engineering_wildcard_tokens:
            self._validate_token(token)
            if token in seen_tokens:
                raise ValueError("a runtime token cannot have multiple privilege scopes")
            seen_tokens.add(token)
            entries.append((token, AuthPrincipal(frozenset(), engineering_wildcard=True)))
        self._entries = tuple(entries)

    @staticmethod
    def _validate_token(token: str) -> None:
        if len(token) < 32:
            raise ValueError("local runtime token must contain at least 32 characters")

    @classmethod
    def engineering_wildcard(cls, token: str) -> "TokenAuthorizer":
        return cls({}, engineering_wildcard_tokens={token})

    @classmethod
    def from_environment_config(
        cls, path: Path, environment: Mapping[str, str]
    ) -> "TokenAuthorizer":
        config = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(config, dict) or not isinstance(config.get("grants"), list):
            raise ValueError("auth grants config must contain a grants list")
        grants: dict[str, set[str]] = {}
        seen_env: set[str] = set()
        for item in config["grants"]:
            if not isinstance(item, dict) or "token" in item:
                raise ValueError("auth config must reference environment variables, never raw tokens")
            token_env = item.get("token_env")
            member_ids = item.get("member_ids")
            if (
                not isinstance(token_env, str)
                or not re.fullmatch(r"EDGE_MEMBER_TOKEN_[A-Z0-9_]+", token_env)
                or token_env in seen_env
                or not isinstance(member_ids, list)
                or not all(isinstance(value, str) for value in member_ids)
            ):
                raise ValueError("invalid auth grant")
            token = environment.get(token_env)
            if token is None:
                raise ValueError(f"required token environment variable is missing: {token_env}")
            if token in grants:
                raise ValueError("two token environment variables resolve to the same secret")
            grants[token] = set(member_ids)
            seen_env.add(token_env)
        return cls(grants)

    def authenticate(self, headers: dict[str, str]) -> AuthPrincipal | None:
        authorization = headers.get("authorization", "")
        prefix = "Bearer "
        if not authorization.startswith(prefix):
            return None
        candidate = authorization[len(prefix) :]
        match: AuthPrincipal | None = None
        for token, principal in self._entries:
            if secrets.compare_digest(candidate, token):
                match = principal
        return match


class DeviceApplication:
    contract_version = "1.0.0"
    component_version = "0.2.0"
    component_capabilities = {
        "ocr": frozenset({"confirmation_required", "local_only", "ocr_task"}),
        "asr": frozenset(
            {
                "asr_stream",
                "confirmation_required",
                "local_only",
                "raw_audio_memory_only",
            }
        ),
    }

    def __init__(
        self,
        store: RecordStore,
        authorizer: TokenAuthorizer,
        *,
        ocr_adapter: ComponentAdapter | None = None,
        asr_adapter: ComponentAdapter | None = None,
        release_id: str | None = None,
        runtime_product_accepted: bool = False,
    ) -> None:
        self.store = store
        self.authorizer = authorizer
        self.ocr_adapter = ocr_adapter or UnavailableAdapter("ocr", "OCR_RKNN_NOT_READY")
        self.asr_adapter = asr_adapter or UnavailableAdapter("asr", "ASR_ARM64_NOT_READY")
        self.release_id = release_id
        self.runtime_product_accepted = runtime_product_accepted

    def _product_complete(
        self,
        storage: dict[str, Any],
        ocr: dict[str, Any],
        asr: dict[str, Any],
    ) -> bool:
        return bool(
            not self.store.engineering_only
            and self.runtime_product_accepted
            and isinstance(self.release_id, str)
            and _RELEASE_ID.fullmatch(self.release_id)
            and storage.get("ready") is True
            and storage.get("product_secure") is True
            and ocr.get("ready") is True
            and asr.get("ready") is True
        )

    def _component_health(self, name: str, adapter: ComponentAdapter) -> dict[str, Any]:
        try:
            return normalize_component_health(
                name,
                adapter.health(),
                required_capabilities=self.component_capabilities[name],
            )
        except ComponentContractError:
            reason = "COMPONENT_CONTRACT_INCOMPATIBLE"
        except Exception:
            reason = "COMPONENT_NOT_READY"
        return {
            "name": name,
            "ready": False,
            "contract_version": COMPONENT_CONTRACT_VERSION,
            "component_version": "0.0.0",
            "capabilities": [],
            "model_sha256": None,
            "reason": reason,
        }

    def _require_component_ready(self, name: str, adapter: ComponentAdapter) -> None:
        state = self._component_health(name, adapter)
        if not state["ready"]:
            code = state["reason"]
            if code not in {
                "COMPONENT_NOT_READY",
                "COMPONENT_TIMEOUT",
                "COMPONENT_BUSY",
                "COMPONENT_CIRCUIT_OPEN",
                "COMPONENT_CONTRACT_INCOMPATIBLE",
                "MODEL_HASH_MISMATCH",
            }:
                code = "COMPONENT_NOT_READY"
            raise TaskStateError(code, f"{name} runtime is unavailable")

    def _storage_health(self) -> dict[str, Any]:
        try:
            schema_version = self.store.schema_version()
        except Exception:
            return {
                "ready": False,
                "codec": self.store.codec.name,
                "product_secure": self.store.codec.secure_for_product,
                "schema_version": None,
                "reason": "STORAGE_UNAVAILABLE",
            }
        return {
            "ready": True,
            "codec": self.store.codec.name,
            "product_secure": self.store.codec.secure_for_product,
            "schema_version": schema_version,
            "reason": None,
        }

    def _response(
        self,
        result: Any,
        *,
        status: str = "success",
        request_id: str | None = None,
        task_id: str | None = None,
        requires_confirmation: bool = False,
        warnings: list[str] | None = None,
        error: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return {
            "status": status,
            "request_id": request_id or uuid.uuid4().hex,
            "task_id": task_id,
            "requires_confirmation": requires_confirmation,
            "contract_version": self.contract_version,
            "component_version": self.component_version,
            "result": result,
            "warnings": warnings or [],
            "error": error,
        }

    def authorize_member_request(
        self, headers: dict[str, str], member_id: str
    ) -> tuple[bool, str]:
        normalized = {key.lower(): value for key, value in headers.items()}
        principal = self.authorizer.authenticate(normalized)
        if principal is None:
            return False, "AUTH_REQUIRED"
        if not principal.permits(member_id):
            return False, "AUTH_INVALID"
        return True, "OK"

    def open_asr_stream(
        self, member_id: str, config: dict[str, Any]
    ) -> AsrStreamSession:
        _validate_member_id(member_id)
        if not hasattr(self.asr_adapter, "open_stream"):
            raise TaskStateError("COMPONENT_NOT_READY", "ASR streaming runtime is unavailable")
        try:
            # The isolated streaming adapter validates readiness, contract, capabilities,
            # and model hash in the same process that owns the stream. A separate health
            # preflight would load the ASR model twice and would still be subject to a
            # check/use race.
            return AsrStreamSession(self.store, self.asr_adapter, member_id, config)  # type: ignore[arg-type]
        except ComponentOperationError as exc:
            raise TaskStateError(exc.code, "ASR runtime operation failed") from exc
        except TaskStateError:
            raise
        except TimeoutError as exc:
            raise TaskStateError("COMPONENT_TIMEOUT", "ASR runtime timed out") from exc
        except Exception as exc:
            raise TaskStateError("COMPONENT_NOT_READY", "ASR runtime failed safely") from exc

    def dispatch(
        self,
        method: str,
        path: str,
        headers: dict[str, str] | None = None,
        body: dict[str, Any] | None = None,
    ) -> tuple[int, dict[str, Any]]:
        request_id = uuid.uuid4().hex
        normalized_headers = {key.lower(): value for key, value in (headers or {}).items()}
        payload = body or {}
        if method == "GET" and path == "/v1/health":
            storage = self._storage_health()
            ocr = self._component_health("ocr", self.ocr_adapter)
            asr = self._component_health("asr", self.asr_adapter)
            product_complete = self._product_complete(storage, ocr, asr)
            degraded = (
                not storage["ready"]
                or not ocr["ready"]
                or not asr["ready"]
                or (not self.store.engineering_only and not product_complete)
            )
            return 200, self._response(
                {
                    "status": "degraded" if degraded else (
                        "ok_engineering" if self.store.engineering_only else "ok"
                    ),
                    "network_scope": "loopback_only",
                    "storage": storage,
                    "health_rules": {
                        "ready": True,
                        "non_diagnostic": True,
                        "contract_version": COMPONENT_CONTRACT_VERSION,
                        "component_version": "1.0.0",
                        "capabilities": ["health_attention", "local_only"],
                    },
                    "ocr": ocr,
                    "asr": asr,
                    "product_complete": product_complete,
                },
                request_id=request_id,
            )
        principal = self.authorizer.authenticate(normalized_headers)
        if principal is None:
            return 401, self._response(
                None,
                status="error",
                request_id=request_id,
                error={"code": "AUTH_REQUIRED", "message": "A valid local token is required", "retryable": False},
            )

        try:
            if method == "GET" and path == "/v1/version":
                storage = self._storage_health()
                ocr = self._component_health("ocr", self.ocr_adapter)
                asr = self._component_health("asr", self.asr_adapter)
                return 200, self._response(
                    {
                        "contract_version": self.contract_version,
                        "component_version": self.component_version,
                        "release_id": self.release_id,
                        "database_schema_version": self.store.schema_version(),
                        "components": {
                            "ocr": ocr,
                            "asr": asr,
                            "health_rules": {
                                "ready": True,
                                "non_diagnostic": True,
                                "contract_version": COMPONENT_CONTRACT_VERSION,
                                "component_version": "1.0.0",
                                "capabilities": ["health_attention", "local_only"],
                            },
                        },
                        "product_complete": self._product_complete(storage, ocr, asr),
                    },
                    request_id=request_id,
                )
            if method == "POST" and path == "/v1/health/evaluate":
                member_id = _request_member_id(payload, normalized_headers)
                _require_member_access(principal, member_id)
                return 200, self._response(
                    evaluate_payload(payload), request_id=request_id
                )
            if method == "POST" and path == "/v1/ocr/tasks":
                member_id = _required_string(payload, "member_id")
                _validate_member_id(member_id)
                _require_member_access(principal, member_id)
                image = normalize_ocr_input(payload)
                self._require_component_ready("ocr", self.ocr_adapter)
                try:
                    adapter_result = self.ocr_adapter.create_task(
                        member_id, image.adapter_payload()
                    )
                except ComponentOperationError as exc:
                    raise TaskStateError(exc.code, "OCR runtime operation failed") from exc
                except TaskStateError:
                    raise
                except TimeoutError as exc:
                    raise TaskStateError("COMPONENT_TIMEOUT", "OCR runtime timed out") from exc
                except Exception as exc:
                    raise TaskStateError("COMPONENT_NOT_READY", "OCR runtime failed safely") from exc
                result = validate_ocr_result(adapter_result)
                task = self.store.create_task(member_id, "ocr", result)
                return 202, self._response(
                    task,
                    request_id=request_id,
                    task_id=task["task_id"],
                    requires_confirmation=True,
                )
            task_match = re.fullmatch(r"/v1/tasks/([0-9a-f]{32})", path)
            if task_match and method == "GET":
                member_id = _request_member_id(payload, normalized_headers)
                _require_member_access(principal, member_id)
                task = self.store.get_task(task_match.group(1), member_id)
                return 200, self._response(
                    task,
                    request_id=request_id,
                    task_id=task["task_id"],
                    requires_confirmation=task["requires_confirmation"],
                )
            if task_match and method == "DELETE":
                member_id = _request_member_id(payload, normalized_headers)
                _require_member_access(principal, member_id)
                deleted = self.store.cancel_task(task_match.group(1), member_id)
                return 200, self._response({"deleted": deleted}, request_id=request_id)
            if method == "POST" and path == "/v1/records/confirm":
                member_id = _required_string(payload, "member_id")
                _validate_member_id(member_id)
                _require_member_access(principal, member_id)
                task_id = _required_string(payload, "task_id")
                if re.fullmatch(r"[0-9a-f]{32}", task_id) is None:
                    raise TaskStateError("INPUT_INVALID", "task_id format is invalid")
                idempotency_key = _required_string(payload, "idempotency_key")
                confirmed_fields = payload.get("confirmed_fields")
                if not isinstance(confirmed_fields, dict):
                    raise TaskStateError("INPUT_INVALID", "confirmed_fields 必须是对象")
                record, replayed = self.store.confirm_task(
                    task_id, member_id, idempotency_key, confirmed_fields
                )
                return 200, self._response(
                    {"record": record, "idempotent_replay": replayed},
                    request_id=request_id,
                )
            record_page = _parse_record_list_request(path) if method == "GET" else None
            if record_page is not None:
                member_id, limit, after = record_page
                _require_member_access(principal, member_id)
                records, has_more = self.store.list_records_page(
                    member_id, limit=limit, after=after
                )
                return 200, self._response(
                    {
                        "records": records,
                        "has_more": has_more,
                        "next_cursor": _record_cursor(records[-1])
                        if has_more and records
                        else None,
                    },
                    request_id=request_id,
                )
            delete_match = re.fullmatch(
                r"/v1/members/([A-Za-z0-9._-]{1,64})/records/([0-9a-f]{32})", path
            )
            if delete_match and method == "DELETE":
                _require_member_access(principal, delete_match.group(1))
                deleted = self.store.delete_record(delete_match.group(1), delete_match.group(2))
                return 200, self._response({"deleted": deleted}, request_id=request_id)
            correct_match = re.fullmatch(
                r"/v1/members/([A-Za-z0-9._-]{1,64})/records/([0-9a-f]{32})/correct",
                path,
            )
            if correct_match and method == "POST":
                member_id, record_id = correct_match.groups()
                _require_member_access(principal, member_id)
                corrected_fields = payload.get("confirmed_fields")
                expected_version = payload.get("expected_version")
                if not isinstance(corrected_fields, dict) or not isinstance(expected_version, int):
                    raise TaskStateError(
                        "INPUT_INVALID", "confirmed_fields and expected_version are required"
                    )
                record = self.store.correct_record(
                    member_id, record_id, corrected_fields, expected_version
                )
                return 200, self._response({"record": record}, request_id=request_id)
            withdraw_match = re.fullmatch(
                r"/v1/members/([A-Za-z0-9._-]{1,64})/withdraw-consent", path
            )
            if withdraw_match and method == "POST":
                member_id = withdraw_match.group(1)
                _require_member_access(principal, member_id)
                if payload.get("confirmed") is not True:
                    raise TaskStateError("INPUT_INVALID", "explicit confirmation is required")
                deleted = self.store.withdraw_member(member_id)
                return 200, self._response(deleted, request_id=request_id)
        except RuleInputError as exc:
            return 422, self._response(
                None,
                status="error",
                request_id=request_id,
                error={"code": exc.code, "message": str(exc), "retryable": False},
            )
        except TaskStateError as exc:
            status_map = {
                "INPUT_INVALID": 422,
                "TASK_NOT_CONFIRMED": 409,
                "TASK_NOT_FOUND": 404,
                "TASK_EXPIRED": 410,
                "TASK_ALREADY_CONFIRMED": 409,
                "STORAGE_CONFLICT": 409,
                "COMPONENT_NOT_READY": 503,
                "COMPONENT_TIMEOUT": 504,
                "COMPONENT_BUSY": 503,
                "COMPONENT_CIRCUIT_OPEN": 503,
                "COMPONENT_CONTRACT_INCOMPATIBLE": 503,
                "STORAGE_UNAVAILABLE": 503,
                "INPUT_OUT_OF_RANGE": 422,
                "MODEL_HASH_MISMATCH": 503,
                "AUTH_INVALID": 403,
            }
            retryable = exc.code in {
                "COMPONENT_NOT_READY",
                "COMPONENT_TIMEOUT",
                "COMPONENT_BUSY",
                "COMPONENT_CIRCUIT_OPEN",
                "STORAGE_UNAVAILABLE",
            }
            return status_map.get(exc.code, 500), self._response(
                None,
                status="error",
                request_id=request_id,
                error={"code": exc.code, "message": str(exc), "retryable": retryable},
            )
        except (sqlite3.Error, OSError):
            return 503, self._response(
                None,
                status="error",
                request_id=request_id,
                error={
                    "code": "STORAGE_UNAVAILABLE",
                    "message": "Local storage is unavailable",
                    "retryable": True,
                },
            )
        return 404, self._response(
            None,
            status="error",
            request_id=request_id,
            error={"code": "TASK_NOT_FOUND", "message": "接口不存在", "retryable": False},
        )


def _required_string(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip() or len(value) > 128:
        raise TaskStateError("INPUT_INVALID", f"{key} 必须是非空字符串")
    return value.strip()


def _validate_member_id(member_id: str) -> None:
    if re.fullmatch(r"[A-Za-z0-9._-]{1,64}", member_id) is None:
        raise TaskStateError("INPUT_INVALID", "member_id 格式无效")


def _request_member_id(payload: dict[str, Any], headers: dict[str, str]) -> str:
    header_value = headers.get("x-edge-member-id")
    body_value = payload.get("member_id")
    if header_value is not None and body_value is not None and header_value != body_value:
        raise TaskStateError("INPUT_INVALID", "member_id header and body disagree")
    value = header_value if header_value is not None else body_value
    if not isinstance(value, str):
        raise TaskStateError("INPUT_INVALID", "X-Edge-Member-Id is required")
    value = value.strip()
    _validate_member_id(value)
    return value


def _require_member_access(principal: AuthPrincipal, member_id: str) -> None:
    if not principal.permits(member_id):
        raise TaskStateError("AUTH_INVALID", "The token is not authorized for this member")


def _parse_record_list_request(
    path: str,
) -> tuple[str, int, tuple[str, str] | None] | None:
    split = urlsplit(path)
    match = re.fullmatch(
        r"/v1/members/([A-Za-z0-9._-]{1,64})/records", split.path
    )
    if match is None:
        return None
    if split.fragment:
        raise TaskStateError("INPUT_INVALID", "record page query is invalid")
    try:
        query = parse_qs(
            split.query,
            keep_blank_values=True,
            strict_parsing=True,
            max_num_fields=2,
        )
    except ValueError as exc:
        raise TaskStateError("INPUT_INVALID", "record page query is invalid") from exc
    if set(query) - {"limit", "cursor"} or any(len(values) != 1 for values in query.values()):
        raise TaskStateError("INPUT_INVALID", "record page query is invalid")
    raw_limit = query.get("limit", ["100"])[0]
    if not re.fullmatch(r"[1-9][0-9]{0,2}", raw_limit):
        raise TaskStateError("INPUT_INVALID", "record page limit is invalid")
    limit = int(raw_limit)
    if limit > 100:
        raise TaskStateError("INPUT_INVALID", "record page limit is invalid")
    after = _decode_record_cursor(query["cursor"][0]) if "cursor" in query else None
    return match.group(1), limit, after


def _decode_record_cursor(value: str) -> tuple[str, str]:
    if not value or len(value) > 512 or not re.fullmatch(r"[A-Za-z0-9_-]+", value):
        raise TaskStateError("INPUT_INVALID", "record page cursor is invalid")
    try:
        padding = "=" * ((4 - len(value) % 4) % 4)
        decoded = base64.b64decode(value + padding, altchars=b"-_", validate=True)
        cursor = json.loads(decoded.decode("utf-8"))
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError, binascii.Error) as exc:
        raise TaskStateError("INPUT_INVALID", "record page cursor is invalid") from exc
    if (
        not isinstance(cursor, dict)
        or set(cursor) != {"created_at", "record_id"}
        or not isinstance(cursor["created_at"], str)
        or len(cursor["created_at"]) > 64
        or not isinstance(cursor["record_id"], str)
        or re.fullmatch(r"[0-9a-f]{32}", cursor["record_id"]) is None
    ):
        raise TaskStateError("INPUT_INVALID", "record page cursor is invalid")
    try:
        timestamp = datetime.fromisoformat(cursor["created_at"])
    except ValueError as exc:
        raise TaskStateError("INPUT_INVALID", "record page cursor is invalid") from exc
    if timestamp.tzinfo is None:
        raise TaskStateError("INPUT_INVALID", "record page cursor is invalid")
    return cursor["created_at"], cursor["record_id"]


def _record_cursor(record: dict[str, Any]) -> str:
    encoded = json.dumps(
        {"created_at": record["created_at"], "record_id": record["record_id"]},
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return base64.urlsafe_b64encode(encoded).rstrip(b"=").decode("ascii")
