from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path

from asr_runtime.worker import load_and_verify_manifest as load_asr_manifest
from integration_adapter import CircuitBreakerPolicy, JsonLineProcessAdapter, ProcessLimits
from ocr_runtime.rknn_worker import (
    ModelIntegrityError,
    load_and_verify_manifest as load_ocr_manifest,
)
from runtime_backends import BackendRegistryError, load_registry, load_selection


MAX_CONFIG_BYTES = 64 * 1024
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_SEMVER = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
_TOP_LEVEL = {"schema_version", "mode", "product_accepted", "asr", "ocr"}
_ASR_FIELDS = {
    "enabled",
    "backend_id",
    "python_module",
    "model_id",
    "model_dir",
    "manifest",
    "runtime_name",
    "runtime_version",
    "contract_version",
    "component_version",
    "model_bundle_sha256",
    "operation_timeout_seconds",
    "max_inflight_requests",
    "circuit_failure_threshold",
    "circuit_recovery_seconds",
}
_OCR_FIELDS = {
    "enabled",
    "backend_id",
    "python_module",
    "model_id",
    "manifest",
    "runtime_name",
    "runtime_version",
    "contract_version",
    "component_version",
    "model_bundle_sha256",
    "operation_timeout_seconds",
    "max_inflight_requests",
    "circuit_failure_threshold",
    "circuit_recovery_seconds",
}


class RuntimeBootstrapError(ValueError):
    """Raised when a local runtime configuration is unsafe or incomplete."""


@dataclass(frozen=True)
class RuntimeAdapters:
    asr: JsonLineProcessAdapter | None
    ocr: JsonLineProcessAdapter | None = None
    product_mode: bool = False


def _release_path(root: Path, relative: object, *, directory: bool) -> Path:
    if not isinstance(relative, str):
        raise RuntimeBootstrapError("runtime path is missing")
    candidate = Path(relative)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise RuntimeBootstrapError("runtime path must stay release-relative")
    unresolved = root
    for part in candidate.parts:
        unresolved = unresolved / part
        if unresolved.is_symlink():
            raise RuntimeBootstrapError("runtime path cannot contain symlinks")
    path = unresolved.resolve()
    if not path.is_relative_to(root):
        raise RuntimeBootstrapError("runtime path escapes release root")
    if path.is_symlink() or (directory and not path.is_dir()) or (not directory and not path.is_file()):
        raise RuntimeBootstrapError("runtime path is missing or unsafe")
    return path


def _release_config_path(root: Path, path: Path) -> Path:
    candidate = path.absolute()
    if candidate.is_symlink() or candidate.parent.is_symlink():
        raise RuntimeBootstrapError("backend control file is unsafe")
    try:
        resolved = candidate.resolve(strict=True)
    except OSError as exc:
        raise RuntimeBootstrapError("backend control file is missing") from exc
    if not resolved.is_relative_to(root) or not resolved.is_file():
        raise RuntimeBootstrapError("backend control file is outside release root")
    return resolved


def _process_policy(config: dict[str, object], component: str) -> tuple[ProcessLimits, CircuitBreakerPolicy]:
    try:
        return (
            ProcessLimits(
                operation_timeout_seconds=config["operation_timeout_seconds"],
                max_inflight_requests=config["max_inflight_requests"],
            ),
            CircuitBreakerPolicy(
                failure_threshold=config["circuit_failure_threshold"],
                recovery_timeout_seconds=config["circuit_recovery_seconds"],
            ),
        )
    except (TypeError, ValueError, KeyError) as exc:
        raise RuntimeBootstrapError(f"{component} runtime limits are invalid") from exc


def _build_asr_adapter(
    release_root: Path,
    config: dict[str, object],
    selected: object,
    *,
    product_mode: bool,
) -> JsonLineProcessAdapter:
    if (
        set(config) != _ASR_FIELDS
        or config.get("enabled") is not True
        or config.get("backend_id") != selected.backend_id
        or config.get("python_module") != "asr_runtime.worker"
        or config.get("model_id") != selected.model_id
        or config.get("runtime_name") != selected.runtime_name
        or not isinstance(config.get("runtime_version"), str)
        or _SEMVER.fullmatch(config["runtime_version"]) is None
        or not isinstance(config.get("contract_version"), str)
        or _SEMVER.fullmatch(config["contract_version"]) is None
        or not isinstance(config.get("component_version"), str)
        or _SEMVER.fullmatch(config["component_version"]) is None
        or not isinstance(config.get("model_bundle_sha256"), str)
        or _SHA256.fullmatch(config["model_bundle_sha256"]) is None
        or selected.implementation_module != config["python_module"]
        or selected.runtime_version != config["runtime_version"]
        or selected.contract_version != config["contract_version"]
        or selected.component_version != config["component_version"]
        or selected.model_bundle_sha256 != config["model_bundle_sha256"]
    ):
        raise RuntimeBootstrapError("ASR runtime config and selected backend do not match")
    model_dir = _release_path(release_root, config["model_dir"], directory=True)
    manifest_path = _release_path(release_root, config["manifest"], directory=False)
    try:
        manifest = load_asr_manifest(
            model_dir,
            manifest_path,
            expected_product_mode=product_mode,
        )
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError, ModelIntegrityError) as exc:
        raise RuntimeBootstrapError("ASR model manifest verification failed") from exc
    if (
        manifest.get("model_bundle_sha256") != config["model_bundle_sha256"]
        or manifest.get("runtime_version") != config["runtime_version"]
        or manifest.get("product_accepted") is not product_mode
    ):
        raise RuntimeBootstrapError("ASR runtime and model pins do not match")
    limits, breaker = _process_policy(config, "ASR")
    command = [
        sys.executable,
        "-m",
        "asr_runtime.worker",
        "--model-dir",
        str(model_dir),
        "--manifest",
        str(manifest_path),
        "--runtime-version",
        config["runtime_version"],
    ]
    if product_mode:
        command.append("--product-mode")
    return JsonLineProcessAdapter(
        "asr",
        command,
        required_capabilities=(
            "asr_stream",
            "confirmation_required",
            "local_only",
            "raw_audio_memory_only",
        ),
        limits=limits,
        breaker_policy=breaker,
        expected_model_sha256=config["model_bundle_sha256"],
        cwd=release_root,
    )


def _build_ocr_adapter(
    release_root: Path,
    config: dict[str, object],
    selected: object,
    *,
    product_mode: bool,
) -> JsonLineProcessAdapter:
    if (
        set(config) != _OCR_FIELDS
        or config.get("enabled") is not True
        or config.get("backend_id") != selected.backend_id
        or config.get("python_module") != "ocr_runtime.rknn_worker"
        or config.get("model_id") != selected.model_id
        or config.get("runtime_name") != selected.runtime_name
        or not isinstance(config.get("runtime_version"), str)
        or _SEMVER.fullmatch(config["runtime_version"]) is None
        or not isinstance(config.get("contract_version"), str)
        or _SEMVER.fullmatch(config["contract_version"]) is None
        or not isinstance(config.get("component_version"), str)
        or _SEMVER.fullmatch(config["component_version"]) is None
        or not isinstance(config.get("model_bundle_sha256"), str)
        or _SHA256.fullmatch(config["model_bundle_sha256"]) is None
        or selected.implementation_module != config["python_module"]
        or selected.runtime_version != config["runtime_version"]
        or selected.contract_version != config["contract_version"]
        or selected.component_version != config["component_version"]
        or selected.model_bundle_sha256 != config["model_bundle_sha256"]
    ):
        raise RuntimeBootstrapError("OCR runtime config and selected backend do not match")
    manifest_path = _release_path(release_root, config["manifest"], directory=False)
    try:
        manifest = load_ocr_manifest(
            release_root,
            manifest_path,
            expected_product_mode=product_mode,
        ).manifest
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        raise RuntimeBootstrapError("OCR model manifest verification failed") from exc
    if (
        manifest.get("model_bundle_sha256") != config["model_bundle_sha256"]
        or manifest.get("runtime_version") != config["runtime_version"]
        or manifest.get("product_accepted") is not product_mode
    ):
        raise RuntimeBootstrapError("OCR runtime and model pins do not match")
    limits, breaker = _process_policy(config, "OCR")
    command = [
        sys.executable,
        "-m",
        "ocr_runtime.rknn_worker",
        "--release-root",
        str(release_root),
        "--manifest",
        str(manifest_path),
    ]
    if product_mode:
        command.append("--product-mode")
    return JsonLineProcessAdapter(
        "ocr",
        command,
        required_capabilities=("confirmation_required", "local_only", "ocr_task"),
        limits=limits,
        breaker_policy=breaker,
        expected_model_sha256=config["model_bundle_sha256"],
        cwd=release_root,
    )


def load_runtime_adapters(
    config_path: Path,
    *,
    engineering: bool,
    registry_path: Path,
    selection_path: Path,
) -> RuntimeAdapters:
    """Create allowlisted local adapters from a release-bound configuration."""

    product_mode = not engineering
    config_input = config_path.absolute()
    if config_input.is_symlink() or config_input.parent.is_symlink():
        raise RuntimeBootstrapError("runtime config is unsafe")
    config = config_input.resolve(strict=True)
    if config.stat().st_size > MAX_CONFIG_BYTES:
        raise RuntimeBootstrapError("runtime config is unsafe")
    release_root = config.parent.parent.resolve(strict=True)
    if not config.is_relative_to(release_root):
        raise RuntimeBootstrapError("runtime config is outside release root")
    try:
        payload = json.loads(config.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeBootstrapError("runtime config is invalid") from exc
    expected_mode = (
        "PRODUCT_SELECTED_BACKENDS"
        if product_mode
        else "ENGINEERING_SELECTED_BACKENDS"
    )
    if (
        not isinstance(payload, dict)
        or set(payload) != _TOP_LEVEL
        or payload.get("schema_version") != "1.0.0"
        or payload.get("mode") != expected_mode
        or payload.get("product_accepted") is not product_mode
    ):
        raise RuntimeBootstrapError("runtime config boundary is invalid")
    registry_file = _release_config_path(release_root, registry_path)
    selection_file = _release_config_path(release_root, selection_path)
    try:
        registry = load_registry(registry_file)
        selection = load_selection(
            registry=registry,
            path=selection_file,
            product_mode=product_mode,
        )
    except BackendRegistryError as exc:
        raise RuntimeBootstrapError(f"backend selection rejected: {exc.code}") from exc
    asr = payload.get("asr")
    if not isinstance(asr, dict):
        raise RuntimeBootstrapError("ASR runtime config is invalid")
    asr_adapter = _build_asr_adapter(
        release_root,
        asr,
        selection.asr,
        product_mode=product_mode,
    )
    ocr = payload.get("ocr")
    if selection.ocr is None:
        if ocr != {"enabled": False}:
            raise RuntimeBootstrapError("disabled OCR config does not match backend selection")
        ocr_adapter = None
    else:
        if not isinstance(ocr, dict):
            raise RuntimeBootstrapError("OCR runtime config is invalid")
        ocr_adapter = _build_ocr_adapter(
            release_root,
            ocr,
            selection.ocr,
            product_mode=product_mode,
        )
    return RuntimeAdapters(
        asr=asr_adapter,
        ocr=ocr_adapter,
        product_mode=product_mode,
    )
