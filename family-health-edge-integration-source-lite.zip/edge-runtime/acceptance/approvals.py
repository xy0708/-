from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from acceptance.paths import has_redirected_component


REQUIRED_EXTERNAL_GATES = frozenset(
    {
        "product_scope_approval",
        "classification_legal_opinion",
        "privacy_legal_review",
        "ocr_commercial_distribution_opinion",
        "asr_commercial_distribution_opinion",
        "management_runtime_distribution_opinion",
        "ocr_acceptance_data_rights_approval",
        "asr_acceptance_data_rights_approval",
        "health_rules_approval",
        "acceptance_threshold_approval",
        "encryption_key_design_approval",
        "security_threat_model_approval",
        "rk3566_independent_acceptance",
        "release_signing_key_provisioning",
        "release_approval",
    }
)
ACCEPTANCE_DATA_GATES = {
    "ocr": "ocr_acceptance_data_rights_approval",
    "asr": "asr_acceptance_data_rights_approval",
}
APPROVAL_BINDING_GATES = frozenset(
    {
        "privacy_legal_review",
        "ocr_acceptance_data_rights_approval",
        "asr_acceptance_data_rights_approval",
    }
)
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}")
PLACEHOLDER_APPROVERS = {"tbd", "unknown", "pending", "test", "demo", "none"}
MAX_APPROVAL_EVIDENCE_BYTES = 64 * 1024 * 1024


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_gate_registry(root: Path) -> dict[str, Any]:
    value = json.loads(
        (root / "configs" / "product_gate_evidence.json").read_text(encoding="utf-8")
    )
    if not isinstance(value, dict):
        raise ValueError("EXTERNAL_GATE_REGISTRY_NOT_OBJECT")
    return value


def gate_registry_errors(value: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if value.get("schema_version") != "1.0.0":
        errors.append("REGISTRY_SCHEMA_INVALID")
    gates = value.get("gates")
    if not isinstance(gates, dict):
        return [*errors, "REGISTRY_GATES_INVALID"]
    names = set(gates)
    for name in sorted(REQUIRED_EXTERNAL_GATES - names):
        errors.append(f"REQUIRED_GATE_MISSING:{name}")
    for name in sorted(names - REQUIRED_EXTERNAL_GATES):
        errors.append(f"UNEXPECTED_GATE:{name}")
    return errors


def _approval_time_is_valid(value: object) -> bool:
    if not isinstance(value, str) or not value.strip():
        return False
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return False
    return parsed.astimezone(timezone.utc) <= datetime.now(timezone.utc) + timedelta(
        minutes=5
    )


def approval_gate_errors(
    root: Path, value: dict[str, Any], gate_name: str
) -> list[str]:
    gates = value.get("gates")
    if not isinstance(gates, dict) or gate_name not in gates:
        return ["MISSING"]
    gate = gates[gate_name]
    if not isinstance(gate, dict):
        return ["RECORD_INVALID"]
    if gate.get("approved") is not True:
        return ["NOT_APPROVED"]
    errors: list[str] = []
    approver = gate.get("approved_by")
    if (
        not isinstance(approver, str)
        or not 2 <= len(approver.strip()) <= 128
        or approver != approver.strip()
        or any(character.isspace() and character not in {" ", "\t"} for character in approver)
        or not any(character.isalpha() for character in approver)
        or approver.strip().lower() in PLACEHOLDER_APPROVERS
    ):
        errors.append("APPROVER_INVALID")
    if not _approval_time_is_valid(gate.get("approved_at")):
        errors.append("APPROVED_AT_INVALID")
    relative = gate.get("evidence_file")
    expected_hash = gate.get("evidence_sha256")
    if not isinstance(relative, str) or not relative.strip():
        errors.append("EVIDENCE_PATH_INVALID")
        return errors
    relative_path = Path(relative)
    if relative_path.is_absolute() or ".." in relative_path.parts:
        errors.append("EVIDENCE_PATH_INVALID")
        return errors
    if not isinstance(expected_hash, str) or not SHA256_PATTERN.fullmatch(expected_hash):
        errors.append("EVIDENCE_SHA256_INVALID")
        return errors
    candidate = root / relative_path
    approval_root = root / "evidence" / "approvals"
    if has_redirected_component(approval_root, root) or has_redirected_component(
        candidate, approval_root
    ):
        errors.append("EVIDENCE_PATH_UNSAFE")
        return errors
    try:
        resolved = candidate.resolve(strict=True)
        resolved_approval_root = approval_root.resolve(strict=True)
    except OSError:
        errors.append("EVIDENCE_MISSING")
        return errors
    if (
        candidate.is_symlink()
        or not resolved.is_relative_to(resolved_approval_root)
        or not resolved.is_file()
    ):
        errors.append("EVIDENCE_PATH_UNSAFE")
    elif not 1 <= resolved.stat().st_size <= MAX_APPROVAL_EVIDENCE_BYTES:
        errors.append("EVIDENCE_SIZE_INVALID")
    elif sha256(resolved) != expected_hash:
        errors.append("EVIDENCE_HASH_MISMATCH")
    return errors


def acceptance_manifest_approval_errors(
    root: Path,
    manifest: dict[str, Any],
    registry: dict[str, Any],
    components: set[str],
) -> list[str]:
    errors = gate_registry_errors(registry)
    required = {"privacy_legal_review"}
    for component in components:
        gate_name = ACCEPTANCE_DATA_GATES.get(component)
        if gate_name is None:
            errors.append(f"ACCEPTANCE_COMPONENT_INVALID:{component}")
        else:
            required.add(gate_name)
    bindings = manifest.get("approval_bindings")
    if not isinstance(bindings, dict):
        return [*errors, "APPROVAL_BINDINGS_INVALID"]
    if set(bindings) != required:
        errors.append("APPROVAL_BINDING_SET_INVALID")
    gates = registry.get("gates") if isinstance(registry.get("gates"), dict) else {}
    for gate_name in sorted(required):
        for error in approval_gate_errors(root, registry, gate_name):
            errors.append(f"APPROVAL_GATE_{error}:{gate_name}")
        gate = gates.get(gate_name, {})
        expected_hash = gate.get("evidence_sha256") if isinstance(gate, dict) else None
        if bindings.get(gate_name) != expected_hash:
            errors.append(f"APPROVAL_BINDING_HASH_MISMATCH:{gate_name}")
    return errors
