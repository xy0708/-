from __future__ import annotations

import base64
import hashlib
import json
import secrets
import socket
import urllib.error
import urllib.request
import wave
from pathlib import Path
from typing import Any

from device_service.websocket import (
    encode_client_frame,
    read_server_frame,
    websocket_accept,
)


MAX_HTTP_RESPONSE_BYTES = 1024 * 1024


def http_json(
    port: int,
    token: str,
    method: str,
    path: str,
    body: dict[str, Any],
) -> tuple[int, dict[str, Any]]:
    if not 1 <= port <= 65535 or not path.startswith("/v1/"):
        raise ValueError("invalid loopback request")
    data = json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8")
    request = urllib.request.Request(
        f"http://127.0.0.1:{port}{path}",
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(request, timeout=15) as response:
            raw = response.read(MAX_HTTP_RESPONSE_BYTES + 1)
            status = response.status
    except urllib.error.HTTPError as exc:
        raw = exc.read(MAX_HTTP_RESPONSE_BYTES + 1)
        status = exc.code
    if len(raw) > MAX_HTTP_RESPONSE_BYTES:
        raise ValueError("device response exceeds limit")
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("device response is not an object")
    return status, value


def run_ocr_case(
    port: int,
    token: str,
    member_id: str,
    case: dict[str, Any],
    input_root: Path,
) -> list[dict[str, Any]]:
    relative = case.get("path")
    if not isinstance(relative, str):
        raise ValueError("OCR case path is missing")
    path = (input_root / relative).resolve(strict=True)
    root = input_root.resolve(strict=True)
    if root not in path.parents or not path.is_file():
        raise ValueError("OCR case escapes input_root")
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != case.get("sha256"):
        raise ValueError("OCR case hash mismatch")
    body = {
        "member_id": member_id,
        "image": {
            "media_type": case.get("media_type"),
            "data_base64": base64.b64encode(data).decode("ascii"),
            "sha256": digest,
        },
    }
    status, created = http_json(port, token, "POST", "/v1/ocr/tasks", body)
    base = {
        "sample_id": case.get("sample_id"),
        "split": "independent_acceptance",
        "real_report": True,
        "should_reject": case.get("should_reject") is True,
    }
    if case.get("should_reject") is True:
        return [{**base, "rejected": status in {413, 415, 422}}]
    if status != 202 or not isinstance(created.get("task_id"), str):
        raise ValueError("OCR task creation failed")
    task_id = created["task_id"]
    try:
        status, fetched = http_json(
            port, token, "GET", f"/v1/tasks/{task_id}", {"member_id": member_id}
        )
        if status != 200:
            raise ValueError("OCR pending result fetch failed")
        result = fetched.get("result", {}).get("result", {})
        fields = result.get("fields") if isinstance(result, dict) else None
        if not isinstance(fields, list):
            raise ValueError("OCR result fields are invalid")
        predicted = {
            str(item.get("field")): str(item.get("value", ""))
            for item in fields
            if isinstance(item, dict) and isinstance(item.get("field"), str)
        }
        ground_truth = case.get("ground_truth")
        if not isinstance(ground_truth, list) or not ground_truth:
            raise ValueError("OCR ground truth is missing")
        return [
            {
                **base,
                "field": item["field"],
                "required": item.get("required") is True,
                "truth": str(item.get("truth", "")),
                "prediction": predicted.get(item["field"], ""),
            }
            for item in ground_truth
            if isinstance(item, dict) and isinstance(item.get("field"), str)
        ]
    finally:
        http_json(port, token, "DELETE", f"/v1/tasks/{task_id}", {"member_id": member_id})


def run_asr_case(
    port: int,
    token: str,
    member_id: str,
    case: dict[str, Any],
    input_root: Path,
) -> dict[str, Any]:
    path = (input_root / str(case.get("path", ""))).resolve(strict=True)
    root = input_root.resolve(strict=True)
    if root not in path.parents or not path.is_file():
        raise ValueError("ASR case escapes input_root")
    if hashlib.sha256(path.read_bytes()).hexdigest() != case.get("sha256"):
        raise ValueError("ASR case hash mismatch")
    with wave.open(str(path), "rb") as audio:
        if (
            audio.getnchannels() != 1
            or audio.getsampwidth() != 2
            or audio.getframerate() != 16000
            or audio.getcomptype() != "NONE"
        ):
            raise ValueError("ASR WAV must be uncompressed 16 kHz mono s16le")
        sock = socket.create_connection(("127.0.0.1", port), timeout=15)
        stream = sock.makefile("rwb", buffering=0)
        task_id = None
        try:
            key = base64.b64encode(secrets.token_bytes(16)).decode("ascii")
            request = (
                "GET /v1/asr/stream HTTP/1.1\r\n"
                f"Host: 127.0.0.1:{port}\r\n"
                "Upgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\n"
                f"Sec-WebSocket-Key: {key}\r\nAuthorization: Bearer {token}\r\n"
                f"X-Edge-Member-Id: {member_id}\r\nOrigin: null\r\n\r\n"
            )
            stream.write(request.encode("ascii"))
            status_line = stream.readline().decode("ascii", errors="strict")
            headers = {}
            while True:
                line = stream.readline()
                if line in {b"\r\n", b""}:
                    break
                key_name, value = line.decode("ascii").split(":", 1)
                headers[key_name.lower()] = value.strip()
            if " 101 " not in status_line or headers.get("sec-websocket-accept") != websocket_accept(key):
                raise ValueError("ASR websocket handshake failed")
            start = json.dumps({"type": "start", "sample_rate_hz": 16000, "channels": 1, "sample_format": "s16le"}).encode("utf-8")
            stream.write(encode_client_frame(0x1, start))
            _, payload = read_server_frame(stream, max_payload_bytes=1024 * 1024)
            if json.loads(payload).get("type") != "started":
                raise ValueError("ASR stream did not start")
            while True:
                chunk = audio.readframes(1600)
                if not chunk:
                    break
                stream.write(encode_client_frame(0x2, chunk))
                _, payload = read_server_frame(stream, max_payload_bytes=1024 * 1024)
                if json.loads(payload).get("type") not in {"partial", "audio_accepted"}:
                    raise ValueError("ASR audio frame failed")
            stream.write(encode_client_frame(0x1, b'{"type":"stop"}'))
            _, payload = read_server_frame(stream, max_payload_bytes=1024 * 1024)
            final = json.loads(payload)
            if final.get("type") != "final_pending_confirmation":
                raise ValueError("ASR final result missing")
            task_id = final.get("task", {}).get("task_id")
            result = final.get("result", {})
            return {
                "sample_id": case.get("sample_id"),
                "split": "independent_acceptance",
                "real_human": True,
                "target_microphone": True,
                "reference": case.get("reference"),
                "prediction": result.get("text"),
                "expected_slots": case.get("expected_slots"),
                "predicted_slots": result.get("fields", {}),
            }
        finally:
            stream.close()
            sock.close()
            if isinstance(task_id, str):
                http_json(port, token, "DELETE", f"/v1/tasks/{task_id}", {"member_id": member_id})
