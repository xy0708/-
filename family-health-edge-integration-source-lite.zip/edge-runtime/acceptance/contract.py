from __future__ import annotations

from typing import Any


REQUIRED_PRODUCT_SCENARIOS = frozenset(
    {
        "offline_operation",
        "power_loss_recovery",
        "disk_full",
        "database_corruption",
        "model_hash_mismatch",
        "microphone_disconnect",
        "child_service_crash",
        "proxy_environment",
        "privacy_log_scan",
        "clean_device_install",
        "signed_offline_upgrade",
        "automatic_rollback",
        "old_version_recovery",
        "offline_three_runtime_application",
        "factory_identity_provisioning",
        "per_device_key_provisioning",
        "signed_ota_update",
        "cross_sku_update_rejection",
        "target_vulnerability_scan",
        "rk3566_hardening",
    }
)


def acceptance_contract_scenario_errors(contract: dict[str, Any]) -> list[str]:
    scenarios = contract.get("required_scenarios")
    if (
        not isinstance(scenarios, list)
        or not scenarios
        or any(not isinstance(name, str) or not name for name in scenarios)
        or len(scenarios) != len(set(scenarios))
    ):
        return ["ACCEPTANCE_REQUIRED_SCENARIOS_INVALID"]
    missing = sorted(REQUIRED_PRODUCT_SCENARIOS - set(scenarios))
    return [f"ACCEPTANCE_REQUIRED_SCENARIO_MISSING:{name}" for name in missing]
