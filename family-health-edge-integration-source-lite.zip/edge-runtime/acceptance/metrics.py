from __future__ import annotations

import math
import re
from typing import Any


MAX_OCR_VALUE_CHARACTERS = 4_096
MAX_ASR_TEXT_CHARACTERS = 4_096
MAX_ASR_ROWS = 10_000
MAX_PERFORMANCE_ROWS = 1_000_000


def normalized_text(value: str) -> str:
    return "".join(character.lower() for character in value if not character.isspace() and character not in "，。！？、,.!?;；:：")


def edit_distance(left: str, right: str) -> int:
    previous = list(range(len(right) + 1))
    for index, left_char in enumerate(left, 1):
        current = [index]
        for column, right_char in enumerate(right, 1):
            current.append(
                min(
                    current[-1] + 1,
                    previous[column] + 1,
                    previous[column - 1] + (left_char != right_char),
                )
            )
        previous = current
    return previous[-1]


def percentile(values: list[float], percentile_value: float) -> float:
    if not values:
        raise ValueError("percentile requires values")
    ordered = sorted(values)
    rank = (len(ordered) - 1) * percentile_value
    lower = math.floor(rank)
    upper = math.ceil(rank)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (rank - lower)


def compute_metrics(
    ocr_rows: list[dict[str, Any]],
    asr_rows: list[dict[str, Any]],
    performance_rows: list[dict[str, Any]],
    soak: dict[str, Any],
    scenarios: dict[str, Any],
) -> dict[str, Any]:
    if not ocr_rows or not asr_rows or not performance_rows:
        raise ValueError("OCR, ASR, and performance evidence must be non-empty")
    if len(asr_rows) > MAX_ASR_ROWS or len(performance_rows) > MAX_PERFORMANCE_ROWS:
        raise ValueError("acceptance evidence exceeds the supported sample limit")
    ocr_valid = [row for row in ocr_rows if row.get("should_reject") is not True]
    rejection = [row for row in ocr_rows if row.get("should_reject") is True]
    if not ocr_valid or not rejection:
        raise ValueError("OCR evidence must include recognized and rejection cases")
    for row in ocr_rows:
        if row.get("split") != "independent_acceptance" or row.get("real_report") is not True:
            raise ValueError("OCR row is not real independent acceptance evidence")
        if any(
            len(str(row.get(field, ""))) > MAX_OCR_VALUE_CHARACTERS
            for field in ("truth", "prediction")
        ):
            raise ValueError("OCR evidence value exceeds the size limit")
    exact = sum(
        normalized_text(str(row.get("truth", "")))
        == normalized_text(str(row.get("prediction", "")))
        for row in ocr_valid
    ) / len(ocr_valid)
    required = [row for row in ocr_valid if row.get("required") is True]
    if not required:
        raise ValueError("OCR evidence contains no required fields")
    required_recalled = sum(bool(normalized_text(str(row.get("prediction", "")))) for row in required) / len(required)
    rejection_accuracy = sum(row.get("rejected") is True for row in rejection) / len(rejection)

    total_edits = 0
    total_reference_chars = 0
    slot_total = 0
    slot_correct = 0
    for row in asr_rows:
        if (
            row.get("split") != "independent_acceptance"
            or row.get("real_human") is not True
            or row.get("target_microphone") is not True
        ):
            raise ValueError("ASR row is not real target-microphone acceptance evidence")
        reference = normalized_text(str(row.get("reference", "")))
        prediction = normalized_text(str(row.get("prediction", "")))
        if not reference:
            raise ValueError("ASR reference must be non-empty")
        if (
            len(reference) > MAX_ASR_TEXT_CHARACTERS
            or len(prediction) > MAX_ASR_TEXT_CHARACTERS
        ):
            raise ValueError("ASR evidence text exceeds the size limit")
        total_edits += edit_distance(reference, prediction)
        total_reference_chars += len(reference)
        expected_slots = row.get("expected_slots")
        predicted_slots = row.get("predicted_slots")
        if not isinstance(expected_slots, dict) or not isinstance(predicted_slots, dict):
            raise ValueError("ASR slots must be objects")
        for key, value in expected_slots.items():
            slot_total += 1
            slot_correct += predicted_slots.get(key) == value
    if slot_total == 0:
        raise ValueError("ASR evidence contains no health slots")

    numeric_fields = ("latency_ms", "peak_memory_mib", "temperature_c")
    for row in performance_rows:
        if row.get("measured_on_real_rk3566") is not True:
            raise ValueError("performance row is not real RK3566 evidence")
        for field in numeric_fields:
            value = row.get(field)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
                raise ValueError(f"invalid performance field: {field}")
        if (
            float(row["latency_ms"]) <= 0
            or float(row["peak_memory_mib"]) <= 0
            or not -40 <= float(row["temperature_c"]) <= 125
        ):
            raise ValueError("performance evidence is outside physical bounds")
    latencies = [float(row["latency_ms"]) for row in performance_rows]
    memory = [float(row["peak_memory_mib"]) for row in performance_rows]
    temperatures = [float(row["temperature_c"]) for row in performance_rows]
    duration = soak.get("duration_hours")
    crashes = soak.get("unrecovered_crashes")
    growth = soak.get("memory_growth_mib")
    if not all(
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
        for value in (duration, crashes, growth)
    ):
        raise ValueError("invalid soak evidence")
    if (
        float(duration) <= 0
        or not isinstance(crashes, int)
        or crashes < 0
        or float(growth) < 0
    ):
        raise ValueError("soak evidence is outside valid bounds")
    if soak.get("measured_on_real_rk3566") is not True:
        raise ValueError("soak evidence is not from real RK3566")
    if not scenarios or any(value != "PASS" for value in scenarios.values()):
        raise ValueError("all supplied fault scenarios must be PASS")
    return {
        "ocr_field_exact_match": round(exact, 8),
        "ocr_required_field_recall": round(required_recalled, 8),
        "ocr_unsupported_input_rejection": round(rejection_accuracy, 8),
        "asr_cer": round(total_edits / total_reference_chars, 8),
        "asr_health_slot_exact_match": round(slot_correct / slot_total, 8),
        "p50_latency_ms": round(percentile(latencies, 0.50), 3),
        "p95_latency_ms": round(percentile(latencies, 0.95), 3),
        "peak_memory_mib": round(max(memory), 3),
        "max_temperature_c": round(max(temperatures), 3),
        "soak_duration_hours": float(duration),
        "unrecovered_crashes": int(crashes),
        "memory_growth_mib": float(growth),
        "scenarios": scenarios,
        "sample_counts": {
            "ocr_fields": len(ocr_valid),
            "ocr_rejection_cases": len(rejection),
            "asr_utterances": len(asr_rows),
            "performance_samples": len(performance_rows),
        },
    }
