from __future__ import annotations

import os
from pathlib import Path


def is_redirected(path: Path) -> bool:
    return path.is_symlink() or (
        hasattr(os.path, "isjunction") and os.path.isjunction(path)
    )


def has_redirected_component(path: Path, boundary: Path) -> bool:
    """Return true when path or an in-boundary parent is a link/junction."""

    candidate = Path(os.path.abspath(path))
    root = Path(os.path.abspath(boundary))
    if candidate != root and root not in candidate.parents:
        return True
    current = candidate
    while True:
        if is_redirected(current):
            return True
        if current == root:
            return False
        current = current.parent
