from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import wave
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from ocr_runtime.input_validation import MAX_OCR_IMAGE_BYTES
from acceptance.paths import has_redirected_component


MAX_CASES = 10_000
MAX_REFERENCE_CHARACTERS = 2_000
MAX_OCR_FIELDS = 128
MAX_ASR_SLOTS = 64
SAMPLE_ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
FIELD_PATTERN = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,63}")
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}")
FORBIDDEN_FORMAL_PATH_TOKENS = ("charls", "nhanes", "synthetic")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def controlled_output_path(project_root: Path, requested: Path) -> Path:
    evidence_root = (project_root / "evidence" / "acceptance").resolve()
    evidence_root.mkdir(parents=True, exist_ok=True)
    if has_redirected_component(
        project_root / "evidence" / "acceptance", project_root
    ):
        raise ValueError("acceptance evidence directory must not be redirected")
    if requested.is_absolute():
        candidate = requested
    else:
        candidate = project_root / requested
    if candidate.exists() or candidate.is_symlink():
        raise ValueError("acceptance output must be a new non-symlink file")
    if has_redirected_component(candidate.parent, project_root):
        raise ValueError("acceptance output path must not be redirected")
    parent = candidate.parent.resolve(strict=True)
    resolved = parent / candidate.name
    if parent != evidence_root and evidence_root not in parent.parents:
        raise ValueError("acceptance output must be inside evidence/acceptance")
    return resolved


def write_jsonl_atomically(output: Path, rows: Iterable[dict[str, Any]]) -> int:
    """Publish a complete evidence file without overwriting existing evidence."""

    pending_path: Path | None = None
    count = 0
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            prefix=".pending-",
            suffix=".jsonl",
            dir=output.parent,
            delete=False,
        ) as stream:
            pending_path = Path(stream.name)
            for row in rows:
                stream.write(json.dumps(row, ensure_ascii=False) + "\n")
                count += 1
            stream.flush()
            os.fsync(stream.fileno())
        os.link(pending_path, output)
        return count
    finally:
        if pending_path is not None:
            pending_path.unlink(missing_ok=True)


def _case_file(input_root: Path, case: dict[str, Any]) -> Path:
    relative = case.get("path")
    expected_hash = case.get("sha256")
    if not isinstance(relative, str) or not relative:
        raise ValueError("case path is missing")
    relative_path = Path(relative)
    lowered = relative.lower()
    if (
        relative_path.is_absolute()
        or ".." in relative_path.parts
        or any(token in lowered for token in FORBIDDEN_FORMAL_PATH_TOKENS)
    ):
        raise ValueError("case path is unsafe or forbidden for formal evidence")
    if not isinstance(expected_hash, str) or not SHA256_PATTERN.fullmatch(expected_hash):
        raise ValueError("case sha256 is invalid")
    root = input_root.resolve(strict=True)
    candidate = input_root / relative_path
    if has_redirected_component(candidate, input_root):
        raise ValueError("case path contains a symlink or junction")
    resolved = candidate.resolve(strict=True)
    if (
        candidate.is_symlink()
        or not resolved.is_file()
        or (resolved.parent != root and root not in resolved.parents)
    ):
        raise ValueError("case path escapes input root or is not a regular file")
    if sha256(resolved) != expected_hash:
        raise ValueError("case sha256 mismatch")
    return resolved


def _validate_common_manifest(manifest: dict[str, Any], component: str) -> list[dict[str, Any]]:
    if manifest.get("schema_version") != "1.0.0":
        raise ValueError("acceptance manifest schema is invalid")
    if manifest.get("component") != component:
        raise ValueError("acceptance manifest component is invalid")
    if (
        manifest.get("rights_cleared") is not True
        or manifest.get("synthetic") is not False
        or manifest.get("independent_split") is not True
        or manifest.get("direct_identifiers_removed") is not True
    ):
        raise ValueError("manifest is not eligible for formal acceptance")
    cases = manifest.get("cases")
    if not isinstance(cases, list) or not 1 <= len(cases) <= MAX_CASES:
        raise ValueError("acceptance cases are empty or exceed the limit")
    if not all(isinstance(case, dict) for case in cases):
        raise ValueError("acceptance case must be an object")
    sample_ids = [case.get("sample_id") for case in cases]
    if any(
        not isinstance(sample_id, str)
        or not SAMPLE_ID_PATTERN.fullmatch(sample_id)
        for sample_id in sample_ids
    ):
        raise ValueError("sample_id is invalid")
    if len(set(sample_ids)) != len(sample_ids):
        raise ValueError("sample_id must be unique")
    return cases


def _validate_ocr_case(case: dict[str, Any], path: Path) -> None:
    should_reject = case.get("should_reject")
    if not isinstance(should_reject, bool):
        raise ValueError("OCR should_reject must be boolean")
    if case.get("media_type") not in {"image/png", "image/jpeg"}:
        raise ValueError("OCR media_type is invalid")
    if not 1 <= path.stat().st_size <= MAX_OCR_IMAGE_BYTES:
        raise ValueError("OCR file size is invalid")
    if should_reject:
        return
    ground_truth = case.get("ground_truth")
    if not isinstance(ground_truth, list) or not 1 <= len(ground_truth) <= MAX_OCR_FIELDS:
        raise ValueError("OCR ground truth is empty or exceeds the limit")
    fields: list[str] = []
    for item in ground_truth:
        if not isinstance(item, dict):
            raise ValueError("OCR ground truth item must be an object")
        field = item.get("field")
        truth = item.get("truth")
        if not isinstance(field, str) or not FIELD_PATTERN.fullmatch(field):
            raise ValueError("OCR ground truth field is invalid")
        if not isinstance(truth, str) or not truth or len(truth) > 512:
            raise ValueError("OCR ground truth value is invalid")
        if not isinstance(item.get("required"), bool):
            raise ValueError("OCR ground truth required flag is invalid")
        fields.append(field)
    if len(set(fields)) != len(fields):
        raise ValueError("OCR ground truth fields must be unique per case")


def _validate_asr_case(case: dict[str, Any], path: Path) -> None:
    reference = case.get("reference")
    slots = case.get("expected_slots")
    if (
        not isinstance(reference, str)
        or not reference.strip()
        or len(reference) > MAX_REFERENCE_CHARACTERS
    ):
        raise ValueError("ASR reference is invalid")
    if not isinstance(slots, dict) or not 1 <= len(slots) <= MAX_ASR_SLOTS:
        raise ValueError("ASR expected_slots is empty or exceeds the limit")
    if any(
        not isinstance(name, str)
        or not FIELD_PATTERN.fullmatch(name)
        or isinstance(value, (dict, list))
        for name, value in slots.items()
    ):
        raise ValueError("ASR expected_slots contains an invalid value")
    try:
        with wave.open(str(path), "rb") as audio:
            duration = audio.getnframes() / audio.getframerate()
            valid = (
                audio.getnchannels() == 1
                and audio.getsampwidth() == 2
                and audio.getframerate() == 16_000
                and audio.getcomptype() == "NONE"
                and 0 < duration <= 120
            )
    except (wave.Error, EOFError, ZeroDivisionError) as exc:
        raise ValueError("ASR WAV is invalid") from exc
    if not valid:
        raise ValueError("ASR WAV must be uncompressed 16 kHz mono s16le and at most 120 seconds")


def validate_acceptance_cases(
    manifest: dict[str, Any], component: str, input_root: Path
) -> list[dict[str, Any]]:
    cases = _validate_common_manifest(manifest, component)
    accepted = 0
    rejected = 0
    for case in cases:
        path = _case_file(input_root, case)
        if component == "ocr":
            _validate_ocr_case(case, path)
            if case["should_reject"]:
                rejected += 1
            else:
                accepted += 1
        elif component == "asr":
            _validate_asr_case(case, path)
        else:
            raise ValueError("unsupported acceptance component")
    if component == "ocr" and (accepted == 0 or rejected == 0):
        raise ValueError("OCR acceptance requires recognized and rejection cases")
    return cases
