# RK3566 官方模型生产化重构 Loop

> **Android 迁移说明（2026-10-10）**：本文件中的模型来源、转换和同集比较证据
> 继续保留；Linux systemd/worker/ARM64 容器运行方式已被活动 Android Loop 替代。
> 任何候选都必须重新完成 Android AAR/JNI/NDK 集成与 RK3566 Android 真机验收。

更新日期：2026-09-16  
适用范围：体检报告 OCR、语音转文字、端侧设备服务及 RK3566 发布链  
目标：把 Rockchip 官方 RKNN Model Zoo 候选、现有 CPU 模型和真实产品验收纳入同一条可审计、可回退、失败关闭的生产链。

## 当前工程决策（2026-09-22）

- R03 工程比较已完成到合成同集：修正公平预处理后，PP-OCRv5 CPU 在 66 个字段上完整精确匹配 66/66，PP-OCRv4 RKNN PC 仿真为 28/66、必填字段召回 53/66。合成集不构成产品指标，但足以将官方 OCR 候选从当前活动选型路径延后。
- R04 研究比较已完成到 MED-CH 60 条同集：X-ASR CPU CER 7.9161%/实体召回 9/36，Zipformer RKNN PC 仿真 CER 16.2613%/实体召回 1/36。数据商业权利和目标麦克风验收缺失，因此无产品赢家；官方 ASR 候选从当前活动选型路径延后。
- 两个官方候选的 ONNX/RKNN 二进制均已迁至同级 `官方模型对比实验` 研究归档，未进入活动产品树或发布输入。归档 12 个文件、650,339,242 字节，12/12 锁定记录校验通过。
- 当前工程路由仅保留 X-ASR/Sherpa CPU；OCR 产品后端仍为空。后续只有授权真实同集或真 RK3566 证据推翻当前观察并通过具名门禁，官方候选才允许重新进入活动选型。
- 迁移与候选隔离决策必须由每轮完整总控重新绑定当前输入哈希；通过状态只能是 `PASS_ENGINEERING_PRODUCT_BLOCKED`，且不得创建 release。

## 0. 为什么需要重构

旧路线只围绕现有 PP-OCRv5 Paddle CPU 和 X-ASR/Sherpa-ONNX CPU 资产推进，遗漏了 Rockchip 官方为 RK3566 提供的 RKNN 候选：

- PPOCR-Det：PP-OCRv4，FP16/INT8；
- PPOCR-Rec：PP-OCRv4，FP16；
- ASR：wav2vec2、Whisper、Zipformer，FP16。

官方来源：

- `https://github.com/airockchip/rknn_model_zoo`
- `https://github.com/airockchip/rknn-toolkit2`

“官方支持 RK3566”只证明存在参考模型、转换脚本和运行示例，不证明适合本产品，不证明许可证、中文健康场景精度、实时性、稳定性或量产条件已经通过。本 Loop 不覆盖旧证据、不删除现有模型，也不把官方示例冒充产品模型。

## 1. 重构目标

1. OCR 建立两条可比较后端：
   - A：Rockchip 官方 PP-OCRv4 Det/Rec RKNN；
   - B：现有 PP-OCRv5 Paddle CPU，后续仅在转换可行时增加 PP-OCRv5 RKNN 候选。
2. ASR 建立两条可比较后端：
   - A：Rockchip 官方 Zipformer RKNN，优先核对中文、流式和实时能力；
   - B：现有 X-ASR INT8 + Sherpa-ONNX CPU；
   - Whisper RKNN 仅作备选；wav2vec2 在语言与产品口令适配未证明前不得成为默认候选。
3. 设备服务只依赖稳定组件合同，不依赖开发目录、统一 Demo 或具体推理框架。
4. 使用同一批冻结输入比较准确性、延迟、内存、温度和稳定性；禁止跨数据集挑最好看的指标。
5. 只有通过真实 RK3566、真实独立数据、许可和具名批准的候选才可进入正式发布。

## 2. 永久规则

1. 保留现有 PP-OCRv5、X-ASR、ARM64 模拟证据和失败记录，直到替代后端完成正式验收及回滚演练。
2. 官方 Model Zoo 的 `main` 分支不能直接进入构建；必须固定 commit、文件 URL、字节数、SHA-256、许可证和下载时间。
3. RKNN Toolkit2、RKNPU Runtime、NPU 驱动和系统镜像必须形成兼容矩阵；只改其中一项必须重跑转换、对齐和真机验收。
4. `.onnx`、`.rknn`、字典、预处理和后处理必须作为同一个不可拆分模型包绑定 hash。
5. 不下载来源不明的二次打包模型，不使用未经登记的网盘权重，不伪造 `.rknn`、许可或真机结果。
6. 合成报告、模型自带音频和开发样例只用于 smoke，不得计算产品准确率。
7. OCR 真实报告按敏感个人信息处理；ASR 原始 PCM 默认只在内存流转；确认前禁止入库。
8. 普通 Accuracy 不作为主要产品指标。类别不平衡时必须同时报告 PR-AUC、敏感度、特异度、精确率及错误类型；OCR/ASR 使用各自任务指标。
9. 产品 Test 和独立验证集禁止用于模型选择、阈值选择、量化校准、词典调优或规则修改。
10. NPU 不是强制目标。若官方 RKNN 候选在真实任务上劣于已冻结 CPU 后端，允许选择 CPU 后端，但仍须满足真机资源门槛。

## 3. 新架构

后续在 `端侧上线/` 内建立，不直接改写上游模型仓库：

```text
vendor/rockchip/
├─ model_zoo.lock.json
├─ toolkit_runtime_matrix.json
└─ THIRD_PARTY_NOTICES.md
model_registry/
├─ ocr_candidates.json
├─ asr_candidates.json
└─ schemas/
runtime_backends/
├─ common/
├─ paddle_cpu/
├─ sherpa_cpu/
└─ rknn/
conversion/
├─ ocr/
└─ asr/
benchmarks/
├─ host_reference/
├─ rk3566/
└─ comparison/
```

统一组件合同至少包含：

- `component_name`、`component_version`、`backend`；
- `model_id`、模型包 SHA-256、运行库版本；
- `capabilities`、输入/输出 schema；
- `product_accepted`、`hardware_validated`、`license_approved`；
- 启动握手、超时、取消、健康状态和固定错误码。

设备服务根据冻结的产品配置选择后端，禁止静默回退。发生回退时必须返回安全状态码并写入不含健康内容的运维事件。

## 4. 状态定义

- `NOT_STARTED`：尚未执行。
- `IN_PROGRESS`：正在执行，已有可恢复状态。
- `PASS_ENGINEERING`：工程复现或软件门通过，不代表产品可用。
- `PASS_PRODUCT_GATE`：真实设备、真实数据、冻结阈值和批准均通过。
- `FAIL`：真实执行未达到预先冻结门槛。
- `BLOCKED_EXTERNAL`：缺硬件、授权数据、许可证或具名批准。

任何阶段不得用 `PASS_ENGINEERING` 替代 `PASS_PRODUCT_GATE`。

## 5. Gate 顺序

### R00：事实纠正与证据保护

- 保存旧总 Loop、S1/S2/S3、模型 manifest、hash 和失败证据。
- 将“没有官方候选”纠正为“官方候选存在但尚未导入、冻结和验收”。
- 不删除 PP-OCRv5 或 X-ASR，不改写历史 Run。

完成条件：旧证据仍可独立验证，文档不存在“官方候选不存在”的错误表述。

### R01：官方来源冻结

- 固定 `rknn_model_zoo` 与 `rknn-toolkit2` commit。
- 登记 PP-OCRv4 Det/Rec、Zipformer、Whisper 的上游来源、模型文件、许可证、大小和 SHA-256。
- 保存完整许可证和第三方 NOTICE；形成工程许可审计，法务结论仍单独阻断。
- 验证下载可复现，下载后删除压缩包和无关示例。

完成条件：`model_zoo.lock.json` 可离线复验全部候选；任一 hash 漂移会失败。

### R02：RK3566 工具链冻结

- 固定 Ubuntu/容器镜像、Python、RKNN Toolkit2、RKNN Runtime、RKNPU 驱动和目标平台 `rk3566`。
- 建立宿主转换环境和板端 RKNNLite2 环境，不在全局 Python 安装依赖。
- 编写兼容矩阵和最小官方样例 smoke；模拟器结果单独标记，不冒充真机。

完成条件：转换环境可重建，工具链 hash 完整；真机缺失时保持 `BLOCKED_EXTERNAL`。

### R03：OCR 官方 RKNN 基线

1. 复现官方 PP-OCRv4 Det 和 Rec 转换。
2. 保留原 ONNX、RKNN、字典、预处理、后处理和转换日志。
3. 在相同非产品工程图片上对齐官方 ONNX、RKNN 模拟器和当前 PP-OCRv5 CPU 输出。
4. 禁止用合成报告的 100%字段命中率作为产品结论。
5. 若 PP-OCRv4 明显退化，记录失败，不为使用 NPU 而强行入选；随后评估 PP-OCRv5 转换兼容性。

完成条件：工程对齐报告可复现；产品状态仍取决于真实报告与真机。

### R04：ASR 官方 RKNN 基线

1. 优先复现官方 Zipformer；先验证中文、流式/非流式、采样率、词表和分段行为，不根据模型名称推断。
2. 使用同一公开工程音频比较官方 Zipformer RKNN 与现有 X-ASR CPU。
3. Whisper 仅在 Zipformer不满足准确性或能力要求时进入比较；wav2vec2 只有语言能力被证明后才能进入。
4. 报告 CER、数字/单位/健康槽位精确率、空结果率、首字/最终延迟和内存。
5. 不把当前 MED-CH CER 或模型自带样例当目标麦克风产品结果。

完成条件：至少一条官方 RKNN ASR 路线完成工程复现；产品状态仍由真人独立集和真机决定。

### R05：可插拔运行时

- 实现 OCR/ASR 后端接口与机器可读 manifest。
- 所有后端运行在隔离进程，执行 hash、版本、能力和配置握手。
- 保留超时、取消、并发限制、熔断、资源回收和确认前不落库语义。
- 测试 CPU/RKNN 切换、错误配置、模型篡改、运行库不匹配和后端崩溃。

完成条件：设备服务无需修改业务 API 即可显式切换已登记后端，且不会静默降级。

### R06：同集比较与选型

冻结一份工程比较合同：

- 相同输入、相同预处理边界、相同后处理口径；
- OCR 比较字段 exact match、必填字段召回、拒识、字符错误和版面失败；
- ASR 比较 CER、数字/单位/成员/日期槽位 exact match、空结果和失败率；
- 同时报告 P50/P95 延迟、峰值 RSS、CPU/NPU 使用和模型大小；
- 比较集不得用于正式产品宣传。

完成条件：形成可复算的候选排序；没有满足条件的候选时允许结论为 `FAIL`，禁止硬选。

### R07：真实产品数据门禁

OCR 数据必须按人员、报告来源、机构/模板和采集设备隔离：

- Development Train；
- Development Validation；
- 封存 Development Test；
- 独立机构、独立时间或独立设备验收集。

ASR 数据必须按说话人隔离，并覆盖目标麦克风、老人、口音、噪声和语速；同一说话人的切片不得跨 Train/Validation/Test。官方预训练模型若不微调，也必须保留独立产品 Test 和现场验收集。

没有真实授权数据时只执行工程 Gate，不得生成产品指标。

### R08：真 RK3566 验收

- 导入不可伪造的板卡预检：SoC、aarch64、系统镜像、RKNPU 驱动、RKNN Runtime、内存、声卡、温度和设备 ID。
- 在板上运行 OCR/ASR 两个候选和 CPU 回退路径。
- 测量冷启动、热启动、P50/P95、峰值内存、温度、连续运行、断电恢复和错误回收。
- 所有阈值必须在测试前由产品负责人冻结；本 Loop 不预填虚假门槛。

完成条件：真实报告含原始命令、时间、设备指纹、输入/输出 hash 和批准；模拟结果不能通过本 Gate。

### R09：三模块产品集成

- OCR/ASR 只输出待确认结果；健康 V1 继续使用非诊断规则和趋势，不接收未确认字段。
- 设备服务、模型、运行库、配置、字典、许可、SBOM 和 systemd 形成自包含 ARM64 候选包。
- 统一 Demo 仅作展示客户端，不进入运行依赖、不作为产品 Gate。
- 统一 Demo 必须直接读取冻结实验报告并显示报告哈希；不得把单次模型分数、OCR 置信度或运行成功率称为正确率。
- 真实数据、合成数据和缺失数据必须分栏标记。没有真实 OCR/ASR/健康产品验收时，页面必须显示阻断项，不得用合成 100% 或单条样例替代。
- 完成成员隔离、加密存储、删除撤回、日志脱敏、离线启动和无研发电脑运行。

### R10：发布、升级与回滚

- 只有 R01-R09 所有必需产品 Gate 通过，才允许构建 release candidate。
- 使用公司签名服务签名；设备只信任工厂注入公钥。
- 执行正常升级、中断升级、断电、健康检查失败、模型损坏、数据库迁移失败和回滚测试。
- 正式 release 不包含训练数据、测试数据、开发环境、缓存、绝对路径或统一 Demo。

### R11：最终产品验收

必须同时满足：

- OCR、ASR 选定后端的真实数据和真机指标达到测试前冻结门槛；
- 许可、隐私、产品分类、阈值和文案获得具名批准；
- 健康模块仍为非诊断提示；
- 完整三模块、安装、启动、升级、回滚和数据生命周期通过；
- 所有证据 hash 与候选包一致。

否则状态只能是 `PASS_ENGINEERING_PRODUCT_BLOCKED`、`BLOCKED_EXTERNAL` 或 `FAIL`。

## 6. 每轮执行方法

1. 读取本文件、`EDGE_PRODUCTION_LOOP.md`、`LOOP_STATE.md`、`PROGRESS.md` 和 `BLOCKERS.md`。
2. 检查真实文件、进程、硬件、模型、报告和 Git 状态，不从旧总结假设完成。
3. 选择第一个未完成且当前可独立推进的 Gate。
4. 每轮只完成一个可回滚的主要改动；保存失败证据。
5. 运行定向测试、完整端侧测试及对应上游回归。
6. 为代码、模型、工具链、输入和输出记录 SHA-256。
7. 更新状态、进度、阻断项和精确恢复命令。
8. 外部条件缺失时继续其他工程 Gate；没有可推进项时明确停止，不制造通过状态。

## 7. 当前状态

| Gate | 状态 | 当前事实 |
|---|---|---|
| R00 | PASS_ENGINEERING | 已确认官方 RK3566 OCR/ASR 候选存在；旧证据保留 |
| R01 | PASS_ENGINEERING | 已固定 5 个仓库 commit，7 个 ONNX 与运行辅助文件均完成大小/SHA-256 锁定；许可法务仍阻断产品分发 |
| R02 | PASS_ENGINEERING / PRODUCT_BLOCKED | Toolkit2/Lite2/Runtime/Server 2.3.2、Ubuntu digest 及 126 项离线依赖已冻结并可断网重建；5/5 转换成功，但 3/5 产物不逐字节复现且 PC 模拟器不能执行导出制品，必须在真机关闭 |
| R03 | PASS_ENGINEERING / PRODUCT_BLOCKED | PP-OCRv4 Det/Rec 工程 RKNN、完整 worker、单图对齐和 6 张/66 字段合成同集比较均已完成；结果明显弱于当前 CPU，但合成集不能产生产品赢家。授权真实报告和真机仍缺失 |
| R04 | PASS_ENGINEERING / PRODUCT_BLOCKED | Zipformer 三组件工程 RKNN、单条功能仿真和 MED-CH 60 条研究同集比较均已完成；当前质量弱于 X-ASR CPU。研究数据权利、目标麦克风真人集及真机仍缺失；A3 按条件候选暂缓 |
| R05 | PASS_ENGINEERING / PRODUCT_BLOCKED | 严格注册表、显式选型、哈希/版本/能力握手、ASR ARM64 S3 和 OCR 工程 worker 均已完成；被阻断后端禁止静默回退。产品后端保持 0，等待 R07/R08 |
| R06 | PASS_ENGINEERING / PRODUCT_BLOCKED | OCR 合成同集和 ASR 研究同集比较均可复算并独立校验；公开数据审计完成，但没有找到可替代授权真实报告、目标麦克风真人集和真机资源测量的公开数据，因此不产生产品赢家 |
| R07 | BLOCKED_EXTERNAL | 缺授权真实报告及目标麦克风真人独立数据 |
| R08 | BLOCKED_EXTERNAL | 缺可核验真 RK3566 设备环境 |
| R09 | BLOCKED_EXTERNAL | 设备服务及工程集成已完成到 S3 部分通过；完整三产品模型集成依赖 R07 授权数据、产品后端批准和 R08 真机，不以测试替身冒充完成 |
| R10 | BLOCKED_EXTERNAL | 缺签名、OTA、工厂密钥及上游产品 Gate |
| R11 | BLOCKED_EXTERNAL | 上游 Gate 未全部通过 |

## 8. 当前下一步

R06 已有同一 MED-CH 60 条研究工程集比较，但不得用它完成产品选型。下一步取得商业可分发的目标麦克风独立集，冻结统一切分、阈值、优先级与 tie-breaker，并在真 RK3566 上比较质量、延迟、内存、温度和功耗；同时在真机比较固定制品与重放制品输出以调查 3 个非确定性产物——Toolkit2 PC 模拟器已实测无法执行导出的 `.rknn`，不能用 ONNX 重建仿真替代——并在板卡 SKU 确定后导入签名系统镜像、内核和 RKNPU 驱动证据。当前没有产品赢家、真机通过或正式 release。
